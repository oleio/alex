/*     */ package com.yunsichuangzhi.lucene;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.StringReader;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.cli.CommandLine;
/*     */ import org.apache.commons.cli.CommandLineParser;
/*     */ import org.apache.commons.cli.DefaultParser;
/*     */ import org.apache.commons.cli.Options;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.document.Document;
/*     */ import org.apache.lucene.index.DirectoryReader;
/*     */ import org.apache.lucene.index.IndexReader;
/*     */ import org.apache.lucene.index.IndexableField;
/*     */ import org.apache.lucene.index.MultiReader;
/*     */ import org.apache.lucene.index.Term;
/*     */ import org.apache.lucene.search.BooleanClause.Occur;
/*     */ import org.apache.lucene.search.BooleanQuery;
/*     */ import org.apache.lucene.search.IndexSearcher;
/*     */ import org.apache.lucene.search.ScoreDoc;
/*     */ import org.apache.lucene.search.TermQuery;
/*     */ import org.apache.lucene.search.TopDocs;
/*     */ import org.apache.lucene.store.Directory;
/*     */ import org.apache.lucene.store.FSDirectory;
/*     */ 
/*     */ public class LuceneQuery
/*     */ {
/*  41 */   static IndexReader indexReader = null;
/*  42 */   static IndexSearcher storeSearcher = null;
/*     */   static int skipSize;
/*  45 */   final Analyzer searcherAnalyzer = Util.getChineseAnalyzer();
/*  46 */   final int MAX_NUM_RESULTS = 100;
/*     */ 
/*  83 */   private static final FileFilter dirFilter = new FileFilter() {
/*  84 */     public boolean accept(File path) { return path.isDirectory(); }
/*     */ 
/*  83 */   };
/*     */ 
/*     */   public LuceneQuery(String storePath, int skip)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  53 */       indexReader = getReader(getIndexSetForDirs(storePath));
/*  54 */       storeSearcher = new IndexSearcher(indexReader);
/*  55 */       skipSize = skip;
/*     */     } catch (IOException e) {
/*  57 */       System.err.println(e.getMessage());
/*  58 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Set<File> getIndexSetForDirs(String dir)
/*     */     throws IOException
/*     */   {
/*  68 */     Set set = new HashSet();
/*  69 */     File root = new File(dir);
/*  70 */     Directory ld = FSDirectory.open(root);
/*     */     try {
/*  72 */       if (DirectoryReader.indexExists(ld)) { set.add(root);
/*     */       } else {
/*  74 */         File[] subdirs = root.listFiles(dirFilter);
/*  75 */         if (subdirs != null) for (File f2 : subdirs) set.add(f2);  
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*  78 */       ld.close();
/*     */     }
/*  80 */     return set;
/*     */   }
/*     */ 
/*     */   public static IndexReader getReader(File index)
/*     */     throws IOException
/*     */   {
/*  88 */     FSDirectory dir = FSDirectory.open(index);
/*  89 */     return DirectoryReader.open(dir);
/*     */   }
/*     */ 
/*     */   public static IndexReader getReader(Set<File> indices)
/*     */     throws IOException
/*     */   {
/*  96 */     if (indices.size() == 1) return getReader((File)indices.iterator().next());
/*  97 */     IndexReader[] indexReaders = new IndexReader[indices.size()];
/*  98 */     int i = 0;
/*     */     File index;
/*  99 */     for (Iterator localIterator = indices.iterator(); localIterator.hasNext(); indexReaders[(i++)] = getReader(index)) index = (File)localIterator.next();
/* 100 */     return new MultiReader(indexReaders, false);
/*     */   }
/*     */ 
/*     */   protected List<List<String>> searchTokens(Set<String> tokens, String field, List<List<String>> keyWordGroups, int num, List<String> returnFields) throws IOException {
/* 104 */     if (((keyWordGroups == null) || (keyWordGroups.isEmpty())) && (tokens.isEmpty()))
/* 105 */       return null;
/* 106 */     BooleanQuery booleanQuery = buildMultTermQuery(tokens, field, keyWordGroups, num);
/* 107 */     TopDocs hits = storeSearcher.search(booleanQuery, num);
/* 108 */     List rs = new ArrayList();
/* 109 */     for (ScoreDoc d : hits.scoreDocs) {
/* 110 */       rs.add(getBreakDown(d.doc, returnFields));
/*     */     }
/* 112 */     return rs;
/*     */   }
/*     */ 
/*     */   protected BooleanQuery buildMultTermQuery(Set<String> tokens, String field, List<List<String>> keyWordGroups, int num) throws IOException {
/* 116 */     BooleanQuery booleanQuery = new BooleanQuery();
/*     */     TermQuery tq;
/* 117 */     if ((keyWordGroups != null) && (!keyWordGroups.isEmpty()))
/*     */     {
/* 132 */       for (int i = 0; i < keyWordGroups.size(); i++) {
/* 133 */         tq = buildTermQuery((String)((List)keyWordGroups.get(i)).get(0), field);
/* 134 */         booleanQuery.add(tq, BooleanClause.Occur.SHOULD);
/*     */       }
/*     */     }
/* 137 */     if (!tokens.isEmpty()) {
/* 138 */       for (String token : tokens) {
/* 139 */         TermQuery tq = buildTermQuery(token, field);
/* 140 */         booleanQuery.add(tq, BooleanClause.Occur.SHOULD);
/*     */       }
/*     */     }
/* 143 */     return booleanQuery;
/*     */   }
/*     */ 
/*     */   protected TermQuery buildTermQuery(String token, String field) throws IOException {
/* 147 */     TokenStream ts = this.searcherAnalyzer.tokenStream(field, new StringReader(token));
/* 148 */     ts.reset();
/* 149 */     CharTermAttribute cta = (CharTermAttribute)ts.addAttribute(CharTermAttribute.class);
/* 150 */     ts.incrementToken();
/* 151 */     Term term = new Term(field, cta.toString());
/* 152 */     ts.end();
/* 153 */     ts.close();
/* 154 */     TermQuery tq = new TermQuery(term, 2);
/* 155 */     return tq;
/*     */   }
/*     */ 
/*     */   protected BooleanQuery buildMultFieldsQuery(List<String> values, List<String> fields) throws IOException {
/* 159 */     BooleanQuery booleanQuery = new BooleanQuery();
/* 160 */     for (int j = 0; j < values.size(); j++) {
/* 161 */       BooleanQuery orQuery = new BooleanQuery();
/* 162 */       for (int i = 0; i < fields.size(); i++) {
/* 163 */         if (BreakDownDoc.types.get(fields.get(i)) == BreakDownDoc.FIELD_TYPE.TEXT) {
/* 164 */           Set words = new HashSet(Util.getUnigramsFromString(Util.tokenEnglish((String)values.get(j))));
/* 165 */           BooleanQuery q = buildMultTermQuery(words, (String)fields.get(i), null, 100);
/* 166 */           orQuery.add(q, BooleanClause.Occur.SHOULD);
/*     */         } else {
/* 168 */           TermQuery q = buildValueQuery((String)values.get(j), (String)fields.get(i));
/* 169 */           orQuery.add(q, BooleanClause.Occur.SHOULD);
/*     */         }
/*     */       }
/* 172 */       booleanQuery.add(orQuery, BooleanClause.Occur.MUST);
/*     */     }
/* 174 */     return booleanQuery;
/*     */   }
/*     */ 
/*     */   protected List<String> getBreakDown(int docId, List<String> returnfields) {
/* 178 */     Document d = null;
/*     */     try {
/* 180 */       d = indexReader.document(docId);
/*     */     } catch (IOException e) {
/* 182 */       e.printStackTrace();
/*     */     }
/* 184 */     List retVals = new ArrayList();
/* 185 */     if (d != null) {
/* 186 */       for (String f : returnfields)
/* 187 */         if (d.getField(f) != null)
/*     */         {
/* 189 */           String v = d.getField(f).stringValue();
/* 190 */           if (BreakDownDoc.types.get(f) == BreakDownDoc.FIELD_TYPE.TEXT)
/* 191 */             retVals.add(Util.recoverDigit(v));
/* 192 */           else if (BreakDownDoc.types.get(f) == BreakDownDoc.FIELD_TYPE.DATE)
/*     */             try {
/* 194 */               Date date = new Date(Long.parseLong(v));
/* 195 */               SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm");
/* 196 */               retVals.add(dateFormat.format(date));
/*     */             } catch (Exception e) {
/* 198 */               retVals.add(v);
/*     */             }
/*     */           else
/* 201 */             retVals.add(v);
/*     */         }
/*     */     }
/* 204 */     return retVals;
/*     */   }
/*     */ 
/*     */   public TermQuery buildValueQuery(String v, String field) {
/* 208 */     Term term = new Term(field, v);
/* 209 */     TermQuery vq = new TermQuery(term, 2);
/* 210 */     return vq;
/*     */   }
/*     */ 
/*     */   public List<List<String>> searchOnText(String q, String field, List<String> returnFields)
/*     */   {
/* 215 */     List rs = null;
/*     */     try {
/* 217 */       Set words = new HashSet(Util.getUnigramsFromString(q));
/*     */ 
/* 219 */       List keyWordGroups = new ArrayList();
/* 220 */       for (List keywords : keyWordGroups) {
/* 221 */         words.remove(keywords.get(0));
/*     */       }
/* 223 */       rs = searchTokens(words, field, keyWordGroups, 100, returnFields);
/*     */     }
/*     */     catch (IOException e) {
/* 226 */       e.printStackTrace();
/*     */     }
/* 228 */     if ((rs != null) && (rs.size() > 0)) {
/* 229 */       return rs;
/*     */     }
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */   public List<Integer> getAllDocs(List<String> returnfields) throws IOException {
/* 235 */     List rs = new ArrayList();
/* 236 */     for (int i = 0; i < indexReader.maxDoc(); i++) {
/* 237 */       rs.add(Integer.valueOf(i));
/*     */     }
/* 239 */     return rs;
/*     */   }
/*     */ 
/*     */   public List<Integer> search(List<String> values, List<String> fields, int num, List<String> returnfields) throws IOException {
/* 243 */     BooleanQuery booleanQuery = buildMultFieldsQuery(values, fields);
/* 244 */     TopDocs hits = storeSearcher.search(booleanQuery, num);
/* 245 */     List rs = new ArrayList();
/*     */ 
/* 247 */     for (ScoreDoc d : hits.scoreDocs) {
/* 248 */       rs.add(Integer.valueOf(d.doc));
/*     */     }
/* 250 */     return rs;
/*     */   }
/*     */ 
/*     */   public static boolean checkFields(List<String> fields) {
/* 254 */     for (String f : fields) {
/* 255 */       if (!BreakDownDoc.fields.contains(f)) {
/* 256 */         System.err.println("Unrecognized field " + f);
/* 257 */         System.err.println("All known fields are " + BreakDownDoc.fields.toString());
/* 258 */         return false;
/*     */       }
/*     */     }
/* 261 */     return true;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws IOException, org.apache.lucene.queryparser.classic.ParseException, org.apache.commons.cli.ParseException {
/* 265 */     Options options = new Options();
/* 266 */     options.addOption("fields", true, "specifiy the list of fields to search");
/* 267 */     options.addOption("values", true, "specifiy the list of values to search");
/* 268 */     options.addOption("return", true, "specifiy the field to return, default is fileName");
/* 269 */     options.addOption("max", true, "specifiy the max number of records to return, default is 10");
/* 270 */     CommandLineParser parser = new DefaultParser();
/* 271 */     CommandLine cmd = parser.parse(options, args);
/* 272 */     List returnFields = Arrays.asList(new String[] { "fileName" });
/* 273 */     if (cmd.hasOption("return")) {
/* 274 */       returnFields = Arrays.asList(cmd.getOptionValue("return").split(","));
/* 275 */       if (!checkFields(returnFields))
/* 276 */         return;
/*     */     }
/* 278 */     int maxReturn = 10;
/* 279 */     if (cmd.hasOption("max")) {
/* 280 */       maxReturn = Integer.parseInt(cmd.getOptionValue("max"));
/*     */     }
/* 282 */     LuceneQuery exe = new LuceneQuery("resources/index/", maxReturn);
/* 283 */     List rs = null;
/* 284 */     List fields = null;
/* 285 */     List values = null;
/* 286 */     if (cmd.hasOption("values")) {
/* 287 */       if (cmd.hasOption("feilds")) {
/* 288 */         String fieldsStr = cmd.getOptionValue("fields");
/* 289 */         fields = Arrays.asList(fieldsStr.split(","));
/*     */       } else {
/* 291 */         fields = BreakDownDoc.fields;
/*     */       }
/* 293 */       String valuesStr = cmd.getOptionValue("values");
/* 294 */       values = Arrays.asList(valuesStr.split(","));
/* 295 */       if (!checkFields(fields))
/* 296 */         return;
/* 297 */       rs = exe.search(values, fields, maxReturn, returnFields);
/*     */     } else {
/* 299 */       rs = exe.getAllDocs(returnFields);
/*     */     }
/*     */     List ss;
/* 300 */     if (fields != BreakDownDoc.fields) {
/* 301 */       for (String f : returnFields)
/* 302 */         System.out.print(f + "\t");
/* 303 */       System.out.println();
/* 304 */       for (Integer r : rs) {
/* 305 */         ss = exe.getBreakDown(r.intValue(), returnFields);
/* 306 */         int count = 0;
/* 307 */         for (String v : ss) {
/* 308 */           System.out.print(v + "\t");
/*     */         }
/* 310 */         System.out.println();
/*     */       }
/*     */     } else {
/* 313 */       List returnFieldIndex = new ArrayList();
/* 314 */       for (String f : returnFields) {
/* 315 */         int pos = fields.indexOf(f);
/* 316 */         if (pos >= 0)
/* 317 */           returnFieldIndex.add(Integer.valueOf(pos));
/*     */       }
/* 319 */       Collections.sort(returnFieldIndex);
/* 320 */       for (Integer f : returnFieldIndex)
/* 321 */         System.out.print((String)fields.get(f.intValue()) + "\t");
/* 322 */       if (fields == BreakDownDoc.fields)
/* 323 */         System.out.print("Summary\t");
/* 324 */       System.out.println();
/* 325 */       for (Integer r : rs) {
/* 326 */         List ss = exe.getBreakDown(r.intValue(), fields);
/* 327 */         String summary = "";
/* 328 */         for (int i = 0; i < ss.size(); i++) {
/* 329 */           if (returnFieldIndex.contains(Integer.valueOf(i)))
/* 330 */             System.out.print((String)ss.get(i) + "\t");
/* 331 */           for (String v : values)
/* 332 */             if (((String)ss.get(i)).contains(v))
/* 333 */               summary = summary + ((String)ss.get(i)).replace(v, new StringBuilder("##").append(v).append("##").toString()) + " ... ";
/*     */         }
/* 335 */         System.out.print(summary + "\t");
/* 336 */         System.out.println();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     com.yunsichuangzhi.lucene.LuceneQuery
 * JD-Core Version:    0.6.2
 */