/*     */ package com.yunsichuangzhi.lucene;
/*     */ 
/*     */ import java.io.FileReader;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONObject;
/*     */ import org.json.simple.parser.JSONParser;
/*     */ 
/*     */ public class BreakDownDoc
/*     */ {
/*     */   public static List<String> fields;
/*     */   public static List<FIELD_TYPE> fieldTypes;
/*  31 */   public Map<String, String> values = new HashMap();
/*     */   public static Map<String, FIELD_TYPE> types;
/*     */ 
/*     */   static
/*     */   {
/*  22 */     fields = new ArrayList(Arrays.asList(new String[] { 
/*  23 */       "fileName", "savedJsonName", "title", "codeNo", "downtimeDate", "equipName", 
/*  24 */       "breakdownTime", "areaLocation", "maintainTeam", "lostTime", "lostProductNum", "plantName", "originator", "rootCause", 
/*  25 */       "person_TL", "person_ENG", "person_GL", "person_Manager", "faultDesc" }));
/*  26 */     fieldTypes = new ArrayList(Arrays.asList(
/*  27 */       new FIELD_TYPE[] { FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.TEXT, FIELD_TYPE.VALUE, FIELD_TYPE.DATE, FIELD_TYPE.VALUE, 
/*  28 */       FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.TEXT, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.TEXT, 
/*  29 */       FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.TEXT }));
/*     */ 
/*  32 */     types = new HashMap();
/*     */ 
/*  34 */     assert (fields.size() == fieldTypes.size());
/*  35 */     for (int i = 1; i <= 7; i++) {
/*  36 */       fields.add("troubleShooting_" + i + "_" + "descr");
/*  37 */       fieldTypes.add(FIELD_TYPE.TEXT);
/*  38 */       fields.add("troubleShooting_" + i + "_" + "lostMin");
/*  39 */       fieldTypes.add(FIELD_TYPE.VALUE);
/*  40 */       fields.add("troubleShooting_" + i + "_" + "success");
/*  41 */       fieldTypes.add(FIELD_TYPE.VALUE);
/*     */     }
/*  43 */     for (int i = 1; i <= 2; i++) {
/*  44 */       String prefix = i == 1 ? "shortTerm_" : "longTerm_";
/*  45 */       for (int j = 1; j <= 4; j++) {
/*  46 */         fields.add(prefix + j + "_" + "counterMeasure");
/*  47 */         fieldTypes.add(FIELD_TYPE.TEXT);
/*  48 */         fields.add(prefix + j + "_" + "resp");
/*  49 */         fieldTypes.add(FIELD_TYPE.TEXT);
/*  50 */         fields.add(prefix + j + "_" + "supp");
/*  51 */         fieldTypes.add(FIELD_TYPE.TEXT);
/*  52 */         fields.add(prefix + j + "_" + "compDate");
/*  53 */         fieldTypes.add(FIELD_TYPE.TEXT);
/*  54 */         fields.add(prefix + j + "_" + "status");
/*  55 */         fieldTypes.add(FIELD_TYPE.TEXT);
/*     */       }
/*     */     }
/*  58 */     for (int i = 1; i <= 5; i++) {
/*  59 */       fields.add("why_" + i);
/*  60 */       fieldTypes.add(FIELD_TYPE.TEXT);
/*     */     }
/*  62 */     for (int i = 0; i < fields.size(); i++)
/*  63 */       types.put((String)fields.get(i), (FIELD_TYPE)fieldTypes.get(i));
/*     */   }
/*     */ 
/*     */   public BreakDownDoc()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BreakDownDoc(String file) {
/*  71 */     loadFromJson(file);
/*     */   }
/*     */ 
/*     */   private String cleanString(String v) {
/*  75 */     return v.replaceAll(":", "").replace("\n", "").trim();
/*     */   }
/*     */ 
/*     */   public void loadFromJson(String file) {
/*  79 */     JSONParser parser = new JSONParser();
/*     */     try {
/*  81 */       Object obj = parser.parse(new FileReader(file));
/*  82 */       JSONObject root = (JSONObject)obj;
/*     */ 
/*  84 */       this.values.put("fileName", (String)root.get("fileName"));
/*  85 */       this.values.put("savedJsonName", (String)root.get("savedJsonName"));
/*  86 */       this.values.put("title", (String)root.get("title"));
/*  87 */       this.values.put("codeNo", (String)root.get("codeNo"));
/*  88 */       this.values.put("downtimeDate", getDate(root.get("downtimeDate")));
/*  89 */       this.values.put("equipName", ((String)root.get("equipName")).replace("设备名称:", "").trim());
/*  90 */       this.values.put("breakdownTime", Long.valueOf(getNumber(cleanString((String)root.get("breakdownTime")).replace("停机时间：", ""))).toString());
/*  91 */       this.values.put("areaLocation", cleanString((String)root.get("areaLocation")).replace("停机区域/点", ""));
/*  92 */       this.values.put("maintainTeam", cleanString((String)root.get("maintainTeam")).replace("维修班组", ""));
/*  93 */       this.values.put("lostTime", Long.valueOf(getNumber(cleanString((String)root.get("lostTime")).replace("NONE", "0"))).toString());
/*  94 */       this.values.put("lostProductNum", Long.valueOf(getNumber(cleanString((String)root.get("lostProductNum")).replace("NONE", "0"))).toString());
/*  95 */       this.values.put("plantName", cleanString((String)root.get("plantName")).replace("厂区：", "").replace("Plant", ""));
/*  96 */       this.values.put("originator", Util.extractUnicode(cleanString((String)root.get("originator")).replace("填表人/日期", "").replace("Oringinator", "")));
/*  97 */       this.values.put("rootCause", cleanString((String)root.get("rootCause")).replace("根本原因 /Root Cause: ", ""));
/*  98 */       this.values.put("person_TL", cleanString((String)root.get("person_TL")).replace("班组长/TL", "").replace("签名及日期 /Signature & Date", ""));
/*  99 */       this.values.put("person_ENG", cleanString((String)root.get("person_ENG")).replace("工程师/ENG.", ""));
/* 100 */       this.values.put("person_GL", cleanString((String)root.get("person_GL")).replace("班组长/TL", "").replace("工段长/ GL", ""));
/* 101 */       this.values.put("person_Manager", cleanString((String)root.get("person_Manager")).replace("工程师/ENG.", "").replace("技术经理/Tech.Manager", "").replace(".", ""));
/*     */ 
/* 103 */       JSONArray troubleShooting = (JSONArray)root.get("troubleShooting");
/* 104 */       Iterator troubleShootingIter = troubleShooting.iterator();
/* 105 */       while (troubleShootingIter.hasNext()) {
/* 106 */         JSONArray troubleArray = (JSONArray)troubleShootingIter.next();
/* 107 */         JSONObject trouble = (JSONObject)troubleArray.iterator().next();
/* 108 */         long step = getNumber(trouble.get("step"));
/* 109 */         String prefix = "troubleShooting_" + step + "_";
/* 110 */         String descr = (String)trouble.get("descr");
/* 111 */         this.values.put(prefix + "descr", descr);
/* 112 */         long lostMin = getNumber(trouble.get("lostMin"));
/* 113 */         this.values.put(prefix + "lostMin", Long.valueOf(lostMin).toString());
/* 114 */         boolean success = getBoolean(trouble.get("success"));
/* 115 */         this.values.put(prefix + "success", success ? "true" : "false");
/*     */       }
/*     */ 
/* 118 */       JSONArray faultDescription = (JSONArray)root.get("faultDescription");
/* 119 */       Iterator faultDescriptionIter = faultDescription.iterator();
/* 120 */       String faultDesc = "";
/* 121 */       while (faultDescriptionIter.hasNext()) {
/* 122 */         JSONArray falutArray = (JSONArray)faultDescriptionIter.next();
/* 123 */         faultDesc = faultDesc + (String)falutArray.iterator().next();
/*     */       }
/* 125 */       this.values.put("faultDesc", cleanString(faultDesc));
/*     */ 
/* 127 */       JSONArray fiveWhy = (JSONArray)root.get("fiveWhy");
/* 128 */       Iterator fiveWhyIter = fiveWhy.iterator();
/* 129 */       int countWhy = 0;
/* 130 */       while (fiveWhyIter.hasNext()) {
/* 131 */         JSONArray whyArray = (JSONArray)fiveWhyIter.next();
/* 132 */         String why = (String)whyArray.iterator().next();
/* 133 */         countWhy++;
/* 134 */         this.values.put("why_" + countWhy, cleanString(why));
/*     */       }
/*     */ 
/* 137 */       loadShortOrLongTerm((JSONArray)root.get("shortTerm"), true);
/* 138 */       loadShortOrLongTerm((JSONArray)root.get("longTerm"), false);
/*     */ 
/* 140 */       JSONArray correctPath = (JSONArray)root.get("correctPath");
/* 141 */       Iterator correctPathIter = correctPath.iterator();
/* 142 */       while (correctPathIter.hasNext()) {
/* 143 */         JSONArray correctArray = (JSONArray)correctPathIter.next();
/* 144 */         JSONObject correct = (JSONObject)correctArray.iterator().next();
/* 145 */         long step = getNumber(correct.get("step"));
/* 146 */         String descr = (String)correct.get("descr");
/* 147 */         String prefix = "correctPath_" + step + "_";
/* 148 */         this.values.put(prefix + "descr", cleanString(descr));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 152 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String getDate(Object v) throws ParseException {
/* 157 */     String strV = ((String)v).trim();
/* 158 */     Pattern p1 = Pattern.compile(".*(20[0-9]{2})[^0-9]+([0-9]{1,2})[^0-9]+([0-9]{1,2})[^0-9]+([0-9]{1,2})[^0-9]+([0-9]{1,2}).*");
/* 159 */     Pattern p2 = Pattern.compile(".*(20[0-9]{2})[^0-9]+([0-9]{1,2})[^0-9]+([0-9]{1,2})[^0-9]+([0-9]+).*");
/* 160 */     Pattern p3 = Pattern.compile(".*(20[0-9]{2})[^0-9]+([0-9]{1,2})[^0-9]+([0-9]{1,2}).*");
/* 161 */     Matcher m = p1.matcher(strV);
/* 162 */     String year = "0"; String month = "0"; String day = "0"; String hour = "0"; String minute = "0";
/* 163 */     boolean found = m.find();
/* 164 */     if (!found) {
/* 165 */       m = p2.matcher(strV);
/* 166 */       if (!(found = m.find())) {
/* 167 */         m = p3.matcher(strV);
/* 168 */         found = m.find();
/*     */       } else {
/* 170 */         hour = m.group(4);
/*     */       }
/*     */     } else {
/* 173 */       hour = m.group(4);
/* 174 */       minute = m.group(5);
/*     */     }
/* 176 */     if (found) {
/* 177 */       year = m.group(1);
/* 178 */       month = m.group(2);
/* 179 */       day = m.group(3);
/* 180 */       String timeString = year + "-" + month + "-" + day + "-" + hour + ":" + minute;
/* 181 */       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH:mm");
/* 182 */       Date date = sdf.parse(timeString);
/* 183 */       return Long.valueOf(date.getTime()).toString();
/*     */     }
/*     */ 
/* 187 */     return strV;
/*     */   }
/*     */ 
/*     */   protected boolean getBoolean(Object v) {
/* 191 */     if ((v instanceof Long)) {
/* 192 */       return ((Long)v).longValue() == 0L;
/*     */     }
/* 194 */     String strV = ((String)v).trim();
/* 195 */     if ((strV.isEmpty()) || (strV.equals("O")))
/* 196 */       return true;
/* 197 */     if (strV.equals("X"))
/* 198 */       return false;
/* 199 */     return true;
/*     */   }
/*     */ 
/*     */   protected String getString(Object v) {
/* 203 */     if ((v instanceof Long)) {
/* 204 */       return ((Long)v).toString();
/*     */     }
/* 206 */     return (String)v;
/*     */   }
/*     */ 
/*     */   protected long getNumber(Object v) {
/* 210 */     if ((v instanceof Long)) {
/* 211 */       long step = ((Long)v).longValue();
/* 212 */       return step;
/*     */     }
/* 214 */     String strV = ((String)v).trim();
/* 215 */     if ((!strV.isEmpty()) && (strV.charAt(0) == '"') && (strV.charAt(strV.length() - 1) == '"'))
/* 216 */       strV = strV.substring(1, strV.length() - 1).trim();
/* 217 */     if ((strV.length() > 3) && (strV.endsWith("min")))
/* 218 */       strV = strV.substring(0, strV.length() - 3).trim();
/* 219 */     if ((strV.length() > 2) && (strV.startsWith("累计")))
/* 220 */       strV = strV.substring(2);
/* 221 */     if ((strV.isEmpty()) || (strV.equals("O")))
/* 222 */       return 0L;
/*     */     try
/*     */     {
/* 225 */       return Integer.parseInt(strV); } catch (NumberFormatException e) {
/*     */     }
/* 227 */     return 0L;
/*     */   }
/*     */ 
/*     */   protected void loadShortOrLongTerm(JSONArray term, boolean shortTerm)
/*     */   {
/* 233 */     Iterator termIter = term.iterator();
/* 234 */     int count = 0;
/* 235 */     String prefix = shortTerm ? "shortTerm_" : "longTerm_";
/* 236 */     while (termIter.hasNext()) {
/* 237 */       JSONArray termArray = (JSONArray)termIter.next();
/* 238 */       JSONObject shortT = (JSONObject)termArray.iterator().next();
/* 239 */       count++;
/* 240 */       this.values.put(prefix + count + "_" + "counterMeasure", cleanString((String)shortT.get("counterMeasure")));
/* 241 */       this.values.put(prefix + count + "_" + "resp", cleanString((String)shortT.get("resp")));
/* 242 */       this.values.put(prefix + count + "_" + "supp", cleanString((String)shortT.get("supp")));
/* 243 */       this.values.put(prefix + count + "_" + "compDate", cleanString(Long.valueOf(getNumber(shortT.get("compDate"))).toString()));
/* 244 */       this.values.put(prefix + count + "_" + "status", cleanString((String)shortT.get("status")));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 249 */     BreakDownDoc test = new BreakDownDoc("/Users/yangyu/Documents/my/doc/self/com/sparesData/jsonv2/2011ESI20.json");
/*     */   }
/*     */ 
/*     */   public static enum FIELD_TYPE
/*     */   {
/*  21 */     TEXT, VALUE, DATE;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     com.yunsichuangzhi.lucene.BreakDownDoc
 * JD-Core Version:    0.6.2
 */