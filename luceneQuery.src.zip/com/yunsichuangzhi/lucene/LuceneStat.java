/*     */ package com.yunsichuangzhi.lucene;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.index.DirectoryReader;
/*     */ import org.apache.lucene.index.Fields;
/*     */ import org.apache.lucene.index.IndexReader;
/*     */ import org.apache.lucene.index.MultiFields;
/*     */ import org.apache.lucene.index.MultiReader;
/*     */ import org.apache.lucene.index.Terms;
/*     */ import org.apache.lucene.index.TermsEnum;
/*     */ import org.apache.lucene.search.IndexSearcher;
/*     */ import org.apache.lucene.store.Directory;
/*     */ import org.apache.lucene.store.FSDirectory;
/*     */ import org.apache.lucene.util.BytesRef;
/*     */ 
/*     */ public class LuceneStat
/*     */ {
/*  23 */   static IndexReader indexReader = null;
/*  24 */   static IndexSearcher storeSearcher = null;
/*     */   static String FIELD_DOC;
/*     */   static int skipSize;
/*  27 */   final Analyzer searcherAnalyzer = Util.getChineseAnalyzer();
/*  28 */   final int MAX_NUM_RESULTS = 100;
/*     */ 
/*  66 */   private static final FileFilter dirFilter = new FileFilter() {
/*  67 */     public boolean accept(File path) { return path.isDirectory(); }
/*     */ 
/*  66 */   };
/*     */ 
/*     */   public LuceneStat(String storePath, String fieldDoc, int skip)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  35 */       indexReader = getReader(getIndexSetForDirs(storePath));
/*  36 */       storeSearcher = new IndexSearcher(indexReader);
/*  37 */       FIELD_DOC = fieldDoc;
/*  38 */       skipSize = skip;
/*     */     } catch (IOException e) {
/*  40 */       System.err.println(e.getMessage());
/*  41 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Set<File> getIndexSetForDirs(String dir)
/*     */     throws IOException
/*     */   {
/*  51 */     Set set = new HashSet();
/*  52 */     File root = new File(dir);
/*  53 */     Directory ld = FSDirectory.open(root);
/*     */     try {
/*  55 */       if (DirectoryReader.indexExists(ld)) { set.add(root);
/*     */       } else {
/*  57 */         File[] subdirs = root.listFiles(dirFilter);
/*  58 */         if (subdirs != null) for (File f2 : subdirs) set.add(f2);  
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*  61 */       ld.close();
/*     */     }
/*  63 */     return set;
/*     */   }
/*     */ 
/*     */   public static IndexReader getReader(File index)
/*     */     throws IOException
/*     */   {
/*  71 */     FSDirectory dir = FSDirectory.open(index);
/*  72 */     return DirectoryReader.open(dir);
/*     */   }
/*     */ 
/*     */   public static IndexReader getReader(Set<File> indices)
/*     */     throws IOException
/*     */   {
/*  79 */     if (indices.size() == 1) return getReader((File)indices.iterator().next());
/*  80 */     IndexReader[] indexReaders = new IndexReader[indices.size()];
/*  81 */     int i = 0;
/*     */     File index;
/*  82 */     for (Iterator localIterator = indices.iterator(); localIterator.hasNext(); indexReaders[(i++)] = getReader(index)) index = (File)localIterator.next();
/*  83 */     return new MultiReader(indexReaders, false);
/*     */   }
/*     */ 
/*     */   public void getTermFreq(String field) throws IOException {
/*  87 */     Fields fields = MultiFields.getFields(indexReader);
/*  88 */     for (String f : fields)
/*  89 */       if (f.equals(field))
/*     */       {
/*  91 */         Terms terms = fields.terms(f);
/*  92 */         long tt = terms.getSumDocFreq();
/*  93 */         System.out.println(tt);
/*  94 */         TermsEnum termsEnum = terms.iterator(null);
/*  95 */         int count = 0;
/*  96 */         BytesRef b = termsEnum.next();
/*  97 */         while (b != null)
/*     */         {
/* 100 */           System.out.println(b.utf8ToString() + ", " + termsEnum.totalTermFreq());
/* 101 */           count++;
/* 102 */           b = termsEnum.next();
/*     */         }
/* 104 */         System.out.println(count);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws IOException {
/* 109 */     LuceneStat test = new LuceneStat("resources/index/", "fileName", 2);
/* 110 */     test.getTermFreq("faultDesc");
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     com.yunsichuangzhi.lucene.LuceneStat
 * JD-Core Version:    0.6.2
 */