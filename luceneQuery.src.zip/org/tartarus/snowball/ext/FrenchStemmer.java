/*      */ package org.tartarus.snowball.ext;
/*      */ 
/*      */ import org.tartarus.snowball.Among;
/*      */ import org.tartarus.snowball.SnowballProgram;
/*      */ 
/*      */ public class FrenchStemmer extends SnowballProgram
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   17 */   private static final FrenchStemmer methodObject = new FrenchStemmer();
/*      */ 
/*   19 */   private static final Among[] a_0 = { new Among("col", -1, -1, "", methodObject), new Among("par", -1, -1, "", methodObject), new Among("tap", -1, -1, "", methodObject) };
/*      */ 
/*   25 */   private static final Among[] a_1 = { new Among("", -1, 4, "", methodObject), new Among("I", 0, 1, "", methodObject), new Among("U", 0, 2, "", methodObject), new Among("Y", 0, 3, "", methodObject) };
/*      */ 
/*   32 */   private static final Among[] a_2 = { new Among("iqU", -1, 3, "", methodObject), new Among("abl", -1, 3, "", methodObject), new Among("Ièr", -1, 4, "", methodObject), new Among("ièr", -1, 4, "", methodObject), new Among("eus", -1, 2, "", methodObject), new Among("iv", -1, 1, "", methodObject) };
/*      */ 
/*   41 */   private static final Among[] a_3 = { new Among("ic", -1, 2, "", methodObject), new Among("abil", -1, 1, "", methodObject), new Among("iv", -1, 3, "", methodObject) };
/*      */ 
/*   47 */   private static final Among[] a_4 = { new Among("iqUe", -1, 1, "", methodObject), new Among("atrice", -1, 2, "", methodObject), new Among("ance", -1, 1, "", methodObject), new Among("ence", -1, 5, "", methodObject), new Among("logie", -1, 3, "", methodObject), new Among("able", -1, 1, "", methodObject), new Among("isme", -1, 1, "", methodObject), new Among("euse", -1, 11, "", methodObject), new Among("iste", -1, 1, "", methodObject), new Among("ive", -1, 8, "", methodObject), new Among("if", -1, 8, "", methodObject), new Among("usion", -1, 4, "", methodObject), new Among("ation", -1, 2, "", methodObject), new Among("ution", -1, 4, "", methodObject), new Among("ateur", -1, 2, "", methodObject), new Among("iqUes", -1, 1, "", methodObject), new Among("atrices", -1, 2, "", methodObject), new Among("ances", -1, 1, "", methodObject), new Among("ences", -1, 5, "", methodObject), new Among("logies", -1, 3, "", methodObject), new Among("ables", -1, 1, "", methodObject), new Among("ismes", -1, 1, "", methodObject), new Among("euses", -1, 11, "", methodObject), new Among("istes", -1, 1, "", methodObject), new Among("ives", -1, 8, "", methodObject), new Among("ifs", -1, 8, "", methodObject), new Among("usions", -1, 4, "", methodObject), new Among("ations", -1, 2, "", methodObject), new Among("utions", -1, 4, "", methodObject), new Among("ateurs", -1, 2, "", methodObject), new Among("ments", -1, 15, "", methodObject), new Among("ements", 30, 6, "", methodObject), new Among("issements", 31, 12, "", methodObject), new Among("ités", -1, 7, "", methodObject), new Among("ment", -1, 15, "", methodObject), new Among("ement", 34, 6, "", methodObject), new Among("issement", 35, 12, "", methodObject), new Among("amment", 34, 13, "", methodObject), new Among("emment", 34, 14, "", methodObject), new Among("aux", -1, 10, "", methodObject), new Among("eaux", 39, 9, "", methodObject), new Among("eux", -1, 1, "", methodObject), new Among("ité", -1, 7, "", methodObject) };
/*      */ 
/*   93 */   private static final Among[] a_5 = { new Among("ira", -1, 1, "", methodObject), new Among("ie", -1, 1, "", methodObject), new Among("isse", -1, 1, "", methodObject), new Among("issante", -1, 1, "", methodObject), new Among("i", -1, 1, "", methodObject), new Among("irai", 4, 1, "", methodObject), new Among("ir", -1, 1, "", methodObject), new Among("iras", -1, 1, "", methodObject), new Among("ies", -1, 1, "", methodObject), new Among("îmes", -1, 1, "", methodObject), new Among("isses", -1, 1, "", methodObject), new Among("issantes", -1, 1, "", methodObject), new Among("îtes", -1, 1, "", methodObject), new Among("is", -1, 1, "", methodObject), new Among("irais", 13, 1, "", methodObject), new Among("issais", 13, 1, "", methodObject), new Among("irions", -1, 1, "", methodObject), new Among("issions", -1, 1, "", methodObject), new Among("irons", -1, 1, "", methodObject), new Among("issons", -1, 1, "", methodObject), new Among("issants", -1, 1, "", methodObject), new Among("it", -1, 1, "", methodObject), new Among("irait", 21, 1, "", methodObject), new Among("issait", 21, 1, "", methodObject), new Among("issant", -1, 1, "", methodObject), new Among("iraIent", -1, 1, "", methodObject), new Among("issaIent", -1, 1, "", methodObject), new Among("irent", -1, 1, "", methodObject), new Among("issent", -1, 1, "", methodObject), new Among("iront", -1, 1, "", methodObject), new Among("ît", -1, 1, "", methodObject), new Among("iriez", -1, 1, "", methodObject), new Among("issiez", -1, 1, "", methodObject), new Among("irez", -1, 1, "", methodObject), new Among("issez", -1, 1, "", methodObject) };
/*      */ 
/*  131 */   private static final Among[] a_6 = { new Among("a", -1, 3, "", methodObject), new Among("era", 0, 2, "", methodObject), new Among("asse", -1, 3, "", methodObject), new Among("ante", -1, 3, "", methodObject), new Among("ée", -1, 2, "", methodObject), new Among("ai", -1, 3, "", methodObject), new Among("erai", 5, 2, "", methodObject), new Among("er", -1, 2, "", methodObject), new Among("as", -1, 3, "", methodObject), new Among("eras", 8, 2, "", methodObject), new Among("âmes", -1, 3, "", methodObject), new Among("asses", -1, 3, "", methodObject), new Among("antes", -1, 3, "", methodObject), new Among("âtes", -1, 3, "", methodObject), new Among("ées", -1, 2, "", methodObject), new Among("ais", -1, 3, "", methodObject), new Among("erais", 15, 2, "", methodObject), new Among("ions", -1, 1, "", methodObject), new Among("erions", 17, 2, "", methodObject), new Among("assions", 17, 3, "", methodObject), new Among("erons", -1, 2, "", methodObject), new Among("ants", -1, 3, "", methodObject), new Among("és", -1, 2, "", methodObject), new Among("ait", -1, 3, "", methodObject), new Among("erait", 23, 2, "", methodObject), new Among("ant", -1, 3, "", methodObject), new Among("aIent", -1, 3, "", methodObject), new Among("eraIent", 26, 2, "", methodObject), new Among("èrent", -1, 2, "", methodObject), new Among("assent", -1, 3, "", methodObject), new Among("eront", -1, 2, "", methodObject), new Among("ât", -1, 3, "", methodObject), new Among("ez", -1, 2, "", methodObject), new Among("iez", 32, 2, "", methodObject), new Among("eriez", 33, 2, "", methodObject), new Among("assiez", 33, 3, "", methodObject), new Among("erez", 32, 2, "", methodObject), new Among("é", -1, 2, "", methodObject) };
/*      */ 
/*  172 */   private static final Among[] a_7 = { new Among("e", -1, 3, "", methodObject), new Among("Ière", 0, 2, "", methodObject), new Among("ière", 0, 2, "", methodObject), new Among("ion", -1, 1, "", methodObject), new Among("Ier", -1, 2, "", methodObject), new Among("ier", -1, 2, "", methodObject), new Among("ë", -1, 4, "", methodObject) };
/*      */ 
/*  182 */   private static final Among[] a_8 = { new Among("ell", -1, -1, "", methodObject), new Among("eill", -1, -1, "", methodObject), new Among("enn", -1, -1, "", methodObject), new Among("onn", -1, -1, "", methodObject), new Among("ett", -1, -1, "", methodObject) };
/*      */ 
/*  190 */   private static final char[] g_v = { '\021', 'A', '\020', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '', '', 'g', '\b', '\005' };
/*      */ 
/*  192 */   private static final char[] g_keep_with_s = { '\001', 'A', '\024', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '' };
/*      */   private int I_p2;
/*      */   private int I_p1;
/*      */   private int I_pV;
/*      */ 
/*      */   private void copy_from(FrenchStemmer other)
/*      */   {
/*  199 */     this.I_p2 = other.I_p2;
/*  200 */     this.I_p1 = other.I_p1;
/*  201 */     this.I_pV = other.I_pV;
/*  202 */     super.copy_from(other);
/*      */   }
/*      */ 
/*      */   private boolean r_prelude()
/*      */   {
/*  213 */     int v_1 = this.cursor;
/*      */     while (true)
/*      */     {
/*  218 */       int v_2 = this.cursor;
/*      */ 
/*  223 */       int v_3 = this.cursor;
/*      */ 
/*  226 */       if (in_grouping(g_v, 97, 251))
/*      */       {
/*  231 */         this.bra = this.cursor;
/*      */ 
/*  234 */         int v_4 = this.cursor;
/*      */ 
/*  238 */         if (eq_s(1, "u"))
/*      */         {
/*  243 */           this.ket = this.cursor;
/*  244 */           if (in_grouping(g_v, 97, 251))
/*      */           {
/*  249 */             slice_from("U");
/*  250 */             break label299;
/*      */           }
/*      */         }
/*  252 */         this.cursor = v_4;
/*      */ 
/*  256 */         if (eq_s(1, "i"))
/*      */         {
/*  261 */           this.ket = this.cursor;
/*  262 */           if (in_grouping(g_v, 97, 251))
/*      */           {
/*  267 */             slice_from("I");
/*  268 */             break label299;
/*      */           }
/*      */         }
/*  270 */         this.cursor = v_4;
/*      */ 
/*  273 */         if (eq_s(1, "y"))
/*      */         {
/*  278 */           this.ket = this.cursor;
/*      */ 
/*  280 */           slice_from("Y");
/*      */ 
/*  282 */           break label299;
/*      */         }
/*      */       }
/*  284 */       this.cursor = v_3;
/*      */ 
/*  288 */       this.bra = this.cursor;
/*      */ 
/*  290 */       if (eq_s(1, "y"))
/*      */       {
/*  295 */         this.ket = this.cursor;
/*  296 */         if (in_grouping(g_v, 97, 251))
/*      */         {
/*  301 */           slice_from("Y");
/*  302 */           break label299;
/*      */         }
/*      */       }
/*  304 */       this.cursor = v_3;
/*      */ 
/*  307 */       if (eq_s(1, "q"))
/*      */       {
/*  312 */         this.bra = this.cursor;
/*      */ 
/*  314 */         if (eq_s(1, "u"))
/*      */         {
/*  319 */           this.ket = this.cursor;
/*      */ 
/*  321 */           slice_from("U");
/*      */ 
/*  323 */           label299: this.cursor = v_2;
/*  324 */           break;
/*      */         }
/*      */       }
/*  326 */       this.cursor = v_2;
/*  327 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label339;
/*      */       }
/*  331 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  335 */     label339: this.cursor = v_1;
/*      */ 
/*  338 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_regions()
/*      */   {
/*  346 */     this.I_pV = this.limit;
/*  347 */     this.I_p1 = this.limit;
/*  348 */     this.I_p2 = this.limit;
/*      */ 
/*  350 */     int v_1 = this.cursor;
/*      */ 
/*  355 */     int v_2 = this.cursor;
/*      */ 
/*  358 */     if (in_grouping(g_v, 97, 251))
/*      */     {
/*  362 */       if (in_grouping(g_v, 97, 251))
/*      */       {
/*  367 */         if (this.cursor < this.limit)
/*      */         {
/*  371 */           this.cursor += 1;
/*  372 */           break label184;
/*      */         }
/*      */       }
/*      */     }
/*  374 */     this.cursor = v_2;
/*      */ 
/*  377 */     if (find_among(a_0, 3) == 0)
/*      */     {
/*  383 */       this.cursor = v_2;
/*      */ 
/*  386 */       if (this.cursor < this.limit)
/*      */       {
/*  390 */         this.cursor += 1;
/*      */ 
/*  395 */         while (!in_grouping(g_v, 97, 251))
/*      */         {
/*  401 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break label192;
/*      */           }
/*  405 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */     } else {
/*  409 */       label184: this.I_pV = this.cursor;
/*      */     }
/*  411 */     label192: this.cursor = v_1;
/*      */ 
/*  413 */     int v_4 = this.cursor;
/*      */ 
/*  420 */     while (!in_grouping(g_v, 97, 251))
/*      */     {
/*  426 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label386;
/*      */       }
/*  430 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  436 */     while (!out_grouping(g_v, 97, 251))
/*      */     {
/*  442 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label386;
/*      */       }
/*  446 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  449 */     this.I_p1 = this.cursor;
/*      */ 
/*  454 */     while (!in_grouping(g_v, 97, 251))
/*      */     {
/*  460 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label386;
/*      */       }
/*  464 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  470 */     while (!out_grouping(g_v, 97, 251))
/*      */     {
/*  476 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label386;
/*      */       }
/*  480 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  483 */     this.I_p2 = this.cursor;
/*      */ 
/*  485 */     label386: this.cursor = v_4;
/*  486 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_postlude()
/*      */   {
/*      */     int v_1;
/*      */     while (true)
/*      */     {
/*  495 */       v_1 = this.cursor;
/*      */ 
/*  499 */       this.bra = this.cursor;
/*      */ 
/*  501 */       int among_var = find_among(a_1, 4);
/*  502 */       if (among_var == 0)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  507 */       this.ket = this.cursor;
/*  508 */       switch (among_var) {
/*      */       case 0:
/*  510 */         break;
/*      */       case 1:
/*  514 */         slice_from("i");
/*  515 */         break;
/*      */       case 2:
/*  519 */         slice_from("u");
/*  520 */         break;
/*      */       case 3:
/*  524 */         slice_from("y");
/*  525 */         break;
/*      */       case 4:
/*  529 */         if (this.cursor >= this.limit)
/*      */         {
/*      */           break label129;
/*      */         }
/*  533 */         this.cursor += 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  538 */     label129: this.cursor = v_1;
/*      */ 
/*  541 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_RV() {
/*  545 */     if (this.I_pV > this.cursor)
/*      */     {
/*  547 */       return false;
/*      */     }
/*  549 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R1() {
/*  553 */     if (this.I_p1 > this.cursor)
/*      */     {
/*  555 */       return false;
/*      */     }
/*  557 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R2() {
/*  561 */     if (this.I_p2 > this.cursor)
/*      */     {
/*  563 */       return false;
/*      */     }
/*  565 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_standard_suffix()
/*      */   {
/*  583 */     this.ket = this.cursor;
/*      */ 
/*  585 */     int among_var = find_among_b(a_4, 43);
/*  586 */     if (among_var == 0)
/*      */     {
/*  588 */       return false;
/*      */     }
/*      */ 
/*  591 */     this.bra = this.cursor;
/*  592 */     switch (among_var) {
/*      */     case 0:
/*  594 */       return false;
/*      */     case 1:
/*  598 */       if (!r_R2())
/*      */       {
/*  600 */         return false;
/*      */       }
/*      */ 
/*  603 */       slice_del();
/*  604 */       break;
/*      */     case 2:
/*  608 */       if (!r_R2())
/*      */       {
/*  610 */         return false;
/*      */       }
/*      */ 
/*  613 */       slice_del();
/*      */ 
/*  615 */       int v_1 = this.limit - this.cursor;
/*      */ 
/*  619 */       this.ket = this.cursor;
/*      */ 
/*  621 */       if (!eq_s_b(2, "ic"))
/*      */       {
/*  623 */         this.cursor = (this.limit - v_1);
/*      */       }
/*      */       else
/*      */       {
/*  627 */         this.bra = this.cursor;
/*      */ 
/*  630 */         int v_2 = this.limit - this.cursor;
/*      */ 
/*  634 */         if (r_R2())
/*      */         {
/*  639 */           slice_del();
/*      */         }
/*      */         else {
/*  642 */           this.cursor = (this.limit - v_2);
/*      */ 
/*  644 */           slice_from("iqU");
/*      */         }
/*      */       }
/*  647 */       break;
/*      */     case 3:
/*  651 */       if (!r_R2())
/*      */       {
/*  653 */         return false;
/*      */       }
/*      */ 
/*  656 */       slice_from("log");
/*  657 */       break;
/*      */     case 4:
/*  661 */       if (!r_R2())
/*      */       {
/*  663 */         return false;
/*      */       }
/*      */ 
/*  666 */       slice_from("u");
/*  667 */       break;
/*      */     case 5:
/*  671 */       if (!r_R2())
/*      */       {
/*  673 */         return false;
/*      */       }
/*      */ 
/*  676 */       slice_from("ent");
/*  677 */       break;
/*      */     case 6:
/*  681 */       if (!r_RV())
/*      */       {
/*  683 */         return false;
/*      */       }
/*      */ 
/*  686 */       slice_del();
/*      */ 
/*  688 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  692 */       this.ket = this.cursor;
/*      */ 
/*  694 */       among_var = find_among_b(a_2, 6);
/*  695 */       if (among_var == 0)
/*      */       {
/*  697 */         this.cursor = (this.limit - v_3);
/*      */       }
/*      */       else
/*      */       {
/*  701 */         this.bra = this.cursor;
/*  702 */         switch (among_var) {
/*      */         case 0:
/*  704 */           this.cursor = (this.limit - v_3);
/*  705 */           break;
/*      */         case 1:
/*  709 */           if (!r_R2())
/*      */           {
/*  711 */             this.cursor = (this.limit - v_3);
/*      */           }
/*      */           else
/*      */           {
/*  715 */             slice_del();
/*      */ 
/*  717 */             this.ket = this.cursor;
/*      */ 
/*  719 */             if (!eq_s_b(2, "at"))
/*      */             {
/*  721 */               this.cursor = (this.limit - v_3);
/*      */             }
/*      */             else
/*      */             {
/*  725 */               this.bra = this.cursor;
/*      */ 
/*  727 */               if (!r_R2())
/*      */               {
/*  729 */                 this.cursor = (this.limit - v_3);
/*      */               }
/*      */               else
/*      */               {
/*  733 */                 slice_del(); }  } 
/*  734 */           }break;
/*      */         case 2:
/*  739 */           int v_4 = this.limit - this.cursor;
/*      */ 
/*  743 */           if (r_R2())
/*      */           {
/*  748 */             slice_del();
/*      */           }
/*      */           else {
/*  751 */             this.cursor = (this.limit - v_4);
/*      */ 
/*  754 */             if (!r_R1())
/*      */             {
/*  756 */               this.cursor = (this.limit - v_3);
/*      */             }
/*      */             else
/*      */             {
/*  760 */               slice_from("eux");
/*      */             }
/*      */           }
/*  762 */           break;
/*      */         case 3:
/*  766 */           if (!r_R2())
/*      */           {
/*  768 */             this.cursor = (this.limit - v_3);
/*      */           }
/*      */           else
/*      */           {
/*  772 */             slice_del();
/*  773 */           }break;
/*      */         case 4:
/*  777 */           if (!r_RV())
/*      */           {
/*  779 */             this.cursor = (this.limit - v_3);
/*      */           }
/*      */           else
/*      */           {
/*  783 */             slice_from("i");
/*      */           }break;
/*      */         }
/*      */       }
/*  787 */       break;
/*      */     case 7:
/*  791 */       if (!r_R2())
/*      */       {
/*  793 */         return false;
/*      */       }
/*      */ 
/*  796 */       slice_del();
/*      */ 
/*  798 */       int v_5 = this.limit - this.cursor;
/*      */ 
/*  802 */       this.ket = this.cursor;
/*      */ 
/*  804 */       among_var = find_among_b(a_3, 3);
/*  805 */       if (among_var == 0)
/*      */       {
/*  807 */         this.cursor = (this.limit - v_5);
/*      */       }
/*      */       else
/*      */       {
/*  811 */         this.bra = this.cursor;
/*  812 */         switch (among_var) {
/*      */         case 0:
/*  814 */           this.cursor = (this.limit - v_5);
/*  815 */           break;
/*      */         case 1:
/*  820 */           int v_6 = this.limit - this.cursor;
/*      */ 
/*  824 */           if (r_R2())
/*      */           {
/*  829 */             slice_del();
/*      */           }
/*      */           else {
/*  832 */             this.cursor = (this.limit - v_6);
/*      */ 
/*  834 */             slice_from("abl");
/*      */           }
/*  836 */           break;
/*      */         case 2:
/*  841 */           int v_7 = this.limit - this.cursor;
/*      */ 
/*  845 */           if (r_R2())
/*      */           {
/*  850 */             slice_del();
/*      */           }
/*      */           else {
/*  853 */             this.cursor = (this.limit - v_7);
/*      */ 
/*  855 */             slice_from("iqU");
/*      */           }
/*  857 */           break;
/*      */         case 3:
/*  861 */           if (!r_R2())
/*      */           {
/*  863 */             this.cursor = (this.limit - v_5);
/*      */           }
/*      */           else
/*      */           {
/*  867 */             slice_del();
/*      */           }break;
/*      */         }
/*      */       }
/*  871 */       break;
/*      */     case 8:
/*  875 */       if (!r_R2())
/*      */       {
/*  877 */         return false;
/*      */       }
/*      */ 
/*  880 */       slice_del();
/*      */ 
/*  882 */       int v_8 = this.limit - this.cursor;
/*      */ 
/*  886 */       this.ket = this.cursor;
/*      */ 
/*  888 */       if (!eq_s_b(2, "at"))
/*      */       {
/*  890 */         this.cursor = (this.limit - v_8);
/*      */       }
/*      */       else
/*      */       {
/*  894 */         this.bra = this.cursor;
/*      */ 
/*  896 */         if (!r_R2())
/*      */         {
/*  898 */           this.cursor = (this.limit - v_8);
/*      */         }
/*      */         else
/*      */         {
/*  902 */           slice_del();
/*      */ 
/*  904 */           this.ket = this.cursor;
/*      */ 
/*  906 */           if (!eq_s_b(2, "ic"))
/*      */           {
/*  908 */             this.cursor = (this.limit - v_8);
/*      */           }
/*      */           else
/*      */           {
/*  912 */             this.bra = this.cursor;
/*      */ 
/*  915 */             int v_9 = this.limit - this.cursor;
/*      */ 
/*  919 */             if (r_R2())
/*      */             {
/*  924 */               slice_del();
/*      */             }
/*      */             else {
/*  927 */               this.cursor = (this.limit - v_9);
/*      */ 
/*  929 */               slice_from("iqU");
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  932 */       break;
/*      */     case 9:
/*  936 */       slice_from("eau");
/*  937 */       break;
/*      */     case 10:
/*  941 */       if (!r_R1())
/*      */       {
/*  943 */         return false;
/*      */       }
/*      */ 
/*  946 */       slice_from("al");
/*  947 */       break;
/*      */     case 11:
/*  952 */       int v_10 = this.limit - this.cursor;
/*      */ 
/*  956 */       if (r_R2())
/*      */       {
/*  961 */         slice_del();
/*      */       }
/*      */       else {
/*  964 */         this.cursor = (this.limit - v_10);
/*      */ 
/*  967 */         if (!r_R1())
/*      */         {
/*  969 */           return false;
/*      */         }
/*      */ 
/*  972 */         slice_from("eux");
/*      */       }
/*  974 */       break;
/*      */     case 12:
/*  978 */       if (!r_R1())
/*      */       {
/*  980 */         return false;
/*      */       }
/*  982 */       if (!out_grouping_b(g_v, 97, 251))
/*      */       {
/*  984 */         return false;
/*      */       }
/*      */ 
/*  987 */       slice_del();
/*  988 */       break;
/*      */     case 13:
/*  992 */       if (!r_RV())
/*      */       {
/*  994 */         return false;
/*      */       }
/*      */ 
/*  999 */       slice_from("ant");
/* 1000 */       return false;
/*      */     case 14:
/* 1004 */       if (!r_RV())
/*      */       {
/* 1006 */         return false;
/*      */       }
/*      */ 
/* 1011 */       slice_from("ent");
/* 1012 */       return false;
/*      */     case 15:
/* 1016 */       int v_11 = this.limit - this.cursor;
/*      */ 
/* 1018 */       if (!in_grouping_b(g_v, 97, 251))
/*      */       {
/* 1020 */         return false;
/*      */       }
/*      */ 
/* 1023 */       if (!r_RV())
/*      */       {
/* 1025 */         return false;
/*      */       }
/* 1027 */       this.cursor = (this.limit - v_11);
/*      */ 
/* 1031 */       slice_del();
/* 1032 */       return false;
/*      */     }
/* 1034 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_i_verb_suffix()
/*      */   {
/* 1042 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1044 */     if (this.cursor < this.I_pV)
/*      */     {
/* 1046 */       return false;
/*      */     }
/* 1048 */     this.cursor = this.I_pV;
/* 1049 */     int v_2 = this.limit_backward;
/* 1050 */     this.limit_backward = this.cursor;
/* 1051 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1054 */     this.ket = this.cursor;
/*      */ 
/* 1056 */     int among_var = find_among_b(a_5, 35);
/* 1057 */     if (among_var == 0)
/*      */     {
/* 1059 */       this.limit_backward = v_2;
/* 1060 */       return false;
/*      */     }
/*      */ 
/* 1063 */     this.bra = this.cursor;
/* 1064 */     switch (among_var) {
/*      */     case 0:
/* 1066 */       this.limit_backward = v_2;
/* 1067 */       return false;
/*      */     case 1:
/* 1070 */       if (!out_grouping_b(g_v, 97, 251))
/*      */       {
/* 1072 */         this.limit_backward = v_2;
/* 1073 */         return false;
/*      */       }
/*      */ 
/* 1076 */       slice_del();
/*      */     }
/*      */ 
/* 1079 */     this.limit_backward = v_2;
/* 1080 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_verb_suffix()
/*      */   {
/* 1089 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1091 */     if (this.cursor < this.I_pV)
/*      */     {
/* 1093 */       return false;
/*      */     }
/* 1095 */     this.cursor = this.I_pV;
/* 1096 */     int v_2 = this.limit_backward;
/* 1097 */     this.limit_backward = this.cursor;
/* 1098 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1101 */     this.ket = this.cursor;
/*      */ 
/* 1103 */     int among_var = find_among_b(a_6, 38);
/* 1104 */     if (among_var == 0)
/*      */     {
/* 1106 */       this.limit_backward = v_2;
/* 1107 */       return false;
/*      */     }
/*      */ 
/* 1110 */     this.bra = this.cursor;
/* 1111 */     switch (among_var) {
/*      */     case 0:
/* 1113 */       this.limit_backward = v_2;
/* 1114 */       return false;
/*      */     case 1:
/* 1118 */       if (!r_R2())
/*      */       {
/* 1120 */         this.limit_backward = v_2;
/* 1121 */         return false;
/*      */       }
/*      */ 
/* 1124 */       slice_del();
/* 1125 */       break;
/*      */     case 2:
/* 1129 */       slice_del();
/* 1130 */       break;
/*      */     case 3:
/* 1134 */       slice_del();
/*      */ 
/* 1136 */       int v_3 = this.limit - this.cursor;
/*      */ 
/* 1140 */       this.ket = this.cursor;
/*      */ 
/* 1142 */       if (!eq_s_b(1, "e"))
/*      */       {
/* 1144 */         this.cursor = (this.limit - v_3);
/*      */       }
/*      */       else
/*      */       {
/* 1148 */         this.bra = this.cursor;
/*      */ 
/* 1150 */         slice_del();
/*      */       }
/*      */       break;
/*      */     }
/* 1154 */     this.limit_backward = v_2;
/* 1155 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_residual_suffix()
/*      */   {
/* 1167 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1171 */     this.ket = this.cursor;
/*      */ 
/* 1173 */     if (!eq_s_b(1, "s"))
/*      */     {
/* 1175 */       this.cursor = (this.limit - v_1);
/*      */     }
/*      */     else
/*      */     {
/* 1179 */       this.bra = this.cursor;
/*      */ 
/* 1181 */       int v_2 = this.limit - this.cursor;
/* 1182 */       if (!out_grouping_b(g_keep_with_s, 97, 232))
/*      */       {
/* 1184 */         this.cursor = (this.limit - v_1);
/*      */       }
/*      */       else {
/* 1187 */         this.cursor = (this.limit - v_2);
/*      */ 
/* 1189 */         slice_del();
/*      */       }
/*      */     }
/* 1192 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1194 */     if (this.cursor < this.I_pV)
/*      */     {
/* 1196 */       return false;
/*      */     }
/* 1198 */     this.cursor = this.I_pV;
/* 1199 */     int v_4 = this.limit_backward;
/* 1200 */     this.limit_backward = this.cursor;
/* 1201 */     this.cursor = (this.limit - v_3);
/*      */ 
/* 1204 */     this.ket = this.cursor;
/*      */ 
/* 1206 */     int among_var = find_among_b(a_7, 7);
/* 1207 */     if (among_var == 0)
/*      */     {
/* 1209 */       this.limit_backward = v_4;
/* 1210 */       return false;
/*      */     }
/*      */ 
/* 1213 */     this.bra = this.cursor;
/* 1214 */     switch (among_var) {
/*      */     case 0:
/* 1216 */       this.limit_backward = v_4;
/* 1217 */       return false;
/*      */     case 1:
/* 1221 */       if (!r_R2())
/*      */       {
/* 1223 */         this.limit_backward = v_4;
/* 1224 */         return false;
/*      */       }
/*      */ 
/* 1228 */       int v_5 = this.limit - this.cursor;
/*      */ 
/* 1231 */       if (!eq_s_b(1, "s"))
/*      */       {
/* 1237 */         this.cursor = (this.limit - v_5);
/*      */ 
/* 1239 */         if (!eq_s_b(1, "t"))
/*      */         {
/* 1241 */           this.limit_backward = v_4;
/* 1242 */           return false;
/*      */         }
/*      */       }
/*      */ 
/* 1246 */       slice_del();
/* 1247 */       break;
/*      */     case 2:
/* 1251 */       slice_from("i");
/* 1252 */       break;
/*      */     case 3:
/* 1256 */       slice_del();
/* 1257 */       break;
/*      */     case 4:
/* 1261 */       if (!eq_s_b(2, "gu"))
/*      */       {
/* 1263 */         this.limit_backward = v_4;
/* 1264 */         return false;
/*      */       }
/*      */ 
/* 1267 */       slice_del();
/*      */     }
/*      */ 
/* 1270 */     this.limit_backward = v_4;
/* 1271 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_un_double()
/*      */   {
/* 1278 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1280 */     if (find_among_b(a_8, 5) == 0)
/*      */     {
/* 1282 */       return false;
/*      */     }
/* 1284 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1286 */     this.ket = this.cursor;
/*      */ 
/* 1288 */     if (this.cursor <= this.limit_backward)
/*      */     {
/* 1290 */       return false;
/*      */     }
/* 1292 */     this.cursor -= 1;
/*      */ 
/* 1294 */     this.bra = this.cursor;
/*      */ 
/* 1296 */     slice_del();
/* 1297 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_un_accent()
/*      */   {
/* 1305 */     int v_1 = 1;
/*      */ 
/* 1310 */     while (out_grouping_b(g_v, 97, 251))
/*      */     {
/* 1314 */       v_1--;
/*      */     }
/*      */ 
/* 1319 */     if (v_1 > 0)
/*      */     {
/* 1321 */       return false;
/*      */     }
/*      */ 
/* 1325 */     this.ket = this.cursor;
/*      */ 
/* 1328 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1331 */     if (!eq_s_b(1, "é"))
/*      */     {
/* 1337 */       this.cursor = (this.limit - v_3);
/*      */ 
/* 1339 */       if (!eq_s_b(1, "è"))
/*      */       {
/* 1341 */         return false;
/*      */       }
/*      */     }
/*      */ 
/* 1345 */     this.bra = this.cursor;
/*      */ 
/* 1347 */     slice_from("e");
/* 1348 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean stem()
/*      */   {
/* 1366 */     int v_1 = this.cursor;
/*      */ 
/* 1369 */     if (!r_prelude());
/* 1374 */     this.cursor = v_1;
/*      */ 
/* 1376 */     int v_2 = this.cursor;
/*      */ 
/* 1379 */     if (!r_mark_regions());
/* 1384 */     this.cursor = v_2;
/*      */ 
/* 1386 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 1389 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1394 */     int v_4 = this.limit - this.cursor;
/*      */ 
/* 1398 */     int v_5 = this.limit - this.cursor;
/*      */ 
/* 1402 */     int v_6 = this.limit - this.cursor;
/*      */ 
/* 1405 */     if (!r_standard_suffix())
/*      */     {
/* 1411 */       this.cursor = (this.limit - v_6);
/*      */ 
/* 1414 */       if (!r_i_verb_suffix())
/*      */       {
/* 1420 */         this.cursor = (this.limit - v_6);
/*      */ 
/* 1422 */         if (!r_verb_suffix()) {
/*      */           break label262;
/*      */         }
/*      */       }
/*      */     }
/* 1427 */     this.cursor = (this.limit - v_5);
/*      */ 
/* 1429 */     int v_7 = this.limit - this.cursor;
/*      */ 
/* 1433 */     this.ket = this.cursor;
/*      */ 
/* 1436 */     int v_8 = this.limit - this.cursor;
/*      */ 
/* 1440 */     if (eq_s_b(1, "Y"))
/*      */     {
/* 1445 */       this.bra = this.cursor;
/*      */ 
/* 1447 */       slice_from("i");
/*      */     }
/*      */     else {
/* 1450 */       this.cursor = (this.limit - v_8);
/*      */ 
/* 1453 */       if (!eq_s_b(1, "ç"))
/*      */       {
/* 1455 */         this.cursor = (this.limit - v_7);
/*      */       }
/*      */       else
/*      */       {
/* 1459 */         this.bra = this.cursor;
/*      */ 
/* 1461 */         slice_from("c");
/*      */ 
/* 1464 */         break label280;
/*      */ 
/* 1466 */         label262: this.cursor = (this.limit - v_4);
/*      */ 
/* 1468 */         if (r_residual_suffix());
/*      */       }
/*      */     }
/* 1474 */     label280: this.cursor = (this.limit - v_3);
/*      */ 
/* 1476 */     int v_9 = this.limit - this.cursor;
/*      */ 
/* 1479 */     if (!r_un_double());
/* 1484 */     this.cursor = (this.limit - v_9);
/*      */ 
/* 1486 */     int v_10 = this.limit - this.cursor;
/*      */ 
/* 1489 */     if (!r_un_accent());
/* 1494 */     this.cursor = (this.limit - v_10);
/* 1495 */     this.cursor = this.limit_backward;
/* 1496 */     int v_11 = this.cursor;
/*      */ 
/* 1499 */     if (!r_postlude());
/* 1504 */     this.cursor = v_11;
/* 1505 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1510 */     return o instanceof FrenchStemmer;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1515 */     return FrenchStemmer.class.getName().hashCode();
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.tartarus.snowball.ext.FrenchStemmer
 * JD-Core Version:    0.6.2
 */