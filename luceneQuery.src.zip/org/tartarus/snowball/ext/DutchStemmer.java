/*     */ package org.tartarus.snowball.ext;
/*     */ 
/*     */ import org.tartarus.snowball.Among;
/*     */ import org.tartarus.snowball.SnowballProgram;
/*     */ 
/*     */ public class DutchStemmer extends SnowballProgram
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  17 */   private static final DutchStemmer methodObject = new DutchStemmer();
/*     */ 
/*  19 */   private static final Among[] a_0 = { new Among("", -1, 6, "", methodObject), new Among("á", 0, 1, "", methodObject), new Among("ä", 0, 1, "", methodObject), new Among("é", 0, 2, "", methodObject), new Among("ë", 0, 2, "", methodObject), new Among("í", 0, 3, "", methodObject), new Among("ï", 0, 3, "", methodObject), new Among("ó", 0, 4, "", methodObject), new Among("ö", 0, 4, "", methodObject), new Among("ú", 0, 5, "", methodObject), new Among("ü", 0, 5, "", methodObject) };
/*     */ 
/*  33 */   private static final Among[] a_1 = { new Among("", -1, 3, "", methodObject), new Among("I", 0, 2, "", methodObject), new Among("Y", 0, 1, "", methodObject) };
/*     */ 
/*  39 */   private static final Among[] a_2 = { new Among("dd", -1, -1, "", methodObject), new Among("kk", -1, -1, "", methodObject), new Among("tt", -1, -1, "", methodObject) };
/*     */ 
/*  45 */   private static final Among[] a_3 = { new Among("ene", -1, 2, "", methodObject), new Among("se", -1, 3, "", methodObject), new Among("en", -1, 2, "", methodObject), new Among("heden", 2, 1, "", methodObject), new Among("s", -1, 3, "", methodObject) };
/*     */ 
/*  53 */   private static final Among[] a_4 = { new Among("end", -1, 1, "", methodObject), new Among("ig", -1, 2, "", methodObject), new Among("ing", -1, 1, "", methodObject), new Among("lijk", -1, 3, "", methodObject), new Among("baar", -1, 4, "", methodObject), new Among("bar", -1, 5, "", methodObject) };
/*     */ 
/*  62 */   private static final Among[] a_5 = { new Among("aa", -1, -1, "", methodObject), new Among("ee", -1, -1, "", methodObject), new Among("oo", -1, -1, "", methodObject), new Among("uu", -1, -1, "", methodObject) };
/*     */ 
/*  69 */   private static final char[] g_v = { '\021', 'A', '\020', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '' };
/*     */ 
/*  71 */   private static final char[] g_v_I = { '\001', '\000', '\000', '\021', 'A', '\020', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '' };
/*     */ 
/*  73 */   private static final char[] g_v_j = { '\021', 'C', '\020', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '' };
/*     */   private int I_p2;
/*     */   private int I_p1;
/*     */   private boolean B_e_found;
/*     */ 
/*     */   private void copy_from(DutchStemmer other)
/*     */   {
/*  80 */     this.I_p2 = other.I_p2;
/*  81 */     this.I_p1 = other.I_p1;
/*  82 */     this.B_e_found = other.B_e_found;
/*  83 */     super.copy_from(other);
/*     */   }
/*     */ 
/*     */   private boolean r_prelude()
/*     */   {
/*  96 */     int v_1 = this.cursor;
/*     */     int v_2;
/*     */     while (true)
/*     */     {
/* 100 */       v_2 = this.cursor;
/*     */ 
/* 104 */       this.bra = this.cursor;
/*     */ 
/* 106 */       int among_var = find_among(a_0, 11);
/* 107 */       if (among_var == 0)
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 112 */       this.ket = this.cursor;
/* 113 */       switch (among_var) {
/*     */       case 0:
/* 115 */         break;
/*     */       case 1:
/* 119 */         slice_from("a");
/* 120 */         break;
/*     */       case 2:
/* 124 */         slice_from("e");
/* 125 */         break;
/*     */       case 3:
/* 129 */         slice_from("i");
/* 130 */         break;
/*     */       case 4:
/* 134 */         slice_from("o");
/* 135 */         break;
/*     */       case 5:
/* 139 */         slice_from("u");
/* 140 */         break;
/*     */       case 6:
/* 144 */         if (this.cursor >= this.limit)
/*     */         {
/*     */           break label163;
/*     */         }
/* 148 */         this.cursor += 1;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 153 */     label163: this.cursor = v_2;
/*     */ 
/* 156 */     this.cursor = v_1;
/*     */ 
/* 158 */     int v_3 = this.cursor;
/*     */ 
/* 162 */     this.bra = this.cursor;
/*     */ 
/* 164 */     if (!eq_s(1, "y"))
/*     */     {
/* 166 */       this.cursor = v_3;
/*     */     }
/*     */     else
/*     */     {
/* 170 */       this.ket = this.cursor;
/*     */ 
/* 172 */       slice_from("Y");
/*     */     }
/*     */ 
/* 177 */     int v_4 = this.cursor;
/*     */     while (true)
/*     */     {
/* 182 */       int v_5 = this.cursor;
/*     */ 
/* 185 */       if (in_grouping(g_v, 97, 232))
/*     */       {
/* 190 */         this.bra = this.cursor;
/*     */ 
/* 193 */         int v_6 = this.cursor;
/*     */ 
/* 197 */         if (eq_s(1, "i"))
/*     */         {
/* 202 */           this.ket = this.cursor;
/* 203 */           if (in_grouping(g_v, 97, 232))
/*     */           {
/* 208 */             slice_from("I");
/* 209 */             break label348;
/*     */           }
/*     */         }
/* 211 */         this.cursor = v_6;
/*     */ 
/* 214 */         if (eq_s(1, "y"))
/*     */         {
/* 219 */           this.ket = this.cursor;
/*     */ 
/* 221 */           slice_from("Y");
/*     */ 
/* 223 */           label348: this.cursor = v_5;
/* 224 */           break;
/*     */         }
/*     */       }
/* 226 */       this.cursor = v_5;
/* 227 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label390;
/*     */       }
/* 231 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 235 */     label390: this.cursor = v_4;
/*     */ 
/* 238 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_mark_regions()
/*     */   {
/* 243 */     this.I_p1 = this.limit;
/* 244 */     this.I_p2 = this.limit;
/*     */ 
/* 249 */     while (!in_grouping(g_v, 97, 232))
/*     */     {
/* 255 */       if (this.cursor >= this.limit)
/*     */       {
/* 257 */         return false;
/*     */       }
/* 259 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 265 */     while (!out_grouping(g_v, 97, 232))
/*     */     {
/* 271 */       if (this.cursor >= this.limit)
/*     */       {
/* 273 */         return false;
/*     */       }
/* 275 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 278 */     this.I_p1 = this.cursor;
/*     */ 
/* 282 */     if (this.I_p1 < 3)
/*     */     {
/* 286 */       this.I_p1 = 3;
/*     */     }
/*     */ 
/* 292 */     while (!in_grouping(g_v, 97, 232))
/*     */     {
/* 298 */       if (this.cursor >= this.limit)
/*     */       {
/* 300 */         return false;
/*     */       }
/* 302 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 308 */     while (!out_grouping(g_v, 97, 232))
/*     */     {
/* 314 */       if (this.cursor >= this.limit)
/*     */       {
/* 316 */         return false;
/*     */       }
/* 318 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 321 */     this.I_p2 = this.cursor;
/* 322 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_postlude()
/*     */   {
/*     */     int v_1;
/*     */     while (true)
/*     */     {
/* 331 */       v_1 = this.cursor;
/*     */ 
/* 335 */       this.bra = this.cursor;
/*     */ 
/* 337 */       int among_var = find_among(a_1, 3);
/* 338 */       if (among_var == 0)
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 343 */       this.ket = this.cursor;
/* 344 */       switch (among_var) {
/*     */       case 0:
/* 346 */         break;
/*     */       case 1:
/* 350 */         slice_from("y");
/* 351 */         break;
/*     */       case 2:
/* 355 */         slice_from("i");
/* 356 */         break;
/*     */       case 3:
/* 360 */         if (this.cursor >= this.limit)
/*     */         {
/*     */           break label116;
/*     */         }
/* 364 */         this.cursor += 1;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 369 */     label116: this.cursor = v_1;
/*     */ 
/* 372 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R1() {
/* 376 */     if (this.I_p1 > this.cursor)
/*     */     {
/* 378 */       return false;
/*     */     }
/* 380 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R2() {
/* 384 */     if (this.I_p2 > this.cursor)
/*     */     {
/* 386 */       return false;
/*     */     }
/* 388 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_undouble()
/*     */   {
/* 395 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 397 */     if (find_among_b(a_2, 3) == 0)
/*     */     {
/* 399 */       return false;
/*     */     }
/* 401 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 403 */     this.ket = this.cursor;
/*     */ 
/* 405 */     if (this.cursor <= this.limit_backward)
/*     */     {
/* 407 */       return false;
/*     */     }
/* 409 */     this.cursor -= 1;
/*     */ 
/* 411 */     this.bra = this.cursor;
/*     */ 
/* 413 */     slice_del();
/* 414 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_e_ending()
/*     */   {
/* 421 */     this.B_e_found = false;
/*     */ 
/* 423 */     this.ket = this.cursor;
/*     */ 
/* 425 */     if (!eq_s_b(1, "e"))
/*     */     {
/* 427 */       return false;
/*     */     }
/*     */ 
/* 430 */     this.bra = this.cursor;
/*     */ 
/* 432 */     if (!r_R1())
/*     */     {
/* 434 */       return false;
/*     */     }
/*     */ 
/* 437 */     int v_1 = this.limit - this.cursor;
/* 438 */     if (!out_grouping_b(g_v, 97, 232))
/*     */     {
/* 440 */       return false;
/*     */     }
/* 442 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 444 */     slice_del();
/*     */ 
/* 446 */     this.B_e_found = true;
/*     */ 
/* 448 */     if (!r_undouble())
/*     */     {
/* 450 */       return false;
/*     */     }
/* 452 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_en_ending()
/*     */   {
/* 460 */     if (!r_R1())
/*     */     {
/* 462 */       return false;
/*     */     }
/*     */ 
/* 465 */     int v_1 = this.limit - this.cursor;
/* 466 */     if (!out_grouping_b(g_v, 97, 232))
/*     */     {
/* 468 */       return false;
/*     */     }
/* 470 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 473 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 476 */     if (eq_s_b(3, "gem"))
/*     */     {
/* 480 */       return false;
/*     */     }
/* 482 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 485 */     slice_del();
/*     */ 
/* 487 */     if (!r_undouble())
/*     */     {
/* 489 */       return false;
/*     */     }
/* 491 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_standard_suffix()
/*     */   {
/* 508 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 512 */     this.ket = this.cursor;
/*     */ 
/* 514 */     int among_var = find_among_b(a_3, 5);
/* 515 */     if (among_var != 0)
/*     */     {
/* 520 */       this.bra = this.cursor;
/* 521 */       switch (among_var) {
/*     */       case 0:
/* 523 */         break;
/*     */       case 1:
/* 527 */         if (r_R1())
/*     */         {
/* 532 */           slice_from("heid");
/* 533 */         }break;
/*     */       case 2:
/* 537 */         if (r_en_ending()) break;
/*     */       case 3:
/* 539 */         if ((goto 136) && 
/* 545 */           (r_R1()))
/*     */         {
/* 549 */           if (out_grouping_b(g_v_j, 97, 232))
/*     */           {
/* 554 */             slice_del(); } 
/*     */         }break;
/*     */       }
/*     */     }
/* 558 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 560 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 563 */     if (!r_e_ending());
/* 568 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 570 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 574 */     this.ket = this.cursor;
/*     */ 
/* 576 */     if (eq_s_b(4, "heid"))
/*     */     {
/* 581 */       this.bra = this.cursor;
/*     */ 
/* 583 */       if (r_R2())
/*     */       {
/* 589 */         int v_4 = this.limit - this.cursor;
/*     */ 
/* 592 */         if (!eq_s_b(1, "c"))
/*     */         {
/* 598 */           this.cursor = (this.limit - v_4);
/*     */ 
/* 601 */           slice_del();
/*     */ 
/* 603 */           this.ket = this.cursor;
/*     */ 
/* 605 */           if (eq_s_b(2, "en"))
/*     */           {
/* 610 */             this.bra = this.cursor;
/*     */ 
/* 612 */             if (r_en_ending());
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 617 */     this.cursor = (this.limit - v_3);
/*     */ 
/* 619 */     int v_5 = this.limit - this.cursor;
/*     */ 
/* 623 */     this.ket = this.cursor;
/*     */ 
/* 625 */     among_var = find_among_b(a_4, 6);
/* 626 */     if (among_var != 0)
/*     */     {
/* 631 */       this.bra = this.cursor;
/* 632 */       switch (among_var) {
/*     */       case 0:
/* 634 */         break;
/*     */       case 1:
/* 638 */         if (r_R2())
/*     */         {
/* 643 */           slice_del();
/*     */ 
/* 646 */           int v_6 = this.limit - this.cursor;
/*     */ 
/* 650 */           this.ket = this.cursor;
/*     */ 
/* 652 */           if (eq_s_b(2, "ig"))
/*     */           {
/* 657 */             this.bra = this.cursor;
/*     */ 
/* 659 */             if (r_R2())
/*     */             {
/* 665 */               int v_7 = this.limit - this.cursor;
/*     */ 
/* 668 */               if (!eq_s_b(1, "e"))
/*     */               {
/* 674 */                 this.cursor = (this.limit - v_7);
/*     */ 
/* 677 */                 slice_del();
/* 678 */                 break;
/*     */               }
/*     */             }
/*     */           }
/* 680 */           this.cursor = (this.limit - v_6);
/*     */ 
/* 682 */           if (r_undouble()) break;  } break;
/*     */       case 2:
/* 684 */         if ((goto 629) && 
/* 691 */           (r_R2()))
/*     */         {
/* 697 */           int v_8 = this.limit - this.cursor;
/*     */ 
/* 700 */           if (!eq_s_b(1, "e"))
/*     */           {
/* 706 */             this.cursor = (this.limit - v_8);
/*     */ 
/* 709 */             slice_del(); } 
/* 710 */         }break;
/*     */       case 3:
/* 714 */         if (r_R2())
/*     */         {
/* 719 */           slice_del();
/*     */ 
/* 721 */           if (r_e_ending()) break;  } break;
/*     */       case 4:
/* 723 */         if ((goto 629) && 
/* 729 */           (r_R2()))
/*     */         {
/* 734 */           slice_del();
/* 735 */         }break;
/*     */       case 5:
/* 739 */         if (r_R2())
/*     */         {
/* 744 */           if (this.B_e_found)
/*     */           {
/* 749 */             slice_del(); } 
/*     */         }break;
/*     */       }
/*     */     }
/* 753 */     this.cursor = (this.limit - v_5);
/*     */ 
/* 755 */     int v_9 = this.limit - this.cursor;
/*     */ 
/* 758 */     if (out_grouping_b(g_v_I, 73, 232))
/*     */     {
/* 763 */       int v_10 = this.limit - this.cursor;
/*     */ 
/* 766 */       if (find_among_b(a_5, 4) != 0)
/*     */       {
/* 770 */         if (out_grouping_b(g_v, 97, 232))
/*     */         {
/* 774 */           this.cursor = (this.limit - v_10);
/*     */ 
/* 776 */           this.ket = this.cursor;
/*     */ 
/* 778 */           if (this.cursor > this.limit_backward)
/*     */           {
/* 782 */             this.cursor -= 1;
/*     */ 
/* 784 */             this.bra = this.cursor;
/*     */ 
/* 786 */             slice_del();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 788 */     this.cursor = (this.limit - v_9);
/* 789 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean stem()
/*     */   {
/* 800 */     int v_1 = this.cursor;
/*     */ 
/* 803 */     if (!r_prelude());
/* 808 */     this.cursor = v_1;
/*     */ 
/* 810 */     int v_2 = this.cursor;
/*     */ 
/* 813 */     if (!r_mark_regions());
/* 818 */     this.cursor = v_2;
/*     */ 
/* 820 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*     */ 
/* 822 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 825 */     if (!r_standard_suffix());
/* 830 */     this.cursor = (this.limit - v_3);
/* 831 */     this.cursor = this.limit_backward;
/* 832 */     int v_4 = this.cursor;
/*     */ 
/* 835 */     if (!r_postlude());
/* 840 */     this.cursor = v_4;
/* 841 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 846 */     return o instanceof DutchStemmer;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 851 */     return DutchStemmer.class.getName().hashCode();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.tartarus.snowball.ext.DutchStemmer
 * JD-Core Version:    0.6.2
 */