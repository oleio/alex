/*      */ package org.tartarus.snowball.ext;
/*      */ 
/*      */ import org.tartarus.snowball.Among;
/*      */ import org.tartarus.snowball.SnowballProgram;
/*      */ 
/*      */ public class LovinsStemmer extends SnowballProgram
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   17 */   private static final LovinsStemmer methodObject = new LovinsStemmer();
/*      */ 
/*   19 */   private static final Among[] a_0 = { new Among("d", -1, -1, "", methodObject), new Among("f", -1, -1, "", methodObject), new Among("ph", -1, -1, "", methodObject), new Among("th", -1, -1, "", methodObject), new Among("l", -1, -1, "", methodObject), new Among("er", -1, -1, "", methodObject), new Among("or", -1, -1, "", methodObject), new Among("es", -1, -1, "", methodObject), new Among("t", -1, -1, "", methodObject) };
/*      */ 
/*   31 */   private static final Among[] a_1 = { new Among("s'", -1, 1, "r_A", methodObject), new Among("a", -1, 1, "r_A", methodObject), new Among("ia", 1, 1, "r_A", methodObject), new Among("ata", 1, 1, "r_A", methodObject), new Among("ic", -1, 1, "r_A", methodObject), new Among("aic", 4, 1, "r_A", methodObject), new Among("allic", 4, 1, "r_BB", methodObject), new Among("aric", 4, 1, "r_A", methodObject), new Among("atic", 4, 1, "r_B", methodObject), new Among("itic", 4, 1, "r_H", methodObject), new Among("antic", 4, 1, "r_C", methodObject), new Among("istic", 4, 1, "r_A", methodObject), new Among("alistic", 11, 1, "r_B", methodObject), new Among("aristic", 11, 1, "r_A", methodObject), new Among("ivistic", 11, 1, "r_A", methodObject), new Among("ed", -1, 1, "r_E", methodObject), new Among("anced", 15, 1, "r_B", methodObject), new Among("enced", 15, 1, "r_A", methodObject), new Among("ished", 15, 1, "r_A", methodObject), new Among("ied", 15, 1, "r_A", methodObject), new Among("ened", 15, 1, "r_E", methodObject), new Among("ioned", 15, 1, "r_A", methodObject), new Among("ated", 15, 1, "r_I", methodObject), new Among("ented", 15, 1, "r_C", methodObject), new Among("ized", 15, 1, "r_F", methodObject), new Among("arized", 24, 1, "r_A", methodObject), new Among("oid", -1, 1, "r_A", methodObject), new Among("aroid", 26, 1, "r_A", methodObject), new Among("hood", -1, 1, "r_A", methodObject), new Among("ehood", 28, 1, "r_A", methodObject), new Among("ihood", 28, 1, "r_A", methodObject), new Among("elihood", 30, 1, "r_E", methodObject), new Among("ward", -1, 1, "r_A", methodObject), new Among("e", -1, 1, "r_A", methodObject), new Among("ae", 33, 1, "r_A", methodObject), new Among("ance", 33, 1, "r_B", methodObject), new Among("icance", 35, 1, "r_A", methodObject), new Among("ence", 33, 1, "r_A", methodObject), new Among("ide", 33, 1, "r_L", methodObject), new Among("icide", 38, 1, "r_A", methodObject), new Among("otide", 38, 1, "r_A", methodObject), new Among("age", 33, 1, "r_B", methodObject), new Among("able", 33, 1, "r_A", methodObject), new Among("atable", 42, 1, "r_A", methodObject), new Among("izable", 42, 1, "r_E", methodObject), new Among("arizable", 44, 1, "r_A", methodObject), new Among("ible", 33, 1, "r_A", methodObject), new Among("encible", 46, 1, "r_A", methodObject), new Among("ene", 33, 1, "r_E", methodObject), new Among("ine", 33, 1, "r_M", methodObject), new Among("idine", 49, 1, "r_I", methodObject), new Among("one", 33, 1, "r_R", methodObject), new Among("ature", 33, 1, "r_E", methodObject), new Among("eature", 52, 1, "r_Z", methodObject), new Among("ese", 33, 1, "r_A", methodObject), new Among("wise", 33, 1, "r_A", methodObject), new Among("ate", 33, 1, "r_A", methodObject), new Among("entiate", 56, 1, "r_A", methodObject), new Among("inate", 56, 1, "r_A", methodObject), new Among("ionate", 56, 1, "r_D", methodObject), new Among("ite", 33, 1, "r_AA", methodObject), new Among("ive", 33, 1, "r_A", methodObject), new Among("ative", 61, 1, "r_A", methodObject), new Among("ize", 33, 1, "r_F", methodObject), new Among("alize", 63, 1, "r_A", methodObject), new Among("icalize", 64, 1, "r_A", methodObject), new Among("ialize", 64, 1, "r_A", methodObject), new Among("entialize", 66, 1, "r_A", methodObject), new Among("ionalize", 64, 1, "r_A", methodObject), new Among("arize", 63, 1, "r_A", methodObject), new Among("ing", -1, 1, "r_N", methodObject), new Among("ancing", 70, 1, "r_B", methodObject), new Among("encing", 70, 1, "r_A", methodObject), new Among("aging", 70, 1, "r_B", methodObject), new Among("ening", 70, 1, "r_E", methodObject), new Among("ioning", 70, 1, "r_A", methodObject), new Among("ating", 70, 1, "r_I", methodObject), new Among("enting", 70, 1, "r_C", methodObject), new Among("ying", 70, 1, "r_B", methodObject), new Among("izing", 70, 1, "r_F", methodObject), new Among("arizing", 79, 1, "r_A", methodObject), new Among("ish", -1, 1, "r_C", methodObject), new Among("yish", 81, 1, "r_A", methodObject), new Among("i", -1, 1, "r_A", methodObject), new Among("al", -1, 1, "r_BB", methodObject), new Among("ical", 84, 1, "r_A", methodObject), new Among("aical", 85, 1, "r_A", methodObject), new Among("istical", 85, 1, "r_A", methodObject), new Among("oidal", 84, 1, "r_A", methodObject), new Among("eal", 84, 1, "r_Y", methodObject), new Among("ial", 84, 1, "r_A", methodObject), new Among("ancial", 90, 1, "r_A", methodObject), new Among("arial", 90, 1, "r_A", methodObject), new Among("ential", 90, 1, "r_A", methodObject), new Among("ional", 84, 1, "r_A", methodObject), new Among("ational", 94, 1, "r_B", methodObject), new Among("izational", 95, 1, "r_A", methodObject), new Among("ental", 84, 1, "r_A", methodObject), new Among("ful", -1, 1, "r_A", methodObject), new Among("eful", 98, 1, "r_A", methodObject), new Among("iful", 98, 1, "r_A", methodObject), new Among("yl", -1, 1, "r_R", methodObject), new Among("ism", -1, 1, "r_B", methodObject), new Among("icism", 102, 1, "r_A", methodObject), new Among("oidism", 102, 1, "r_A", methodObject), new Among("alism", 102, 1, "r_B", methodObject), new Among("icalism", 105, 1, "r_A", methodObject), new Among("ionalism", 105, 1, "r_A", methodObject), new Among("inism", 102, 1, "r_J", methodObject), new Among("ativism", 102, 1, "r_A", methodObject), new Among("um", -1, 1, "r_U", methodObject), new Among("ium", 110, 1, "r_A", methodObject), new Among("ian", -1, 1, "r_A", methodObject), new Among("ician", 112, 1, "r_A", methodObject), new Among("en", -1, 1, "r_F", methodObject), new Among("ogen", 114, 1, "r_A", methodObject), new Among("on", -1, 1, "r_S", methodObject), new Among("ion", 116, 1, "r_Q", methodObject), new Among("ation", 117, 1, "r_B", methodObject), new Among("ication", 118, 1, "r_G", methodObject), new Among("entiation", 118, 1, "r_A", methodObject), new Among("ination", 118, 1, "r_A", methodObject), new Among("isation", 118, 1, "r_A", methodObject), new Among("arisation", 122, 1, "r_A", methodObject), new Among("entation", 118, 1, "r_A", methodObject), new Among("ization", 118, 1, "r_F", methodObject), new Among("arization", 125, 1, "r_A", methodObject), new Among("action", 117, 1, "r_G", methodObject), new Among("o", -1, 1, "r_A", methodObject), new Among("ar", -1, 1, "r_X", methodObject), new Among("ear", 129, 1, "r_Y", methodObject), new Among("ier", -1, 1, "r_A", methodObject), new Among("ariser", -1, 1, "r_A", methodObject), new Among("izer", -1, 1, "r_F", methodObject), new Among("arizer", 133, 1, "r_A", methodObject), new Among("or", -1, 1, "r_T", methodObject), new Among("ator", 135, 1, "r_A", methodObject), new Among("s", -1, 1, "r_W", methodObject), new Among("'s", 137, 1, "r_A", methodObject), new Among("as", 137, 1, "r_B", methodObject), new Among("ics", 137, 1, "r_A", methodObject), new Among("istics", 140, 1, "r_A", methodObject), new Among("es", 137, 1, "r_E", methodObject), new Among("ances", 142, 1, "r_B", methodObject), new Among("ences", 142, 1, "r_A", methodObject), new Among("ides", 142, 1, "r_L", methodObject), new Among("oides", 145, 1, "r_A", methodObject), new Among("ages", 142, 1, "r_B", methodObject), new Among("ies", 142, 1, "r_P", methodObject), new Among("acies", 148, 1, "r_A", methodObject), new Among("ancies", 148, 1, "r_A", methodObject), new Among("encies", 148, 1, "r_A", methodObject), new Among("aries", 148, 1, "r_A", methodObject), new Among("ities", 148, 1, "r_A", methodObject), new Among("alities", 153, 1, "r_A", methodObject), new Among("ivities", 153, 1, "r_A", methodObject), new Among("ines", 142, 1, "r_M", methodObject), new Among("nesses", 142, 1, "r_A", methodObject), new Among("ates", 142, 1, "r_A", methodObject), new Among("atives", 142, 1, "r_A", methodObject), new Among("ings", 137, 1, "r_N", methodObject), new Among("is", 137, 1, "r_A", methodObject), new Among("als", 137, 1, "r_BB", methodObject), new Among("ials", 162, 1, "r_A", methodObject), new Among("entials", 163, 1, "r_A", methodObject), new Among("ionals", 162, 1, "r_A", methodObject), new Among("isms", 137, 1, "r_B", methodObject), new Among("ians", 137, 1, "r_A", methodObject), new Among("icians", 167, 1, "r_A", methodObject), new Among("ions", 137, 1, "r_B", methodObject), new Among("ations", 169, 1, "r_B", methodObject), new Among("arisations", 170, 1, "r_A", methodObject), new Among("entations", 170, 1, "r_A", methodObject), new Among("izations", 170, 1, "r_A", methodObject), new Among("arizations", 173, 1, "r_A", methodObject), new Among("ars", 137, 1, "r_O", methodObject), new Among("iers", 137, 1, "r_A", methodObject), new Among("izers", 137, 1, "r_F", methodObject), new Among("ators", 137, 1, "r_A", methodObject), new Among("less", 137, 1, "r_A", methodObject), new Among("eless", 179, 1, "r_A", methodObject), new Among("ness", 137, 1, "r_A", methodObject), new Among("eness", 181, 1, "r_E", methodObject), new Among("ableness", 182, 1, "r_A", methodObject), new Among("eableness", 183, 1, "r_E", methodObject), new Among("ibleness", 182, 1, "r_A", methodObject), new Among("ateness", 182, 1, "r_A", methodObject), new Among("iteness", 182, 1, "r_A", methodObject), new Among("iveness", 182, 1, "r_A", methodObject), new Among("ativeness", 188, 1, "r_A", methodObject), new Among("ingness", 181, 1, "r_A", methodObject), new Among("ishness", 181, 1, "r_A", methodObject), new Among("iness", 181, 1, "r_A", methodObject), new Among("ariness", 192, 1, "r_E", methodObject), new Among("alness", 181, 1, "r_A", methodObject), new Among("icalness", 194, 1, "r_A", methodObject), new Among("antialness", 194, 1, "r_A", methodObject), new Among("entialness", 194, 1, "r_A", methodObject), new Among("ionalness", 194, 1, "r_A", methodObject), new Among("fulness", 181, 1, "r_A", methodObject), new Among("lessness", 181, 1, "r_A", methodObject), new Among("ousness", 181, 1, "r_A", methodObject), new Among("eousness", 201, 1, "r_A", methodObject), new Among("iousness", 201, 1, "r_A", methodObject), new Among("itousness", 201, 1, "r_A", methodObject), new Among("entness", 181, 1, "r_A", methodObject), new Among("ants", 137, 1, "r_B", methodObject), new Among("ists", 137, 1, "r_A", methodObject), new Among("icists", 207, 1, "r_A", methodObject), new Among("us", 137, 1, "r_V", methodObject), new Among("ous", 209, 1, "r_A", methodObject), new Among("eous", 210, 1, "r_A", methodObject), new Among("aceous", 211, 1, "r_A", methodObject), new Among("antaneous", 211, 1, "r_A", methodObject), new Among("ious", 210, 1, "r_A", methodObject), new Among("acious", 214, 1, "r_B", methodObject), new Among("itous", 210, 1, "r_A", methodObject), new Among("ant", -1, 1, "r_B", methodObject), new Among("icant", 217, 1, "r_A", methodObject), new Among("ent", -1, 1, "r_C", methodObject), new Among("ement", 219, 1, "r_A", methodObject), new Among("izement", 220, 1, "r_A", methodObject), new Among("ist", -1, 1, "r_A", methodObject), new Among("icist", 222, 1, "r_A", methodObject), new Among("alist", 222, 1, "r_A", methodObject), new Among("icalist", 224, 1, "r_A", methodObject), new Among("ialist", 224, 1, "r_A", methodObject), new Among("ionist", 222, 1, "r_A", methodObject), new Among("entist", 222, 1, "r_A", methodObject), new Among("y", -1, 1, "r_B", methodObject), new Among("acy", 229, 1, "r_A", methodObject), new Among("ancy", 229, 1, "r_B", methodObject), new Among("ency", 229, 1, "r_A", methodObject), new Among("ly", 229, 1, "r_B", methodObject), new Among("ealy", 233, 1, "r_Y", methodObject), new Among("ably", 233, 1, "r_A", methodObject), new Among("ibly", 233, 1, "r_A", methodObject), new Among("edly", 233, 1, "r_E", methodObject), new Among("iedly", 237, 1, "r_A", methodObject), new Among("ely", 233, 1, "r_E", methodObject), new Among("ately", 239, 1, "r_A", methodObject), new Among("ively", 239, 1, "r_A", methodObject), new Among("atively", 241, 1, "r_A", methodObject), new Among("ingly", 233, 1, "r_B", methodObject), new Among("atingly", 243, 1, "r_A", methodObject), new Among("ily", 233, 1, "r_A", methodObject), new Among("lily", 245, 1, "r_A", methodObject), new Among("arily", 245, 1, "r_A", methodObject), new Among("ally", 233, 1, "r_B", methodObject), new Among("ically", 248, 1, "r_A", methodObject), new Among("aically", 249, 1, "r_A", methodObject), new Among("allically", 249, 1, "r_C", methodObject), new Among("istically", 249, 1, "r_A", methodObject), new Among("alistically", 252, 1, "r_B", methodObject), new Among("oidally", 248, 1, "r_A", methodObject), new Among("ially", 248, 1, "r_A", methodObject), new Among("entially", 255, 1, "r_A", methodObject), new Among("ionally", 248, 1, "r_A", methodObject), new Among("ationally", 257, 1, "r_B", methodObject), new Among("izationally", 258, 1, "r_B", methodObject), new Among("entally", 248, 1, "r_A", methodObject), new Among("fully", 233, 1, "r_A", methodObject), new Among("efully", 261, 1, "r_A", methodObject), new Among("ifully", 261, 1, "r_A", methodObject), new Among("enly", 233, 1, "r_E", methodObject), new Among("arly", 233, 1, "r_K", methodObject), new Among("early", 265, 1, "r_Y", methodObject), new Among("lessly", 233, 1, "r_A", methodObject), new Among("ously", 233, 1, "r_A", methodObject), new Among("eously", 268, 1, "r_A", methodObject), new Among("iously", 268, 1, "r_A", methodObject), new Among("ently", 233, 1, "r_A", methodObject), new Among("ary", 229, 1, "r_F", methodObject), new Among("ery", 229, 1, "r_E", methodObject), new Among("icianry", 229, 1, "r_A", methodObject), new Among("atory", 229, 1, "r_A", methodObject), new Among("ity", 229, 1, "r_A", methodObject), new Among("acity", 276, 1, "r_A", methodObject), new Among("icity", 276, 1, "r_A", methodObject), new Among("eity", 276, 1, "r_A", methodObject), new Among("ality", 276, 1, "r_A", methodObject), new Among("icality", 280, 1, "r_A", methodObject), new Among("iality", 280, 1, "r_A", methodObject), new Among("antiality", 282, 1, "r_A", methodObject), new Among("entiality", 282, 1, "r_A", methodObject), new Among("ionality", 280, 1, "r_A", methodObject), new Among("elity", 276, 1, "r_A", methodObject), new Among("ability", 276, 1, "r_A", methodObject), new Among("izability", 287, 1, "r_A", methodObject), new Among("arizability", 288, 1, "r_A", methodObject), new Among("ibility", 276, 1, "r_A", methodObject), new Among("inity", 276, 1, "r_CC", methodObject), new Among("arity", 276, 1, "r_B", methodObject), new Among("ivity", 276, 1, "r_A", methodObject) };
/*      */ 
/*  328 */   private static final Among[] a_2 = { new Among("bb", -1, -1, "", methodObject), new Among("dd", -1, -1, "", methodObject), new Among("gg", -1, -1, "", methodObject), new Among("ll", -1, -1, "", methodObject), new Among("mm", -1, -1, "", methodObject), new Among("nn", -1, -1, "", methodObject), new Among("pp", -1, -1, "", methodObject), new Among("rr", -1, -1, "", methodObject), new Among("ss", -1, -1, "", methodObject), new Among("tt", -1, -1, "", methodObject) };
/*      */ 
/*  341 */   private static final Among[] a_3 = { new Among("uad", -1, 18, "", methodObject), new Among("vad", -1, 19, "", methodObject), new Among("cid", -1, 20, "", methodObject), new Among("lid", -1, 21, "", methodObject), new Among("erid", -1, 22, "", methodObject), new Among("pand", -1, 23, "", methodObject), new Among("end", -1, 24, "", methodObject), new Among("ond", -1, 25, "", methodObject), new Among("lud", -1, 26, "", methodObject), new Among("rud", -1, 27, "", methodObject), new Among("ul", -1, 9, "", methodObject), new Among("her", -1, 28, "", methodObject), new Among("metr", -1, 7, "", methodObject), new Among("istr", -1, 6, "", methodObject), new Among("urs", -1, 5, "", methodObject), new Among("uct", -1, 2, "", methodObject), new Among("et", -1, 32, "", methodObject), new Among("mit", -1, 29, "", methodObject), new Among("ent", -1, 30, "", methodObject), new Among("umpt", -1, 3, "", methodObject), new Among("rpt", -1, 4, "", methodObject), new Among("ert", -1, 31, "", methodObject), new Among("yt", -1, 33, "", methodObject), new Among("iev", -1, 1, "", methodObject), new Among("olv", -1, 8, "", methodObject), new Among("ax", -1, 14, "", methodObject), new Among("ex", -1, 15, "", methodObject), new Among("bex", 26, 10, "", methodObject), new Among("dex", 26, 11, "", methodObject), new Among("pex", 26, 12, "", methodObject), new Among("tex", 26, 13, "", methodObject), new Among("ix", -1, 16, "", methodObject), new Among("lux", -1, 17, "", methodObject), new Among("yz", -1, 34, "", methodObject) };
/*      */ 
/*      */   private void copy_from(LovinsStemmer other)
/*      */   {
/*  380 */     super.copy_from(other);
/*      */   }
/*      */ 
/*      */   private boolean r_A()
/*      */   {
/*  387 */     int c = this.cursor - 2;
/*  388 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  390 */       return false;
/*      */     }
/*  392 */     this.cursor = c;
/*      */ 
/*  394 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_B()
/*      */   {
/*  401 */     int c = this.cursor - 3;
/*  402 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  404 */       return false;
/*      */     }
/*  406 */     this.cursor = c;
/*      */ 
/*  408 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_C()
/*      */   {
/*  415 */     int c = this.cursor - 4;
/*  416 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  418 */       return false;
/*      */     }
/*  420 */     this.cursor = c;
/*      */ 
/*  422 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_D()
/*      */   {
/*  429 */     int c = this.cursor - 5;
/*  430 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  432 */       return false;
/*      */     }
/*  434 */     this.cursor = c;
/*      */ 
/*  436 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_E()
/*      */   {
/*  444 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  447 */     int c = this.cursor - 2;
/*  448 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  450 */       return false;
/*      */     }
/*  452 */     this.cursor = c;
/*      */ 
/*  454 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  457 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  460 */     if (eq_s_b(1, "e"))
/*      */     {
/*  464 */       return false;
/*      */     }
/*  466 */     this.cursor = (this.limit - v_2);
/*      */ 
/*  468 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_F()
/*      */   {
/*  476 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  479 */     int c = this.cursor - 3;
/*  480 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  482 */       return false;
/*      */     }
/*  484 */     this.cursor = c;
/*      */ 
/*  486 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  489 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  492 */     if (eq_s_b(1, "e"))
/*      */     {
/*  496 */       return false;
/*      */     }
/*  498 */     this.cursor = (this.limit - v_2);
/*      */ 
/*  500 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_G()
/*      */   {
/*  507 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  510 */     int c = this.cursor - 3;
/*  511 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  513 */       return false;
/*      */     }
/*  515 */     this.cursor = c;
/*      */ 
/*  517 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  519 */     if (!eq_s_b(1, "f"))
/*      */     {
/*  521 */       return false;
/*      */     }
/*  523 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_H()
/*      */   {
/*  531 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  534 */     int c = this.cursor - 2;
/*  535 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  537 */       return false;
/*      */     }
/*  539 */     this.cursor = c;
/*      */ 
/*  541 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  544 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  547 */     if (!eq_s_b(1, "t"))
/*      */     {
/*  553 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  555 */       if (!eq_s_b(2, "ll"))
/*      */       {
/*  557 */         return false;
/*      */       }
/*      */     }
/*  560 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_I()
/*      */   {
/*  569 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  572 */     int c = this.cursor - 2;
/*  573 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  575 */       return false;
/*      */     }
/*  577 */     this.cursor = c;
/*      */ 
/*  579 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  582 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  585 */     if (eq_s_b(1, "o"))
/*      */     {
/*  589 */       return false;
/*      */     }
/*  591 */     this.cursor = (this.limit - v_2);
/*      */ 
/*  595 */     int v_3 = this.limit - this.cursor;
/*      */ 
/*  598 */     if (eq_s_b(1, "e"))
/*      */     {
/*  602 */       return false;
/*      */     }
/*  604 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  606 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_J()
/*      */   {
/*  615 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  618 */     int c = this.cursor - 2;
/*  619 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  621 */       return false;
/*      */     }
/*  623 */     this.cursor = c;
/*      */ 
/*  625 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  628 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  631 */     if (eq_s_b(1, "a"))
/*      */     {
/*  635 */       return false;
/*      */     }
/*  637 */     this.cursor = (this.limit - v_2);
/*      */ 
/*  641 */     int v_3 = this.limit - this.cursor;
/*      */ 
/*  644 */     if (eq_s_b(1, "e"))
/*      */     {
/*  648 */       return false;
/*      */     }
/*  650 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  652 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_K()
/*      */   {
/*  660 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  663 */     int c = this.cursor - 3;
/*  664 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  666 */       return false;
/*      */     }
/*  668 */     this.cursor = c;
/*      */ 
/*  670 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  673 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  676 */     if (!eq_s_b(1, "l"))
/*      */     {
/*  682 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  685 */       if (!eq_s_b(1, "i"))
/*      */       {
/*  691 */         this.cursor = (this.limit - v_2);
/*      */ 
/*  694 */         if (!eq_s_b(1, "e"))
/*      */         {
/*  696 */           return false;
/*      */         }
/*      */ 
/*  699 */         if (this.cursor <= this.limit_backward)
/*      */         {
/*  701 */           return false;
/*      */         }
/*  703 */         this.cursor -= 1;
/*      */ 
/*  705 */         if (!eq_s_b(1, "u"))
/*      */         {
/*  707 */           return false;
/*      */         }
/*      */       }
/*      */     }
/*  710 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_L()
/*      */   {
/*  721 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  724 */     int c = this.cursor - 2;
/*  725 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  727 */       return false;
/*      */     }
/*  729 */     this.cursor = c;
/*      */ 
/*  731 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  734 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  737 */     if (eq_s_b(1, "u"))
/*      */     {
/*  741 */       return false;
/*      */     }
/*  743 */     this.cursor = (this.limit - v_2);
/*      */ 
/*  747 */     int v_3 = this.limit - this.cursor;
/*      */ 
/*  750 */     if (eq_s_b(1, "x"))
/*      */     {
/*  754 */       return false;
/*      */     }
/*  756 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  760 */     int v_4 = this.limit - this.cursor;
/*      */ 
/*  764 */     if (eq_s_b(1, "s"))
/*      */     {
/*  770 */       int v_5 = this.limit - this.cursor;
/*      */ 
/*  773 */       if (!eq_s_b(1, "o"))
/*      */       {
/*  779 */         this.cursor = (this.limit - v_5);
/*      */ 
/*  781 */         return false;
/*      */       }
/*      */     }
/*  783 */     this.cursor = (this.limit - v_4);
/*      */ 
/*  785 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_M()
/*      */   {
/*  796 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  799 */     int c = this.cursor - 2;
/*  800 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  802 */       return false;
/*      */     }
/*  804 */     this.cursor = c;
/*      */ 
/*  806 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  809 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  812 */     if (eq_s_b(1, "a"))
/*      */     {
/*  816 */       return false;
/*      */     }
/*  818 */     this.cursor = (this.limit - v_2);
/*      */ 
/*  822 */     int v_3 = this.limit - this.cursor;
/*      */ 
/*  825 */     if (eq_s_b(1, "c"))
/*      */     {
/*  829 */       return false;
/*      */     }
/*  831 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  835 */     int v_4 = this.limit - this.cursor;
/*      */ 
/*  838 */     if (eq_s_b(1, "e"))
/*      */     {
/*  842 */       return false;
/*      */     }
/*  844 */     this.cursor = (this.limit - v_4);
/*      */ 
/*  848 */     int v_5 = this.limit - this.cursor;
/*      */ 
/*  851 */     if (eq_s_b(1, "m"))
/*      */     {
/*  855 */       return false;
/*      */     }
/*  857 */     this.cursor = (this.limit - v_5);
/*      */ 
/*  859 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_N()
/*      */   {
/*  868 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  871 */     int c = this.cursor - 3;
/*  872 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  874 */       return false;
/*      */     }
/*  876 */     this.cursor = c;
/*      */ 
/*  878 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  882 */     int c = this.cursor - 2;
/*  883 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  885 */       return false;
/*      */     }
/*  887 */     this.cursor = c;
/*      */ 
/*  891 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  895 */     int v_3 = this.limit - this.cursor;
/*      */ 
/*  898 */     if (!eq_s_b(1, "s"))
/*      */     {
/*  904 */       this.cursor = (this.limit - v_3);
/*      */     }
/*      */     else
/*      */     {
/*  908 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  911 */       int c = this.cursor - 2;
/*  912 */       if ((this.limit_backward > c) || (c > this.limit))
/*      */       {
/*  914 */         return false;
/*      */       }
/*  916 */       this.cursor = c;
/*      */     }
/*      */ 
/*  919 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_O()
/*      */   {
/*  927 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  930 */     int c = this.cursor - 2;
/*  931 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  933 */       return false;
/*      */     }
/*  935 */     this.cursor = c;
/*      */ 
/*  937 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  940 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  943 */     if (!eq_s_b(1, "l"))
/*      */     {
/*  949 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  951 */       if (!eq_s_b(1, "i"))
/*      */       {
/*  953 */         return false;
/*      */       }
/*      */     }
/*  956 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_P()
/*      */   {
/*  964 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  967 */     int c = this.cursor - 2;
/*  968 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  970 */       return false;
/*      */     }
/*  972 */     this.cursor = c;
/*      */ 
/*  974 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  977 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  980 */     if (eq_s_b(1, "c"))
/*      */     {
/*  984 */       return false;
/*      */     }
/*  986 */     this.cursor = (this.limit - v_2);
/*      */ 
/*  988 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Q()
/*      */   {
/*  998 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1001 */     int c = this.cursor - 2;
/* 1002 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1004 */       return false;
/*      */     }
/* 1006 */     this.cursor = c;
/*      */ 
/* 1008 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1010 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1013 */     int c = this.cursor - 3;
/* 1014 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1016 */       return false;
/*      */     }
/* 1018 */     this.cursor = c;
/*      */ 
/* 1020 */     this.cursor = (this.limit - v_2);
/*      */ 
/* 1023 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1026 */     if (eq_s_b(1, "l"))
/*      */     {
/* 1030 */       return false;
/*      */     }
/* 1032 */     this.cursor = (this.limit - v_3);
/*      */ 
/* 1036 */     int v_4 = this.limit - this.cursor;
/*      */ 
/* 1039 */     if (eq_s_b(1, "n"))
/*      */     {
/* 1043 */       return false;
/*      */     }
/* 1045 */     this.cursor = (this.limit - v_4);
/*      */ 
/* 1047 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R()
/*      */   {
/* 1055 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1058 */     int c = this.cursor - 2;
/* 1059 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1061 */       return false;
/*      */     }
/* 1063 */     this.cursor = c;
/*      */ 
/* 1065 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1068 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1071 */     if (!eq_s_b(1, "n"))
/*      */     {
/* 1077 */       this.cursor = (this.limit - v_2);
/*      */ 
/* 1079 */       if (!eq_s_b(1, "r"))
/*      */       {
/* 1081 */         return false;
/*      */       }
/*      */     }
/* 1084 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_S()
/*      */   {
/* 1093 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1096 */     int c = this.cursor - 2;
/* 1097 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1099 */       return false;
/*      */     }
/* 1101 */     this.cursor = c;
/*      */ 
/* 1103 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1106 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1109 */     if (!eq_s_b(2, "dr"))
/*      */     {
/* 1115 */       this.cursor = (this.limit - v_2);
/*      */ 
/* 1118 */       if (!eq_s_b(1, "t"))
/*      */       {
/* 1120 */         return false;
/*      */       }
/*      */ 
/* 1124 */       int v_3 = this.limit - this.cursor;
/*      */ 
/* 1127 */       if (eq_s_b(1, "t"))
/*      */       {
/* 1131 */         return false;
/*      */       }
/* 1133 */       this.cursor = (this.limit - v_3);
/*      */     }
/*      */ 
/* 1136 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_T()
/*      */   {
/* 1145 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1148 */     int c = this.cursor - 2;
/* 1149 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1151 */       return false;
/*      */     }
/* 1153 */     this.cursor = c;
/*      */ 
/* 1155 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1158 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1161 */     if (!eq_s_b(1, "s"))
/*      */     {
/* 1167 */       this.cursor = (this.limit - v_2);
/*      */ 
/* 1170 */       if (!eq_s_b(1, "t"))
/*      */       {
/* 1172 */         return false;
/*      */       }
/*      */ 
/* 1176 */       int v_3 = this.limit - this.cursor;
/*      */ 
/* 1179 */       if (eq_s_b(1, "o"))
/*      */       {
/* 1183 */         return false;
/*      */       }
/* 1185 */       this.cursor = (this.limit - v_3);
/*      */     }
/*      */ 
/* 1188 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_U()
/*      */   {
/* 1196 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1199 */     int c = this.cursor - 2;
/* 1200 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1202 */       return false;
/*      */     }
/* 1204 */     this.cursor = c;
/*      */ 
/* 1206 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1209 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1212 */     if (!eq_s_b(1, "l"))
/*      */     {
/* 1218 */       this.cursor = (this.limit - v_2);
/*      */ 
/* 1221 */       if (!eq_s_b(1, "m"))
/*      */       {
/* 1227 */         this.cursor = (this.limit - v_2);
/*      */ 
/* 1230 */         if (!eq_s_b(1, "n"))
/*      */         {
/* 1236 */           this.cursor = (this.limit - v_2);
/*      */ 
/* 1238 */           if (!eq_s_b(1, "r"))
/*      */           {
/* 1240 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1243 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_V()
/*      */   {
/* 1250 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1253 */     int c = this.cursor - 2;
/* 1254 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1256 */       return false;
/*      */     }
/* 1258 */     this.cursor = c;
/*      */ 
/* 1260 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1262 */     if (!eq_s_b(1, "c"))
/*      */     {
/* 1264 */       return false;
/*      */     }
/* 1266 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_W()
/*      */   {
/* 1275 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1278 */     int c = this.cursor - 2;
/* 1279 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1281 */       return false;
/*      */     }
/* 1283 */     this.cursor = c;
/*      */ 
/* 1285 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1288 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1291 */     if (eq_s_b(1, "s"))
/*      */     {
/* 1295 */       return false;
/*      */     }
/* 1297 */     this.cursor = (this.limit - v_2);
/*      */ 
/* 1301 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1304 */     if (eq_s_b(1, "u"))
/*      */     {
/* 1308 */       return false;
/*      */     }
/* 1310 */     this.cursor = (this.limit - v_3);
/*      */ 
/* 1312 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_X()
/*      */   {
/* 1320 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1323 */     int c = this.cursor - 2;
/* 1324 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1326 */       return false;
/*      */     }
/* 1328 */     this.cursor = c;
/*      */ 
/* 1330 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1333 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1336 */     if (!eq_s_b(1, "l"))
/*      */     {
/* 1342 */       this.cursor = (this.limit - v_2);
/*      */ 
/* 1345 */       if (!eq_s_b(1, "i"))
/*      */       {
/* 1351 */         this.cursor = (this.limit - v_2);
/*      */ 
/* 1354 */         if (!eq_s_b(1, "e"))
/*      */         {
/* 1356 */           return false;
/*      */         }
/*      */ 
/* 1359 */         if (this.cursor <= this.limit_backward)
/*      */         {
/* 1361 */           return false;
/*      */         }
/* 1363 */         this.cursor -= 1;
/*      */ 
/* 1365 */         if (!eq_s_b(1, "u"))
/*      */         {
/* 1367 */           return false;
/*      */         }
/*      */       }
/*      */     }
/* 1370 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Y()
/*      */   {
/* 1377 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1380 */     int c = this.cursor - 2;
/* 1381 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1383 */       return false;
/*      */     }
/* 1385 */     this.cursor = c;
/*      */ 
/* 1387 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1389 */     if (!eq_s_b(2, "in"))
/*      */     {
/* 1391 */       return false;
/*      */     }
/* 1393 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Z()
/*      */   {
/* 1401 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1404 */     int c = this.cursor - 2;
/* 1405 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1407 */       return false;
/*      */     }
/* 1409 */     this.cursor = c;
/*      */ 
/* 1411 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1414 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1417 */     if (eq_s_b(1, "f"))
/*      */     {
/* 1421 */       return false;
/*      */     }
/* 1423 */     this.cursor = (this.limit - v_2);
/*      */ 
/* 1425 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_AA()
/*      */   {
/* 1432 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1435 */     int c = this.cursor - 2;
/* 1436 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1438 */       return false;
/*      */     }
/* 1440 */     this.cursor = c;
/*      */ 
/* 1442 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1444 */     if (find_among_b(a_0, 9) == 0)
/*      */     {
/* 1446 */       return false;
/*      */     }
/* 1448 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_BB()
/*      */   {
/* 1457 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1460 */     int c = this.cursor - 3;
/* 1461 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1463 */       return false;
/*      */     }
/* 1465 */     this.cursor = c;
/*      */ 
/* 1467 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1470 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1473 */     if (eq_s_b(3, "met"))
/*      */     {
/* 1477 */       return false;
/*      */     }
/* 1479 */     this.cursor = (this.limit - v_2);
/*      */ 
/* 1483 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1486 */     if (eq_s_b(4, "ryst"))
/*      */     {
/* 1490 */       return false;
/*      */     }
/* 1492 */     this.cursor = (this.limit - v_3);
/*      */ 
/* 1494 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_CC()
/*      */   {
/* 1501 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1504 */     int c = this.cursor - 2;
/* 1505 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/* 1507 */       return false;
/*      */     }
/* 1509 */     this.cursor = c;
/*      */ 
/* 1511 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1513 */     if (!eq_s_b(1, "l"))
/*      */     {
/* 1515 */       return false;
/*      */     }
/* 1517 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_endings()
/*      */   {
/* 1524 */     this.ket = this.cursor;
/*      */ 
/* 1526 */     int among_var = find_among_b(a_1, 294);
/* 1527 */     if (among_var == 0)
/*      */     {
/* 1529 */       return false;
/*      */     }
/*      */ 
/* 1532 */     this.bra = this.cursor;
/* 1533 */     switch (among_var) {
/*      */     case 0:
/* 1535 */       return false;
/*      */     case 1:
/* 1539 */       slice_del();
/*      */     }
/*      */ 
/* 1542 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_undouble()
/*      */   {
/* 1549 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1551 */     if (find_among_b(a_2, 10) == 0)
/*      */     {
/* 1553 */       return false;
/*      */     }
/* 1555 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1557 */     this.ket = this.cursor;
/*      */ 
/* 1559 */     if (this.cursor <= this.limit_backward)
/*      */     {
/* 1561 */       return false;
/*      */     }
/* 1563 */     this.cursor -= 1;
/*      */ 
/* 1565 */     this.bra = this.cursor;
/*      */ 
/* 1567 */     slice_del();
/* 1568 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_respell()
/*      */   {
/* 1583 */     this.ket = this.cursor;
/*      */ 
/* 1585 */     int among_var = find_among_b(a_3, 34);
/* 1586 */     if (among_var == 0)
/*      */     {
/* 1588 */       return false;
/*      */     }
/*      */ 
/* 1591 */     this.bra = this.cursor;
/* 1592 */     switch (among_var) {
/*      */     case 0:
/* 1594 */       return false;
/*      */     case 1:
/* 1598 */       slice_from("ief");
/* 1599 */       break;
/*      */     case 2:
/* 1603 */       slice_from("uc");
/* 1604 */       break;
/*      */     case 3:
/* 1608 */       slice_from("um");
/* 1609 */       break;
/*      */     case 4:
/* 1613 */       slice_from("rb");
/* 1614 */       break;
/*      */     case 5:
/* 1618 */       slice_from("ur");
/* 1619 */       break;
/*      */     case 6:
/* 1623 */       slice_from("ister");
/* 1624 */       break;
/*      */     case 7:
/* 1628 */       slice_from("meter");
/* 1629 */       break;
/*      */     case 8:
/* 1633 */       slice_from("olut");
/* 1634 */       break;
/*      */     case 9:
/* 1639 */       int v_1 = this.limit - this.cursor;
/*      */ 
/* 1642 */       if (eq_s_b(1, "a"))
/*      */       {
/* 1646 */         return false;
/*      */       }
/* 1648 */       this.cursor = (this.limit - v_1);
/*      */ 
/* 1652 */       int v_2 = this.limit - this.cursor;
/*      */ 
/* 1655 */       if (eq_s_b(1, "i"))
/*      */       {
/* 1659 */         return false;
/*      */       }
/* 1661 */       this.cursor = (this.limit - v_2);
/*      */ 
/* 1665 */       int v_3 = this.limit - this.cursor;
/*      */ 
/* 1668 */       if (eq_s_b(1, "o"))
/*      */       {
/* 1672 */         return false;
/*      */       }
/* 1674 */       this.cursor = (this.limit - v_3);
/*      */ 
/* 1677 */       slice_from("l");
/* 1678 */       break;
/*      */     case 10:
/* 1682 */       slice_from("bic");
/* 1683 */       break;
/*      */     case 11:
/* 1687 */       slice_from("dic");
/* 1688 */       break;
/*      */     case 12:
/* 1692 */       slice_from("pic");
/* 1693 */       break;
/*      */     case 13:
/* 1697 */       slice_from("tic");
/* 1698 */       break;
/*      */     case 14:
/* 1702 */       slice_from("ac");
/* 1703 */       break;
/*      */     case 15:
/* 1707 */       slice_from("ec");
/* 1708 */       break;
/*      */     case 16:
/* 1712 */       slice_from("ic");
/* 1713 */       break;
/*      */     case 17:
/* 1717 */       slice_from("luc");
/* 1718 */       break;
/*      */     case 18:
/* 1722 */       slice_from("uas");
/* 1723 */       break;
/*      */     case 19:
/* 1727 */       slice_from("vas");
/* 1728 */       break;
/*      */     case 20:
/* 1732 */       slice_from("cis");
/* 1733 */       break;
/*      */     case 21:
/* 1737 */       slice_from("lis");
/* 1738 */       break;
/*      */     case 22:
/* 1742 */       slice_from("eris");
/* 1743 */       break;
/*      */     case 23:
/* 1747 */       slice_from("pans");
/* 1748 */       break;
/*      */     case 24:
/* 1753 */       int v_4 = this.limit - this.cursor;
/*      */ 
/* 1756 */       if (eq_s_b(1, "s"))
/*      */       {
/* 1760 */         return false;
/*      */       }
/* 1762 */       this.cursor = (this.limit - v_4);
/*      */ 
/* 1765 */       slice_from("ens");
/* 1766 */       break;
/*      */     case 25:
/* 1770 */       slice_from("ons");
/* 1771 */       break;
/*      */     case 26:
/* 1775 */       slice_from("lus");
/* 1776 */       break;
/*      */     case 27:
/* 1780 */       slice_from("rus");
/* 1781 */       break;
/*      */     case 28:
/* 1786 */       int v_5 = this.limit - this.cursor;
/*      */ 
/* 1789 */       if (eq_s_b(1, "p"))
/*      */       {
/* 1793 */         return false;
/*      */       }
/* 1795 */       this.cursor = (this.limit - v_5);
/*      */ 
/* 1799 */       int v_6 = this.limit - this.cursor;
/*      */ 
/* 1802 */       if (eq_s_b(1, "t"))
/*      */       {
/* 1806 */         return false;
/*      */       }
/* 1808 */       this.cursor = (this.limit - v_6);
/*      */ 
/* 1811 */       slice_from("hes");
/* 1812 */       break;
/*      */     case 29:
/* 1816 */       slice_from("mis");
/* 1817 */       break;
/*      */     case 30:
/* 1822 */       int v_7 = this.limit - this.cursor;
/*      */ 
/* 1825 */       if (eq_s_b(1, "m"))
/*      */       {
/* 1829 */         return false;
/*      */       }
/* 1831 */       this.cursor = (this.limit - v_7);
/*      */ 
/* 1834 */       slice_from("ens");
/* 1835 */       break;
/*      */     case 31:
/* 1839 */       slice_from("ers");
/* 1840 */       break;
/*      */     case 32:
/* 1845 */       int v_8 = this.limit - this.cursor;
/*      */ 
/* 1848 */       if (eq_s_b(1, "n"))
/*      */       {
/* 1852 */         return false;
/*      */       }
/* 1854 */       this.cursor = (this.limit - v_8);
/*      */ 
/* 1857 */       slice_from("es");
/* 1858 */       break;
/*      */     case 33:
/* 1862 */       slice_from("ys");
/* 1863 */       break;
/*      */     case 34:
/* 1867 */       slice_from("ys");
/*      */     }
/*      */ 
/* 1870 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean stem()
/*      */   {
/* 1880 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 1883 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1886 */     if (!r_endings());
/* 1891 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 1893 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1896 */     if (!r_undouble());
/* 1901 */     this.cursor = (this.limit - v_2);
/*      */ 
/* 1903 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1906 */     if (!r_respell());
/* 1911 */     this.cursor = (this.limit - v_3);
/* 1912 */     this.cursor = this.limit_backward; return true;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1917 */     return o instanceof LovinsStemmer;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1922 */     return LovinsStemmer.class.getName().hashCode();
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.tartarus.snowball.ext.LovinsStemmer
 * JD-Core Version:    0.6.2
 */