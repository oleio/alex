/*      */ package org.tartarus.snowball.ext;
/*      */ 
/*      */ import org.tartarus.snowball.Among;
/*      */ import org.tartarus.snowball.SnowballProgram;
/*      */ 
/*      */ public class FinnishStemmer extends SnowballProgram
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   17 */   private static final FinnishStemmer methodObject = new FinnishStemmer();
/*      */ 
/*   19 */   private static final Among[] a_0 = { new Among("pa", -1, 1, "", methodObject), new Among("sti", -1, 2, "", methodObject), new Among("kaan", -1, 1, "", methodObject), new Among("han", -1, 1, "", methodObject), new Among("kin", -1, 1, "", methodObject), new Among("hän", -1, 1, "", methodObject), new Among("kään", -1, 1, "", methodObject), new Among("ko", -1, 1, "", methodObject), new Among("pä", -1, 1, "", methodObject), new Among("kö", -1, 1, "", methodObject) };
/*      */ 
/*   32 */   private static final Among[] a_1 = { new Among("lla", -1, -1, "", methodObject), new Among("na", -1, -1, "", methodObject), new Among("ssa", -1, -1, "", methodObject), new Among("ta", -1, -1, "", methodObject), new Among("lta", 3, -1, "", methodObject), new Among("sta", 3, -1, "", methodObject) };
/*      */ 
/*   41 */   private static final Among[] a_2 = { new Among("llä", -1, -1, "", methodObject), new Among("nä", -1, -1, "", methodObject), new Among("ssä", -1, -1, "", methodObject), new Among("tä", -1, -1, "", methodObject), new Among("ltä", 3, -1, "", methodObject), new Among("stä", 3, -1, "", methodObject) };
/*      */ 
/*   50 */   private static final Among[] a_3 = { new Among("lle", -1, -1, "", methodObject), new Among("ine", -1, -1, "", methodObject) };
/*      */ 
/*   55 */   private static final Among[] a_4 = { new Among("nsa", -1, 3, "", methodObject), new Among("mme", -1, 3, "", methodObject), new Among("nne", -1, 3, "", methodObject), new Among("ni", -1, 2, "", methodObject), new Among("si", -1, 1, "", methodObject), new Among("an", -1, 4, "", methodObject), new Among("en", -1, 6, "", methodObject), new Among("än", -1, 5, "", methodObject), new Among("nsä", -1, 3, "", methodObject) };
/*      */ 
/*   67 */   private static final Among[] a_5 = { new Among("aa", -1, -1, "", methodObject), new Among("ee", -1, -1, "", methodObject), new Among("ii", -1, -1, "", methodObject), new Among("oo", -1, -1, "", methodObject), new Among("uu", -1, -1, "", methodObject), new Among("ää", -1, -1, "", methodObject), new Among("öö", -1, -1, "", methodObject) };
/*      */ 
/*   77 */   private static final Among[] a_6 = { new Among("a", -1, 8, "", methodObject), new Among("lla", 0, -1, "", methodObject), new Among("na", 0, -1, "", methodObject), new Among("ssa", 0, -1, "", methodObject), new Among("ta", 0, -1, "", methodObject), new Among("lta", 4, -1, "", methodObject), new Among("sta", 4, -1, "", methodObject), new Among("tta", 4, 9, "", methodObject), new Among("lle", -1, -1, "", methodObject), new Among("ine", -1, -1, "", methodObject), new Among("ksi", -1, -1, "", methodObject), new Among("n", -1, 7, "", methodObject), new Among("han", 11, 1, "", methodObject), new Among("den", 11, -1, "r_VI", methodObject), new Among("seen", 11, -1, "r_LONG", methodObject), new Among("hen", 11, 2, "", methodObject), new Among("tten", 11, -1, "r_VI", methodObject), new Among("hin", 11, 3, "", methodObject), new Among("siin", 11, -1, "r_VI", methodObject), new Among("hon", 11, 4, "", methodObject), new Among("hän", 11, 5, "", methodObject), new Among("hön", 11, 6, "", methodObject), new Among("ä", -1, 8, "", methodObject), new Among("llä", 22, -1, "", methodObject), new Among("nä", 22, -1, "", methodObject), new Among("ssä", 22, -1, "", methodObject), new Among("tä", 22, -1, "", methodObject), new Among("ltä", 26, -1, "", methodObject), new Among("stä", 26, -1, "", methodObject), new Among("ttä", 26, 9, "", methodObject) };
/*      */ 
/*  110 */   private static final Among[] a_7 = { new Among("eja", -1, -1, "", methodObject), new Among("mma", -1, 1, "", methodObject), new Among("imma", 1, -1, "", methodObject), new Among("mpa", -1, 1, "", methodObject), new Among("impa", 3, -1, "", methodObject), new Among("mmi", -1, 1, "", methodObject), new Among("immi", 5, -1, "", methodObject), new Among("mpi", -1, 1, "", methodObject), new Among("impi", 7, -1, "", methodObject), new Among("ejä", -1, -1, "", methodObject), new Among("mmä", -1, 1, "", methodObject), new Among("immä", 10, -1, "", methodObject), new Among("mpä", -1, 1, "", methodObject), new Among("impä", 12, -1, "", methodObject) };
/*      */ 
/*  127 */   private static final Among[] a_8 = { new Among("i", -1, -1, "", methodObject), new Among("j", -1, -1, "", methodObject) };
/*      */ 
/*  132 */   private static final Among[] a_9 = { new Among("mma", -1, 1, "", methodObject), new Among("imma", 0, -1, "", methodObject) };
/*      */ 
/*  137 */   private static final char[] g_AEI = { '\021', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\b' };
/*      */ 
/*  139 */   private static final char[] g_V1 = { '\021', 'A', '\020', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\b', '\000', ' ' };
/*      */ 
/*  141 */   private static final char[] g_V2 = { '\021', 'A', '\020', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\b', '\000', ' ' };
/*      */ 
/*  143 */   private static final char[] g_particle_end = { '\021', 'a', '\030', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\b', '\000', ' ' };
/*      */   private boolean B_ending_removed;
/*  146 */   private StringBuilder S_x = new StringBuilder();
/*      */   private int I_p2;
/*      */   private int I_p1;
/*      */ 
/*      */   private void copy_from(FinnishStemmer other)
/*      */   {
/*  151 */     this.B_ending_removed = other.B_ending_removed;
/*  152 */     this.S_x = other.S_x;
/*  153 */     this.I_p2 = other.I_p2;
/*  154 */     this.I_p1 = other.I_p1;
/*  155 */     super.copy_from(other);
/*      */   }
/*      */ 
/*      */   private boolean r_mark_regions()
/*      */   {
/*  162 */     this.I_p1 = this.limit;
/*  163 */     this.I_p2 = this.limit;
/*      */     while (true)
/*      */     {
/*  167 */       int v_1 = this.cursor;
/*      */ 
/*  169 */       if (in_grouping(g_V1, 97, 246))
/*      */       {
/*  173 */         this.cursor = v_1;
/*  174 */         break;
/*      */       }
/*  176 */       this.cursor = v_1;
/*  177 */       if (this.cursor >= this.limit)
/*      */       {
/*  179 */         return false;
/*      */       }
/*  181 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  187 */     while (!out_grouping(g_V1, 97, 246))
/*      */     {
/*  193 */       if (this.cursor >= this.limit)
/*      */       {
/*  195 */         return false;
/*      */       }
/*  197 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  200 */     this.I_p1 = this.cursor;
/*      */     while (true)
/*      */     {
/*  204 */       int v_3 = this.cursor;
/*      */ 
/*  206 */       if (in_grouping(g_V1, 97, 246))
/*      */       {
/*  210 */         this.cursor = v_3;
/*  211 */         break;
/*      */       }
/*  213 */       this.cursor = v_3;
/*  214 */       if (this.cursor >= this.limit)
/*      */       {
/*  216 */         return false;
/*      */       }
/*  218 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  224 */     while (!out_grouping(g_V1, 97, 246))
/*      */     {
/*  230 */       if (this.cursor >= this.limit)
/*      */       {
/*  232 */         return false;
/*      */       }
/*  234 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  237 */     this.I_p2 = this.cursor;
/*  238 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R2() {
/*  242 */     if (this.I_p2 > this.cursor)
/*      */     {
/*  244 */       return false;
/*      */     }
/*  246 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_particle_etc()
/*      */   {
/*  255 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  257 */     if (this.cursor < this.I_p1)
/*      */     {
/*  259 */       return false;
/*      */     }
/*  261 */     this.cursor = this.I_p1;
/*  262 */     int v_2 = this.limit_backward;
/*  263 */     this.limit_backward = this.cursor;
/*  264 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  267 */     this.ket = this.cursor;
/*      */ 
/*  269 */     int among_var = find_among_b(a_0, 10);
/*  270 */     if (among_var == 0)
/*      */     {
/*  272 */       this.limit_backward = v_2;
/*  273 */       return false;
/*      */     }
/*      */ 
/*  276 */     this.bra = this.cursor;
/*  277 */     this.limit_backward = v_2;
/*  278 */     switch (among_var) {
/*      */     case 0:
/*  280 */       return false;
/*      */     case 1:
/*  283 */       if (!in_grouping_b(g_particle_end, 97, 246))
/*      */       {
/*  285 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 2:
/*  291 */       if (!r_R2())
/*      */       {
/*  293 */         return false;
/*      */       }
/*      */       break;
/*      */     }
/*      */ 
/*  298 */     slice_del();
/*  299 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_possessive()
/*      */   {
/*  309 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  311 */     if (this.cursor < this.I_p1)
/*      */     {
/*  313 */       return false;
/*      */     }
/*  315 */     this.cursor = this.I_p1;
/*  316 */     int v_2 = this.limit_backward;
/*  317 */     this.limit_backward = this.cursor;
/*  318 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  321 */     this.ket = this.cursor;
/*      */ 
/*  323 */     int among_var = find_among_b(a_4, 9);
/*  324 */     if (among_var == 0)
/*      */     {
/*  326 */       this.limit_backward = v_2;
/*  327 */       return false;
/*      */     }
/*      */ 
/*  330 */     this.bra = this.cursor;
/*  331 */     this.limit_backward = v_2;
/*  332 */     switch (among_var) {
/*      */     case 0:
/*  334 */       return false;
/*      */     case 1:
/*  339 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  342 */       if (eq_s_b(1, "k"))
/*      */       {
/*  346 */         return false;
/*      */       }
/*  348 */       this.cursor = (this.limit - v_3);
/*      */ 
/*  351 */       slice_del();
/*  352 */       break;
/*      */     case 2:
/*  356 */       slice_del();
/*      */ 
/*  358 */       this.ket = this.cursor;
/*      */ 
/*  360 */       if (!eq_s_b(3, "kse"))
/*      */       {
/*  362 */         return false;
/*      */       }
/*      */ 
/*  365 */       this.bra = this.cursor;
/*      */ 
/*  367 */       slice_from("ksi");
/*  368 */       break;
/*      */     case 3:
/*  372 */       slice_del();
/*  373 */       break;
/*      */     case 4:
/*  377 */       if (find_among_b(a_1, 6) == 0)
/*      */       {
/*  379 */         return false;
/*      */       }
/*      */ 
/*  382 */       slice_del();
/*  383 */       break;
/*      */     case 5:
/*  387 */       if (find_among_b(a_2, 6) == 0)
/*      */       {
/*  389 */         return false;
/*      */       }
/*      */ 
/*  392 */       slice_del();
/*  393 */       break;
/*      */     case 6:
/*  397 */       if (find_among_b(a_3, 2) == 0)
/*      */       {
/*  399 */         return false;
/*      */       }
/*      */ 
/*  402 */       slice_del();
/*      */     }
/*      */ 
/*  405 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_LONG()
/*      */   {
/*  410 */     if (find_among_b(a_5, 7) == 0)
/*      */     {
/*  412 */       return false;
/*      */     }
/*  414 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_VI()
/*      */   {
/*  420 */     if (!eq_s_b(1, "i"))
/*      */     {
/*  422 */       return false;
/*      */     }
/*  424 */     if (!in_grouping_b(g_V2, 97, 246))
/*      */     {
/*  426 */       return false;
/*      */     }
/*  428 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_case_ending()
/*      */   {
/*  440 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  442 */     if (this.cursor < this.I_p1)
/*      */     {
/*  444 */       return false;
/*      */     }
/*  446 */     this.cursor = this.I_p1;
/*  447 */     int v_2 = this.limit_backward;
/*  448 */     this.limit_backward = this.cursor;
/*  449 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  452 */     this.ket = this.cursor;
/*      */ 
/*  454 */     int among_var = find_among_b(a_6, 30);
/*  455 */     if (among_var == 0)
/*      */     {
/*  457 */       this.limit_backward = v_2;
/*  458 */       return false;
/*      */     }
/*      */ 
/*  461 */     this.bra = this.cursor;
/*  462 */     this.limit_backward = v_2;
/*  463 */     switch (among_var) {
/*      */     case 0:
/*  465 */       return false;
/*      */     case 1:
/*  469 */       if (!eq_s_b(1, "a"))
/*      */       {
/*  471 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 2:
/*  477 */       if (!eq_s_b(1, "e"))
/*      */       {
/*  479 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 3:
/*  485 */       if (!eq_s_b(1, "i"))
/*      */       {
/*  487 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 4:
/*  493 */       if (!eq_s_b(1, "o"))
/*      */       {
/*  495 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 5:
/*  501 */       if (!eq_s_b(1, "ä"))
/*      */       {
/*  503 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 6:
/*  509 */       if (!eq_s_b(1, "ö"))
/*      */       {
/*  511 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 7:
/*  517 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  521 */       int v_4 = this.limit - this.cursor;
/*      */ 
/*  524 */       int v_5 = this.limit - this.cursor;
/*      */ 
/*  527 */       if (!r_LONG())
/*      */       {
/*  533 */         this.cursor = (this.limit - v_5);
/*      */ 
/*  535 */         if (!eq_s_b(2, "ie"))
/*      */         {
/*  537 */           this.cursor = (this.limit - v_3);
/*  538 */           break;
/*      */         }
/*      */       }
/*  541 */       this.cursor = (this.limit - v_4);
/*      */ 
/*  543 */       if (this.cursor <= this.limit_backward)
/*      */       {
/*  545 */         this.cursor = (this.limit - v_3);
/*      */       }
/*      */       else {
/*  548 */         this.cursor -= 1;
/*      */ 
/*  550 */         this.bra = this.cursor;
/*      */       }
/*  552 */       break;
/*      */     case 8:
/*  555 */       if (!in_grouping_b(g_V1, 97, 246))
/*      */       {
/*  557 */         return false;
/*      */       }
/*  559 */       if (!out_grouping_b(g_V1, 97, 246))
/*      */       {
/*  561 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 9:
/*  567 */       if (!eq_s_b(1, "e"))
/*      */       {
/*  569 */         return false;
/*      */       }
/*      */       break;
/*      */     }
/*      */ 
/*  574 */     slice_del();
/*      */ 
/*  576 */     this.B_ending_removed = true;
/*  577 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_other_endings()
/*      */   {
/*  587 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  589 */     if (this.cursor < this.I_p2)
/*      */     {
/*  591 */       return false;
/*      */     }
/*  593 */     this.cursor = this.I_p2;
/*  594 */     int v_2 = this.limit_backward;
/*  595 */     this.limit_backward = this.cursor;
/*  596 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  599 */     this.ket = this.cursor;
/*      */ 
/*  601 */     int among_var = find_among_b(a_7, 14);
/*  602 */     if (among_var == 0)
/*      */     {
/*  604 */       this.limit_backward = v_2;
/*  605 */       return false;
/*      */     }
/*      */ 
/*  608 */     this.bra = this.cursor;
/*  609 */     this.limit_backward = v_2;
/*  610 */     switch (among_var) {
/*      */     case 0:
/*  612 */       return false;
/*      */     case 1:
/*  617 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  620 */       if (eq_s_b(2, "po"))
/*      */       {
/*  624 */         return false;
/*      */       }
/*  626 */       this.cursor = (this.limit - v_3);
/*      */     }
/*      */ 
/*  631 */     slice_del();
/*  632 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_i_plural()
/*      */   {
/*  640 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  642 */     if (this.cursor < this.I_p1)
/*      */     {
/*  644 */       return false;
/*      */     }
/*  646 */     this.cursor = this.I_p1;
/*  647 */     int v_2 = this.limit_backward;
/*  648 */     this.limit_backward = this.cursor;
/*  649 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  652 */     this.ket = this.cursor;
/*      */ 
/*  654 */     if (find_among_b(a_8, 2) == 0)
/*      */     {
/*  656 */       this.limit_backward = v_2;
/*  657 */       return false;
/*      */     }
/*      */ 
/*  660 */     this.bra = this.cursor;
/*  661 */     this.limit_backward = v_2;
/*      */ 
/*  663 */     slice_del();
/*  664 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_t_plural()
/*      */   {
/*  677 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  679 */     if (this.cursor < this.I_p1)
/*      */     {
/*  681 */       return false;
/*      */     }
/*  683 */     this.cursor = this.I_p1;
/*  684 */     int v_2 = this.limit_backward;
/*  685 */     this.limit_backward = this.cursor;
/*  686 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  689 */     this.ket = this.cursor;
/*      */ 
/*  691 */     if (!eq_s_b(1, "t"))
/*      */     {
/*  693 */       this.limit_backward = v_2;
/*  694 */       return false;
/*      */     }
/*      */ 
/*  697 */     this.bra = this.cursor;
/*      */ 
/*  699 */     int v_3 = this.limit - this.cursor;
/*  700 */     if (!in_grouping_b(g_V1, 97, 246))
/*      */     {
/*  702 */       this.limit_backward = v_2;
/*  703 */       return false;
/*      */     }
/*  705 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  707 */     slice_del();
/*  708 */     this.limit_backward = v_2;
/*      */ 
/*  710 */     int v_4 = this.limit - this.cursor;
/*      */ 
/*  712 */     if (this.cursor < this.I_p2)
/*      */     {
/*  714 */       return false;
/*      */     }
/*  716 */     this.cursor = this.I_p2;
/*  717 */     int v_5 = this.limit_backward;
/*  718 */     this.limit_backward = this.cursor;
/*  719 */     this.cursor = (this.limit - v_4);
/*      */ 
/*  722 */     this.ket = this.cursor;
/*      */ 
/*  724 */     int among_var = find_among_b(a_9, 2);
/*  725 */     if (among_var == 0)
/*      */     {
/*  727 */       this.limit_backward = v_5;
/*  728 */       return false;
/*      */     }
/*      */ 
/*  731 */     this.bra = this.cursor;
/*  732 */     this.limit_backward = v_5;
/*  733 */     switch (among_var) {
/*      */     case 0:
/*  735 */       return false;
/*      */     case 1:
/*  740 */       int v_6 = this.limit - this.cursor;
/*      */ 
/*  743 */       if (eq_s_b(2, "po"))
/*      */       {
/*  747 */         return false;
/*      */       }
/*  749 */       this.cursor = (this.limit - v_6);
/*      */     }
/*      */ 
/*  754 */     slice_del();
/*  755 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_tidy()
/*      */   {
/*  770 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  772 */     if (this.cursor < this.I_p1)
/*      */     {
/*  774 */       return false;
/*      */     }
/*  776 */     this.cursor = this.I_p1;
/*  777 */     int v_2 = this.limit_backward;
/*  778 */     this.limit_backward = this.cursor;
/*  779 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  782 */     int v_3 = this.limit - this.cursor;
/*      */ 
/*  786 */     int v_4 = this.limit - this.cursor;
/*      */ 
/*  788 */     if (r_LONG())
/*      */     {
/*  792 */       this.cursor = (this.limit - v_4);
/*      */ 
/*  795 */       this.ket = this.cursor;
/*      */ 
/*  797 */       if (this.cursor > this.limit_backward)
/*      */       {
/*  801 */         this.cursor -= 1;
/*      */ 
/*  803 */         this.bra = this.cursor;
/*      */ 
/*  805 */         slice_del();
/*      */       }
/*      */     }
/*  807 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  809 */     int v_5 = this.limit - this.cursor;
/*      */ 
/*  813 */     this.ket = this.cursor;
/*  814 */     if (in_grouping_b(g_AEI, 97, 228))
/*      */     {
/*  819 */       this.bra = this.cursor;
/*  820 */       if (out_grouping_b(g_V1, 97, 246))
/*      */       {
/*  825 */         slice_del();
/*      */       }
/*      */     }
/*  827 */     this.cursor = (this.limit - v_5);
/*      */ 
/*  829 */     int v_6 = this.limit - this.cursor;
/*      */ 
/*  833 */     this.ket = this.cursor;
/*      */ 
/*  835 */     if (eq_s_b(1, "j"))
/*      */     {
/*  840 */       this.bra = this.cursor;
/*      */ 
/*  843 */       int v_7 = this.limit - this.cursor;
/*      */ 
/*  846 */       if (!eq_s_b(1, "o"))
/*      */       {
/*  852 */         this.cursor = (this.limit - v_7);
/*      */ 
/*  854 */         if (!eq_s_b(1, "u"));
/*      */       }
/*      */       else
/*      */       {
/*  860 */         slice_del();
/*      */       }
/*      */     }
/*  862 */     this.cursor = (this.limit - v_6);
/*      */ 
/*  864 */     int v_8 = this.limit - this.cursor;
/*      */ 
/*  868 */     this.ket = this.cursor;
/*      */ 
/*  870 */     if (eq_s_b(1, "o"))
/*      */     {
/*  875 */       this.bra = this.cursor;
/*      */ 
/*  877 */       if (eq_s_b(1, "j"))
/*      */       {
/*  882 */         slice_del();
/*      */       }
/*      */     }
/*  884 */     this.cursor = (this.limit - v_8);
/*  885 */     this.limit_backward = v_2;
/*      */     while (true)
/*      */     {
/*  889 */       int v_9 = this.limit - this.cursor;
/*      */ 
/*  891 */       if (out_grouping_b(g_V1, 97, 246))
/*      */       {
/*  895 */         this.cursor = (this.limit - v_9);
/*  896 */         break;
/*      */       }
/*  898 */       this.cursor = (this.limit - v_9);
/*  899 */       if (this.cursor <= this.limit_backward)
/*      */       {
/*  901 */         return false;
/*      */       }
/*  903 */       this.cursor -= 1;
/*      */     }
/*      */ 
/*  906 */     this.ket = this.cursor;
/*      */ 
/*  908 */     if (this.cursor <= this.limit_backward)
/*      */     {
/*  910 */       return false;
/*      */     }
/*  912 */     this.cursor -= 1;
/*      */ 
/*  914 */     this.bra = this.cursor;
/*      */ 
/*  916 */     this.S_x = slice_to(this.S_x);
/*      */ 
/*  918 */     if (!eq_v_b(this.S_x))
/*      */     {
/*  920 */       return false;
/*      */     }
/*      */ 
/*  923 */     slice_del();
/*  924 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean stem()
/*      */   {
/*  940 */     int v_1 = this.cursor;
/*      */ 
/*  943 */     if (!r_mark_regions());
/*  948 */     this.cursor = v_1;
/*      */ 
/*  950 */     this.B_ending_removed = false;
/*      */ 
/*  952 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/*  955 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  958 */     if (!r_particle_etc());
/*  963 */     this.cursor = (this.limit - v_2);
/*      */ 
/*  965 */     int v_3 = this.limit - this.cursor;
/*      */ 
/*  968 */     if (!r_possessive());
/*  973 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  975 */     int v_4 = this.limit - this.cursor;
/*      */ 
/*  978 */     if (!r_case_ending());
/*  983 */     this.cursor = (this.limit - v_4);
/*      */ 
/*  985 */     int v_5 = this.limit - this.cursor;
/*      */ 
/*  988 */     if (!r_other_endings());
/*  993 */     this.cursor = (this.limit - v_5);
/*      */ 
/*  996 */     int v_6 = this.limit - this.cursor;
/*      */ 
/* 1000 */     if (this.B_ending_removed)
/*      */     {
/* 1005 */       int v_7 = this.limit - this.cursor;
/*      */ 
/* 1008 */       if (!r_i_plural());
/* 1013 */       this.cursor = (this.limit - v_7);
/*      */     }
/*      */     else {
/* 1016 */       this.cursor = (this.limit - v_6);
/*      */ 
/* 1018 */       int v_8 = this.limit - this.cursor;
/*      */ 
/* 1021 */       if (!r_t_plural());
/* 1026 */       this.cursor = (this.limit - v_8);
/*      */     }
/*      */ 
/* 1029 */     int v_9 = this.limit - this.cursor;
/*      */ 
/* 1032 */     if (!r_tidy());
/* 1037 */     this.cursor = (this.limit - v_9);
/* 1038 */     this.cursor = this.limit_backward; return true;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1043 */     return o instanceof FinnishStemmer;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1048 */     return FinnishStemmer.class.getName().hashCode();
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.tartarus.snowball.ext.FinnishStemmer
 * JD-Core Version:    0.6.2
 */