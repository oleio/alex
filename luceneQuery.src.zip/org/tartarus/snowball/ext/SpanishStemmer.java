/*      */ package org.tartarus.snowball.ext;
/*      */ 
/*      */ import org.tartarus.snowball.Among;
/*      */ import org.tartarus.snowball.SnowballProgram;
/*      */ 
/*      */ public class SpanishStemmer extends SnowballProgram
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   17 */   private static final SpanishStemmer methodObject = new SpanishStemmer();
/*      */ 
/*   19 */   private static final Among[] a_0 = { new Among("", -1, 6, "", methodObject), new Among("á", 0, 1, "", methodObject), new Among("é", 0, 2, "", methodObject), new Among("í", 0, 3, "", methodObject), new Among("ó", 0, 4, "", methodObject), new Among("ú", 0, 5, "", methodObject) };
/*      */ 
/*   28 */   private static final Among[] a_1 = { new Among("la", -1, -1, "", methodObject), new Among("sela", 0, -1, "", methodObject), new Among("le", -1, -1, "", methodObject), new Among("me", -1, -1, "", methodObject), new Among("se", -1, -1, "", methodObject), new Among("lo", -1, -1, "", methodObject), new Among("selo", 5, -1, "", methodObject), new Among("las", -1, -1, "", methodObject), new Among("selas", 7, -1, "", methodObject), new Among("les", -1, -1, "", methodObject), new Among("los", -1, -1, "", methodObject), new Among("selos", 10, -1, "", methodObject), new Among("nos", -1, -1, "", methodObject) };
/*      */ 
/*   44 */   private static final Among[] a_2 = { new Among("ando", -1, 6, "", methodObject), new Among("iendo", -1, 6, "", methodObject), new Among("yendo", -1, 7, "", methodObject), new Among("ándo", -1, 2, "", methodObject), new Among("iéndo", -1, 1, "", methodObject), new Among("ar", -1, 6, "", methodObject), new Among("er", -1, 6, "", methodObject), new Among("ir", -1, 6, "", methodObject), new Among("ár", -1, 3, "", methodObject), new Among("ér", -1, 4, "", methodObject), new Among("ír", -1, 5, "", methodObject) };
/*      */ 
/*   58 */   private static final Among[] a_3 = { new Among("ic", -1, -1, "", methodObject), new Among("ad", -1, -1, "", methodObject), new Among("os", -1, -1, "", methodObject), new Among("iv", -1, 1, "", methodObject) };
/*      */ 
/*   65 */   private static final Among[] a_4 = { new Among("able", -1, 1, "", methodObject), new Among("ible", -1, 1, "", methodObject), new Among("ante", -1, 1, "", methodObject) };
/*      */ 
/*   71 */   private static final Among[] a_5 = { new Among("ic", -1, 1, "", methodObject), new Among("abil", -1, 1, "", methodObject), new Among("iv", -1, 1, "", methodObject) };
/*      */ 
/*   77 */   private static final Among[] a_6 = { new Among("ica", -1, 1, "", methodObject), new Among("ancia", -1, 2, "", methodObject), new Among("encia", -1, 5, "", methodObject), new Among("adora", -1, 2, "", methodObject), new Among("osa", -1, 1, "", methodObject), new Among("ista", -1, 1, "", methodObject), new Among("iva", -1, 9, "", methodObject), new Among("anza", -1, 1, "", methodObject), new Among("logía", -1, 3, "", methodObject), new Among("idad", -1, 8, "", methodObject), new Among("able", -1, 1, "", methodObject), new Among("ible", -1, 1, "", methodObject), new Among("ante", -1, 2, "", methodObject), new Among("mente", -1, 7, "", methodObject), new Among("amente", 13, 6, "", methodObject), new Among("ación", -1, 2, "", methodObject), new Among("ución", -1, 4, "", methodObject), new Among("ico", -1, 1, "", methodObject), new Among("ismo", -1, 1, "", methodObject), new Among("oso", -1, 1, "", methodObject), new Among("amiento", -1, 1, "", methodObject), new Among("imiento", -1, 1, "", methodObject), new Among("ivo", -1, 9, "", methodObject), new Among("ador", -1, 2, "", methodObject), new Among("icas", -1, 1, "", methodObject), new Among("ancias", -1, 2, "", methodObject), new Among("encias", -1, 5, "", methodObject), new Among("adoras", -1, 2, "", methodObject), new Among("osas", -1, 1, "", methodObject), new Among("istas", -1, 1, "", methodObject), new Among("ivas", -1, 9, "", methodObject), new Among("anzas", -1, 1, "", methodObject), new Among("logías", -1, 3, "", methodObject), new Among("idades", -1, 8, "", methodObject), new Among("ables", -1, 1, "", methodObject), new Among("ibles", -1, 1, "", methodObject), new Among("aciones", -1, 2, "", methodObject), new Among("uciones", -1, 4, "", methodObject), new Among("adores", -1, 2, "", methodObject), new Among("antes", -1, 2, "", methodObject), new Among("icos", -1, 1, "", methodObject), new Among("ismos", -1, 1, "", methodObject), new Among("osos", -1, 1, "", methodObject), new Among("amientos", -1, 1, "", methodObject), new Among("imientos", -1, 1, "", methodObject), new Among("ivos", -1, 9, "", methodObject) };
/*      */ 
/*  126 */   private static final Among[] a_7 = { new Among("ya", -1, 1, "", methodObject), new Among("ye", -1, 1, "", methodObject), new Among("yan", -1, 1, "", methodObject), new Among("yen", -1, 1, "", methodObject), new Among("yeron", -1, 1, "", methodObject), new Among("yendo", -1, 1, "", methodObject), new Among("yo", -1, 1, "", methodObject), new Among("yas", -1, 1, "", methodObject), new Among("yes", -1, 1, "", methodObject), new Among("yais", -1, 1, "", methodObject), new Among("yamos", -1, 1, "", methodObject), new Among("yó", -1, 1, "", methodObject) };
/*      */ 
/*  141 */   private static final Among[] a_8 = { new Among("aba", -1, 2, "", methodObject), new Among("ada", -1, 2, "", methodObject), new Among("ida", -1, 2, "", methodObject), new Among("ara", -1, 2, "", methodObject), new Among("iera", -1, 2, "", methodObject), new Among("ía", -1, 2, "", methodObject), new Among("aría", 5, 2, "", methodObject), new Among("ería", 5, 2, "", methodObject), new Among("iría", 5, 2, "", methodObject), new Among("ad", -1, 2, "", methodObject), new Among("ed", -1, 2, "", methodObject), new Among("id", -1, 2, "", methodObject), new Among("ase", -1, 2, "", methodObject), new Among("iese", -1, 2, "", methodObject), new Among("aste", -1, 2, "", methodObject), new Among("iste", -1, 2, "", methodObject), new Among("an", -1, 2, "", methodObject), new Among("aban", 16, 2, "", methodObject), new Among("aran", 16, 2, "", methodObject), new Among("ieran", 16, 2, "", methodObject), new Among("ían", 16, 2, "", methodObject), new Among("arían", 20, 2, "", methodObject), new Among("erían", 20, 2, "", methodObject), new Among("irían", 20, 2, "", methodObject), new Among("en", -1, 1, "", methodObject), new Among("asen", 24, 2, "", methodObject), new Among("iesen", 24, 2, "", methodObject), new Among("aron", -1, 2, "", methodObject), new Among("ieron", -1, 2, "", methodObject), new Among("arán", -1, 2, "", methodObject), new Among("erán", -1, 2, "", methodObject), new Among("irán", -1, 2, "", methodObject), new Among("ado", -1, 2, "", methodObject), new Among("ido", -1, 2, "", methodObject), new Among("ando", -1, 2, "", methodObject), new Among("iendo", -1, 2, "", methodObject), new Among("ar", -1, 2, "", methodObject), new Among("er", -1, 2, "", methodObject), new Among("ir", -1, 2, "", methodObject), new Among("as", -1, 2, "", methodObject), new Among("abas", 39, 2, "", methodObject), new Among("adas", 39, 2, "", methodObject), new Among("idas", 39, 2, "", methodObject), new Among("aras", 39, 2, "", methodObject), new Among("ieras", 39, 2, "", methodObject), new Among("ías", 39, 2, "", methodObject), new Among("arías", 45, 2, "", methodObject), new Among("erías", 45, 2, "", methodObject), new Among("irías", 45, 2, "", methodObject), new Among("es", -1, 1, "", methodObject), new Among("ases", 49, 2, "", methodObject), new Among("ieses", 49, 2, "", methodObject), new Among("abais", -1, 2, "", methodObject), new Among("arais", -1, 2, "", methodObject), new Among("ierais", -1, 2, "", methodObject), new Among("íais", -1, 2, "", methodObject), new Among("aríais", 55, 2, "", methodObject), new Among("eríais", 55, 2, "", methodObject), new Among("iríais", 55, 2, "", methodObject), new Among("aseis", -1, 2, "", methodObject), new Among("ieseis", -1, 2, "", methodObject), new Among("asteis", -1, 2, "", methodObject), new Among("isteis", -1, 2, "", methodObject), new Among("áis", -1, 2, "", methodObject), new Among("éis", -1, 1, "", methodObject), new Among("aréis", 64, 2, "", methodObject), new Among("eréis", 64, 2, "", methodObject), new Among("iréis", 64, 2, "", methodObject), new Among("ados", -1, 2, "", methodObject), new Among("idos", -1, 2, "", methodObject), new Among("amos", -1, 2, "", methodObject), new Among("ábamos", 70, 2, "", methodObject), new Among("áramos", 70, 2, "", methodObject), new Among("iéramos", 70, 2, "", methodObject), new Among("íamos", 70, 2, "", methodObject), new Among("aríamos", 74, 2, "", methodObject), new Among("eríamos", 74, 2, "", methodObject), new Among("iríamos", 74, 2, "", methodObject), new Among("emos", -1, 1, "", methodObject), new Among("aremos", 78, 2, "", methodObject), new Among("eremos", 78, 2, "", methodObject), new Among("iremos", 78, 2, "", methodObject), new Among("ásemos", 78, 2, "", methodObject), new Among("iésemos", 78, 2, "", methodObject), new Among("imos", -1, 2, "", methodObject), new Among("arás", -1, 2, "", methodObject), new Among("erás", -1, 2, "", methodObject), new Among("irás", -1, 2, "", methodObject), new Among("ís", -1, 2, "", methodObject), new Among("ará", -1, 2, "", methodObject), new Among("erá", -1, 2, "", methodObject), new Among("irá", -1, 2, "", methodObject), new Among("aré", -1, 2, "", methodObject), new Among("eré", -1, 2, "", methodObject), new Among("iré", -1, 2, "", methodObject), new Among("ió", -1, 2, "", methodObject) };
/*      */ 
/*  240 */   private static final Among[] a_9 = { new Among("a", -1, 1, "", methodObject), new Among("e", -1, 2, "", methodObject), new Among("o", -1, 1, "", methodObject), new Among("os", -1, 1, "", methodObject), new Among("á", -1, 1, "", methodObject), new Among("é", -1, 2, "", methodObject), new Among("í", -1, 1, "", methodObject), new Among("ó", -1, 1, "", methodObject) };
/*      */ 
/*  251 */   private static final char[] g_v = { '\021', 'A', '\020', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\001', '\021', '\004', '\n' };
/*      */   private int I_p2;
/*      */   private int I_p1;
/*      */   private int I_pV;
/*      */ 
/*      */   private void copy_from(SpanishStemmer other)
/*      */   {
/*  258 */     this.I_p2 = other.I_p2;
/*  259 */     this.I_p1 = other.I_p1;
/*  260 */     this.I_pV = other.I_pV;
/*  261 */     super.copy_from(other);
/*      */   }
/*      */ 
/*      */   private boolean r_mark_regions()
/*      */   {
/*  271 */     this.I_pV = this.limit;
/*  272 */     this.I_p1 = this.limit;
/*  273 */     this.I_p2 = this.limit;
/*      */ 
/*  275 */     int v_1 = this.cursor;
/*      */ 
/*  280 */     int v_2 = this.cursor;
/*      */ 
/*  283 */     if (in_grouping(g_v, 97, 252))
/*      */     {
/*  289 */       int v_3 = this.cursor;
/*      */ 
/*  292 */       if (out_grouping(g_v, 97, 252))
/*      */       {
/*      */         while (true)
/*      */         {
/*  300 */           if (in_grouping(g_v, 97, 252))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  306 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  310 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */ 
/*  314 */       this.cursor = v_3;
/*      */ 
/*  316 */       if (in_grouping(g_v, 97, 252))
/*      */       {
/*      */         while (true)
/*      */         {
/*  324 */           if (out_grouping(g_v, 97, 252))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  330 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  334 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  339 */     this.cursor = v_2;
/*      */ 
/*  341 */     if (out_grouping(g_v, 97, 252))
/*      */     {
/*  347 */       int v_6 = this.cursor;
/*      */ 
/*  350 */       if (out_grouping(g_v, 97, 252))
/*      */       {
/*      */         while (true)
/*      */         {
/*  358 */           if (in_grouping(g_v, 97, 252))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  364 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  368 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */ 
/*  372 */       this.cursor = v_6;
/*      */ 
/*  374 */       if (in_grouping(g_v, 97, 252))
/*      */       {
/*  379 */         if (this.cursor < this.limit)
/*      */         {
/*  383 */           this.cursor += 1;
/*      */ 
/*  387 */           label319: this.I_pV = this.cursor;
/*      */         }
/*      */       }
/*      */     }
/*  389 */     this.cursor = v_1;
/*      */ 
/*  391 */     int v_8 = this.cursor;
/*      */ 
/*  398 */     while (!in_grouping(g_v, 97, 252))
/*      */     {
/*  404 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  408 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  414 */     while (!out_grouping(g_v, 97, 252))
/*      */     {
/*  420 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  424 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  427 */     this.I_p1 = this.cursor;
/*      */ 
/*  432 */     while (!in_grouping(g_v, 97, 252))
/*      */     {
/*  438 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  442 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  448 */     while (!out_grouping(g_v, 97, 252))
/*      */     {
/*  454 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  458 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  461 */     this.I_p2 = this.cursor;
/*      */ 
/*  463 */     label522: this.cursor = v_8;
/*  464 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_postlude()
/*      */   {
/*      */     int v_1;
/*      */     while (true)
/*      */     {
/*  473 */       v_1 = this.cursor;
/*      */ 
/*  477 */       this.bra = this.cursor;
/*      */ 
/*  479 */       int among_var = find_among(a_0, 6);
/*  480 */       if (among_var == 0)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  485 */       this.ket = this.cursor;
/*  486 */       switch (among_var) {
/*      */       case 0:
/*  488 */         break;
/*      */       case 1:
/*  492 */         slice_from("a");
/*  493 */         break;
/*      */       case 2:
/*  497 */         slice_from("e");
/*  498 */         break;
/*      */       case 3:
/*  502 */         slice_from("i");
/*  503 */         break;
/*      */       case 4:
/*  507 */         slice_from("o");
/*  508 */         break;
/*      */       case 5:
/*  512 */         slice_from("u");
/*  513 */         break;
/*      */       case 6:
/*  517 */         if (this.cursor >= this.limit)
/*      */         {
/*      */           break label155;
/*      */         }
/*  521 */         this.cursor += 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  526 */     label155: this.cursor = v_1;
/*      */ 
/*  529 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_RV() {
/*  533 */     if (this.I_pV > this.cursor)
/*      */     {
/*  535 */       return false;
/*      */     }
/*  537 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R1() {
/*  541 */     if (this.I_p1 > this.cursor)
/*      */     {
/*  543 */       return false;
/*      */     }
/*  545 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R2() {
/*  549 */     if (this.I_p2 > this.cursor)
/*      */     {
/*  551 */       return false;
/*      */     }
/*  553 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_attached_pronoun()
/*      */   {
/*  560 */     this.ket = this.cursor;
/*      */ 
/*  562 */     if (find_among_b(a_1, 13) == 0)
/*      */     {
/*  564 */       return false;
/*      */     }
/*      */ 
/*  567 */     this.bra = this.cursor;
/*      */ 
/*  569 */     int among_var = find_among_b(a_2, 11);
/*  570 */     if (among_var == 0)
/*      */     {
/*  572 */       return false;
/*      */     }
/*      */ 
/*  575 */     if (!r_RV())
/*      */     {
/*  577 */       return false;
/*      */     }
/*  579 */     switch (among_var) {
/*      */     case 0:
/*  581 */       return false;
/*      */     case 1:
/*  585 */       this.bra = this.cursor;
/*      */ 
/*  587 */       slice_from("iendo");
/*  588 */       break;
/*      */     case 2:
/*  592 */       this.bra = this.cursor;
/*      */ 
/*  594 */       slice_from("ando");
/*  595 */       break;
/*      */     case 3:
/*  599 */       this.bra = this.cursor;
/*      */ 
/*  601 */       slice_from("ar");
/*  602 */       break;
/*      */     case 4:
/*  606 */       this.bra = this.cursor;
/*      */ 
/*  608 */       slice_from("er");
/*  609 */       break;
/*      */     case 5:
/*  613 */       this.bra = this.cursor;
/*      */ 
/*  615 */       slice_from("ir");
/*  616 */       break;
/*      */     case 6:
/*  620 */       slice_del();
/*  621 */       break;
/*      */     case 7:
/*  625 */       if (!eq_s_b(1, "u"))
/*      */       {
/*  627 */         return false;
/*      */       }
/*      */ 
/*  630 */       slice_del();
/*      */     }
/*      */ 
/*  633 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_standard_suffix()
/*      */   {
/*  645 */     this.ket = this.cursor;
/*      */ 
/*  647 */     int among_var = find_among_b(a_6, 46);
/*  648 */     if (among_var == 0)
/*      */     {
/*  650 */       return false;
/*      */     }
/*      */ 
/*  653 */     this.bra = this.cursor;
/*  654 */     switch (among_var) {
/*      */     case 0:
/*  656 */       return false;
/*      */     case 1:
/*  660 */       if (!r_R2())
/*      */       {
/*  662 */         return false;
/*      */       }
/*      */ 
/*  665 */       slice_del();
/*  666 */       break;
/*      */     case 2:
/*  670 */       if (!r_R2())
/*      */       {
/*  672 */         return false;
/*      */       }
/*      */ 
/*  675 */       slice_del();
/*      */ 
/*  677 */       int v_1 = this.limit - this.cursor;
/*      */ 
/*  681 */       this.ket = this.cursor;
/*      */ 
/*  683 */       if (!eq_s_b(2, "ic"))
/*      */       {
/*  685 */         this.cursor = (this.limit - v_1);
/*      */       }
/*      */       else
/*      */       {
/*  689 */         this.bra = this.cursor;
/*      */ 
/*  691 */         if (!r_R2())
/*      */         {
/*  693 */           this.cursor = (this.limit - v_1);
/*      */         }
/*      */         else
/*      */         {
/*  697 */           slice_del();
/*      */         }
/*      */       }
/*  699 */       break;
/*      */     case 3:
/*  703 */       if (!r_R2())
/*      */       {
/*  705 */         return false;
/*      */       }
/*      */ 
/*  708 */       slice_from("log");
/*  709 */       break;
/*      */     case 4:
/*  713 */       if (!r_R2())
/*      */       {
/*  715 */         return false;
/*      */       }
/*      */ 
/*  718 */       slice_from("u");
/*  719 */       break;
/*      */     case 5:
/*  723 */       if (!r_R2())
/*      */       {
/*  725 */         return false;
/*      */       }
/*      */ 
/*  728 */       slice_from("ente");
/*  729 */       break;
/*      */     case 6:
/*  733 */       if (!r_R1())
/*      */       {
/*  735 */         return false;
/*      */       }
/*      */ 
/*  738 */       slice_del();
/*      */ 
/*  740 */       int v_2 = this.limit - this.cursor;
/*      */ 
/*  744 */       this.ket = this.cursor;
/*      */ 
/*  746 */       among_var = find_among_b(a_3, 4);
/*  747 */       if (among_var == 0)
/*      */       {
/*  749 */         this.cursor = (this.limit - v_2);
/*      */       }
/*      */       else
/*      */       {
/*  753 */         this.bra = this.cursor;
/*      */ 
/*  755 */         if (!r_R2())
/*      */         {
/*  757 */           this.cursor = (this.limit - v_2);
/*      */         }
/*      */         else
/*      */         {
/*  761 */           slice_del();
/*  762 */           switch (among_var) {
/*      */           case 0:
/*  764 */             this.cursor = (this.limit - v_2);
/*  765 */             break;
/*      */           case 1:
/*  769 */             this.ket = this.cursor;
/*      */ 
/*  771 */             if (!eq_s_b(2, "at"))
/*      */             {
/*  773 */               this.cursor = (this.limit - v_2);
/*      */             }
/*      */             else
/*      */             {
/*  777 */               this.bra = this.cursor;
/*      */ 
/*  779 */               if (!r_R2())
/*      */               {
/*  781 */                 this.cursor = (this.limit - v_2);
/*      */               }
/*      */               else
/*      */               {
/*  785 */                 slice_del(); }  } break;
/*      */           }
/*      */         }
/*      */       }
/*  789 */       break;
/*      */     case 7:
/*  793 */       if (!r_R2())
/*      */       {
/*  795 */         return false;
/*      */       }
/*      */ 
/*  798 */       slice_del();
/*      */ 
/*  800 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  804 */       this.ket = this.cursor;
/*      */ 
/*  806 */       among_var = find_among_b(a_4, 3);
/*  807 */       if (among_var == 0)
/*      */       {
/*  809 */         this.cursor = (this.limit - v_3);
/*      */       }
/*      */       else
/*      */       {
/*  813 */         this.bra = this.cursor;
/*  814 */         switch (among_var) {
/*      */         case 0:
/*  816 */           this.cursor = (this.limit - v_3);
/*  817 */           break;
/*      */         case 1:
/*  821 */           if (!r_R2())
/*      */           {
/*  823 */             this.cursor = (this.limit - v_3);
/*      */           }
/*      */           else
/*      */           {
/*  827 */             slice_del();
/*      */           }break;
/*      */         }
/*      */       }
/*  831 */       break;
/*      */     case 8:
/*  835 */       if (!r_R2())
/*      */       {
/*  837 */         return false;
/*      */       }
/*      */ 
/*  840 */       slice_del();
/*      */ 
/*  842 */       int v_4 = this.limit - this.cursor;
/*      */ 
/*  846 */       this.ket = this.cursor;
/*      */ 
/*  848 */       among_var = find_among_b(a_5, 3);
/*  849 */       if (among_var == 0)
/*      */       {
/*  851 */         this.cursor = (this.limit - v_4);
/*      */       }
/*      */       else
/*      */       {
/*  855 */         this.bra = this.cursor;
/*  856 */         switch (among_var) {
/*      */         case 0:
/*  858 */           this.cursor = (this.limit - v_4);
/*  859 */           break;
/*      */         case 1:
/*  863 */           if (!r_R2())
/*      */           {
/*  865 */             this.cursor = (this.limit - v_4);
/*      */           }
/*      */           else
/*      */           {
/*  869 */             slice_del();
/*      */           }break;
/*      */         }
/*      */       }
/*  873 */       break;
/*      */     case 9:
/*  877 */       if (!r_R2())
/*      */       {
/*  879 */         return false;
/*      */       }
/*      */ 
/*  882 */       slice_del();
/*      */ 
/*  884 */       int v_5 = this.limit - this.cursor;
/*      */ 
/*  888 */       this.ket = this.cursor;
/*      */ 
/*  890 */       if (!eq_s_b(2, "at"))
/*      */       {
/*  892 */         this.cursor = (this.limit - v_5);
/*      */       }
/*      */       else
/*      */       {
/*  896 */         this.bra = this.cursor;
/*      */ 
/*  898 */         if (!r_R2())
/*      */         {
/*  900 */           this.cursor = (this.limit - v_5);
/*      */         }
/*      */         else
/*      */         {
/*  904 */           slice_del();
/*      */         }
/*      */       }
/*      */       break;
/*      */     }
/*  908 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_y_verb_suffix()
/*      */   {
/*  917 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  919 */     if (this.cursor < this.I_pV)
/*      */     {
/*  921 */       return false;
/*      */     }
/*  923 */     this.cursor = this.I_pV;
/*  924 */     int v_2 = this.limit_backward;
/*  925 */     this.limit_backward = this.cursor;
/*  926 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  929 */     this.ket = this.cursor;
/*      */ 
/*  931 */     int among_var = find_among_b(a_7, 12);
/*  932 */     if (among_var == 0)
/*      */     {
/*  934 */       this.limit_backward = v_2;
/*  935 */       return false;
/*      */     }
/*      */ 
/*  938 */     this.bra = this.cursor;
/*  939 */     this.limit_backward = v_2;
/*  940 */     switch (among_var) {
/*      */     case 0:
/*  942 */       return false;
/*      */     case 1:
/*  946 */       if (!eq_s_b(1, "u"))
/*      */       {
/*  948 */         return false;
/*      */       }
/*      */ 
/*  951 */       slice_del();
/*      */     }
/*      */ 
/*  954 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_verb_suffix()
/*      */   {
/*  965 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  967 */     if (this.cursor < this.I_pV)
/*      */     {
/*  969 */       return false;
/*      */     }
/*  971 */     this.cursor = this.I_pV;
/*  972 */     int v_2 = this.limit_backward;
/*  973 */     this.limit_backward = this.cursor;
/*  974 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  977 */     this.ket = this.cursor;
/*      */ 
/*  979 */     int among_var = find_among_b(a_8, 96);
/*  980 */     if (among_var == 0)
/*      */     {
/*  982 */       this.limit_backward = v_2;
/*  983 */       return false;
/*      */     }
/*      */ 
/*  986 */     this.bra = this.cursor;
/*  987 */     this.limit_backward = v_2;
/*  988 */     switch (among_var) {
/*      */     case 0:
/*  990 */       return false;
/*      */     case 1:
/*  994 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  998 */       if (!eq_s_b(1, "u"))
/*      */       {
/* 1000 */         this.cursor = (this.limit - v_3);
/*      */       }
/*      */       else
/*      */       {
/* 1004 */         int v_4 = this.limit - this.cursor;
/*      */ 
/* 1006 */         if (!eq_s_b(1, "g"))
/*      */         {
/* 1008 */           this.cursor = (this.limit - v_3);
/*      */         }
/*      */         else {
/* 1011 */           this.cursor = (this.limit - v_4);
/*      */         }
/*      */       }
/* 1014 */       this.bra = this.cursor;
/*      */ 
/* 1016 */       slice_del();
/* 1017 */       break;
/*      */     case 2:
/* 1021 */       slice_del();
/*      */     }
/*      */ 
/* 1024 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_residual_suffix()
/*      */   {
/* 1033 */     this.ket = this.cursor;
/*      */ 
/* 1035 */     int among_var = find_among_b(a_9, 8);
/* 1036 */     if (among_var == 0)
/*      */     {
/* 1038 */       return false;
/*      */     }
/*      */ 
/* 1041 */     this.bra = this.cursor;
/* 1042 */     switch (among_var) {
/*      */     case 0:
/* 1044 */       return false;
/*      */     case 1:
/* 1048 */       if (!r_RV())
/*      */       {
/* 1050 */         return false;
/*      */       }
/*      */ 
/* 1053 */       slice_del();
/* 1054 */       break;
/*      */     case 2:
/* 1058 */       if (!r_RV())
/*      */       {
/* 1060 */         return false;
/*      */       }
/*      */ 
/* 1063 */       slice_del();
/*      */ 
/* 1065 */       int v_1 = this.limit - this.cursor;
/*      */ 
/* 1069 */       this.ket = this.cursor;
/*      */ 
/* 1071 */       if (!eq_s_b(1, "u"))
/*      */       {
/* 1073 */         this.cursor = (this.limit - v_1);
/*      */       }
/*      */       else
/*      */       {
/* 1077 */         this.bra = this.cursor;
/*      */ 
/* 1079 */         int v_2 = this.limit - this.cursor;
/*      */ 
/* 1081 */         if (!eq_s_b(1, "g"))
/*      */         {
/* 1083 */           this.cursor = (this.limit - v_1);
/*      */         }
/*      */         else {
/* 1086 */           this.cursor = (this.limit - v_2);
/*      */ 
/* 1088 */           if (!r_RV())
/*      */           {
/* 1090 */             this.cursor = (this.limit - v_1);
/*      */           }
/*      */           else
/*      */           {
/* 1094 */             slice_del();
/*      */           }
/*      */         }
/*      */       }
/*      */       break;
/*      */     }
/* 1098 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean stem()
/*      */   {
/* 1111 */     int v_1 = this.cursor;
/*      */ 
/* 1114 */     if (!r_mark_regions());
/* 1119 */     this.cursor = v_1;
/*      */ 
/* 1121 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 1124 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1127 */     if (!r_attached_pronoun());
/* 1132 */     this.cursor = (this.limit - v_2);
/*      */ 
/* 1134 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1139 */     int v_4 = this.limit - this.cursor;
/*      */ 
/* 1142 */     if (!r_standard_suffix())
/*      */     {
/* 1148 */       this.cursor = (this.limit - v_4);
/*      */ 
/* 1151 */       if (!r_y_verb_suffix())
/*      */       {
/* 1157 */         this.cursor = (this.limit - v_4);
/*      */ 
/* 1159 */         if (r_verb_suffix());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1165 */     this.cursor = (this.limit - v_3);
/*      */ 
/* 1167 */     int v_5 = this.limit - this.cursor;
/*      */ 
/* 1170 */     if (!r_residual_suffix());
/* 1175 */     this.cursor = (this.limit - v_5);
/* 1176 */     this.cursor = this.limit_backward;
/* 1177 */     int v_6 = this.cursor;
/*      */ 
/* 1180 */     if (!r_postlude());
/* 1185 */     this.cursor = v_6;
/* 1186 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1191 */     return o instanceof SpanishStemmer;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1196 */     return SpanishStemmer.class.getName().hashCode();
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.tartarus.snowball.ext.SpanishStemmer
 * JD-Core Version:    0.6.2
 */