/*      */ package org.tartarus.snowball.ext;
/*      */ 
/*      */ import org.tartarus.snowball.Among;
/*      */ import org.tartarus.snowball.SnowballProgram;
/*      */ 
/*      */ public class RomanianStemmer extends SnowballProgram
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   17 */   private static final RomanianStemmer methodObject = new RomanianStemmer();
/*      */ 
/*   19 */   private static final Among[] a_0 = { new Among("", -1, 3, "", methodObject), new Among("I", 0, 1, "", methodObject), new Among("U", 0, 2, "", methodObject) };
/*      */ 
/*   25 */   private static final Among[] a_1 = { new Among("ea", -1, 3, "", methodObject), new Among("aţia", -1, 7, "", methodObject), new Among("aua", -1, 2, "", methodObject), new Among("iua", -1, 4, "", methodObject), new Among("aţie", -1, 7, "", methodObject), new Among("ele", -1, 3, "", methodObject), new Among("ile", -1, 5, "", methodObject), new Among("iile", 6, 4, "", methodObject), new Among("iei", -1, 4, "", methodObject), new Among("atei", -1, 6, "", methodObject), new Among("ii", -1, 4, "", methodObject), new Among("ului", -1, 1, "", methodObject), new Among("ul", -1, 1, "", methodObject), new Among("elor", -1, 3, "", methodObject), new Among("ilor", -1, 4, "", methodObject), new Among("iilor", 14, 4, "", methodObject) };
/*      */ 
/*   44 */   private static final Among[] a_2 = { new Among("icala", -1, 4, "", methodObject), new Among("iciva", -1, 4, "", methodObject), new Among("ativa", -1, 5, "", methodObject), new Among("itiva", -1, 6, "", methodObject), new Among("icale", -1, 4, "", methodObject), new Among("aţiune", -1, 5, "", methodObject), new Among("iţiune", -1, 6, "", methodObject), new Among("atoare", -1, 5, "", methodObject), new Among("itoare", -1, 6, "", methodObject), new Among("ătoare", -1, 5, "", methodObject), new Among("icitate", -1, 4, "", methodObject), new Among("abilitate", -1, 1, "", methodObject), new Among("ibilitate", -1, 2, "", methodObject), new Among("ivitate", -1, 3, "", methodObject), new Among("icive", -1, 4, "", methodObject), new Among("ative", -1, 5, "", methodObject), new Among("itive", -1, 6, "", methodObject), new Among("icali", -1, 4, "", methodObject), new Among("atori", -1, 5, "", methodObject), new Among("icatori", 18, 4, "", methodObject), new Among("itori", -1, 6, "", methodObject), new Among("ători", -1, 5, "", methodObject), new Among("icitati", -1, 4, "", methodObject), new Among("abilitati", -1, 1, "", methodObject), new Among("ivitati", -1, 3, "", methodObject), new Among("icivi", -1, 4, "", methodObject), new Among("ativi", -1, 5, "", methodObject), new Among("itivi", -1, 6, "", methodObject), new Among("icităi", -1, 4, "", methodObject), new Among("abilităi", -1, 1, "", methodObject), new Among("ivităi", -1, 3, "", methodObject), new Among("icităţi", -1, 4, "", methodObject), new Among("abilităţi", -1, 1, "", methodObject), new Among("ivităţi", -1, 3, "", methodObject), new Among("ical", -1, 4, "", methodObject), new Among("ator", -1, 5, "", methodObject), new Among("icator", 35, 4, "", methodObject), new Among("itor", -1, 6, "", methodObject), new Among("ător", -1, 5, "", methodObject), new Among("iciv", -1, 4, "", methodObject), new Among("ativ", -1, 5, "", methodObject), new Among("itiv", -1, 6, "", methodObject), new Among("icală", -1, 4, "", methodObject), new Among("icivă", -1, 4, "", methodObject), new Among("ativă", -1, 5, "", methodObject), new Among("itivă", -1, 6, "", methodObject) };
/*      */ 
/*   93 */   private static final Among[] a_3 = { new Among("ica", -1, 1, "", methodObject), new Among("abila", -1, 1, "", methodObject), new Among("ibila", -1, 1, "", methodObject), new Among("oasa", -1, 1, "", methodObject), new Among("ata", -1, 1, "", methodObject), new Among("ita", -1, 1, "", methodObject), new Among("anta", -1, 1, "", methodObject), new Among("ista", -1, 3, "", methodObject), new Among("uta", -1, 1, "", methodObject), new Among("iva", -1, 1, "", methodObject), new Among("ic", -1, 1, "", methodObject), new Among("ice", -1, 1, "", methodObject), new Among("abile", -1, 1, "", methodObject), new Among("ibile", -1, 1, "", methodObject), new Among("isme", -1, 3, "", methodObject), new Among("iune", -1, 2, "", methodObject), new Among("oase", -1, 1, "", methodObject), new Among("ate", -1, 1, "", methodObject), new Among("itate", 17, 1, "", methodObject), new Among("ite", -1, 1, "", methodObject), new Among("ante", -1, 1, "", methodObject), new Among("iste", -1, 3, "", methodObject), new Among("ute", -1, 1, "", methodObject), new Among("ive", -1, 1, "", methodObject), new Among("ici", -1, 1, "", methodObject), new Among("abili", -1, 1, "", methodObject), new Among("ibili", -1, 1, "", methodObject), new Among("iuni", -1, 2, "", methodObject), new Among("atori", -1, 1, "", methodObject), new Among("osi", -1, 1, "", methodObject), new Among("ati", -1, 1, "", methodObject), new Among("itati", 30, 1, "", methodObject), new Among("iti", -1, 1, "", methodObject), new Among("anti", -1, 1, "", methodObject), new Among("isti", -1, 3, "", methodObject), new Among("uti", -1, 1, "", methodObject), new Among("işti", -1, 3, "", methodObject), new Among("ivi", -1, 1, "", methodObject), new Among("ităi", -1, 1, "", methodObject), new Among("oşi", -1, 1, "", methodObject), new Among("ităţi", -1, 1, "", methodObject), new Among("abil", -1, 1, "", methodObject), new Among("ibil", -1, 1, "", methodObject), new Among("ism", -1, 3, "", methodObject), new Among("ator", -1, 1, "", methodObject), new Among("os", -1, 1, "", methodObject), new Among("at", -1, 1, "", methodObject), new Among("it", -1, 1, "", methodObject), new Among("ant", -1, 1, "", methodObject), new Among("ist", -1, 3, "", methodObject), new Among("ut", -1, 1, "", methodObject), new Among("iv", -1, 1, "", methodObject), new Among("ică", -1, 1, "", methodObject), new Among("abilă", -1, 1, "", methodObject), new Among("ibilă", -1, 1, "", methodObject), new Among("oasă", -1, 1, "", methodObject), new Among("ată", -1, 1, "", methodObject), new Among("ită", -1, 1, "", methodObject), new Among("antă", -1, 1, "", methodObject), new Among("istă", -1, 3, "", methodObject), new Among("ută", -1, 1, "", methodObject), new Among("ivă", -1, 1, "", methodObject) };
/*      */ 
/*  158 */   private static final Among[] a_4 = { new Among("ea", -1, 1, "", methodObject), new Among("ia", -1, 1, "", methodObject), new Among("esc", -1, 1, "", methodObject), new Among("ăsc", -1, 1, "", methodObject), new Among("ind", -1, 1, "", methodObject), new Among("ând", -1, 1, "", methodObject), new Among("are", -1, 1, "", methodObject), new Among("ere", -1, 1, "", methodObject), new Among("ire", -1, 1, "", methodObject), new Among("âre", -1, 1, "", methodObject), new Among("se", -1, 2, "", methodObject), new Among("ase", 10, 1, "", methodObject), new Among("sese", 10, 2, "", methodObject), new Among("ise", 10, 1, "", methodObject), new Among("use", 10, 1, "", methodObject), new Among("âse", 10, 1, "", methodObject), new Among("eşte", -1, 1, "", methodObject), new Among("ăşte", -1, 1, "", methodObject), new Among("eze", -1, 1, "", methodObject), new Among("ai", -1, 1, "", methodObject), new Among("eai", 19, 1, "", methodObject), new Among("iai", 19, 1, "", methodObject), new Among("sei", -1, 2, "", methodObject), new Among("eşti", -1, 1, "", methodObject), new Among("ăşti", -1, 1, "", methodObject), new Among("ui", -1, 1, "", methodObject), new Among("ezi", -1, 1, "", methodObject), new Among("âi", -1, 1, "", methodObject), new Among("aşi", -1, 1, "", methodObject), new Among("seşi", -1, 2, "", methodObject), new Among("aseşi", 29, 1, "", methodObject), new Among("seseşi", 29, 2, "", methodObject), new Among("iseşi", 29, 1, "", methodObject), new Among("useşi", 29, 1, "", methodObject), new Among("âseşi", 29, 1, "", methodObject), new Among("işi", -1, 1, "", methodObject), new Among("uşi", -1, 1, "", methodObject), new Among("âşi", -1, 1, "", methodObject), new Among("aţi", -1, 2, "", methodObject), new Among("eaţi", 38, 1, "", methodObject), new Among("iaţi", 38, 1, "", methodObject), new Among("eţi", -1, 2, "", methodObject), new Among("iţi", -1, 2, "", methodObject), new Among("âţi", -1, 2, "", methodObject), new Among("arăţi", -1, 1, "", methodObject), new Among("serăţi", -1, 2, "", methodObject), new Among("aserăţi", 45, 1, "", methodObject), new Among("seserăţi", 45, 2, "", methodObject), new Among("iserăţi", 45, 1, "", methodObject), new Among("userăţi", 45, 1, "", methodObject), new Among("âserăţi", 45, 1, "", methodObject), new Among("irăţi", -1, 1, "", methodObject), new Among("urăţi", -1, 1, "", methodObject), new Among("ârăţi", -1, 1, "", methodObject), new Among("am", -1, 1, "", methodObject), new Among("eam", 54, 1, "", methodObject), new Among("iam", 54, 1, "", methodObject), new Among("em", -1, 2, "", methodObject), new Among("asem", 57, 1, "", methodObject), new Among("sesem", 57, 2, "", methodObject), new Among("isem", 57, 1, "", methodObject), new Among("usem", 57, 1, "", methodObject), new Among("âsem", 57, 1, "", methodObject), new Among("im", -1, 2, "", methodObject), new Among("âm", -1, 2, "", methodObject), new Among("ăm", -1, 2, "", methodObject), new Among("arăm", 65, 1, "", methodObject), new Among("serăm", 65, 2, "", methodObject), new Among("aserăm", 67, 1, "", methodObject), new Among("seserăm", 67, 2, "", methodObject), new Among("iserăm", 67, 1, "", methodObject), new Among("userăm", 67, 1, "", methodObject), new Among("âserăm", 67, 1, "", methodObject), new Among("irăm", 65, 1, "", methodObject), new Among("urăm", 65, 1, "", methodObject), new Among("ârăm", 65, 1, "", methodObject), new Among("au", -1, 1, "", methodObject), new Among("eau", 76, 1, "", methodObject), new Among("iau", 76, 1, "", methodObject), new Among("indu", -1, 1, "", methodObject), new Among("ându", -1, 1, "", methodObject), new Among("ez", -1, 1, "", methodObject), new Among("ească", -1, 1, "", methodObject), new Among("ară", -1, 1, "", methodObject), new Among("seră", -1, 2, "", methodObject), new Among("aseră", 84, 1, "", methodObject), new Among("seseră", 84, 2, "", methodObject), new Among("iseră", 84, 1, "", methodObject), new Among("useră", 84, 1, "", methodObject), new Among("âseră", 84, 1, "", methodObject), new Among("iră", -1, 1, "", methodObject), new Among("ură", -1, 1, "", methodObject), new Among("âră", -1, 1, "", methodObject), new Among("ează", -1, 1, "", methodObject) };
/*      */ 
/*  255 */   private static final Among[] a_5 = { new Among("a", -1, 1, "", methodObject), new Among("e", -1, 1, "", methodObject), new Among("ie", 1, 1, "", methodObject), new Among("i", -1, 1, "", methodObject), new Among("ă", -1, 1, "", methodObject) };
/*      */ 
/*  263 */   private static final char[] g_v = { '\021', 'A', '\020', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\002', ' ', '\000', '\000', '\004' };
/*      */   private boolean B_standard_suffix_removed;
/*      */   private int I_p2;
/*      */   private int I_p1;
/*      */   private int I_pV;
/*      */ 
/*      */   private void copy_from(RomanianStemmer other)
/*      */   {
/*  271 */     this.B_standard_suffix_removed = other.B_standard_suffix_removed;
/*  272 */     this.I_p2 = other.I_p2;
/*  273 */     this.I_p1 = other.I_p1;
/*  274 */     this.I_pV = other.I_pV;
/*  275 */     super.copy_from(other);
/*      */   }
/*      */ 
/*      */   private boolean r_prelude()
/*      */   {
/*  286 */     int v_1 = this.cursor;
/*      */     while (true)
/*      */     {
/*  291 */       int v_2 = this.cursor;
/*      */ 
/*  294 */       if (in_grouping(g_v, 97, 259))
/*      */       {
/*  299 */         this.bra = this.cursor;
/*      */ 
/*  302 */         int v_3 = this.cursor;
/*      */ 
/*  306 */         if (eq_s(1, "u"))
/*      */         {
/*  311 */           this.ket = this.cursor;
/*  312 */           if (in_grouping(g_v, 97, 259))
/*      */           {
/*  317 */             slice_from("U");
/*  318 */             break label139;
/*      */           }
/*      */         }
/*  320 */         this.cursor = v_3;
/*      */ 
/*  323 */         if (eq_s(1, "i"))
/*      */         {
/*  328 */           this.ket = this.cursor;
/*  329 */           if (in_grouping(g_v, 97, 259))
/*      */           {
/*  334 */             slice_from("I");
/*      */ 
/*  336 */             label139: this.cursor = v_2;
/*  337 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  339 */       this.cursor = v_2;
/*  340 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label179;
/*      */       }
/*  344 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  348 */     label179: this.cursor = v_1;
/*      */ 
/*  351 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_regions()
/*      */   {
/*  361 */     this.I_pV = this.limit;
/*  362 */     this.I_p1 = this.limit;
/*  363 */     this.I_p2 = this.limit;
/*      */ 
/*  365 */     int v_1 = this.cursor;
/*      */ 
/*  370 */     int v_2 = this.cursor;
/*      */ 
/*  373 */     if (in_grouping(g_v, 97, 259))
/*      */     {
/*  379 */       int v_3 = this.cursor;
/*      */ 
/*  382 */       if (out_grouping(g_v, 97, 259))
/*      */       {
/*      */         while (true)
/*      */         {
/*  390 */           if (in_grouping(g_v, 97, 259))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  396 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  400 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */ 
/*  404 */       this.cursor = v_3;
/*      */ 
/*  406 */       if (in_grouping(g_v, 97, 259))
/*      */       {
/*      */         while (true)
/*      */         {
/*  414 */           if (out_grouping(g_v, 97, 259))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  420 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  424 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  429 */     this.cursor = v_2;
/*      */ 
/*  431 */     if (out_grouping(g_v, 97, 259))
/*      */     {
/*  437 */       int v_6 = this.cursor;
/*      */ 
/*  440 */       if (out_grouping(g_v, 97, 259))
/*      */       {
/*      */         while (true)
/*      */         {
/*  448 */           if (in_grouping(g_v, 97, 259))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  454 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  458 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */ 
/*  462 */       this.cursor = v_6;
/*      */ 
/*  464 */       if (in_grouping(g_v, 97, 259))
/*      */       {
/*  469 */         if (this.cursor < this.limit)
/*      */         {
/*  473 */           this.cursor += 1;
/*      */ 
/*  477 */           label319: this.I_pV = this.cursor;
/*      */         }
/*      */       }
/*      */     }
/*  479 */     this.cursor = v_1;
/*      */ 
/*  481 */     int v_8 = this.cursor;
/*      */ 
/*  488 */     while (!in_grouping(g_v, 97, 259))
/*      */     {
/*  494 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  498 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  504 */     while (!out_grouping(g_v, 97, 259))
/*      */     {
/*  510 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  514 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  517 */     this.I_p1 = this.cursor;
/*      */ 
/*  522 */     while (!in_grouping(g_v, 97, 259))
/*      */     {
/*  528 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  532 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  538 */     while (!out_grouping(g_v, 97, 259))
/*      */     {
/*  544 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  548 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  551 */     this.I_p2 = this.cursor;
/*      */ 
/*  553 */     label522: this.cursor = v_8;
/*  554 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_postlude()
/*      */   {
/*      */     int v_1;
/*      */     while (true)
/*      */     {
/*  563 */       v_1 = this.cursor;
/*      */ 
/*  567 */       this.bra = this.cursor;
/*      */ 
/*  569 */       int among_var = find_among(a_0, 3);
/*  570 */       if (among_var == 0)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  575 */       this.ket = this.cursor;
/*  576 */       switch (among_var) {
/*      */       case 0:
/*  578 */         break;
/*      */       case 1:
/*  582 */         slice_from("i");
/*  583 */         break;
/*      */       case 2:
/*  587 */         slice_from("u");
/*  588 */         break;
/*      */       case 3:
/*  592 */         if (this.cursor >= this.limit)
/*      */         {
/*      */           break label116;
/*      */         }
/*  596 */         this.cursor += 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  601 */     label116: this.cursor = v_1;
/*      */ 
/*  604 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_RV() {
/*  608 */     if (this.I_pV > this.cursor)
/*      */     {
/*  610 */       return false;
/*      */     }
/*  612 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R1() {
/*  616 */     if (this.I_p1 > this.cursor)
/*      */     {
/*  618 */       return false;
/*      */     }
/*  620 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R2() {
/*  624 */     if (this.I_p2 > this.cursor)
/*      */     {
/*  626 */       return false;
/*      */     }
/*  628 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_step_0()
/*      */   {
/*  636 */     this.ket = this.cursor;
/*      */ 
/*  638 */     int among_var = find_among_b(a_1, 16);
/*  639 */     if (among_var == 0)
/*      */     {
/*  641 */       return false;
/*      */     }
/*      */ 
/*  644 */     this.bra = this.cursor;
/*      */ 
/*  646 */     if (!r_R1())
/*      */     {
/*  648 */       return false;
/*      */     }
/*  650 */     switch (among_var) {
/*      */     case 0:
/*  652 */       return false;
/*      */     case 1:
/*  656 */       slice_del();
/*  657 */       break;
/*      */     case 2:
/*  661 */       slice_from("a");
/*  662 */       break;
/*      */     case 3:
/*  666 */       slice_from("e");
/*  667 */       break;
/*      */     case 4:
/*  671 */       slice_from("i");
/*  672 */       break;
/*      */     case 5:
/*  677 */       int v_1 = this.limit - this.cursor;
/*      */ 
/*  680 */       if (eq_s_b(2, "ab"))
/*      */       {
/*  684 */         return false;
/*      */       }
/*  686 */       this.cursor = (this.limit - v_1);
/*      */ 
/*  689 */       slice_from("i");
/*  690 */       break;
/*      */     case 6:
/*  694 */       slice_from("at");
/*  695 */       break;
/*      */     case 7:
/*  699 */       slice_from("aţi");
/*      */     }
/*      */ 
/*  702 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_combo_suffix()
/*      */   {
/*  709 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  712 */     this.ket = this.cursor;
/*      */ 
/*  714 */     int among_var = find_among_b(a_2, 46);
/*  715 */     if (among_var == 0)
/*      */     {
/*  717 */       return false;
/*      */     }
/*      */ 
/*  720 */     this.bra = this.cursor;
/*      */ 
/*  722 */     if (!r_R1())
/*      */     {
/*  724 */       return false;
/*      */     }
/*      */ 
/*  727 */     switch (among_var) {
/*      */     case 0:
/*  729 */       return false;
/*      */     case 1:
/*  733 */       slice_from("abil");
/*  734 */       break;
/*      */     case 2:
/*  738 */       slice_from("ibil");
/*  739 */       break;
/*      */     case 3:
/*  743 */       slice_from("iv");
/*  744 */       break;
/*      */     case 4:
/*  748 */       slice_from("ic");
/*  749 */       break;
/*      */     case 5:
/*  753 */       slice_from("at");
/*  754 */       break;
/*      */     case 6:
/*  758 */       slice_from("it");
/*      */     }
/*      */ 
/*  762 */     this.B_standard_suffix_removed = true;
/*  763 */     this.cursor = (this.limit - v_1);
/*  764 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_standard_suffix()
/*      */   {
/*  772 */     this.B_standard_suffix_removed = false;
/*      */     int v_1;
/*      */     do {
/*  776 */       v_1 = this.limit - this.cursor;
/*      */     }
/*      */ 
/*  779 */     while (r_combo_suffix());
/*      */ 
/*  785 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  789 */     this.ket = this.cursor;
/*      */ 
/*  791 */     int among_var = find_among_b(a_3, 62);
/*  792 */     if (among_var == 0)
/*      */     {
/*  794 */       return false;
/*      */     }
/*      */ 
/*  797 */     this.bra = this.cursor;
/*      */ 
/*  799 */     if (!r_R2())
/*      */     {
/*  801 */       return false;
/*      */     }
/*      */ 
/*  804 */     switch (among_var) {
/*      */     case 0:
/*  806 */       return false;
/*      */     case 1:
/*  810 */       slice_del();
/*  811 */       break;
/*      */     case 2:
/*  815 */       if (!eq_s_b(1, "ţ"))
/*      */       {
/*  817 */         return false;
/*      */       }
/*      */ 
/*  820 */       this.bra = this.cursor;
/*      */ 
/*  822 */       slice_from("t");
/*  823 */       break;
/*      */     case 3:
/*  827 */       slice_from("ist");
/*      */     }
/*      */ 
/*  831 */     this.B_standard_suffix_removed = true;
/*  832 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_verb_suffix()
/*      */   {
/*  841 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  843 */     if (this.cursor < this.I_pV)
/*      */     {
/*  845 */       return false;
/*      */     }
/*  847 */     this.cursor = this.I_pV;
/*  848 */     int v_2 = this.limit_backward;
/*  849 */     this.limit_backward = this.cursor;
/*  850 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  853 */     this.ket = this.cursor;
/*      */ 
/*  855 */     int among_var = find_among_b(a_4, 94);
/*  856 */     if (among_var == 0)
/*      */     {
/*  858 */       this.limit_backward = v_2;
/*  859 */       return false;
/*      */     }
/*      */ 
/*  862 */     this.bra = this.cursor;
/*  863 */     switch (among_var) {
/*      */     case 0:
/*  865 */       this.limit_backward = v_2;
/*  866 */       return false;
/*      */     case 1:
/*  871 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  873 */       if (!out_grouping_b(g_v, 97, 259))
/*      */       {
/*  879 */         this.cursor = (this.limit - v_3);
/*      */ 
/*  881 */         if (!eq_s_b(1, "u"))
/*      */         {
/*  883 */           this.limit_backward = v_2;
/*  884 */           return false;
/*      */         }
/*      */       }
/*      */ 
/*  888 */       slice_del();
/*  889 */       break;
/*      */     case 2:
/*  893 */       slice_del();
/*      */     }
/*      */ 
/*  896 */     this.limit_backward = v_2;
/*  897 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_vowel_suffix()
/*      */   {
/*  904 */     this.ket = this.cursor;
/*      */ 
/*  906 */     int among_var = find_among_b(a_5, 5);
/*  907 */     if (among_var == 0)
/*      */     {
/*  909 */       return false;
/*      */     }
/*      */ 
/*  912 */     this.bra = this.cursor;
/*      */ 
/*  914 */     if (!r_RV())
/*      */     {
/*  916 */       return false;
/*      */     }
/*  918 */     switch (among_var) {
/*      */     case 0:
/*  920 */       return false;
/*      */     case 1:
/*  924 */       slice_del();
/*      */     }
/*      */ 
/*  927 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean stem()
/*      */   {
/*  942 */     int v_1 = this.cursor;
/*      */ 
/*  945 */     if (!r_prelude());
/*  950 */     this.cursor = v_1;
/*      */ 
/*  952 */     int v_2 = this.cursor;
/*      */ 
/*  955 */     if (!r_mark_regions());
/*  960 */     this.cursor = v_2;
/*      */ 
/*  962 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/*  965 */     int v_3 = this.limit - this.cursor;
/*      */ 
/*  968 */     if (!r_step_0());
/*  973 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  975 */     int v_4 = this.limit - this.cursor;
/*      */ 
/*  978 */     if (!r_standard_suffix());
/*  983 */     this.cursor = (this.limit - v_4);
/*      */ 
/*  985 */     int v_5 = this.limit - this.cursor;
/*      */ 
/*  990 */     int v_6 = this.limit - this.cursor;
/*      */ 
/*  993 */     if (!this.B_standard_suffix_removed)
/*      */     {
/*  999 */       this.cursor = (this.limit - v_6);
/*      */ 
/* 1001 */       if (r_verb_suffix());
/*      */     }
/*      */ 
/* 1007 */     this.cursor = (this.limit - v_5);
/*      */ 
/* 1009 */     int v_7 = this.limit - this.cursor;
/*      */ 
/* 1012 */     if (!r_vowel_suffix());
/* 1017 */     this.cursor = (this.limit - v_7);
/* 1018 */     this.cursor = this.limit_backward;
/* 1019 */     int v_8 = this.cursor;
/*      */ 
/* 1022 */     if (!r_postlude());
/* 1027 */     this.cursor = v_8;
/* 1028 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1033 */     return o instanceof RomanianStemmer;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1038 */     return RomanianStemmer.class.getName().hashCode();
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.tartarus.snowball.ext.RomanianStemmer
 * JD-Core Version:    0.6.2
 */