/*     */ package org.tartarus.snowball.ext;
/*     */ 
/*     */ import org.tartarus.snowball.Among;
/*     */ import org.tartarus.snowball.SnowballProgram;
/*     */ 
/*     */ public class DanishStemmer extends SnowballProgram
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  17 */   private static final DanishStemmer methodObject = new DanishStemmer();
/*     */ 
/*  19 */   private static final Among[] a_0 = { new Among("hed", -1, 1, "", methodObject), new Among("ethed", 0, 1, "", methodObject), new Among("ered", -1, 1, "", methodObject), new Among("e", -1, 1, "", methodObject), new Among("erede", 3, 1, "", methodObject), new Among("ende", 3, 1, "", methodObject), new Among("erende", 5, 1, "", methodObject), new Among("ene", 3, 1, "", methodObject), new Among("erne", 3, 1, "", methodObject), new Among("ere", 3, 1, "", methodObject), new Among("en", -1, 1, "", methodObject), new Among("heden", 10, 1, "", methodObject), new Among("eren", 10, 1, "", methodObject), new Among("er", -1, 1, "", methodObject), new Among("heder", 13, 1, "", methodObject), new Among("erer", 13, 1, "", methodObject), new Among("s", -1, 2, "", methodObject), new Among("heds", 16, 1, "", methodObject), new Among("es", 16, 1, "", methodObject), new Among("endes", 18, 1, "", methodObject), new Among("erendes", 19, 1, "", methodObject), new Among("enes", 18, 1, "", methodObject), new Among("ernes", 18, 1, "", methodObject), new Among("eres", 18, 1, "", methodObject), new Among("ens", 16, 1, "", methodObject), new Among("hedens", 24, 1, "", methodObject), new Among("erens", 24, 1, "", methodObject), new Among("ers", 16, 1, "", methodObject), new Among("ets", 16, 1, "", methodObject), new Among("erets", 28, 1, "", methodObject), new Among("et", -1, 1, "", methodObject), new Among("eret", 30, 1, "", methodObject) };
/*     */ 
/*  54 */   private static final Among[] a_1 = { new Among("gd", -1, -1, "", methodObject), new Among("dt", -1, -1, "", methodObject), new Among("gt", -1, -1, "", methodObject), new Among("kt", -1, -1, "", methodObject) };
/*     */ 
/*  61 */   private static final Among[] a_2 = { new Among("ig", -1, 1, "", methodObject), new Among("lig", 0, 1, "", methodObject), new Among("elig", 1, 1, "", methodObject), new Among("els", -1, 1, "", methodObject), new Among("løst", -1, 2, "", methodObject) };
/*     */ 
/*  69 */   private static final char[] g_v = { '\021', 'A', '\020', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '0', '\000', '' };
/*     */ 
/*  71 */   private static final char[] g_s_ending = { 'ï', 'þ', '*', '\003', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\020' };
/*     */   private int I_x;
/*     */   private int I_p1;
/*  75 */   private StringBuilder S_ch = new StringBuilder();
/*     */ 
/*     */   private void copy_from(DanishStemmer other) {
/*  78 */     this.I_x = other.I_x;
/*  79 */     this.I_p1 = other.I_p1;
/*  80 */     this.S_ch = other.S_ch;
/*  81 */     super.copy_from(other);
/*     */   }
/*     */ 
/*     */   private boolean r_mark_regions()
/*     */   {
/*  88 */     this.I_p1 = this.limit;
/*     */ 
/*  90 */     int v_1 = this.cursor;
/*     */ 
/*  94 */     int c = this.cursor + 3;
/*  95 */     if ((0 > c) || (c > this.limit))
/*     */     {
/*  97 */       return false;
/*     */     }
/*  99 */     this.cursor = c;
/*     */ 
/* 102 */     this.I_x = this.cursor;
/* 103 */     this.cursor = v_1;
/*     */     while (true)
/*     */     {
/* 107 */       int v_2 = this.cursor;
/*     */ 
/* 109 */       if (in_grouping(g_v, 97, 248))
/*     */       {
/* 113 */         this.cursor = v_2;
/* 114 */         break;
/*     */       }
/* 116 */       this.cursor = v_2;
/* 117 */       if (this.cursor >= this.limit)
/*     */       {
/* 119 */         return false;
/*     */       }
/* 121 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 127 */     while (!out_grouping(g_v, 97, 248))
/*     */     {
/* 133 */       if (this.cursor >= this.limit)
/*     */       {
/* 135 */         return false;
/*     */       }
/* 137 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 140 */     this.I_p1 = this.cursor;
/*     */ 
/* 144 */     if (this.I_p1 < this.I_x)
/*     */     {
/* 148 */       this.I_p1 = this.I_x;
/*     */     }
/* 150 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_main_suffix()
/*     */   {
/* 159 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 161 */     if (this.cursor < this.I_p1)
/*     */     {
/* 163 */       return false;
/*     */     }
/* 165 */     this.cursor = this.I_p1;
/* 166 */     int v_2 = this.limit_backward;
/* 167 */     this.limit_backward = this.cursor;
/* 168 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 171 */     this.ket = this.cursor;
/*     */ 
/* 173 */     int among_var = find_among_b(a_0, 32);
/* 174 */     if (among_var == 0)
/*     */     {
/* 176 */       this.limit_backward = v_2;
/* 177 */       return false;
/*     */     }
/*     */ 
/* 180 */     this.bra = this.cursor;
/* 181 */     this.limit_backward = v_2;
/* 182 */     switch (among_var) {
/*     */     case 0:
/* 184 */       return false;
/*     */     case 1:
/* 188 */       slice_del();
/* 189 */       break;
/*     */     case 2:
/* 192 */       if (!in_grouping_b(g_s_ending, 97, 229))
/*     */       {
/* 194 */         return false;
/*     */       }
/*     */ 
/* 197 */       slice_del();
/*     */     }
/*     */ 
/* 200 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_consonant_pair()
/*     */   {
/* 209 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 212 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 214 */     if (this.cursor < this.I_p1)
/*     */     {
/* 216 */       return false;
/*     */     }
/* 218 */     this.cursor = this.I_p1;
/* 219 */     int v_3 = this.limit_backward;
/* 220 */     this.limit_backward = this.cursor;
/* 221 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 224 */     this.ket = this.cursor;
/*     */ 
/* 226 */     if (find_among_b(a_1, 4) == 0)
/*     */     {
/* 228 */       this.limit_backward = v_3;
/* 229 */       return false;
/*     */     }
/*     */ 
/* 232 */     this.bra = this.cursor;
/* 233 */     this.limit_backward = v_3;
/* 234 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 236 */     if (this.cursor <= this.limit_backward)
/*     */     {
/* 238 */       return false;
/*     */     }
/* 240 */     this.cursor -= 1;
/*     */ 
/* 242 */     this.bra = this.cursor;
/*     */ 
/* 244 */     slice_del();
/* 245 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_other_suffix()
/*     */   {
/* 256 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 260 */     this.ket = this.cursor;
/*     */ 
/* 262 */     if (eq_s_b(2, "st"))
/*     */     {
/* 267 */       this.bra = this.cursor;
/*     */ 
/* 269 */       if (eq_s_b(2, "ig"))
/*     */       {
/* 274 */         slice_del();
/*     */       }
/*     */     }
/* 276 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 278 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 280 */     if (this.cursor < this.I_p1)
/*     */     {
/* 282 */       return false;
/*     */     }
/* 284 */     this.cursor = this.I_p1;
/* 285 */     int v_3 = this.limit_backward;
/* 286 */     this.limit_backward = this.cursor;
/* 287 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 290 */     this.ket = this.cursor;
/*     */ 
/* 292 */     int among_var = find_among_b(a_2, 5);
/* 293 */     if (among_var == 0)
/*     */     {
/* 295 */       this.limit_backward = v_3;
/* 296 */       return false;
/*     */     }
/*     */ 
/* 299 */     this.bra = this.cursor;
/* 300 */     this.limit_backward = v_3;
/* 301 */     switch (among_var) {
/*     */     case 0:
/* 303 */       return false;
/*     */     case 1:
/* 307 */       slice_del();
/*     */ 
/* 309 */       int v_4 = this.limit - this.cursor;
/*     */ 
/* 312 */       if (!r_consonant_pair());
/* 317 */       this.cursor = (this.limit - v_4);
/* 318 */       break;
/*     */     case 2:
/* 322 */       slice_from("løs");
/*     */     }
/*     */ 
/* 325 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_undouble()
/*     */   {
/* 333 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 335 */     if (this.cursor < this.I_p1)
/*     */     {
/* 337 */       return false;
/*     */     }
/* 339 */     this.cursor = this.I_p1;
/* 340 */     int v_2 = this.limit_backward;
/* 341 */     this.limit_backward = this.cursor;
/* 342 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 345 */     this.ket = this.cursor;
/* 346 */     if (!out_grouping_b(g_v, 97, 248))
/*     */     {
/* 348 */       this.limit_backward = v_2;
/* 349 */       return false;
/*     */     }
/*     */ 
/* 352 */     this.bra = this.cursor;
/*     */ 
/* 354 */     this.S_ch = slice_to(this.S_ch);
/* 355 */     this.limit_backward = v_2;
/*     */ 
/* 357 */     if (!eq_v_b(this.S_ch))
/*     */     {
/* 359 */       return false;
/*     */     }
/*     */ 
/* 362 */     slice_del();
/* 363 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean stem()
/*     */   {
/* 375 */     int v_1 = this.cursor;
/*     */ 
/* 378 */     if (!r_mark_regions());
/* 383 */     this.cursor = v_1;
/*     */ 
/* 385 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*     */ 
/* 388 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 391 */     if (!r_main_suffix());
/* 396 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 398 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 401 */     if (!r_consonant_pair());
/* 406 */     this.cursor = (this.limit - v_3);
/*     */ 
/* 408 */     int v_4 = this.limit - this.cursor;
/*     */ 
/* 411 */     if (!r_other_suffix());
/* 416 */     this.cursor = (this.limit - v_4);
/*     */ 
/* 418 */     int v_5 = this.limit - this.cursor;
/*     */ 
/* 421 */     if (!r_undouble());
/* 426 */     this.cursor = (this.limit - v_5);
/* 427 */     this.cursor = this.limit_backward; return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 432 */     return o instanceof DanishStemmer;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 437 */     return DanishStemmer.class.getName().hashCode();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.tartarus.snowball.ext.DanishStemmer
 * JD-Core Version:    0.6.2
 */