/*     */ package org.tartarus.snowball.ext;
/*     */ 
/*     */ import org.tartarus.snowball.Among;
/*     */ import org.tartarus.snowball.SnowballProgram;
/*     */ 
/*     */ public class PorterStemmer extends SnowballProgram
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  17 */   private static final PorterStemmer methodObject = new PorterStemmer();
/*     */ 
/*  19 */   private static final Among[] a_0 = { new Among("s", -1, 3, "", methodObject), new Among("ies", 0, 2, "", methodObject), new Among("sses", 0, 1, "", methodObject), new Among("ss", 0, -1, "", methodObject) };
/*     */ 
/*  26 */   private static final Among[] a_1 = { new Among("", -1, 3, "", methodObject), new Among("bb", 0, 2, "", methodObject), new Among("dd", 0, 2, "", methodObject), new Among("ff", 0, 2, "", methodObject), new Among("gg", 0, 2, "", methodObject), new Among("bl", 0, 1, "", methodObject), new Among("mm", 0, 2, "", methodObject), new Among("nn", 0, 2, "", methodObject), new Among("pp", 0, 2, "", methodObject), new Among("rr", 0, 2, "", methodObject), new Among("at", 0, 1, "", methodObject), new Among("tt", 0, 2, "", methodObject), new Among("iz", 0, 1, "", methodObject) };
/*     */ 
/*  42 */   private static final Among[] a_2 = { new Among("ed", -1, 2, "", methodObject), new Among("eed", 0, 1, "", methodObject), new Among("ing", -1, 2, "", methodObject) };
/*     */ 
/*  48 */   private static final Among[] a_3 = { new Among("anci", -1, 3, "", methodObject), new Among("enci", -1, 2, "", methodObject), new Among("abli", -1, 4, "", methodObject), new Among("eli", -1, 6, "", methodObject), new Among("alli", -1, 9, "", methodObject), new Among("ousli", -1, 12, "", methodObject), new Among("entli", -1, 5, "", methodObject), new Among("aliti", -1, 10, "", methodObject), new Among("biliti", -1, 14, "", methodObject), new Among("iviti", -1, 13, "", methodObject), new Among("tional", -1, 1, "", methodObject), new Among("ational", 10, 8, "", methodObject), new Among("alism", -1, 10, "", methodObject), new Among("ation", -1, 8, "", methodObject), new Among("ization", 13, 7, "", methodObject), new Among("izer", -1, 7, "", methodObject), new Among("ator", -1, 8, "", methodObject), new Among("iveness", -1, 13, "", methodObject), new Among("fulness", -1, 11, "", methodObject), new Among("ousness", -1, 12, "", methodObject) };
/*     */ 
/*  71 */   private static final Among[] a_4 = { new Among("icate", -1, 2, "", methodObject), new Among("ative", -1, 3, "", methodObject), new Among("alize", -1, 1, "", methodObject), new Among("iciti", -1, 2, "", methodObject), new Among("ical", -1, 2, "", methodObject), new Among("ful", -1, 3, "", methodObject), new Among("ness", -1, 3, "", methodObject) };
/*     */ 
/*  81 */   private static final Among[] a_5 = { new Among("ic", -1, 1, "", methodObject), new Among("ance", -1, 1, "", methodObject), new Among("ence", -1, 1, "", methodObject), new Among("able", -1, 1, "", methodObject), new Among("ible", -1, 1, "", methodObject), new Among("ate", -1, 1, "", methodObject), new Among("ive", -1, 1, "", methodObject), new Among("ize", -1, 1, "", methodObject), new Among("iti", -1, 1, "", methodObject), new Among("al", -1, 1, "", methodObject), new Among("ism", -1, 1, "", methodObject), new Among("ion", -1, 2, "", methodObject), new Among("er", -1, 1, "", methodObject), new Among("ous", -1, 1, "", methodObject), new Among("ant", -1, 1, "", methodObject), new Among("ent", -1, 1, "", methodObject), new Among("ment", 15, 1, "", methodObject), new Among("ement", 16, 1, "", methodObject), new Among("ou", -1, 1, "", methodObject) };
/*     */ 
/* 103 */   private static final char[] g_v = { '\021', 'A', '\020', '\001' };
/*     */ 
/* 105 */   private static final char[] g_v_WXY = { '\001', '\021', 'A', 'Ð', '\001' };
/*     */   private boolean B_Y_found;
/*     */   private int I_p2;
/*     */   private int I_p1;
/*     */ 
/*     */   private void copy_from(PorterStemmer other)
/*     */   {
/* 112 */     this.B_Y_found = other.B_Y_found;
/* 113 */     this.I_p2 = other.I_p2;
/* 114 */     this.I_p1 = other.I_p1;
/* 115 */     super.copy_from(other);
/*     */   }
/*     */ 
/*     */   private boolean r_shortv()
/*     */   {
/* 120 */     if (!out_grouping_b(g_v_WXY, 89, 121))
/*     */     {
/* 122 */       return false;
/*     */     }
/* 124 */     if (!in_grouping_b(g_v, 97, 121))
/*     */     {
/* 126 */       return false;
/*     */     }
/* 128 */     if (!out_grouping_b(g_v, 97, 121))
/*     */     {
/* 130 */       return false;
/*     */     }
/* 132 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R1() {
/* 136 */     if (this.I_p1 > this.cursor)
/*     */     {
/* 138 */       return false;
/*     */     }
/* 140 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R2() {
/* 144 */     if (this.I_p2 > this.cursor)
/*     */     {
/* 146 */       return false;
/*     */     }
/* 148 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_Step_1a()
/*     */   {
/* 155 */     this.ket = this.cursor;
/*     */ 
/* 157 */     int among_var = find_among_b(a_0, 4);
/* 158 */     if (among_var == 0)
/*     */     {
/* 160 */       return false;
/*     */     }
/*     */ 
/* 163 */     this.bra = this.cursor;
/* 164 */     switch (among_var) {
/*     */     case 0:
/* 166 */       return false;
/*     */     case 1:
/* 170 */       slice_from("ss");
/* 171 */       break;
/*     */     case 2:
/* 175 */       slice_from("i");
/* 176 */       break;
/*     */     case 3:
/* 180 */       slice_del();
/*     */     }
/*     */ 
/* 183 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_Step_1b()
/*     */   {
/* 193 */     this.ket = this.cursor;
/*     */ 
/* 195 */     int among_var = find_among_b(a_2, 3);
/* 196 */     if (among_var == 0)
/*     */     {
/* 198 */       return false;
/*     */     }
/*     */ 
/* 201 */     this.bra = this.cursor;
/* 202 */     switch (among_var) {
/*     */     case 0:
/* 204 */       return false;
/*     */     case 1:
/* 208 */       if (!r_R1())
/*     */       {
/* 210 */         return false;
/*     */       }
/*     */ 
/* 213 */       slice_from("ee");
/* 214 */       break;
/*     */     case 2:
/* 218 */       int v_1 = this.limit - this.cursor;
/*     */ 
/* 223 */       while (!in_grouping_b(g_v, 97, 121))
/*     */       {
/* 229 */         if (this.cursor <= this.limit_backward)
/*     */         {
/* 231 */           return false;
/*     */         }
/* 233 */         this.cursor -= 1;
/*     */       }
/* 235 */       this.cursor = (this.limit - v_1);
/*     */ 
/* 237 */       slice_del();
/*     */ 
/* 239 */       int v_3 = this.limit - this.cursor;
/*     */ 
/* 241 */       among_var = find_among_b(a_1, 13);
/* 242 */       if (among_var == 0)
/*     */       {
/* 244 */         return false;
/*     */       }
/* 246 */       this.cursor = (this.limit - v_3);
/* 247 */       switch (among_var) {
/*     */       case 0:
/* 249 */         return false;
/*     */       case 1:
/* 254 */         int c = this.cursor;
/* 255 */         insert(this.cursor, this.cursor, "e");
/* 256 */         this.cursor = c;
/*     */ 
/* 258 */         break;
/*     */       case 2:
/* 262 */         this.ket = this.cursor;
/*     */ 
/* 264 */         if (this.cursor <= this.limit_backward)
/*     */         {
/* 266 */           return false;
/*     */         }
/* 268 */         this.cursor -= 1;
/*     */ 
/* 270 */         this.bra = this.cursor;
/*     */ 
/* 272 */         slice_del();
/* 273 */         break;
/*     */       case 3:
/* 277 */         if (this.cursor != this.I_p1)
/*     */         {
/* 279 */           return false;
/*     */         }
/*     */ 
/* 282 */         int v_4 = this.limit - this.cursor;
/*     */ 
/* 284 */         if (!r_shortv())
/*     */         {
/* 286 */           return false;
/*     */         }
/* 288 */         this.cursor = (this.limit - v_4);
/*     */ 
/* 291 */         int c = this.cursor;
/* 292 */         insert(this.cursor, this.cursor, "e");
/* 293 */         this.cursor = c;
/*     */       }
/*     */ 
/*     */       break;
/*     */     }
/*     */ 
/* 299 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_Step_1c()
/*     */   {
/* 306 */     this.ket = this.cursor;
/*     */ 
/* 309 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 312 */     if (!eq_s_b(1, "y"))
/*     */     {
/* 318 */       this.cursor = (this.limit - v_1);
/*     */ 
/* 320 */       if (!eq_s_b(1, "Y"))
/*     */       {
/* 322 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 326 */     this.bra = this.cursor;
/*     */ 
/* 331 */     while (!in_grouping_b(g_v, 97, 121))
/*     */     {
/* 337 */       if (this.cursor <= this.limit_backward)
/*     */       {
/* 339 */         return false;
/*     */       }
/* 341 */       this.cursor -= 1;
/*     */     }
/*     */ 
/* 344 */     slice_from("i");
/* 345 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_Step_2()
/*     */   {
/* 352 */     this.ket = this.cursor;
/*     */ 
/* 354 */     int among_var = find_among_b(a_3, 20);
/* 355 */     if (among_var == 0)
/*     */     {
/* 357 */       return false;
/*     */     }
/*     */ 
/* 360 */     this.bra = this.cursor;
/*     */ 
/* 362 */     if (!r_R1())
/*     */     {
/* 364 */       return false;
/*     */     }
/* 366 */     switch (among_var) {
/*     */     case 0:
/* 368 */       return false;
/*     */     case 1:
/* 372 */       slice_from("tion");
/* 373 */       break;
/*     */     case 2:
/* 377 */       slice_from("ence");
/* 378 */       break;
/*     */     case 3:
/* 382 */       slice_from("ance");
/* 383 */       break;
/*     */     case 4:
/* 387 */       slice_from("able");
/* 388 */       break;
/*     */     case 5:
/* 392 */       slice_from("ent");
/* 393 */       break;
/*     */     case 6:
/* 397 */       slice_from("e");
/* 398 */       break;
/*     */     case 7:
/* 402 */       slice_from("ize");
/* 403 */       break;
/*     */     case 8:
/* 407 */       slice_from("ate");
/* 408 */       break;
/*     */     case 9:
/* 412 */       slice_from("al");
/* 413 */       break;
/*     */     case 10:
/* 417 */       slice_from("al");
/* 418 */       break;
/*     */     case 11:
/* 422 */       slice_from("ful");
/* 423 */       break;
/*     */     case 12:
/* 427 */       slice_from("ous");
/* 428 */       break;
/*     */     case 13:
/* 432 */       slice_from("ive");
/* 433 */       break;
/*     */     case 14:
/* 437 */       slice_from("ble");
/*     */     }
/*     */ 
/* 440 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_Step_3()
/*     */   {
/* 447 */     this.ket = this.cursor;
/*     */ 
/* 449 */     int among_var = find_among_b(a_4, 7);
/* 450 */     if (among_var == 0)
/*     */     {
/* 452 */       return false;
/*     */     }
/*     */ 
/* 455 */     this.bra = this.cursor;
/*     */ 
/* 457 */     if (!r_R1())
/*     */     {
/* 459 */       return false;
/*     */     }
/* 461 */     switch (among_var) {
/*     */     case 0:
/* 463 */       return false;
/*     */     case 1:
/* 467 */       slice_from("al");
/* 468 */       break;
/*     */     case 2:
/* 472 */       slice_from("ic");
/* 473 */       break;
/*     */     case 3:
/* 477 */       slice_del();
/*     */     }
/*     */ 
/* 480 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_Step_4()
/*     */   {
/* 488 */     this.ket = this.cursor;
/*     */ 
/* 490 */     int among_var = find_among_b(a_5, 19);
/* 491 */     if (among_var == 0)
/*     */     {
/* 493 */       return false;
/*     */     }
/*     */ 
/* 496 */     this.bra = this.cursor;
/*     */ 
/* 498 */     if (!r_R2())
/*     */     {
/* 500 */       return false;
/*     */     }
/* 502 */     switch (among_var) {
/*     */     case 0:
/* 504 */       return false;
/*     */     case 1:
/* 508 */       slice_del();
/* 509 */       break;
/*     */     case 2:
/* 514 */       int v_1 = this.limit - this.cursor;
/*     */ 
/* 517 */       if (!eq_s_b(1, "s"))
/*     */       {
/* 523 */         this.cursor = (this.limit - v_1);
/*     */ 
/* 525 */         if (!eq_s_b(1, "t"))
/*     */         {
/* 527 */           return false;
/*     */         }
/*     */       }
/*     */ 
/* 531 */       slice_del();
/*     */     }
/*     */ 
/* 534 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_Step_5a()
/*     */   {
/* 542 */     this.ket = this.cursor;
/*     */ 
/* 544 */     if (!eq_s_b(1, "e"))
/*     */     {
/* 546 */       return false;
/*     */     }
/*     */ 
/* 549 */     this.bra = this.cursor;
/*     */ 
/* 552 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 555 */     if (!r_R2())
/*     */     {
/* 561 */       this.cursor = (this.limit - v_1);
/*     */ 
/* 564 */       if (!r_R1())
/*     */       {
/* 566 */         return false;
/*     */       }
/*     */ 
/* 570 */       int v_2 = this.limit - this.cursor;
/*     */ 
/* 573 */       if (r_shortv())
/*     */       {
/* 577 */         return false;
/*     */       }
/* 579 */       this.cursor = (this.limit - v_2);
/*     */     }
/*     */ 
/* 583 */     slice_del();
/* 584 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_Step_5b()
/*     */   {
/* 590 */     this.ket = this.cursor;
/*     */ 
/* 592 */     if (!eq_s_b(1, "l"))
/*     */     {
/* 594 */       return false;
/*     */     }
/*     */ 
/* 597 */     this.bra = this.cursor;
/*     */ 
/* 599 */     if (!r_R2())
/*     */     {
/* 601 */       return false;
/*     */     }
/*     */ 
/* 604 */     if (!eq_s_b(1, "l"))
/*     */     {
/* 606 */       return false;
/*     */     }
/*     */ 
/* 609 */     slice_del();
/* 610 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean stem()
/*     */   {
/* 633 */     this.B_Y_found = false;
/*     */ 
/* 635 */     int v_1 = this.cursor;
/*     */ 
/* 639 */     this.bra = this.cursor;
/*     */ 
/* 641 */     if (eq_s(1, "y"))
/*     */     {
/* 646 */       this.ket = this.cursor;
/*     */ 
/* 648 */       slice_from("Y");
/*     */ 
/* 650 */       this.B_Y_found = true;
/*     */     }
/* 652 */     this.cursor = v_1;
/*     */ 
/* 654 */     int v_2 = this.cursor;
/*     */     int v_3;
/*     */     while (true) {
/* 659 */       v_3 = this.cursor;
/*     */       while (true)
/*     */       {
/* 665 */         int v_4 = this.cursor;
/*     */ 
/* 668 */         if (in_grouping(g_v, 97, 121))
/*     */         {
/* 673 */           this.bra = this.cursor;
/*     */ 
/* 675 */           if (eq_s(1, "y"))
/*     */           {
/* 680 */             this.ket = this.cursor;
/* 681 */             this.cursor = v_4;
/* 682 */             break;
/*     */           }
/*     */         }
/* 684 */         this.cursor = v_4;
/* 685 */         if (this.cursor >= this.limit)
/*     */         {
/*     */           break label173;
/*     */         }
/* 689 */         this.cursor += 1;
/*     */       }
/*     */ 
/* 692 */       slice_from("Y");
/*     */ 
/* 694 */       this.B_Y_found = true;
/*     */     }
/*     */ 
/* 697 */     label173: this.cursor = v_3;
/*     */ 
/* 701 */     this.cursor = v_2;
/* 702 */     this.I_p1 = this.limit;
/* 703 */     this.I_p2 = this.limit;
/*     */ 
/* 705 */     int v_5 = this.cursor;
/*     */ 
/* 712 */     while (!in_grouping(g_v, 97, 121))
/*     */     {
/* 718 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label388;
/*     */       }
/* 722 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 728 */     while (!out_grouping(g_v, 97, 121))
/*     */     {
/* 734 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label388;
/*     */       }
/* 738 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 741 */     this.I_p1 = this.cursor;
/*     */ 
/* 746 */     while (!in_grouping(g_v, 97, 121))
/*     */     {
/* 752 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label388;
/*     */       }
/* 756 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 762 */     while (!out_grouping(g_v, 97, 121))
/*     */     {
/* 768 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label388;
/*     */       }
/* 772 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 775 */     this.I_p2 = this.cursor;
/*     */ 
/* 777 */     label388: this.cursor = v_5;
/*     */ 
/* 779 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*     */ 
/* 782 */     int v_10 = this.limit - this.cursor;
/*     */ 
/* 785 */     if (!r_Step_1a());
/* 790 */     this.cursor = (this.limit - v_10);
/*     */ 
/* 792 */     int v_11 = this.limit - this.cursor;
/*     */ 
/* 795 */     if (!r_Step_1b());
/* 800 */     this.cursor = (this.limit - v_11);
/*     */ 
/* 802 */     int v_12 = this.limit - this.cursor;
/*     */ 
/* 805 */     if (!r_Step_1c());
/* 810 */     this.cursor = (this.limit - v_12);
/*     */ 
/* 812 */     int v_13 = this.limit - this.cursor;
/*     */ 
/* 815 */     if (!r_Step_2());
/* 820 */     this.cursor = (this.limit - v_13);
/*     */ 
/* 822 */     int v_14 = this.limit - this.cursor;
/*     */ 
/* 825 */     if (!r_Step_3());
/* 830 */     this.cursor = (this.limit - v_14);
/*     */ 
/* 832 */     int v_15 = this.limit - this.cursor;
/*     */ 
/* 835 */     if (!r_Step_4());
/* 840 */     this.cursor = (this.limit - v_15);
/*     */ 
/* 842 */     int v_16 = this.limit - this.cursor;
/*     */ 
/* 845 */     if (!r_Step_5a());
/* 850 */     this.cursor = (this.limit - v_16);
/*     */ 
/* 852 */     int v_17 = this.limit - this.cursor;
/*     */ 
/* 855 */     if (!r_Step_5b());
/* 860 */     this.cursor = (this.limit - v_17);
/* 861 */     this.cursor = this.limit_backward;
/* 862 */     int v_18 = this.cursor;
/*     */ 
/* 866 */     if (this.B_Y_found)
/*     */     {
/*     */       int v_19;
/*     */       while (true)
/*     */       {
/* 873 */         v_19 = this.cursor;
/*     */         while (true)
/*     */         {
/* 879 */           int v_20 = this.cursor;
/*     */ 
/* 883 */           this.bra = this.cursor;
/*     */ 
/* 885 */           if (eq_s(1, "Y"))
/*     */           {
/* 890 */             this.ket = this.cursor;
/* 891 */             this.cursor = v_20;
/* 892 */             break;
/*     */           }
/* 894 */           this.cursor = v_20;
/* 895 */           if (this.cursor >= this.limit)
/*     */           {
/*     */             break label758;
/*     */           }
/* 899 */           this.cursor += 1;
/*     */         }
/*     */ 
/* 902 */         slice_from("y");
/*     */       }
/*     */ 
/* 905 */       label758: this.cursor = v_19;
/*     */     }
/*     */ 
/* 909 */     this.cursor = v_18;
/* 910 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 915 */     return o instanceof PorterStemmer;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 920 */     return PorterStemmer.class.getName().hashCode();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.tartarus.snowball.ext.PorterStemmer
 * JD-Core Version:    0.6.2
 */