/*      */ package org.tartarus.snowball.ext;
/*      */ 
/*      */ import org.tartarus.snowball.Among;
/*      */ import org.tartarus.snowball.SnowballProgram;
/*      */ 
/*      */ public class KpStemmer extends SnowballProgram
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   17 */   private static final KpStemmer methodObject = new KpStemmer();
/*      */ 
/*   19 */   private static final Among[] a_0 = { new Among("nde", -1, 7, "", methodObject), new Among("en", -1, 6, "", methodObject), new Among("s", -1, 2, "", methodObject), new Among("'s", 2, 1, "", methodObject), new Among("es", 2, 4, "", methodObject), new Among("ies", 4, 3, "", methodObject), new Among("aus", 2, 5, "", methodObject) };
/*      */ 
/*   29 */   private static final Among[] a_1 = { new Among("de", -1, 5, "", methodObject), new Among("ge", -1, 2, "", methodObject), new Among("ische", -1, 4, "", methodObject), new Among("je", -1, 1, "", methodObject), new Among("lijke", -1, 3, "", methodObject), new Among("le", -1, 9, "", methodObject), new Among("ene", -1, 10, "", methodObject), new Among("re", -1, 8, "", methodObject), new Among("se", -1, 7, "", methodObject), new Among("te", -1, 6, "", methodObject), new Among("ieve", -1, 11, "", methodObject) };
/*      */ 
/*   43 */   private static final Among[] a_2 = { new Among("heid", -1, 3, "", methodObject), new Among("fie", -1, 7, "", methodObject), new Among("gie", -1, 8, "", methodObject), new Among("atie", -1, 1, "", methodObject), new Among("isme", -1, 5, "", methodObject), new Among("ing", -1, 5, "", methodObject), new Among("arij", -1, 6, "", methodObject), new Among("erij", -1, 5, "", methodObject), new Among("sel", -1, 3, "", methodObject), new Among("rder", -1, 4, "", methodObject), new Among("ster", -1, 3, "", methodObject), new Among("iteit", -1, 2, "", methodObject), new Among("dst", -1, 10, "", methodObject), new Among("tst", -1, 9, "", methodObject) };
/*      */ 
/*   60 */   private static final Among[] a_3 = { new Among("end", -1, 10, "", methodObject), new Among("atief", -1, 2, "", methodObject), new Among("erig", -1, 10, "", methodObject), new Among("achtig", -1, 9, "", methodObject), new Among("ioneel", -1, 1, "", methodObject), new Among("baar", -1, 3, "", methodObject), new Among("laar", -1, 5, "", methodObject), new Among("naar", -1, 4, "", methodObject), new Among("raar", -1, 6, "", methodObject), new Among("eriger", -1, 10, "", methodObject), new Among("achtiger", -1, 9, "", methodObject), new Among("lijker", -1, 8, "", methodObject), new Among("tant", -1, 7, "", methodObject), new Among("erigst", -1, 10, "", methodObject), new Among("achtigst", -1, 9, "", methodObject), new Among("lijkst", -1, 8, "", methodObject) };
/*      */ 
/*   79 */   private static final Among[] a_4 = { new Among("ig", -1, 1, "", methodObject), new Among("iger", -1, 1, "", methodObject), new Among("igst", -1, 1, "", methodObject) };
/*      */ 
/*   85 */   private static final Among[] a_5 = { new Among("ft", -1, 2, "", methodObject), new Among("kt", -1, 1, "", methodObject), new Among("pt", -1, 3, "", methodObject) };
/*      */ 
/*   91 */   private static final Among[] a_6 = { new Among("bb", -1, 1, "", methodObject), new Among("cc", -1, 2, "", methodObject), new Among("dd", -1, 3, "", methodObject), new Among("ff", -1, 4, "", methodObject), new Among("gg", -1, 5, "", methodObject), new Among("hh", -1, 6, "", methodObject), new Among("jj", -1, 7, "", methodObject), new Among("kk", -1, 8, "", methodObject), new Among("ll", -1, 9, "", methodObject), new Among("mm", -1, 10, "", methodObject), new Among("nn", -1, 11, "", methodObject), new Among("pp", -1, 12, "", methodObject), new Among("qq", -1, 13, "", methodObject), new Among("rr", -1, 14, "", methodObject), new Among("ss", -1, 15, "", methodObject), new Among("tt", -1, 16, "", methodObject), new Among("v", -1, 21, "", methodObject), new Among("vv", 16, 17, "", methodObject), new Among("ww", -1, 18, "", methodObject), new Among("xx", -1, 19, "", methodObject), new Among("z", -1, 22, "", methodObject), new Among("zz", 20, 20, "", methodObject) };
/*      */ 
/*  116 */   private static final Among[] a_7 = { new Among("d", -1, 1, "", methodObject), new Among("t", -1, 2, "", methodObject) };
/*      */ 
/*  121 */   private static final char[] g_v = { '\021', 'A', '\020', '\001' };
/*      */ 
/*  123 */   private static final char[] g_v_WX = { '\021', 'A', 'Ð', '\001' };
/*      */ 
/*  125 */   private static final char[] g_AOU = { '\001', '@', '\020' };
/*      */ 
/*  127 */   private static final char[] g_AIOU = { '\001', 'A', '\020' };
/*      */   private boolean B_GE_removed;
/*      */   private boolean B_stemmed;
/*      */   private boolean B_Y_found;
/*      */   private int I_p2;
/*      */   private int I_p1;
/*      */   private int I_x;
/*  135 */   private StringBuilder S_ch = new StringBuilder();
/*      */ 
/*      */   private void copy_from(KpStemmer other) {
/*  138 */     this.B_GE_removed = other.B_GE_removed;
/*  139 */     this.B_stemmed = other.B_stemmed;
/*  140 */     this.B_Y_found = other.B_Y_found;
/*  141 */     this.I_p2 = other.I_p2;
/*  142 */     this.I_p1 = other.I_p1;
/*  143 */     this.I_x = other.I_x;
/*  144 */     this.S_ch = other.S_ch;
/*  145 */     super.copy_from(other);
/*      */   }
/*      */ 
/*      */   private boolean r_R1()
/*      */   {
/*  151 */     this.I_x = this.cursor;
/*  152 */     if (this.I_x < this.I_p1)
/*      */     {
/*  154 */       return false;
/*      */     }
/*  156 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R2()
/*      */   {
/*  162 */     this.I_x = this.cursor;
/*  163 */     if (this.I_x < this.I_p2)
/*      */     {
/*  165 */       return false;
/*      */     }
/*  167 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_V()
/*      */   {
/*  174 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  178 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  180 */     if (!in_grouping_b(g_v, 97, 121))
/*      */     {
/*  186 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  188 */       if (!eq_s_b(2, "ij"))
/*      */       {
/*  190 */         return false;
/*      */       }
/*      */     }
/*  193 */     this.cursor = (this.limit - v_1);
/*  194 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_VX()
/*      */   {
/*  201 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  204 */     if (this.cursor <= this.limit_backward)
/*      */     {
/*  206 */       return false;
/*      */     }
/*  208 */     this.cursor -= 1;
/*      */ 
/*  211 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  213 */     if (!in_grouping_b(g_v, 97, 121))
/*      */     {
/*  219 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  221 */       if (!eq_s_b(2, "ij"))
/*      */       {
/*  223 */         return false;
/*      */       }
/*      */     }
/*  226 */     this.cursor = (this.limit - v_1);
/*  227 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_C()
/*      */   {
/*  234 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  238 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  241 */     if (eq_s_b(2, "ij"))
/*      */     {
/*  245 */       return false;
/*      */     }
/*  247 */     this.cursor = (this.limit - v_2);
/*      */ 
/*  249 */     if (!out_grouping_b(g_v, 97, 121))
/*      */     {
/*  251 */       return false;
/*      */     }
/*  253 */     this.cursor = (this.limit - v_1);
/*  254 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_lengthen_V()
/*      */   {
/*  267 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  270 */     if (out_grouping_b(g_v_WX, 97, 121))
/*      */     {
/*  275 */       this.ket = this.cursor;
/*      */ 
/*  278 */       int v_2 = this.limit - this.cursor;
/*      */ 
/*  281 */       if (in_grouping_b(g_AOU, 97, 117))
/*      */       {
/*  286 */         this.bra = this.cursor;
/*      */ 
/*  288 */         int v_3 = this.limit - this.cursor;
/*      */ 
/*  292 */         int v_4 = this.limit - this.cursor;
/*      */ 
/*  294 */         if (!out_grouping_b(g_v, 97, 121))
/*      */         {
/*  300 */           this.cursor = (this.limit - v_4);
/*      */ 
/*  302 */           if (this.cursor > this.limit_backward);
/*      */         }
/*      */         else
/*      */         {
/*  307 */           this.cursor = (this.limit - v_3);
/*  308 */           break label359;
/*      */         }
/*      */       }
/*  310 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  313 */       if (eq_s_b(1, "e"))
/*      */       {
/*  318 */         this.bra = this.cursor;
/*      */ 
/*  320 */         int v_5 = this.limit - this.cursor;
/*      */ 
/*  324 */         int v_6 = this.limit - this.cursor;
/*      */ 
/*  326 */         if (!out_grouping_b(g_v, 97, 121))
/*      */         {
/*  332 */           this.cursor = (this.limit - v_6);
/*      */ 
/*  334 */           if (this.cursor > this.limit_backward);
/*      */         }
/*      */         else
/*      */         {
/*  341 */           int v_7 = this.limit - this.cursor;
/*      */ 
/*  343 */           if (!in_grouping_b(g_AIOU, 97, 117))
/*      */           {
/*  349 */             this.cursor = (this.limit - v_7);
/*      */ 
/*  353 */             int v_8 = this.limit - this.cursor;
/*      */ 
/*  357 */             if (this.cursor > this.limit_backward)
/*      */             {
/*  361 */               this.cursor -= 1;
/*  362 */               if ((in_grouping_b(g_AIOU, 97, 117)) && 
/*  366 */                 (out_grouping_b(g_v, 97, 121)));
/*      */             }
/*      */             else
/*      */             {
/*  372 */               this.cursor = (this.limit - v_8);
/*      */ 
/*  374 */               this.cursor = (this.limit - v_5);
/*      */ 
/*  377 */               label359: this.S_ch = slice_to(this.S_ch);
/*      */ 
/*  380 */               int c = this.cursor;
/*  381 */               insert(this.cursor, this.cursor, this.S_ch);
/*  382 */               this.cursor = c;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  385 */     this.cursor = (this.limit - v_1);
/*  386 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Step_1()
/*      */   {
/*  397 */     this.ket = this.cursor;
/*      */ 
/*  399 */     int among_var = find_among_b(a_0, 7);
/*  400 */     if (among_var == 0)
/*      */     {
/*  402 */       return false;
/*      */     }
/*      */ 
/*  406 */     this.bra = this.cursor;
/*  407 */     switch (among_var) {
/*      */     case 0:
/*  409 */       return false;
/*      */     case 1:
/*  413 */       slice_del();
/*  414 */       break;
/*      */     case 2:
/*  418 */       if (!r_R1())
/*      */       {
/*  420 */         return false;
/*      */       }
/*      */ 
/*  424 */       int v_1 = this.limit - this.cursor;
/*      */ 
/*  428 */       if (eq_s_b(1, "t"))
/*      */       {
/*  433 */         if (r_R1())
/*      */         {
/*  437 */           return false;
/*      */         }
/*      */       }
/*  439 */       this.cursor = (this.limit - v_1);
/*      */ 
/*  442 */       if (!r_C())
/*      */       {
/*  444 */         return false;
/*      */       }
/*      */ 
/*  447 */       slice_del();
/*  448 */       break;
/*      */     case 3:
/*  452 */       if (!r_R1())
/*      */       {
/*  454 */         return false;
/*      */       }
/*      */ 
/*  457 */       slice_from("ie");
/*  458 */       break;
/*      */     case 4:
/*  463 */       int v_2 = this.limit - this.cursor;
/*      */ 
/*  467 */       if (eq_s_b(2, "ar"))
/*      */       {
/*  472 */         if (r_R1())
/*      */         {
/*  477 */           if (r_C())
/*      */           {
/*  482 */             this.bra = this.cursor;
/*      */ 
/*  484 */             slice_del();
/*      */ 
/*  486 */             if (r_lengthen_V()) {
/*      */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  492 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  496 */       if (eq_s_b(2, "er"))
/*      */       {
/*  501 */         if (r_R1())
/*      */         {
/*  506 */           if (r_C())
/*      */           {
/*  511 */             this.bra = this.cursor;
/*      */ 
/*  513 */             slice_del();
/*  514 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  516 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  519 */       if (!r_R1())
/*      */       {
/*  521 */         return false;
/*      */       }
/*      */ 
/*  524 */       if (!r_C())
/*      */       {
/*  526 */         return false;
/*      */       }
/*      */ 
/*  529 */       slice_from("e");
/*      */ 
/*  531 */       break;
/*      */     case 5:
/*  535 */       if (!r_R1())
/*      */       {
/*  537 */         return false;
/*      */       }
/*      */ 
/*  540 */       if (!r_V())
/*      */       {
/*  542 */         return false;
/*      */       }
/*      */ 
/*  545 */       slice_from("au");
/*  546 */       break;
/*      */     case 6:
/*  551 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  555 */       if (eq_s_b(3, "hed"))
/*      */       {
/*  560 */         if (r_R1())
/*      */         {
/*  565 */           this.bra = this.cursor;
/*      */ 
/*  567 */           slice_from("heid");
/*  568 */           break;
/*      */         }
/*      */       }
/*  570 */       this.cursor = (this.limit - v_3);
/*      */ 
/*  574 */       if (eq_s_b(2, "nd"))
/*      */       {
/*  579 */         slice_del();
/*      */       }
/*      */       else {
/*  582 */         this.cursor = (this.limit - v_3);
/*      */ 
/*  586 */         if (eq_s_b(1, "d"))
/*      */         {
/*  591 */           if (r_R1())
/*      */           {
/*  596 */             if (r_C())
/*      */             {
/*  601 */               this.bra = this.cursor;
/*      */ 
/*  603 */               slice_del();
/*  604 */               break;
/*      */             }
/*      */           }
/*      */         }
/*  606 */         this.cursor = (this.limit - v_3);
/*      */ 
/*  611 */         int v_4 = this.limit - this.cursor;
/*      */ 
/*  614 */         if (!eq_s_b(1, "i"))
/*      */         {
/*  620 */           this.cursor = (this.limit - v_4);
/*      */ 
/*  622 */           if (!eq_s_b(1, "j"));
/*      */         }
/*  628 */         else if (r_V())
/*      */         {
/*  633 */           slice_del();
/*  634 */           break;
/*      */         }
/*  636 */         this.cursor = (this.limit - v_3);
/*      */ 
/*  639 */         if (!r_R1())
/*      */         {
/*  641 */           return false;
/*      */         }
/*      */ 
/*  644 */         if (!r_C())
/*      */         {
/*  646 */           return false;
/*      */         }
/*      */ 
/*  649 */         slice_del();
/*      */ 
/*  651 */         if (!r_lengthen_V())
/*      */         {
/*  653 */           return false;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 7:
/*  660 */       slice_from("nd");
/*      */     }
/*      */ 
/*  663 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Step_2()
/*      */   {
/*  671 */     this.ket = this.cursor;
/*      */ 
/*  673 */     int among_var = find_among_b(a_1, 11);
/*  674 */     if (among_var == 0)
/*      */     {
/*  676 */       return false;
/*      */     }
/*      */ 
/*  680 */     this.bra = this.cursor;
/*  681 */     switch (among_var) {
/*      */     case 0:
/*  683 */       return false;
/*      */     case 1:
/*  688 */       int v_1 = this.limit - this.cursor;
/*      */ 
/*  692 */       if (eq_s_b(2, "'t"))
/*      */       {
/*  697 */         this.bra = this.cursor;
/*      */ 
/*  699 */         slice_del();
/*      */       }
/*      */       else {
/*  702 */         this.cursor = (this.limit - v_1);
/*      */ 
/*  706 */         if (eq_s_b(2, "et"))
/*      */         {
/*  711 */           this.bra = this.cursor;
/*      */ 
/*  713 */           if (r_R1())
/*      */           {
/*  718 */             if (r_C())
/*      */             {
/*  723 */               slice_del();
/*  724 */               break;
/*      */             }
/*      */           }
/*      */         }
/*  726 */         this.cursor = (this.limit - v_1);
/*      */ 
/*  730 */         if (eq_s_b(3, "rnt"))
/*      */         {
/*  735 */           this.bra = this.cursor;
/*      */ 
/*  737 */           slice_from("rn");
/*      */         }
/*      */         else {
/*  740 */           this.cursor = (this.limit - v_1);
/*      */ 
/*  744 */           if (eq_s_b(1, "t"))
/*      */           {
/*  749 */             this.bra = this.cursor;
/*      */ 
/*  751 */             if (r_R1())
/*      */             {
/*  756 */               if (r_VX())
/*      */               {
/*  761 */                 slice_del();
/*  762 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*  764 */           this.cursor = (this.limit - v_1);
/*      */ 
/*  768 */           if (eq_s_b(3, "ink"))
/*      */           {
/*  773 */             this.bra = this.cursor;
/*      */ 
/*  775 */             slice_from("ing");
/*      */           }
/*      */           else {
/*  778 */             this.cursor = (this.limit - v_1);
/*      */ 
/*  782 */             if (eq_s_b(2, "mp"))
/*      */             {
/*  787 */               this.bra = this.cursor;
/*      */ 
/*  789 */               slice_from("m");
/*      */             }
/*      */             else {
/*  792 */               this.cursor = (this.limit - v_1);
/*      */ 
/*  796 */               if (eq_s_b(1, "'"))
/*      */               {
/*  801 */                 this.bra = this.cursor;
/*      */ 
/*  803 */                 if (r_R1())
/*      */                 {
/*  808 */                   slice_del();
/*  809 */                   break;
/*      */                 }
/*      */               }
/*  811 */               this.cursor = (this.limit - v_1);
/*      */ 
/*  814 */               this.bra = this.cursor;
/*      */ 
/*  816 */               if (!r_R1())
/*      */               {
/*  818 */                 return false;
/*      */               }
/*      */ 
/*  821 */               if (!r_C())
/*      */               {
/*  823 */                 return false;
/*      */               }
/*      */ 
/*  826 */               slice_del();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  828 */       break;
/*      */     case 2:
/*  832 */       if (!r_R1())
/*      */       {
/*  834 */         return false;
/*      */       }
/*      */ 
/*  837 */       slice_from("g");
/*  838 */       break;
/*      */     case 3:
/*  842 */       if (!r_R1())
/*      */       {
/*  844 */         return false;
/*      */       }
/*      */ 
/*  847 */       slice_from("lijk");
/*  848 */       break;
/*      */     case 4:
/*  852 */       if (!r_R1())
/*      */       {
/*  854 */         return false;
/*      */       }
/*      */ 
/*  857 */       slice_from("isch");
/*  858 */       break;
/*      */     case 5:
/*  862 */       if (!r_R1())
/*      */       {
/*  864 */         return false;
/*      */       }
/*      */ 
/*  867 */       if (!r_C())
/*      */       {
/*  869 */         return false;
/*      */       }
/*      */ 
/*  872 */       slice_del();
/*  873 */       break;
/*      */     case 6:
/*  877 */       if (!r_R1())
/*      */       {
/*  879 */         return false;
/*      */       }
/*      */ 
/*  882 */       slice_from("t");
/*  883 */       break;
/*      */     case 7:
/*  887 */       if (!r_R1())
/*      */       {
/*  889 */         return false;
/*      */       }
/*      */ 
/*  892 */       slice_from("s");
/*  893 */       break;
/*      */     case 8:
/*  897 */       if (!r_R1())
/*      */       {
/*  899 */         return false;
/*      */       }
/*      */ 
/*  902 */       slice_from("r");
/*  903 */       break;
/*      */     case 9:
/*  907 */       if (!r_R1())
/*      */       {
/*  909 */         return false;
/*      */       }
/*      */ 
/*  912 */       slice_del();
/*      */ 
/*  914 */       insert(this.cursor, this.cursor, "l");
/*      */ 
/*  916 */       if (!r_lengthen_V())
/*      */       {
/*  918 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 10:
/*  924 */       if (!r_R1())
/*      */       {
/*  926 */         return false;
/*      */       }
/*      */ 
/*  929 */       if (!r_C())
/*      */       {
/*  931 */         return false;
/*      */       }
/*      */ 
/*  934 */       slice_del();
/*      */ 
/*  936 */       insert(this.cursor, this.cursor, "en");
/*      */ 
/*  938 */       if (!r_lengthen_V())
/*      */       {
/*  940 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 11:
/*  946 */       if (!r_R1())
/*      */       {
/*  948 */         return false;
/*      */       }
/*      */ 
/*  951 */       if (!r_C())
/*      */       {
/*  953 */         return false;
/*      */       }
/*      */ 
/*  956 */       slice_from("ief");
/*      */     }
/*      */ 
/*  959 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Step_3()
/*      */   {
/*  966 */     this.ket = this.cursor;
/*      */ 
/*  968 */     int among_var = find_among_b(a_2, 14);
/*  969 */     if (among_var == 0)
/*      */     {
/*  971 */       return false;
/*      */     }
/*      */ 
/*  975 */     this.bra = this.cursor;
/*  976 */     switch (among_var) {
/*      */     case 0:
/*  978 */       return false;
/*      */     case 1:
/*  982 */       if (!r_R1())
/*      */       {
/*  984 */         return false;
/*      */       }
/*      */ 
/*  987 */       slice_from("eer");
/*  988 */       break;
/*      */     case 2:
/*  992 */       if (!r_R1())
/*      */       {
/*  994 */         return false;
/*      */       }
/*      */ 
/*  997 */       slice_del();
/*      */ 
/*  999 */       if (!r_lengthen_V())
/*      */       {
/* 1001 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 3:
/* 1007 */       if (!r_R1())
/*      */       {
/* 1009 */         return false;
/*      */       }
/*      */ 
/* 1012 */       slice_del();
/* 1013 */       break;
/*      */     case 4:
/* 1017 */       slice_from("r");
/* 1018 */       break;
/*      */     case 5:
/* 1022 */       if (!r_R1())
/*      */       {
/* 1024 */         return false;
/*      */       }
/*      */ 
/* 1027 */       slice_del();
/*      */ 
/* 1029 */       if (!r_lengthen_V())
/*      */       {
/* 1031 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 6:
/* 1037 */       if (!r_R1())
/*      */       {
/* 1039 */         return false;
/*      */       }
/*      */ 
/* 1042 */       if (!r_C())
/*      */       {
/* 1044 */         return false;
/*      */       }
/*      */ 
/* 1047 */       slice_from("aar");
/* 1048 */       break;
/*      */     case 7:
/* 1052 */       if (!r_R2())
/*      */       {
/* 1054 */         return false;
/*      */       }
/*      */ 
/* 1057 */       slice_del();
/*      */ 
/* 1059 */       insert(this.cursor, this.cursor, "f");
/*      */ 
/* 1061 */       if (!r_lengthen_V())
/*      */       {
/* 1063 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 8:
/* 1069 */       if (!r_R2())
/*      */       {
/* 1071 */         return false;
/*      */       }
/*      */ 
/* 1074 */       slice_del();
/*      */ 
/* 1076 */       insert(this.cursor, this.cursor, "g");
/*      */ 
/* 1078 */       if (!r_lengthen_V())
/*      */       {
/* 1080 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 9:
/* 1086 */       if (!r_R1())
/*      */       {
/* 1088 */         return false;
/*      */       }
/*      */ 
/* 1091 */       if (!r_C())
/*      */       {
/* 1093 */         return false;
/*      */       }
/*      */ 
/* 1096 */       slice_from("t");
/* 1097 */       break;
/*      */     case 10:
/* 1101 */       if (!r_R1())
/*      */       {
/* 1103 */         return false;
/*      */       }
/*      */ 
/* 1106 */       if (!r_C())
/*      */       {
/* 1108 */         return false;
/*      */       }
/*      */ 
/* 1111 */       slice_from("d");
/*      */     }
/*      */ 
/* 1114 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Step_4()
/*      */   {
/* 1123 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1127 */     this.ket = this.cursor;
/*      */ 
/* 1129 */     int among_var = find_among_b(a_3, 16);
/* 1130 */     if (among_var != 0)
/*      */     {
/* 1136 */       this.bra = this.cursor;
/* 1137 */       switch (among_var) {
/*      */       case 0:
/* 1139 */         break;
/*      */       case 1:
/* 1143 */         if (!r_R1())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1148 */         slice_from("ie");
/* 1149 */         break;
/*      */       case 2:
/* 1153 */         if (!r_R1())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1158 */         slice_from("eer");
/* 1159 */         break;
/*      */       case 3:
/* 1163 */         if (!r_R1())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1168 */         slice_del();
/* 1169 */         break;
/*      */       case 4:
/* 1173 */         if (!r_R1())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1178 */         if (!r_V())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1183 */         slice_from("n");
/* 1184 */         break;
/*      */       case 5:
/* 1188 */         if (!r_R1())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1193 */         if (!r_V())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1198 */         slice_from("l");
/* 1199 */         break;
/*      */       case 6:
/* 1203 */         if (!r_R1())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1208 */         if (!r_V())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1213 */         slice_from("r");
/* 1214 */         break;
/*      */       case 7:
/* 1218 */         if (!r_R1())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1223 */         slice_from("teer");
/* 1224 */         break;
/*      */       case 8:
/* 1228 */         if (!r_R1())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1233 */         slice_from("lijk");
/* 1234 */         break;
/*      */       case 9:
/* 1238 */         if (!r_R1())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1243 */         slice_del();
/* 1244 */         break;
/*      */       case 10:
/* 1248 */         if (!r_R1())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1253 */         if (!r_C())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */ 
/* 1258 */         slice_del();
/*      */ 
/* 1260 */         if (!r_lengthen_V())
/*      */         {
/*      */           break label341;
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1268 */       label341: this.cursor = (this.limit - v_1);
/*      */ 
/* 1271 */       this.ket = this.cursor;
/*      */ 
/* 1273 */       among_var = find_among_b(a_4, 3);
/* 1274 */       if (among_var == 0)
/*      */       {
/* 1276 */         return false;
/*      */       }
/*      */ 
/* 1280 */       this.bra = this.cursor;
/* 1281 */       switch (among_var) {
/*      */       case 0:
/* 1283 */         return false;
/*      */       case 1:
/* 1287 */         if (!r_R1())
/*      */         {
/* 1289 */           return false;
/*      */         }
/*      */ 
/* 1292 */         if (!r_C())
/*      */         {
/* 1294 */           return false;
/*      */         }
/*      */ 
/* 1297 */         slice_del();
/*      */ 
/* 1299 */         if (!r_lengthen_V())
/*      */         {
/* 1301 */           return false;
/*      */         }
/*      */         break;
/*      */       }
/*      */     }
/* 1306 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Step_7()
/*      */   {
/* 1313 */     this.ket = this.cursor;
/*      */ 
/* 1315 */     int among_var = find_among_b(a_5, 3);
/* 1316 */     if (among_var == 0)
/*      */     {
/* 1318 */       return false;
/*      */     }
/*      */ 
/* 1322 */     this.bra = this.cursor;
/* 1323 */     switch (among_var) {
/*      */     case 0:
/* 1325 */       return false;
/*      */     case 1:
/* 1329 */       slice_from("k");
/* 1330 */       break;
/*      */     case 2:
/* 1334 */       slice_from("f");
/* 1335 */       break;
/*      */     case 3:
/* 1339 */       slice_from("p");
/*      */     }
/*      */ 
/* 1342 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Step_6()
/*      */   {
/* 1349 */     this.ket = this.cursor;
/*      */ 
/* 1351 */     int among_var = find_among_b(a_6, 22);
/* 1352 */     if (among_var == 0)
/*      */     {
/* 1354 */       return false;
/*      */     }
/*      */ 
/* 1358 */     this.bra = this.cursor;
/* 1359 */     switch (among_var) {
/*      */     case 0:
/* 1361 */       return false;
/*      */     case 1:
/* 1365 */       slice_from("b");
/* 1366 */       break;
/*      */     case 2:
/* 1370 */       slice_from("c");
/* 1371 */       break;
/*      */     case 3:
/* 1375 */       slice_from("d");
/* 1376 */       break;
/*      */     case 4:
/* 1380 */       slice_from("f");
/* 1381 */       break;
/*      */     case 5:
/* 1385 */       slice_from("g");
/* 1386 */       break;
/*      */     case 6:
/* 1390 */       slice_from("h");
/* 1391 */       break;
/*      */     case 7:
/* 1395 */       slice_from("j");
/* 1396 */       break;
/*      */     case 8:
/* 1400 */       slice_from("k");
/* 1401 */       break;
/*      */     case 9:
/* 1405 */       slice_from("l");
/* 1406 */       break;
/*      */     case 10:
/* 1410 */       slice_from("m");
/* 1411 */       break;
/*      */     case 11:
/* 1415 */       slice_from("n");
/* 1416 */       break;
/*      */     case 12:
/* 1420 */       slice_from("p");
/* 1421 */       break;
/*      */     case 13:
/* 1425 */       slice_from("q");
/* 1426 */       break;
/*      */     case 14:
/* 1430 */       slice_from("r");
/* 1431 */       break;
/*      */     case 15:
/* 1435 */       slice_from("s");
/* 1436 */       break;
/*      */     case 16:
/* 1440 */       slice_from("t");
/* 1441 */       break;
/*      */     case 17:
/* 1445 */       slice_from("v");
/* 1446 */       break;
/*      */     case 18:
/* 1450 */       slice_from("w");
/* 1451 */       break;
/*      */     case 19:
/* 1455 */       slice_from("x");
/* 1456 */       break;
/*      */     case 20:
/* 1460 */       slice_from("z");
/* 1461 */       break;
/*      */     case 21:
/* 1465 */       slice_from("f");
/* 1466 */       break;
/*      */     case 22:
/* 1470 */       slice_from("s");
/*      */     }
/*      */ 
/* 1473 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Step_1c()
/*      */   {
/* 1482 */     this.ket = this.cursor;
/*      */ 
/* 1484 */     int among_var = find_among_b(a_7, 2);
/* 1485 */     if (among_var == 0)
/*      */     {
/* 1487 */       return false;
/*      */     }
/*      */ 
/* 1491 */     this.bra = this.cursor;
/*      */ 
/* 1493 */     if (!r_R1())
/*      */     {
/* 1495 */       return false;
/*      */     }
/*      */ 
/* 1498 */     if (!r_C())
/*      */     {
/* 1500 */       return false;
/*      */     }
/* 1502 */     switch (among_var) {
/*      */     case 0:
/* 1504 */       return false;
/*      */     case 1:
/* 1509 */       int v_1 = this.limit - this.cursor;
/*      */ 
/* 1513 */       if (eq_s_b(1, "n"))
/*      */       {
/* 1518 */         if (r_R1())
/*      */         {
/* 1522 */           return false;
/*      */         }
/*      */       }
/* 1524 */       this.cursor = (this.limit - v_1);
/*      */ 
/* 1527 */       slice_del();
/* 1528 */       break;
/*      */     case 2:
/* 1533 */       int v_2 = this.limit - this.cursor;
/*      */ 
/* 1537 */       if (eq_s_b(1, "h"))
/*      */       {
/* 1542 */         if (r_R1())
/*      */         {
/* 1546 */           return false;
/*      */         }
/*      */       }
/* 1548 */       this.cursor = (this.limit - v_2);
/*      */ 
/* 1551 */       slice_del();
/*      */     }
/*      */ 
/* 1554 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Lose_prefix()
/*      */   {
/* 1563 */     this.bra = this.cursor;
/*      */ 
/* 1565 */     if (!eq_s(2, "ge"))
/*      */     {
/* 1567 */       return false;
/*      */     }
/*      */ 
/* 1570 */     this.ket = this.cursor;
/*      */ 
/* 1572 */     int v_1 = this.cursor;
/*      */ 
/* 1575 */     int c = this.cursor + 3;
/* 1576 */     if ((0 > c) || (c > this.limit))
/*      */     {
/* 1578 */       return false;
/*      */     }
/* 1580 */     this.cursor = c;
/*      */ 
/* 1582 */     this.cursor = v_1;
/*      */     while (true)
/*      */     {
/* 1587 */       int v_2 = this.cursor;
/*      */ 
/* 1589 */       if (in_grouping(g_v, 97, 121))
/*      */       {
/* 1593 */         this.cursor = v_2;
/* 1594 */         break;
/*      */       }
/* 1596 */       this.cursor = v_2;
/* 1597 */       if (this.cursor >= this.limit)
/*      */       {
/* 1599 */         return false;
/*      */       }
/* 1601 */       this.cursor += 1;
/*      */     }
/*      */ 
/*      */     while (true)
/*      */     {
/* 1606 */       int v_3 = this.cursor;
/*      */ 
/* 1608 */       if (out_grouping(g_v, 97, 121))
/*      */       {
/* 1612 */         this.cursor = v_3;
/* 1613 */         break;
/*      */       }
/* 1615 */       this.cursor = v_3;
/* 1616 */       if (this.cursor >= this.limit)
/*      */       {
/* 1618 */         return false;
/*      */       }
/* 1620 */       this.cursor += 1;
/*      */     }
/*      */ 
/* 1623 */     this.B_GE_removed = true;
/*      */ 
/* 1625 */     slice_del();
/* 1626 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_Lose_infix()
/*      */   {
/* 1635 */     if (this.cursor >= this.limit)
/*      */     {
/* 1637 */       return false;
/*      */     }
/* 1639 */     this.cursor += 1;
/*      */     while (true)
/*      */     {
/* 1646 */       this.bra = this.cursor;
/*      */ 
/* 1648 */       if (eq_s(2, "ge"))
/*      */       {
/* 1653 */         this.ket = this.cursor;
/* 1654 */         break;
/*      */       }
/* 1656 */       if (this.cursor >= this.limit)
/*      */       {
/* 1658 */         return false;
/*      */       }
/* 1660 */       this.cursor += 1;
/*      */     }
/*      */ 
/* 1663 */     int v_2 = this.cursor;
/*      */ 
/* 1666 */     int c = this.cursor + 3;
/* 1667 */     if ((0 > c) || (c > this.limit))
/*      */     {
/* 1669 */       return false;
/*      */     }
/* 1671 */     this.cursor = c;
/*      */ 
/* 1673 */     this.cursor = v_2;
/*      */     while (true)
/*      */     {
/* 1678 */       int v_3 = this.cursor;
/*      */ 
/* 1680 */       if (in_grouping(g_v, 97, 121))
/*      */       {
/* 1684 */         this.cursor = v_3;
/* 1685 */         break;
/*      */       }
/* 1687 */       this.cursor = v_3;
/* 1688 */       if (this.cursor >= this.limit)
/*      */       {
/* 1690 */         return false;
/*      */       }
/* 1692 */       this.cursor += 1;
/*      */     }
/*      */ 
/*      */     while (true)
/*      */     {
/* 1697 */       int v_4 = this.cursor;
/*      */ 
/* 1699 */       if (out_grouping(g_v, 97, 121))
/*      */       {
/* 1703 */         this.cursor = v_4;
/* 1704 */         break;
/*      */       }
/* 1706 */       this.cursor = v_4;
/* 1707 */       if (this.cursor >= this.limit)
/*      */       {
/* 1709 */         return false;
/*      */       }
/* 1711 */       this.cursor += 1;
/*      */     }
/*      */ 
/* 1714 */     this.B_GE_removed = true;
/*      */ 
/* 1716 */     slice_del();
/* 1717 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_measure()
/*      */   {
/* 1729 */     int v_1 = this.cursor;
/*      */ 
/* 1733 */     this.cursor = this.limit;
/*      */ 
/* 1735 */     this.I_p1 = this.cursor;
/*      */ 
/* 1737 */     this.I_p2 = this.cursor;
/*      */ 
/* 1739 */     this.cursor = v_1;
/*      */ 
/* 1741 */     int v_2 = this.cursor;
/*      */     while (true)
/*      */     {
/* 1748 */       if (!out_grouping(g_v, 97, 121))
/*      */       {
/* 1750 */         break;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1758 */     int v_4 = 1;
/*      */     int v_5;
/*      */     while (true)
/*      */     {
/* 1762 */       v_5 = this.cursor;
/*      */ 
/* 1767 */       int v_6 = this.cursor;
/*      */ 
/* 1770 */       if (!eq_s(2, "ij"))
/*      */       {
/* 1776 */         this.cursor = v_6;
/* 1777 */         if (!in_grouping(g_v, 97, 121))
/*      */         {
/*      */           break;
/*      */         }
/*      */       }
/* 1782 */       v_4--;
/*      */     }
/*      */ 
/* 1785 */     this.cursor = v_5;
/*      */ 
/* 1788 */     if (v_4 <= 0)
/*      */     {
/* 1793 */       if (out_grouping(g_v, 97, 121))
/*      */       {
/* 1798 */         this.I_p1 = this.cursor;
/*      */         while (true)
/*      */         {
/* 1803 */           if (!out_grouping(g_v, 97, 121))
/*      */           {
/* 1805 */             break;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1813 */         int v_8 = 1;
/*      */         int v_9;
/*      */         while (true)
/*      */         {
/* 1817 */           v_9 = this.cursor;
/*      */ 
/* 1822 */           int v_10 = this.cursor;
/*      */ 
/* 1825 */           if (!eq_s(2, "ij"))
/*      */           {
/* 1831 */             this.cursor = v_10;
/* 1832 */             if (!in_grouping(g_v, 97, 121))
/*      */             {
/*      */               break;
/*      */             }
/*      */           }
/* 1837 */           v_8--;
/*      */         }
/*      */ 
/* 1840 */         this.cursor = v_9;
/*      */ 
/* 1843 */         if (v_8 <= 0)
/*      */         {
/* 1848 */           if (out_grouping(g_v, 97, 121))
/*      */           {
/* 1853 */             this.I_p2 = this.cursor;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1855 */     this.cursor = v_2;
/* 1856 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean stem()
/*      */   {
/* 1882 */     this.B_Y_found = false;
/*      */ 
/* 1884 */     this.B_stemmed = false;
/*      */ 
/* 1886 */     int v_1 = this.cursor;
/*      */ 
/* 1890 */     this.bra = this.cursor;
/*      */ 
/* 1892 */     if (eq_s(1, "y"))
/*      */     {
/* 1897 */       this.ket = this.cursor;
/*      */ 
/* 1899 */       slice_from("Y");
/*      */ 
/* 1901 */       this.B_Y_found = true;
/*      */     }
/* 1903 */     this.cursor = v_1;
/*      */ 
/* 1905 */     int v_2 = this.cursor;
/*      */     int v_3;
/*      */     while (true) {
/* 1910 */       v_3 = this.cursor;
/*      */       while (true)
/*      */       {
/* 1916 */         int v_4 = this.cursor;
/*      */ 
/* 1919 */         if (in_grouping(g_v, 97, 121))
/*      */         {
/* 1924 */           this.bra = this.cursor;
/*      */ 
/* 1926 */           if (eq_s(1, "y"))
/*      */           {
/* 1931 */             this.ket = this.cursor;
/* 1932 */             this.cursor = v_4;
/* 1933 */             break;
/*      */           }
/*      */         }
/* 1935 */         this.cursor = v_4;
/* 1936 */         if (this.cursor >= this.limit)
/*      */         {
/*      */           break label178;
/*      */         }
/* 1940 */         this.cursor += 1;
/*      */       }
/*      */ 
/* 1943 */       slice_from("Y");
/*      */ 
/* 1945 */       this.B_Y_found = true;
/*      */     }
/*      */ 
/* 1948 */     label178: this.cursor = v_3;
/*      */ 
/* 1952 */     this.cursor = v_2;
/*      */ 
/* 1954 */     if (!r_measure())
/*      */     {
/* 1956 */       return false;
/*      */     }
/*      */ 
/* 1959 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 1962 */     int v_5 = this.limit - this.cursor;
/*      */ 
/* 1966 */     if (r_Step_1())
/*      */     {
/* 1971 */       this.B_stemmed = true;
/*      */     }
/* 1973 */     this.cursor = (this.limit - v_5);
/*      */ 
/* 1975 */     int v_6 = this.limit - this.cursor;
/*      */ 
/* 1979 */     if (r_Step_2())
/*      */     {
/* 1984 */       this.B_stemmed = true;
/*      */     }
/* 1986 */     this.cursor = (this.limit - v_6);
/*      */ 
/* 1988 */     int v_7 = this.limit - this.cursor;
/*      */ 
/* 1992 */     if (r_Step_3())
/*      */     {
/* 1997 */       this.B_stemmed = true;
/*      */     }
/* 1999 */     this.cursor = (this.limit - v_7);
/*      */ 
/* 2001 */     int v_8 = this.limit - this.cursor;
/*      */ 
/* 2005 */     if (r_Step_4())
/*      */     {
/* 2010 */       this.B_stemmed = true;
/*      */     }
/* 2012 */     this.cursor = (this.limit - v_8);
/* 2013 */     this.cursor = this.limit_backward;
/* 2014 */     this.B_GE_removed = false;
/*      */ 
/* 2016 */     int v_9 = this.cursor;
/*      */ 
/* 2020 */     int v_10 = this.cursor;
/*      */ 
/* 2022 */     if (r_Lose_prefix())
/*      */     {
/* 2026 */       this.cursor = v_10;
/*      */ 
/* 2028 */       if (r_measure());
/*      */     }
/*      */ 
/* 2033 */     this.cursor = v_9;
/*      */ 
/* 2035 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 2038 */     int v_11 = this.limit - this.cursor;
/*      */ 
/* 2042 */     if (this.B_GE_removed)
/*      */     {
/* 2047 */       if (r_Step_1c());
/*      */     }
/*      */ 
/* 2052 */     this.cursor = (this.limit - v_11);
/* 2053 */     this.cursor = this.limit_backward;
/* 2054 */     this.B_GE_removed = false;
/*      */ 
/* 2056 */     int v_12 = this.cursor;
/*      */ 
/* 2060 */     int v_13 = this.cursor;
/*      */ 
/* 2062 */     if (r_Lose_infix())
/*      */     {
/* 2066 */       this.cursor = v_13;
/*      */ 
/* 2068 */       if (r_measure());
/*      */     }
/*      */ 
/* 2073 */     this.cursor = v_12;
/*      */ 
/* 2075 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 2078 */     int v_14 = this.limit - this.cursor;
/*      */ 
/* 2082 */     if (this.B_GE_removed)
/*      */     {
/* 2087 */       if (r_Step_1c());
/*      */     }
/*      */ 
/* 2092 */     this.cursor = (this.limit - v_14);
/* 2093 */     this.cursor = this.limit_backward;
/* 2094 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 2097 */     int v_15 = this.limit - this.cursor;
/*      */ 
/* 2101 */     if (r_Step_7())
/*      */     {
/* 2106 */       this.B_stemmed = true;
/*      */     }
/* 2108 */     this.cursor = (this.limit - v_15);
/*      */ 
/* 2110 */     int v_16 = this.limit - this.cursor;
/*      */ 
/* 2117 */     if ((this.B_stemmed) || 
/* 2124 */       (this.B_GE_removed))
/*      */     {
/* 2130 */       if (r_Step_6());
/*      */     }
/*      */ 
/* 2135 */     this.cursor = (this.limit - v_16);
/* 2136 */     this.cursor = this.limit_backward;
/* 2137 */     int v_18 = this.cursor;
/*      */ 
/* 2141 */     if (this.B_Y_found)
/*      */     {
/*      */       int v_19;
/*      */       while (true)
/*      */       {
/* 2148 */         v_19 = this.cursor;
/*      */         while (true)
/*      */         {
/* 2154 */           int v_20 = this.cursor;
/*      */ 
/* 2158 */           this.bra = this.cursor;
/*      */ 
/* 2160 */           if (eq_s(1, "Y"))
/*      */           {
/* 2165 */             this.ket = this.cursor;
/* 2166 */             this.cursor = v_20;
/* 2167 */             break;
/*      */           }
/* 2169 */           this.cursor = v_20;
/* 2170 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break label805;
/*      */           }
/* 2174 */           this.cursor += 1;
/*      */         }
/*      */ 
/* 2177 */         slice_from("y");
/*      */       }
/*      */ 
/* 2180 */       label805: this.cursor = v_19;
/*      */     }
/*      */ 
/* 2184 */     this.cursor = v_18;
/* 2185 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 2190 */     return o instanceof KpStemmer;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 2195 */     return KpStemmer.class.getName().hashCode();
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.tartarus.snowball.ext.KpStemmer
 * JD-Core Version:    0.6.2
 */