/*     */ package org.apache.lucene.collation;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.text.Collator;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.core.KeywordTokenizer;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class CollationKeyAnalyzer extends Analyzer
/*     */ {
/*     */   private final Collator collator;
/*     */   private final CollationAttributeFactory factory;
/*     */   private final Version matchVersion;
/*     */ 
/*     */   public CollationKeyAnalyzer(Version matchVersion, Collator collator)
/*     */   {
/*  97 */     this.matchVersion = matchVersion;
/*  98 */     this.collator = collator;
/*  99 */     this.factory = new CollationAttributeFactory(collator);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public CollationKeyAnalyzer(Collator collator)
/*     */   {
/* 108 */     this(Version.LUCENE_31, collator);
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 114 */     if (this.matchVersion.onOrAfter(Version.LUCENE_40)) {
/* 115 */       KeywordTokenizer tokenizer = new KeywordTokenizer(this.factory, reader, 256);
/* 116 */       return new Analyzer.TokenStreamComponents(tokenizer, tokenizer);
/*     */     }
/* 118 */     KeywordTokenizer tokenizer = new KeywordTokenizer(reader);
/* 119 */     return new Analyzer.TokenStreamComponents(tokenizer, new CollationKeyFilter(tokenizer, this.collator));
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.collation.CollationKeyAnalyzer
 * JD-Core Version:    0.6.2
 */