/*    */ package org.apache.lucene.collation;
/*    */ 
/*    */ import java.text.Collator;
/*    */ import org.apache.lucene.collation.tokenattributes.CollatedTermAttributeImpl;
/*    */ import org.apache.lucene.util.Attribute;
/*    */ import org.apache.lucene.util.AttributeImpl;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public class CollationAttributeFactory extends AttributeSource.AttributeFactory
/*    */ {
/*    */   private final Collator collator;
/*    */   private final AttributeSource.AttributeFactory delegate;
/*    */ 
/*    */   public CollationAttributeFactory(Collator collator)
/*    */   {
/* 82 */     this(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY, collator);
/*    */   }
/*    */ 
/*    */   public CollationAttributeFactory(AttributeSource.AttributeFactory delegate, Collator collator)
/*    */   {
/* 92 */     this.delegate = delegate;
/* 93 */     this.collator = collator;
/*    */   }
/*    */ 
/*    */   public AttributeImpl createAttributeInstance(Class<? extends Attribute> attClass)
/*    */   {
/* 99 */     return attClass.isAssignableFrom(CollatedTermAttributeImpl.class) ? new CollatedTermAttributeImpl(this.collator) : this.delegate.createAttributeInstance(attClass);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.collation.CollationAttributeFactory
 * JD-Core Version:    0.6.2
 */