/*    */ package org.apache.lucene.collation.tokenattributes;
/*    */ 
/*    */ import java.text.CollationKey;
/*    */ import java.text.Collator;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttributeImpl;
/*    */ import org.apache.lucene.util.BytesRef;
/*    */ 
/*    */ public class CollatedTermAttributeImpl extends CharTermAttributeImpl
/*    */ {
/*    */   private final Collator collator;
/*    */ 
/*    */   public CollatedTermAttributeImpl(Collator collator)
/*    */   {
/* 39 */     this.collator = ((Collator)collator.clone());
/*    */   }
/*    */ 
/*    */   public void fillBytesRef()
/*    */   {
/* 44 */     BytesRef bytes = getBytesRef();
/* 45 */     bytes.bytes = this.collator.getCollationKey(toString()).toByteArray();
/* 46 */     bytes.offset = 0;
/* 47 */     bytes.length = bytes.bytes.length;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.collation.tokenattributes.CollatedTermAttributeImpl
 * JD-Core Version:    0.6.2
 */