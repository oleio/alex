/*     */ package org.apache.lucene.collation;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.text.Collator;
/*     */ import java.text.ParseException;
/*     */ import java.text.RuleBasedCollator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.util.AbstractAnalysisFactory;
/*     */ import org.apache.lucene.analysis.util.MultiTermAwareComponent;
/*     */ import org.apache.lucene.analysis.util.ResourceLoader;
/*     */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*     */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ 
/*     */ @Deprecated
/*     */ public class CollationKeyFilterFactory extends TokenFilterFactory
/*     */   implements MultiTermAwareComponent, ResourceLoaderAware
/*     */ {
/*     */   private Collator collator;
/*     */   private final String custom;
/*     */   private final String language;
/*     */   private final String country;
/*     */   private final String variant;
/*     */   private final String strength;
/*     */   private final String decomposition;
/*     */ 
/*     */   public CollationKeyFilterFactory(Map<String, String> args)
/*     */   {
/*  85 */     super(args);
/*  86 */     this.custom = ((String)args.remove("custom"));
/*  87 */     this.language = ((String)args.remove("language"));
/*  88 */     this.country = ((String)args.remove("country"));
/*  89 */     this.variant = ((String)args.remove("variant"));
/*  90 */     this.strength = ((String)args.remove("strength"));
/*  91 */     this.decomposition = ((String)args.remove("decomposition"));
/*     */ 
/*  93 */     if ((this.custom == null) && (this.language == null)) {
/*  94 */       throw new IllegalArgumentException("Either custom or language is required.");
/*     */     }
/*  96 */     if ((this.custom != null) && ((this.language != null) || (this.country != null) || (this.variant != null)))
/*     */     {
/*  98 */       throw new IllegalArgumentException("Cannot specify both language and custom. To tailor rules for a built-in language, see the javadocs for RuleBasedCollator. Then save the entire customized ruleset to a file, and use with the custom parameter");
/*     */     }
/*     */ 
/* 102 */     if (!args.isEmpty())
/* 103 */       throw new IllegalArgumentException(new StringBuilder().append("Unknown parameters: ").append(args).toString());
/*     */   }
/*     */ 
/*     */   public void inform(ResourceLoader loader) throws IOException
/*     */   {
/* 108 */     if (this.language != null)
/*     */     {
/* 110 */       this.collator = createFromLocale(this.language, this.country, this.variant);
/*     */     }
/*     */     else {
/* 113 */       this.collator = createFromRules(this.custom, loader);
/*     */     }
/*     */ 
/* 117 */     if (this.strength != null) {
/* 118 */       if (this.strength.equalsIgnoreCase("primary"))
/* 119 */         this.collator.setStrength(0);
/* 120 */       else if (this.strength.equalsIgnoreCase("secondary"))
/* 121 */         this.collator.setStrength(1);
/* 122 */       else if (this.strength.equalsIgnoreCase("tertiary"))
/* 123 */         this.collator.setStrength(2);
/* 124 */       else if (this.strength.equalsIgnoreCase("identical"))
/* 125 */         this.collator.setStrength(3);
/*     */       else {
/* 127 */         throw new IllegalArgumentException(new StringBuilder().append("Invalid strength: ").append(this.strength).toString());
/*     */       }
/*     */     }
/*     */ 
/* 131 */     if (this.decomposition != null)
/* 132 */       if (this.decomposition.equalsIgnoreCase("no"))
/* 133 */         this.collator.setDecomposition(0);
/* 134 */       else if (this.decomposition.equalsIgnoreCase("canonical"))
/* 135 */         this.collator.setDecomposition(1);
/* 136 */       else if (this.decomposition.equalsIgnoreCase("full"))
/* 137 */         this.collator.setDecomposition(2);
/*     */       else
/* 139 */         throw new IllegalArgumentException(new StringBuilder().append("Invalid decomposition: ").append(this.decomposition).toString());
/*     */   }
/*     */ 
/*     */   public TokenStream create(TokenStream input)
/*     */   {
/* 144 */     return new CollationKeyFilter(input, this.collator);
/*     */   }
/*     */ 
/*     */   private Collator createFromLocale(String language, String country, String variant)
/*     */   {
/* 154 */     if ((language != null) && (country == null) && (variant != null))
/* 155 */       throw new IllegalArgumentException("To specify variant, country is required");
/*     */     Locale locale;
/*     */     Locale locale;
/* 156 */     if ((language != null) && (country != null) && (variant != null)) {
/* 157 */       locale = new Locale(language, country, variant);
/*     */     }
/*     */     else
/*     */     {
/*     */       Locale locale;
/* 158 */       if ((language != null) && (country != null))
/* 159 */         locale = new Locale(language, country);
/*     */       else
/* 161 */         locale = new Locale(language);
/*     */     }
/* 163 */     return Collator.getInstance(locale);
/*     */   }
/*     */ 
/*     */   private Collator createFromRules(String fileName, ResourceLoader loader)
/*     */     throws IOException
/*     */   {
/* 171 */     InputStream input = null;
/*     */     try {
/* 173 */       input = loader.openResource(fileName);
/* 174 */       String rules = toUTF8String(input);
/* 175 */       return new RuleBasedCollator(rules);
/*     */     }
/*     */     catch (ParseException e) {
/* 178 */       throw new IOException("ParseException thrown while parsing rules", e);
/*     */     } finally {
/* 180 */       IOUtils.closeWhileHandlingException(new Closeable[] { input });
/*     */     }
/*     */   }
/*     */ 
/*     */   public AbstractAnalysisFactory getMultiTermComponent()
/*     */   {
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */   private String toUTF8String(InputStream in) throws IOException {
/* 190 */     StringBuilder sb = new StringBuilder();
/* 191 */     char[] buffer = new char[1024];
/* 192 */     Reader r = IOUtils.getDecodingReader(in, StandardCharsets.UTF_8);
/* 193 */     int len = 0;
/* 194 */     while ((len = r.read(buffer)) > 0) {
/* 195 */       sb.append(buffer, 0, len);
/*     */     }
/* 197 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.collation.CollationKeyFilterFactory
 * JD-Core Version:    0.6.2
 */