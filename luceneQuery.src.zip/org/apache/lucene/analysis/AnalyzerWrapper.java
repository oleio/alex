/*     */ package org.apache.lucene.analysis;
/*     */ 
/*     */ import java.io.Reader;
/*     */ 
/*     */ public abstract class AnalyzerWrapper extends Analyzer
/*     */ {
/*     */   @Deprecated
/*     */   protected AnalyzerWrapper()
/*     */   {
/*  44 */     this(PER_FIELD_REUSE_STRATEGY);
/*     */   }
/*     */ 
/*     */   protected AnalyzerWrapper(Analyzer.ReuseStrategy reuseStrategy)
/*     */   {
/*  57 */     super(reuseStrategy);
/*     */   }
/*     */ 
/*     */   protected abstract Analyzer getWrappedAnalyzer(String paramString);
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents wrapComponents(String fieldName, Analyzer.TokenStreamComponents components)
/*     */   {
/*  82 */     return components;
/*     */   }
/*     */ 
/*     */   protected Reader wrapReader(String fieldName, Reader reader)
/*     */   {
/*  97 */     return reader;
/*     */   }
/*     */ 
/*     */   protected final Analyzer.TokenStreamComponents createComponents(String fieldName, Reader aReader)
/*     */   {
/* 102 */     return wrapComponents(fieldName, getWrappedAnalyzer(fieldName).createComponents(fieldName, aReader));
/*     */   }
/*     */ 
/*     */   public int getPositionIncrementGap(String fieldName)
/*     */   {
/* 107 */     return getWrappedAnalyzer(fieldName).getPositionIncrementGap(fieldName);
/*     */   }
/*     */ 
/*     */   public int getOffsetGap(String fieldName)
/*     */   {
/* 112 */     return getWrappedAnalyzer(fieldName).getOffsetGap(fieldName);
/*     */   }
/*     */ 
/*     */   public final Reader initReader(String fieldName, Reader reader)
/*     */   {
/* 117 */     return getWrappedAnalyzer(fieldName).initReader(fieldName, wrapReader(fieldName, reader));
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.AnalyzerWrapper
 * JD-Core Version:    0.6.2
 */