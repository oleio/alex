/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.AbstractAnalysisFactory;
/*    */ import org.apache.lucene.analysis.util.MultiTermAwareComponent;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class ASCIIFoldingFilterFactory extends TokenFilterFactory
/*    */   implements MultiTermAwareComponent
/*    */ {
/*    */   private final boolean preserveOriginal;
/*    */ 
/*    */   public ASCIIFoldingFilterFactory(Map<String, String> args)
/*    */   {
/* 43 */     super(args);
/* 44 */     this.preserveOriginal = getBoolean(args, "preserveOriginal", false);
/* 45 */     if (!args.isEmpty())
/* 46 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ASCIIFoldingFilter create(TokenStream input)
/*    */   {
/* 52 */     return new ASCIIFoldingFilter(input, this.preserveOriginal);
/*    */   }
/*    */ 
/*    */   public AbstractAnalysisFactory getMultiTermComponent()
/*    */   {
/* 57 */     return this;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.ASCIIFoldingFilterFactory
 * JD-Core Version:    0.6.2
 */