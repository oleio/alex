/*      */ package org.apache.lucene.analysis.miscellaneous;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import org.apache.lucene.analysis.TokenFilter;
/*      */ import org.apache.lucene.analysis.TokenStream;
/*      */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*      */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*      */ import org.apache.lucene.util.ArrayUtil;
/*      */ import org.apache.lucene.util.AttributeSource.State;
/*      */ 
/*      */ public final class ASCIIFoldingFilter extends TokenFilter
/*      */ {
/*   61 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*   62 */   private final PositionIncrementAttribute posIncAttr = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*      */   private final boolean preserveOriginal;
/*   64 */   private char[] output = new char[512];
/*      */   private int outputPos;
/*      */   private AttributeSource.State state;
/*      */ 
/*      */   public ASCIIFoldingFilter(TokenStream input)
/*      */   {
/*   70 */     this(input, false);
/*      */   }
/*      */ 
/*      */   public ASCIIFoldingFilter(TokenStream input, boolean preserveOriginal)
/*      */   {
/*   84 */     super(input);
/*   85 */     this.preserveOriginal = preserveOriginal;
/*      */   }
/*      */ 
/*      */   public boolean isPreserveOriginal()
/*      */   {
/*   92 */     return this.preserveOriginal;
/*      */   }
/*      */ 
/*      */   public boolean incrementToken() throws IOException
/*      */   {
/*   97 */     if (this.state != null) {
/*   98 */       assert (this.preserveOriginal) : "state should only be captured if preserveOriginal is true";
/*   99 */       restoreState(this.state);
/*  100 */       this.posIncAttr.setPositionIncrement(0);
/*  101 */       this.state = null;
/*  102 */       return true;
/*      */     }
/*  104 */     if (this.input.incrementToken()) {
/*  105 */       char[] buffer = this.termAtt.buffer();
/*  106 */       int length = this.termAtt.length();
/*      */ 
/*  110 */       for (int i = 0; i < length; i++) {
/*  111 */         char c = buffer[i];
/*  112 */         if (c >= '')
/*      */         {
/*  114 */           foldToASCII(buffer, length);
/*  115 */           this.termAtt.copyBuffer(this.output, 0, this.outputPos);
/*  116 */           break;
/*      */         }
/*      */       }
/*  119 */       return true;
/*      */     }
/*  121 */     return false;
/*      */   }
/*      */ 
/*      */   public void reset()
/*      */     throws IOException
/*      */   {
/*  127 */     super.reset();
/*  128 */     this.state = null;
/*      */   }
/*      */ 
/*      */   public void foldToASCII(char[] input, int length)
/*      */   {
/*  139 */     if (this.preserveOriginal) {
/*  140 */       this.state = captureState();
/*      */     }
/*      */ 
/*  143 */     int maxSizeNeeded = 4 * length;
/*  144 */     if (this.output.length < maxSizeNeeded) {
/*  145 */       this.output = new char[ArrayUtil.oversize(maxSizeNeeded, 2)];
/*      */     }
/*      */ 
/*  148 */     this.outputPos = foldToASCII(input, 0, this.output, 0, length);
/*      */   }
/*      */ 
/*      */   public static final int foldToASCII(char[] input, int inputPos, char[] output, int outputPos, int length)
/*      */   {
/*  164 */     int end = inputPos + length;
/*  165 */     for (int pos = inputPos; pos < end; pos++) {
/*  166 */       char c = input[pos];
/*      */ 
/*  169 */       if (c < '')
/*  170 */         output[(outputPos++)] = c;
/*      */       else {
/*  172 */         switch (c) {
/*      */         case 'À':
/*      */         case 'Á':
/*      */         case 'Â':
/*      */         case 'Ã':
/*      */         case 'Ä':
/*      */         case 'Å':
/*      */         case 'Ā':
/*      */         case 'Ă':
/*      */         case 'Ą':
/*      */         case 'Ə':
/*      */         case 'Ǎ':
/*      */         case 'Ǟ':
/*      */         case 'Ǡ':
/*      */         case 'Ǻ':
/*      */         case 'Ȁ':
/*      */         case 'Ȃ':
/*      */         case 'Ȧ':
/*      */         case 'Ⱥ':
/*      */         case 'ᴀ':
/*      */         case 'Ḁ':
/*      */         case 'Ạ':
/*      */         case 'Ả':
/*      */         case 'Ấ':
/*      */         case 'Ầ':
/*      */         case 'Ẩ':
/*      */         case 'Ẫ':
/*      */         case 'Ậ':
/*      */         case 'Ắ':
/*      */         case 'Ằ':
/*      */         case 'Ẳ':
/*      */         case 'Ẵ':
/*      */         case 'Ặ':
/*      */         case 'Ⓐ':
/*      */         case 'Ａ':
/*  207 */           output[(outputPos++)] = 'A';
/*  208 */           break;
/*      */         case 'à':
/*      */         case 'á':
/*      */         case 'â':
/*      */         case 'ã':
/*      */         case 'ä':
/*      */         case 'å':
/*      */         case 'ā':
/*      */         case 'ă':
/*      */         case 'ą':
/*      */         case 'ǎ':
/*      */         case 'ǟ':
/*      */         case 'ǡ':
/*      */         case 'ǻ':
/*      */         case 'ȁ':
/*      */         case 'ȃ':
/*      */         case 'ȧ':
/*      */         case 'ɐ':
/*      */         case 'ə':
/*      */         case 'ɚ':
/*      */         case 'ᶏ':
/*      */         case 'ᶕ':
/*      */         case 'ḁ':
/*      */         case 'ẚ':
/*      */         case 'ạ':
/*      */         case 'ả':
/*      */         case 'ấ':
/*      */         case 'ầ':
/*      */         case 'ẩ':
/*      */         case 'ẫ':
/*      */         case 'ậ':
/*      */         case 'ắ':
/*      */         case 'ằ':
/*      */         case 'ẳ':
/*      */         case 'ẵ':
/*      */         case 'ặ':
/*      */         case 'ₐ':
/*      */         case 'ₔ':
/*      */         case 'ⓐ':
/*      */         case 'ⱥ':
/*      */         case 'Ɐ':
/*      */         case 'ａ':
/*  250 */           output[(outputPos++)] = 'a';
/*  251 */           break;
/*      */         case 'Ꜳ':
/*  253 */           output[(outputPos++)] = 'A';
/*  254 */           output[(outputPos++)] = 'A';
/*  255 */           break;
/*      */         case 'Æ':
/*      */         case 'Ǣ':
/*      */         case 'Ǽ':
/*      */         case 'ᴁ':
/*  260 */           output[(outputPos++)] = 'A';
/*  261 */           output[(outputPos++)] = 'E';
/*  262 */           break;
/*      */         case 'Ꜵ':
/*  264 */           output[(outputPos++)] = 'A';
/*  265 */           output[(outputPos++)] = 'O';
/*  266 */           break;
/*      */         case 'Ꜷ':
/*  268 */           output[(outputPos++)] = 'A';
/*  269 */           output[(outputPos++)] = 'U';
/*  270 */           break;
/*      */         case 'Ꜹ':
/*      */         case 'Ꜻ':
/*  273 */           output[(outputPos++)] = 'A';
/*  274 */           output[(outputPos++)] = 'V';
/*  275 */           break;
/*      */         case 'Ꜽ':
/*  277 */           output[(outputPos++)] = 'A';
/*  278 */           output[(outputPos++)] = 'Y';
/*  279 */           break;
/*      */         case '⒜':
/*  281 */           output[(outputPos++)] = '(';
/*  282 */           output[(outputPos++)] = 'a';
/*  283 */           output[(outputPos++)] = ')';
/*  284 */           break;
/*      */         case 'ꜳ':
/*  286 */           output[(outputPos++)] = 'a';
/*  287 */           output[(outputPos++)] = 'a';
/*  288 */           break;
/*      */         case 'æ':
/*      */         case 'ǣ':
/*      */         case 'ǽ':
/*      */         case 'ᴂ':
/*  293 */           output[(outputPos++)] = 'a';
/*  294 */           output[(outputPos++)] = 'e';
/*  295 */           break;
/*      */         case 'ꜵ':
/*  297 */           output[(outputPos++)] = 'a';
/*  298 */           output[(outputPos++)] = 'o';
/*  299 */           break;
/*      */         case 'ꜷ':
/*  301 */           output[(outputPos++)] = 'a';
/*  302 */           output[(outputPos++)] = 'u';
/*  303 */           break;
/*      */         case 'ꜹ':
/*      */         case 'ꜻ':
/*  306 */           output[(outputPos++)] = 'a';
/*  307 */           output[(outputPos++)] = 'v';
/*  308 */           break;
/*      */         case 'ꜽ':
/*  310 */           output[(outputPos++)] = 'a';
/*  311 */           output[(outputPos++)] = 'y';
/*  312 */           break;
/*      */         case 'Ɓ':
/*      */         case 'Ƃ':
/*      */         case 'Ƀ':
/*      */         case 'ʙ':
/*      */         case 'ᴃ':
/*      */         case 'Ḃ':
/*      */         case 'Ḅ':
/*      */         case 'Ḇ':
/*      */         case 'Ⓑ':
/*      */         case 'Ｂ':
/*  323 */           output[(outputPos++)] = 'B';
/*  324 */           break;
/*      */         case 'ƀ':
/*      */         case 'ƃ':
/*      */         case 'ɓ':
/*      */         case 'ᵬ':
/*      */         case 'ᶀ':
/*      */         case 'ḃ':
/*      */         case 'ḅ':
/*      */         case 'ḇ':
/*      */         case 'ⓑ':
/*      */         case 'ｂ':
/*  335 */           output[(outputPos++)] = 'b';
/*  336 */           break;
/*      */         case '⒝':
/*  338 */           output[(outputPos++)] = '(';
/*  339 */           output[(outputPos++)] = 'b';
/*  340 */           output[(outputPos++)] = ')';
/*  341 */           break;
/*      */         case 'Ç':
/*      */         case 'Ć':
/*      */         case 'Ĉ':
/*      */         case 'Ċ':
/*      */         case 'Č':
/*      */         case 'Ƈ':
/*      */         case 'Ȼ':
/*      */         case 'ʗ':
/*      */         case 'ᴄ':
/*      */         case 'Ḉ':
/*      */         case 'Ⓒ':
/*      */         case 'Ｃ':
/*  354 */           output[(outputPos++)] = 'C';
/*  355 */           break;
/*      */         case 'ç':
/*      */         case 'ć':
/*      */         case 'ĉ':
/*      */         case 'ċ':
/*      */         case 'č':
/*      */         case 'ƈ':
/*      */         case 'ȼ':
/*      */         case 'ɕ':
/*      */         case 'ḉ':
/*      */         case 'ↄ':
/*      */         case 'ⓒ':
/*      */         case 'Ꜿ':
/*      */         case 'ꜿ':
/*      */         case 'ｃ':
/*  370 */           output[(outputPos++)] = 'c';
/*  371 */           break;
/*      */         case '⒞':
/*  373 */           output[(outputPos++)] = '(';
/*  374 */           output[(outputPos++)] = 'c';
/*  375 */           output[(outputPos++)] = ')';
/*  376 */           break;
/*      */         case 'Ð':
/*      */         case 'Ď':
/*      */         case 'Đ':
/*      */         case 'Ɖ':
/*      */         case 'Ɗ':
/*      */         case 'Ƌ':
/*      */         case 'ᴅ':
/*      */         case 'ᴆ':
/*      */         case 'Ḋ':
/*      */         case 'Ḍ':
/*      */         case 'Ḏ':
/*      */         case 'Ḑ':
/*      */         case 'Ḓ':
/*      */         case 'Ⓓ':
/*      */         case 'Ꝺ':
/*      */         case 'Ｄ':
/*  393 */           output[(outputPos++)] = 'D';
/*  394 */           break;
/*      */         case 'ð':
/*      */         case 'ď':
/*      */         case 'đ':
/*      */         case 'ƌ':
/*      */         case 'ȡ':
/*      */         case 'ɖ':
/*      */         case 'ɗ':
/*      */         case 'ᵭ':
/*      */         case 'ᶁ':
/*      */         case 'ᶑ':
/*      */         case 'ḋ':
/*      */         case 'ḍ':
/*      */         case 'ḏ':
/*      */         case 'ḑ':
/*      */         case 'ḓ':
/*      */         case 'ⓓ':
/*      */         case 'ꝺ':
/*      */         case 'ｄ':
/*  413 */           output[(outputPos++)] = 'd';
/*  414 */           break;
/*      */         case 'Ǆ':
/*      */         case 'Ǳ':
/*  417 */           output[(outputPos++)] = 'D';
/*  418 */           output[(outputPos++)] = 'Z';
/*  419 */           break;
/*      */         case 'ǅ':
/*      */         case 'ǲ':
/*  422 */           output[(outputPos++)] = 'D';
/*  423 */           output[(outputPos++)] = 'z';
/*  424 */           break;
/*      */         case '⒟':
/*  426 */           output[(outputPos++)] = '(';
/*  427 */           output[(outputPos++)] = 'd';
/*  428 */           output[(outputPos++)] = ')';
/*  429 */           break;
/*      */         case 'ȸ':
/*  431 */           output[(outputPos++)] = 'd';
/*  432 */           output[(outputPos++)] = 'b';
/*  433 */           break;
/*      */         case 'ǆ':
/*      */         case 'ǳ':
/*      */         case 'ʣ':
/*      */         case 'ʥ':
/*  438 */           output[(outputPos++)] = 'd';
/*  439 */           output[(outputPos++)] = 'z';
/*  440 */           break;
/*      */         case 'È':
/*      */         case 'É':
/*      */         case 'Ê':
/*      */         case 'Ë':
/*      */         case 'Ē':
/*      */         case 'Ĕ':
/*      */         case 'Ė':
/*      */         case 'Ę':
/*      */         case 'Ě':
/*      */         case 'Ǝ':
/*      */         case 'Ɛ':
/*      */         case 'Ȅ':
/*      */         case 'Ȇ':
/*      */         case 'Ȩ':
/*      */         case 'Ɇ':
/*      */         case 'ᴇ':
/*      */         case 'Ḕ':
/*      */         case 'Ḗ':
/*      */         case 'Ḙ':
/*      */         case 'Ḛ':
/*      */         case 'Ḝ':
/*      */         case 'Ẹ':
/*      */         case 'Ẻ':
/*      */         case 'Ẽ':
/*      */         case 'Ế':
/*      */         case 'Ề':
/*      */         case 'Ể':
/*      */         case 'Ễ':
/*      */         case 'Ệ':
/*      */         case 'Ⓔ':
/*      */         case 'ⱻ':
/*      */         case 'Ｅ':
/*  473 */           output[(outputPos++)] = 'E';
/*  474 */           break;
/*      */         case 'è':
/*      */         case 'é':
/*      */         case 'ê':
/*      */         case 'ë':
/*      */         case 'ē':
/*      */         case 'ĕ':
/*      */         case 'ė':
/*      */         case 'ę':
/*      */         case 'ě':
/*      */         case 'ǝ':
/*      */         case 'ȅ':
/*      */         case 'ȇ':
/*      */         case 'ȩ':
/*      */         case 'ɇ':
/*      */         case 'ɘ':
/*      */         case 'ɛ':
/*      */         case 'ɜ':
/*      */         case 'ɝ':
/*      */         case 'ɞ':
/*      */         case 'ʚ':
/*      */         case 'ᴈ':
/*      */         case 'ᶒ':
/*      */         case 'ᶓ':
/*      */         case 'ᶔ':
/*      */         case 'ḕ':
/*      */         case 'ḗ':
/*      */         case 'ḙ':
/*      */         case 'ḛ':
/*      */         case 'ḝ':
/*      */         case 'ẹ':
/*      */         case 'ẻ':
/*      */         case 'ẽ':
/*      */         case 'ế':
/*      */         case 'ề':
/*      */         case 'ể':
/*      */         case 'ễ':
/*      */         case 'ệ':
/*      */         case 'ₑ':
/*      */         case 'ⓔ':
/*      */         case 'ⱸ':
/*      */         case 'ｅ':
/*  516 */           output[(outputPos++)] = 'e';
/*  517 */           break;
/*      */         case '⒠':
/*  519 */           output[(outputPos++)] = '(';
/*  520 */           output[(outputPos++)] = 'e';
/*  521 */           output[(outputPos++)] = ')';
/*  522 */           break;
/*      */         case 'Ƒ':
/*      */         case 'Ḟ':
/*      */         case 'Ⓕ':
/*      */         case 'ꜰ':
/*      */         case 'Ꝼ':
/*      */         case 'ꟻ':
/*      */         case 'Ｆ':
/*  530 */           output[(outputPos++)] = 'F';
/*  531 */           break;
/*      */         case 'ƒ':
/*      */         case 'ᵮ':
/*      */         case 'ᶂ':
/*      */         case 'ḟ':
/*      */         case 'ẛ':
/*      */         case 'ⓕ':
/*      */         case 'ꝼ':
/*      */         case 'ｆ':
/*  540 */           output[(outputPos++)] = 'f';
/*  541 */           break;
/*      */         case '⒡':
/*  543 */           output[(outputPos++)] = '(';
/*  544 */           output[(outputPos++)] = 'f';
/*  545 */           output[(outputPos++)] = ')';
/*  546 */           break;
/*      */         case 'ﬀ':
/*  548 */           output[(outputPos++)] = 'f';
/*  549 */           output[(outputPos++)] = 'f';
/*  550 */           break;
/*      */         case 'ﬃ':
/*  552 */           output[(outputPos++)] = 'f';
/*  553 */           output[(outputPos++)] = 'f';
/*  554 */           output[(outputPos++)] = 'i';
/*  555 */           break;
/*      */         case 'ﬄ':
/*  557 */           output[(outputPos++)] = 'f';
/*  558 */           output[(outputPos++)] = 'f';
/*  559 */           output[(outputPos++)] = 'l';
/*  560 */           break;
/*      */         case 'ﬁ':
/*  562 */           output[(outputPos++)] = 'f';
/*  563 */           output[(outputPos++)] = 'i';
/*  564 */           break;
/*      */         case 'ﬂ':
/*  566 */           output[(outputPos++)] = 'f';
/*  567 */           output[(outputPos++)] = 'l';
/*  568 */           break;
/*      */         case 'Ĝ':
/*      */         case 'Ğ':
/*      */         case 'Ġ':
/*      */         case 'Ģ':
/*      */         case 'Ɠ':
/*      */         case 'Ǥ':
/*      */         case 'ǥ':
/*      */         case 'Ǧ':
/*      */         case 'ǧ':
/*      */         case 'Ǵ':
/*      */         case 'ɢ':
/*      */         case 'ʛ':
/*      */         case 'Ḡ':
/*      */         case 'Ⓖ':
/*      */         case 'Ᵹ':
/*      */         case 'Ꝿ':
/*      */         case 'Ｇ':
/*  586 */           output[(outputPos++)] = 'G';
/*  587 */           break;
/*      */         case 'ĝ':
/*      */         case 'ğ':
/*      */         case 'ġ':
/*      */         case 'ģ':
/*      */         case 'ǵ':
/*      */         case 'ɠ':
/*      */         case 'ɡ':
/*      */         case 'ᵷ':
/*      */         case 'ᵹ':
/*      */         case 'ᶃ':
/*      */         case 'ḡ':
/*      */         case 'ⓖ':
/*      */         case 'ꝿ':
/*      */         case 'ｇ':
/*  602 */           output[(outputPos++)] = 'g';
/*  603 */           break;
/*      */         case '⒢':
/*  605 */           output[(outputPos++)] = '(';
/*  606 */           output[(outputPos++)] = 'g';
/*  607 */           output[(outputPos++)] = ')';
/*  608 */           break;
/*      */         case 'Ĥ':
/*      */         case 'Ħ':
/*      */         case 'Ȟ':
/*      */         case 'ʜ':
/*      */         case 'Ḣ':
/*      */         case 'Ḥ':
/*      */         case 'Ḧ':
/*      */         case 'Ḩ':
/*      */         case 'Ḫ':
/*      */         case 'Ⓗ':
/*      */         case 'Ⱨ':
/*      */         case 'Ⱶ':
/*      */         case 'Ｈ':
/*  622 */           output[(outputPos++)] = 'H';
/*  623 */           break;
/*      */         case 'ĥ':
/*      */         case 'ħ':
/*      */         case 'ȟ':
/*      */         case 'ɥ':
/*      */         case 'ɦ':
/*      */         case 'ʮ':
/*      */         case 'ʯ':
/*      */         case 'ḣ':
/*      */         case 'ḥ':
/*      */         case 'ḧ':
/*      */         case 'ḩ':
/*      */         case 'ḫ':
/*      */         case 'ẖ':
/*      */         case 'ⓗ':
/*      */         case 'ⱨ':
/*      */         case 'ⱶ':
/*      */         case 'ｈ':
/*  641 */           output[(outputPos++)] = 'h';
/*  642 */           break;
/*      */         case 'Ƕ':
/*  644 */           output[(outputPos++)] = 'H';
/*  645 */           output[(outputPos++)] = 'V';
/*  646 */           break;
/*      */         case '⒣':
/*  648 */           output[(outputPos++)] = '(';
/*  649 */           output[(outputPos++)] = 'h';
/*  650 */           output[(outputPos++)] = ')';
/*  651 */           break;
/*      */         case 'ƕ':
/*  653 */           output[(outputPos++)] = 'h';
/*  654 */           output[(outputPos++)] = 'v';
/*  655 */           break;
/*      */         case 'Ì':
/*      */         case 'Í':
/*      */         case 'Î':
/*      */         case 'Ï':
/*      */         case 'Ĩ':
/*      */         case 'Ī':
/*      */         case 'Ĭ':
/*      */         case 'Į':
/*      */         case 'İ':
/*      */         case 'Ɩ':
/*      */         case 'Ɨ':
/*      */         case 'Ǐ':
/*      */         case 'Ȉ':
/*      */         case 'Ȋ':
/*      */         case 'ɪ':
/*      */         case 'ᵻ':
/*      */         case 'Ḭ':
/*      */         case 'Ḯ':
/*      */         case 'Ỉ':
/*      */         case 'Ị':
/*      */         case 'Ⓘ':
/*      */         case 'ꟾ':
/*      */         case 'Ｉ':
/*  679 */           output[(outputPos++)] = 'I';
/*  680 */           break;
/*      */         case 'ì':
/*      */         case 'í':
/*      */         case 'î':
/*      */         case 'ï':
/*      */         case 'ĩ':
/*      */         case 'ī':
/*      */         case 'ĭ':
/*      */         case 'į':
/*      */         case 'ı':
/*      */         case 'ǐ':
/*      */         case 'ȉ':
/*      */         case 'ȋ':
/*      */         case 'ɨ':
/*      */         case 'ᴉ':
/*      */         case 'ᵢ':
/*      */         case 'ᵼ':
/*      */         case 'ᶖ':
/*      */         case 'ḭ':
/*      */         case 'ḯ':
/*      */         case 'ỉ':
/*      */         case 'ị':
/*      */         case 'ⁱ':
/*      */         case 'ⓘ':
/*      */         case 'ｉ':
/*  705 */           output[(outputPos++)] = 'i';
/*  706 */           break;
/*      */         case 'Ĳ':
/*  708 */           output[(outputPos++)] = 'I';
/*  709 */           output[(outputPos++)] = 'J';
/*  710 */           break;
/*      */         case '⒤':
/*  712 */           output[(outputPos++)] = '(';
/*  713 */           output[(outputPos++)] = 'i';
/*  714 */           output[(outputPos++)] = ')';
/*  715 */           break;
/*      */         case 'ĳ':
/*  717 */           output[(outputPos++)] = 'i';
/*  718 */           output[(outputPos++)] = 'j';
/*  719 */           break;
/*      */         case 'Ĵ':
/*      */         case 'Ɉ':
/*      */         case 'ᴊ':
/*      */         case 'Ⓙ':
/*      */         case 'Ｊ':
/*  725 */           output[(outputPos++)] = 'J';
/*  726 */           break;
/*      */         case 'ĵ':
/*      */         case 'ǰ':
/*      */         case 'ȷ':
/*      */         case 'ɉ':
/*      */         case 'ɟ':
/*      */         case 'ʄ':
/*      */         case 'ʝ':
/*      */         case 'ⓙ':
/*      */         case 'ⱼ':
/*      */         case 'ｊ':
/*  737 */           output[(outputPos++)] = 'j';
/*  738 */           break;
/*      */         case '⒥':
/*  740 */           output[(outputPos++)] = '(';
/*  741 */           output[(outputPos++)] = 'j';
/*  742 */           output[(outputPos++)] = ')';
/*  743 */           break;
/*      */         case 'Ķ':
/*      */         case 'Ƙ':
/*      */         case 'Ǩ':
/*      */         case 'ᴋ':
/*      */         case 'Ḱ':
/*      */         case 'Ḳ':
/*      */         case 'Ḵ':
/*      */         case 'Ⓚ':
/*      */         case 'Ⱪ':
/*      */         case 'Ꝁ':
/*      */         case 'Ꝃ':
/*      */         case 'Ꝅ':
/*      */         case 'Ｋ':
/*  757 */           output[(outputPos++)] = 'K';
/*  758 */           break;
/*      */         case 'ķ':
/*      */         case 'ƙ':
/*      */         case 'ǩ':
/*      */         case 'ʞ':
/*      */         case 'ᶄ':
/*      */         case 'ḱ':
/*      */         case 'ḳ':
/*      */         case 'ḵ':
/*      */         case 'ⓚ':
/*      */         case 'ⱪ':
/*      */         case 'ꝁ':
/*      */         case 'ꝃ':
/*      */         case 'ꝅ':
/*      */         case 'ｋ':
/*  773 */           output[(outputPos++)] = 'k';
/*  774 */           break;
/*      */         case '⒦':
/*  776 */           output[(outputPos++)] = '(';
/*  777 */           output[(outputPos++)] = 'k';
/*  778 */           output[(outputPos++)] = ')';
/*  779 */           break;
/*      */         case 'Ĺ':
/*      */         case 'Ļ':
/*      */         case 'Ľ':
/*      */         case 'Ŀ':
/*      */         case 'Ł':
/*      */         case 'Ƚ':
/*      */         case 'ʟ':
/*      */         case 'ᴌ':
/*      */         case 'Ḷ':
/*      */         case 'Ḹ':
/*      */         case 'Ḻ':
/*      */         case 'Ḽ':
/*      */         case 'Ⓛ':
/*      */         case 'Ⱡ':
/*      */         case 'Ɫ':
/*      */         case 'Ꝇ':
/*      */         case 'Ꝉ':
/*      */         case 'Ꞁ':
/*      */         case 'Ｌ':
/*  799 */           output[(outputPos++)] = 'L';
/*  800 */           break;
/*      */         case 'ĺ':
/*      */         case 'ļ':
/*      */         case 'ľ':
/*      */         case 'ŀ':
/*      */         case 'ł':
/*      */         case 'ƚ':
/*      */         case 'ȴ':
/*      */         case 'ɫ':
/*      */         case 'ɬ':
/*      */         case 'ɭ':
/*      */         case 'ᶅ':
/*      */         case 'ḷ':
/*      */         case 'ḹ':
/*      */         case 'ḻ':
/*      */         case 'ḽ':
/*      */         case 'ⓛ':
/*      */         case 'ⱡ':
/*      */         case 'ꝇ':
/*      */         case 'ꝉ':
/*      */         case 'ꞁ':
/*      */         case 'ｌ':
/*  822 */           output[(outputPos++)] = 'l';
/*  823 */           break;
/*      */         case 'Ǉ':
/*  825 */           output[(outputPos++)] = 'L';
/*  826 */           output[(outputPos++)] = 'J';
/*  827 */           break;
/*      */         case 'Ỻ':
/*  829 */           output[(outputPos++)] = 'L';
/*  830 */           output[(outputPos++)] = 'L';
/*  831 */           break;
/*      */         case 'ǈ':
/*  833 */           output[(outputPos++)] = 'L';
/*  834 */           output[(outputPos++)] = 'j';
/*  835 */           break;
/*      */         case '⒧':
/*  837 */           output[(outputPos++)] = '(';
/*  838 */           output[(outputPos++)] = 'l';
/*  839 */           output[(outputPos++)] = ')';
/*  840 */           break;
/*      */         case 'ǉ':
/*  842 */           output[(outputPos++)] = 'l';
/*  843 */           output[(outputPos++)] = 'j';
/*  844 */           break;
/*      */         case 'ỻ':
/*  846 */           output[(outputPos++)] = 'l';
/*  847 */           output[(outputPos++)] = 'l';
/*  848 */           break;
/*      */         case 'ʪ':
/*  850 */           output[(outputPos++)] = 'l';
/*  851 */           output[(outputPos++)] = 's';
/*  852 */           break;
/*      */         case 'ʫ':
/*  854 */           output[(outputPos++)] = 'l';
/*  855 */           output[(outputPos++)] = 'z';
/*  856 */           break;
/*      */         case 'Ɯ':
/*      */         case 'ᴍ':
/*      */         case 'Ḿ':
/*      */         case 'Ṁ':
/*      */         case 'Ṃ':
/*      */         case 'Ⓜ':
/*      */         case 'Ɱ':
/*      */         case 'ꟽ':
/*      */         case 'ꟿ':
/*      */         case 'Ｍ':
/*  867 */           output[(outputPos++)] = 'M';
/*  868 */           break;
/*      */         case 'ɯ':
/*      */         case 'ɰ':
/*      */         case 'ɱ':
/*      */         case 'ᵯ':
/*      */         case 'ᶆ':
/*      */         case 'ḿ':
/*      */         case 'ṁ':
/*      */         case 'ṃ':
/*      */         case 'ⓜ':
/*      */         case 'ｍ':
/*  879 */           output[(outputPos++)] = 'm';
/*  880 */           break;
/*      */         case '⒨':
/*  882 */           output[(outputPos++)] = '(';
/*  883 */           output[(outputPos++)] = 'm';
/*  884 */           output[(outputPos++)] = ')';
/*  885 */           break;
/*      */         case 'Ñ':
/*      */         case 'Ń':
/*      */         case 'Ņ':
/*      */         case 'Ň':
/*      */         case 'Ŋ':
/*      */         case 'Ɲ':
/*      */         case 'Ǹ':
/*      */         case 'Ƞ':
/*      */         case 'ɴ':
/*      */         case 'ᴎ':
/*      */         case 'Ṅ':
/*      */         case 'Ṇ':
/*      */         case 'Ṉ':
/*      */         case 'Ṋ':
/*      */         case 'Ⓝ':
/*      */         case 'Ｎ':
/*  902 */           output[(outputPos++)] = 'N';
/*  903 */           break;
/*      */         case 'ñ':
/*      */         case 'ń':
/*      */         case 'ņ':
/*      */         case 'ň':
/*      */         case 'ŉ':
/*      */         case 'ŋ':
/*      */         case 'ƞ':
/*      */         case 'ǹ':
/*      */         case 'ȵ':
/*      */         case 'ɲ':
/*      */         case 'ɳ':
/*      */         case 'ᵰ':
/*      */         case 'ᶇ':
/*      */         case 'ṅ':
/*      */         case 'ṇ':
/*      */         case 'ṉ':
/*      */         case 'ṋ':
/*      */         case 'ⁿ':
/*      */         case 'ⓝ':
/*      */         case 'ｎ':
/*  924 */           output[(outputPos++)] = 'n';
/*  925 */           break;
/*      */         case 'Ǌ':
/*  927 */           output[(outputPos++)] = 'N';
/*  928 */           output[(outputPos++)] = 'J';
/*  929 */           break;
/*      */         case 'ǋ':
/*  931 */           output[(outputPos++)] = 'N';
/*  932 */           output[(outputPos++)] = 'j';
/*  933 */           break;
/*      */         case '⒩':
/*  935 */           output[(outputPos++)] = '(';
/*  936 */           output[(outputPos++)] = 'n';
/*  937 */           output[(outputPos++)] = ')';
/*  938 */           break;
/*      */         case 'ǌ':
/*  940 */           output[(outputPos++)] = 'n';
/*  941 */           output[(outputPos++)] = 'j';
/*  942 */           break;
/*      */         case 'Ò':
/*      */         case 'Ó':
/*      */         case 'Ô':
/*      */         case 'Õ':
/*      */         case 'Ö':
/*      */         case 'Ø':
/*      */         case 'Ō':
/*      */         case 'Ŏ':
/*      */         case 'Ő':
/*      */         case 'Ɔ':
/*      */         case 'Ɵ':
/*      */         case 'Ơ':
/*      */         case 'Ǒ':
/*      */         case 'Ǫ':
/*      */         case 'Ǭ':
/*      */         case 'Ǿ':
/*      */         case 'Ȍ':
/*      */         case 'Ȏ':
/*      */         case 'Ȫ':
/*      */         case 'Ȭ':
/*      */         case 'Ȯ':
/*      */         case 'Ȱ':
/*      */         case 'ᴏ':
/*      */         case 'ᴐ':
/*      */         case 'Ṍ':
/*      */         case 'Ṏ':
/*      */         case 'Ṑ':
/*      */         case 'Ṓ':
/*      */         case 'Ọ':
/*      */         case 'Ỏ':
/*      */         case 'Ố':
/*      */         case 'Ồ':
/*      */         case 'Ổ':
/*      */         case 'Ỗ':
/*      */         case 'Ộ':
/*      */         case 'Ớ':
/*      */         case 'Ờ':
/*      */         case 'Ở':
/*      */         case 'Ỡ':
/*      */         case 'Ợ':
/*      */         case 'Ⓞ':
/*      */         case 'Ꝋ':
/*      */         case 'Ꝍ':
/*      */         case 'Ｏ':
/*  987 */           output[(outputPos++)] = 'O';
/*  988 */           break;
/*      */         case 'ò':
/*      */         case 'ó':
/*      */         case 'ô':
/*      */         case 'õ':
/*      */         case 'ö':
/*      */         case 'ø':
/*      */         case 'ō':
/*      */         case 'ŏ':
/*      */         case 'ő':
/*      */         case 'ơ':
/*      */         case 'ǒ':
/*      */         case 'ǫ':
/*      */         case 'ǭ':
/*      */         case 'ǿ':
/*      */         case 'ȍ':
/*      */         case 'ȏ':
/*      */         case 'ȫ':
/*      */         case 'ȭ':
/*      */         case 'ȯ':
/*      */         case 'ȱ':
/*      */         case 'ɔ':
/*      */         case 'ɵ':
/*      */         case 'ᴖ':
/*      */         case 'ᴗ':
/*      */         case 'ᶗ':
/*      */         case 'ṍ':
/*      */         case 'ṏ':
/*      */         case 'ṑ':
/*      */         case 'ṓ':
/*      */         case 'ọ':
/*      */         case 'ỏ':
/*      */         case 'ố':
/*      */         case 'ồ':
/*      */         case 'ổ':
/*      */         case 'ỗ':
/*      */         case 'ộ':
/*      */         case 'ớ':
/*      */         case 'ờ':
/*      */         case 'ở':
/*      */         case 'ỡ':
/*      */         case 'ợ':
/*      */         case 'ₒ':
/*      */         case 'ⓞ':
/*      */         case 'ⱺ':
/*      */         case 'ꝋ':
/*      */         case 'ꝍ':
/*      */         case 'ｏ':
/* 1036 */           output[(outputPos++)] = 'o';
/* 1037 */           break;
/*      */         case 'Œ':
/*      */         case 'ɶ':
/* 1040 */           output[(outputPos++)] = 'O';
/* 1041 */           output[(outputPos++)] = 'E';
/* 1042 */           break;
/*      */         case 'Ꝏ':
/* 1044 */           output[(outputPos++)] = 'O';
/* 1045 */           output[(outputPos++)] = 'O';
/* 1046 */           break;
/*      */         case 'Ȣ':
/*      */         case 'ᴕ':
/* 1049 */           output[(outputPos++)] = 'O';
/* 1050 */           output[(outputPos++)] = 'U';
/* 1051 */           break;
/*      */         case '⒪':
/* 1053 */           output[(outputPos++)] = '(';
/* 1054 */           output[(outputPos++)] = 'o';
/* 1055 */           output[(outputPos++)] = ')';
/* 1056 */           break;
/*      */         case 'œ':
/*      */         case 'ᴔ':
/* 1059 */           output[(outputPos++)] = 'o';
/* 1060 */           output[(outputPos++)] = 'e';
/* 1061 */           break;
/*      */         case 'ꝏ':
/* 1063 */           output[(outputPos++)] = 'o';
/* 1064 */           output[(outputPos++)] = 'o';
/* 1065 */           break;
/*      */         case 'ȣ':
/* 1067 */           output[(outputPos++)] = 'o';
/* 1068 */           output[(outputPos++)] = 'u';
/* 1069 */           break;
/*      */         case 'Ƥ':
/*      */         case 'ᴘ':
/*      */         case 'Ṕ':
/*      */         case 'Ṗ':
/*      */         case 'Ⓟ':
/*      */         case 'Ᵽ':
/*      */         case 'Ꝑ':
/*      */         case 'Ꝓ':
/*      */         case 'Ꝕ':
/*      */         case 'Ｐ':
/* 1080 */           output[(outputPos++)] = 'P';
/* 1081 */           break;
/*      */         case 'ƥ':
/*      */         case 'ᵱ':
/*      */         case 'ᵽ':
/*      */         case 'ᶈ':
/*      */         case 'ṕ':
/*      */         case 'ṗ':
/*      */         case 'ⓟ':
/*      */         case 'ꝑ':
/*      */         case 'ꝓ':
/*      */         case 'ꝕ':
/*      */         case 'ꟼ':
/*      */         case 'ｐ':
/* 1094 */           output[(outputPos++)] = 'p';
/* 1095 */           break;
/*      */         case '⒫':
/* 1097 */           output[(outputPos++)] = '(';
/* 1098 */           output[(outputPos++)] = 'p';
/* 1099 */           output[(outputPos++)] = ')';
/* 1100 */           break;
/*      */         case 'Ɋ':
/*      */         case 'Ⓠ':
/*      */         case 'Ꝗ':
/*      */         case 'Ꝙ':
/*      */         case 'Ｑ':
/* 1106 */           output[(outputPos++)] = 'Q';
/* 1107 */           break;
/*      */         case 'ĸ':
/*      */         case 'ɋ':
/*      */         case 'ʠ':
/*      */         case 'ⓠ':
/*      */         case 'ꝗ':
/*      */         case 'ꝙ':
/*      */         case 'ｑ':
/* 1115 */           output[(outputPos++)] = 'q';
/* 1116 */           break;
/*      */         case '⒬':
/* 1118 */           output[(outputPos++)] = '(';
/* 1119 */           output[(outputPos++)] = 'q';
/* 1120 */           output[(outputPos++)] = ')';
/* 1121 */           break;
/*      */         case 'ȹ':
/* 1123 */           output[(outputPos++)] = 'q';
/* 1124 */           output[(outputPos++)] = 'p';
/* 1125 */           break;
/*      */         case 'Ŕ':
/*      */         case 'Ŗ':
/*      */         case 'Ř':
/*      */         case 'Ȑ':
/*      */         case 'Ȓ':
/*      */         case 'Ɍ':
/*      */         case 'ʀ':
/*      */         case 'ʁ':
/*      */         case 'ᴙ':
/*      */         case 'ᴚ':
/*      */         case 'Ṙ':
/*      */         case 'Ṛ':
/*      */         case 'Ṝ':
/*      */         case 'Ṟ':
/*      */         case 'Ⓡ':
/*      */         case 'Ɽ':
/*      */         case 'Ꝛ':
/*      */         case 'Ꞃ':
/*      */         case 'Ｒ':
/* 1145 */           output[(outputPos++)] = 'R';
/* 1146 */           break;
/*      */         case 'ŕ':
/*      */         case 'ŗ':
/*      */         case 'ř':
/*      */         case 'ȑ':
/*      */         case 'ȓ':
/*      */         case 'ɍ':
/*      */         case 'ɼ':
/*      */         case 'ɽ':
/*      */         case 'ɾ':
/*      */         case 'ɿ':
/*      */         case 'ᵣ':
/*      */         case 'ᵲ':
/*      */         case 'ᵳ':
/*      */         case 'ᶉ':
/*      */         case 'ṙ':
/*      */         case 'ṛ':
/*      */         case 'ṝ':
/*      */         case 'ṟ':
/*      */         case 'ⓡ':
/*      */         case 'ꝛ':
/*      */         case 'ꞃ':
/*      */         case 'ｒ':
/* 1169 */           output[(outputPos++)] = 'r';
/* 1170 */           break;
/*      */         case '⒭':
/* 1172 */           output[(outputPos++)] = '(';
/* 1173 */           output[(outputPos++)] = 'r';
/* 1174 */           output[(outputPos++)] = ')';
/* 1175 */           break;
/*      */         case 'Ś':
/*      */         case 'Ŝ':
/*      */         case 'Ş':
/*      */         case 'Š':
/*      */         case 'Ș':
/*      */         case 'Ṡ':
/*      */         case 'Ṣ':
/*      */         case 'Ṥ':
/*      */         case 'Ṧ':
/*      */         case 'Ṩ':
/*      */         case 'Ⓢ':
/*      */         case 'ꜱ':
/*      */         case 'ꞅ':
/*      */         case 'Ｓ':
/* 1190 */           output[(outputPos++)] = 'S';
/* 1191 */           break;
/*      */         case 'ś':
/*      */         case 'ŝ':
/*      */         case 'ş':
/*      */         case 'š':
/*      */         case 'ſ':
/*      */         case 'ș':
/*      */         case 'ȿ':
/*      */         case 'ʂ':
/*      */         case 'ᵴ':
/*      */         case 'ᶊ':
/*      */         case 'ṡ':
/*      */         case 'ṣ':
/*      */         case 'ṥ':
/*      */         case 'ṧ':
/*      */         case 'ṩ':
/*      */         case 'ẜ':
/*      */         case 'ẝ':
/*      */         case 'ⓢ':
/*      */         case 'Ꞅ':
/*      */         case 'ｓ':
/* 1212 */           output[(outputPos++)] = 's';
/* 1213 */           break;
/*      */         case 'ẞ':
/* 1215 */           output[(outputPos++)] = 'S';
/* 1216 */           output[(outputPos++)] = 'S';
/* 1217 */           break;
/*      */         case '⒮':
/* 1219 */           output[(outputPos++)] = '(';
/* 1220 */           output[(outputPos++)] = 's';
/* 1221 */           output[(outputPos++)] = ')';
/* 1222 */           break;
/*      */         case 'ß':
/* 1224 */           output[(outputPos++)] = 's';
/* 1225 */           output[(outputPos++)] = 's';
/* 1226 */           break;
/*      */         case 'ﬆ':
/* 1228 */           output[(outputPos++)] = 's';
/* 1229 */           output[(outputPos++)] = 't';
/* 1230 */           break;
/*      */         case 'Ţ':
/*      */         case 'Ť':
/*      */         case 'Ŧ':
/*      */         case 'Ƭ':
/*      */         case 'Ʈ':
/*      */         case 'Ț':
/*      */         case 'Ⱦ':
/*      */         case 'ᴛ':
/*      */         case 'Ṫ':
/*      */         case 'Ṭ':
/*      */         case 'Ṯ':
/*      */         case 'Ṱ':
/*      */         case 'Ⓣ':
/*      */         case 'Ꞇ':
/*      */         case 'Ｔ':
/* 1246 */           output[(outputPos++)] = 'T';
/* 1247 */           break;
/*      */         case 'ţ':
/*      */         case 'ť':
/*      */         case 'ŧ':
/*      */         case 'ƫ':
/*      */         case 'ƭ':
/*      */         case 'ț':
/*      */         case 'ȶ':
/*      */         case 'ʇ':
/*      */         case 'ʈ':
/*      */         case 'ᵵ':
/*      */         case 'ṫ':
/*      */         case 'ṭ':
/*      */         case 'ṯ':
/*      */         case 'ṱ':
/*      */         case 'ẗ':
/*      */         case 'ⓣ':
/*      */         case 'ⱦ':
/*      */         case 'ｔ':
/* 1266 */           output[(outputPos++)] = 't';
/* 1267 */           break;
/*      */         case 'Þ':
/*      */         case 'Ꝧ':
/* 1270 */           output[(outputPos++)] = 'T';
/* 1271 */           output[(outputPos++)] = 'H';
/* 1272 */           break;
/*      */         case 'Ꜩ':
/* 1274 */           output[(outputPos++)] = 'T';
/* 1275 */           output[(outputPos++)] = 'Z';
/* 1276 */           break;
/*      */         case '⒯':
/* 1278 */           output[(outputPos++)] = '(';
/* 1279 */           output[(outputPos++)] = 't';
/* 1280 */           output[(outputPos++)] = ')';
/* 1281 */           break;
/*      */         case 'ʨ':
/* 1283 */           output[(outputPos++)] = 't';
/* 1284 */           output[(outputPos++)] = 'c';
/* 1285 */           break;
/*      */         case 'þ':
/*      */         case 'ᵺ':
/*      */         case 'ꝧ':
/* 1289 */           output[(outputPos++)] = 't';
/* 1290 */           output[(outputPos++)] = 'h';
/* 1291 */           break;
/*      */         case 'ʦ':
/* 1293 */           output[(outputPos++)] = 't';
/* 1294 */           output[(outputPos++)] = 's';
/* 1295 */           break;
/*      */         case 'ꜩ':
/* 1297 */           output[(outputPos++)] = 't';
/* 1298 */           output[(outputPos++)] = 'z';
/* 1299 */           break;
/*      */         case 'Ù':
/*      */         case 'Ú':
/*      */         case 'Û':
/*      */         case 'Ü':
/*      */         case 'Ũ':
/*      */         case 'Ū':
/*      */         case 'Ŭ':
/*      */         case 'Ů':
/*      */         case 'Ű':
/*      */         case 'Ų':
/*      */         case 'Ư':
/*      */         case 'Ǔ':
/*      */         case 'Ǖ':
/*      */         case 'Ǘ':
/*      */         case 'Ǚ':
/*      */         case 'Ǜ':
/*      */         case 'Ȕ':
/*      */         case 'Ȗ':
/*      */         case 'Ʉ':
/*      */         case 'ᴜ':
/*      */         case 'ᵾ':
/*      */         case 'Ṳ':
/*      */         case 'Ṵ':
/*      */         case 'Ṷ':
/*      */         case 'Ṹ':
/*      */         case 'Ṻ':
/*      */         case 'Ụ':
/*      */         case 'Ủ':
/*      */         case 'Ứ':
/*      */         case 'Ừ':
/*      */         case 'Ử':
/*      */         case 'Ữ':
/*      */         case 'Ự':
/*      */         case 'Ⓤ':
/*      */         case 'Ｕ':
/* 1335 */           output[(outputPos++)] = 'U';
/* 1336 */           break;
/*      */         case 'ù':
/*      */         case 'ú':
/*      */         case 'û':
/*      */         case 'ü':
/*      */         case 'ũ':
/*      */         case 'ū':
/*      */         case 'ŭ':
/*      */         case 'ů':
/*      */         case 'ű':
/*      */         case 'ų':
/*      */         case 'ư':
/*      */         case 'ǔ':
/*      */         case 'ǖ':
/*      */         case 'ǘ':
/*      */         case 'ǚ':
/*      */         case 'ǜ':
/*      */         case 'ȕ':
/*      */         case 'ȗ':
/*      */         case 'ʉ':
/*      */         case 'ᵤ':
/*      */         case 'ᶙ':
/*      */         case 'ṳ':
/*      */         case 'ṵ':
/*      */         case 'ṷ':
/*      */         case 'ṹ':
/*      */         case 'ṻ':
/*      */         case 'ụ':
/*      */         case 'ủ':
/*      */         case 'ứ':
/*      */         case 'ừ':
/*      */         case 'ử':
/*      */         case 'ữ':
/*      */         case 'ự':
/*      */         case 'ⓤ':
/*      */         case 'ｕ':
/* 1372 */           output[(outputPos++)] = 'u';
/* 1373 */           break;
/*      */         case '⒰':
/* 1375 */           output[(outputPos++)] = '(';
/* 1376 */           output[(outputPos++)] = 'u';
/* 1377 */           output[(outputPos++)] = ')';
/* 1378 */           break;
/*      */         case 'ᵫ':
/* 1380 */           output[(outputPos++)] = 'u';
/* 1381 */           output[(outputPos++)] = 'e';
/* 1382 */           break;
/*      */         case 'Ʋ':
/*      */         case 'Ʌ':
/*      */         case 'ᴠ':
/*      */         case 'Ṽ':
/*      */         case 'Ṿ':
/*      */         case 'Ỽ':
/*      */         case 'Ⓥ':
/*      */         case 'Ꝟ':
/*      */         case 'Ꝩ':
/*      */         case 'Ｖ':
/* 1393 */           output[(outputPos++)] = 'V';
/* 1394 */           break;
/*      */         case 'ʋ':
/*      */         case 'ʌ':
/*      */         case 'ᵥ':
/*      */         case 'ᶌ':
/*      */         case 'ṽ':
/*      */         case 'ṿ':
/*      */         case 'ⓥ':
/*      */         case 'ⱱ':
/*      */         case 'ⱴ':
/*      */         case 'ꝟ':
/*      */         case 'ｖ':
/* 1406 */           output[(outputPos++)] = 'v';
/* 1407 */           break;
/*      */         case 'Ꝡ':
/* 1409 */           output[(outputPos++)] = 'V';
/* 1410 */           output[(outputPos++)] = 'Y';
/* 1411 */           break;
/*      */         case '⒱':
/* 1413 */           output[(outputPos++)] = '(';
/* 1414 */           output[(outputPos++)] = 'v';
/* 1415 */           output[(outputPos++)] = ')';
/* 1416 */           break;
/*      */         case 'ꝡ':
/* 1418 */           output[(outputPos++)] = 'v';
/* 1419 */           output[(outputPos++)] = 'y';
/* 1420 */           break;
/*      */         case 'Ŵ':
/*      */         case 'Ƿ':
/*      */         case 'ᴡ':
/*      */         case 'Ẁ':
/*      */         case 'Ẃ':
/*      */         case 'Ẅ':
/*      */         case 'Ẇ':
/*      */         case 'Ẉ':
/*      */         case 'Ⓦ':
/*      */         case 'Ⱳ':
/*      */         case 'Ｗ':
/* 1432 */           output[(outputPos++)] = 'W';
/* 1433 */           break;
/*      */         case 'ŵ':
/*      */         case 'ƿ':
/*      */         case 'ʍ':
/*      */         case 'ẁ':
/*      */         case 'ẃ':
/*      */         case 'ẅ':
/*      */         case 'ẇ':
/*      */         case 'ẉ':
/*      */         case 'ẘ':
/*      */         case 'ⓦ':
/*      */         case 'ⱳ':
/*      */         case 'ｗ':
/* 1446 */           output[(outputPos++)] = 'w';
/* 1447 */           break;
/*      */         case '⒲':
/* 1449 */           output[(outputPos++)] = '(';
/* 1450 */           output[(outputPos++)] = 'w';
/* 1451 */           output[(outputPos++)] = ')';
/* 1452 */           break;
/*      */         case 'Ẋ':
/*      */         case 'Ẍ':
/*      */         case 'Ⓧ':
/*      */         case 'Ｘ':
/* 1457 */           output[(outputPos++)] = 'X';
/* 1458 */           break;
/*      */         case 'ᶍ':
/*      */         case 'ẋ':
/*      */         case 'ẍ':
/*      */         case 'ₓ':
/*      */         case 'ⓧ':
/*      */         case 'ｘ':
/* 1465 */           output[(outputPos++)] = 'x';
/* 1466 */           break;
/*      */         case '⒳':
/* 1468 */           output[(outputPos++)] = '(';
/* 1469 */           output[(outputPos++)] = 'x';
/* 1470 */           output[(outputPos++)] = ')';
/* 1471 */           break;
/*      */         case 'Ý':
/*      */         case 'Ŷ':
/*      */         case 'Ÿ':
/*      */         case 'Ƴ':
/*      */         case 'Ȳ':
/*      */         case 'Ɏ':
/*      */         case 'ʏ':
/*      */         case 'Ẏ':
/*      */         case 'Ỳ':
/*      */         case 'Ỵ':
/*      */         case 'Ỷ':
/*      */         case 'Ỹ':
/*      */         case 'Ỿ':
/*      */         case 'Ⓨ':
/*      */         case 'Ｙ':
/* 1487 */           output[(outputPos++)] = 'Y';
/* 1488 */           break;
/*      */         case 'ý':
/*      */         case 'ÿ':
/*      */         case 'ŷ':
/*      */         case 'ƴ':
/*      */         case 'ȳ':
/*      */         case 'ɏ':
/*      */         case 'ʎ':
/*      */         case 'ẏ':
/*      */         case 'ẙ':
/*      */         case 'ỳ':
/*      */         case 'ỵ':
/*      */         case 'ỷ':
/*      */         case 'ỹ':
/*      */         case 'ỿ':
/*      */         case 'ⓨ':
/*      */         case 'ｙ':
/* 1505 */           output[(outputPos++)] = 'y';
/* 1506 */           break;
/*      */         case '⒴':
/* 1508 */           output[(outputPos++)] = '(';
/* 1509 */           output[(outputPos++)] = 'y';
/* 1510 */           output[(outputPos++)] = ')';
/* 1511 */           break;
/*      */         case 'Ź':
/*      */         case 'Ż':
/*      */         case 'Ž':
/*      */         case 'Ƶ':
/*      */         case 'Ȝ':
/*      */         case 'Ȥ':
/*      */         case 'ᴢ':
/*      */         case 'Ẑ':
/*      */         case 'Ẓ':
/*      */         case 'Ẕ':
/*      */         case 'Ⓩ':
/*      */         case 'Ⱬ':
/*      */         case 'Ꝣ':
/*      */         case 'Ｚ':
/* 1526 */           output[(outputPos++)] = 'Z';
/* 1527 */           break;
/*      */         case 'ź':
/*      */         case 'ż':
/*      */         case 'ž':
/*      */         case 'ƶ':
/*      */         case 'ȝ':
/*      */         case 'ȥ':
/*      */         case 'ɀ':
/*      */         case 'ʐ':
/*      */         case 'ʑ':
/*      */         case 'ᵶ':
/*      */         case 'ᶎ':
/*      */         case 'ẑ':
/*      */         case 'ẓ':
/*      */         case 'ẕ':
/*      */         case 'ⓩ':
/*      */         case 'ⱬ':
/*      */         case 'ꝣ':
/*      */         case 'ｚ':
/* 1546 */           output[(outputPos++)] = 'z';
/* 1547 */           break;
/*      */         case '⒵':
/* 1549 */           output[(outputPos++)] = '(';
/* 1550 */           output[(outputPos++)] = 'z';
/* 1551 */           output[(outputPos++)] = ')';
/* 1552 */           break;
/*      */         case '⁰':
/*      */         case '₀':
/*      */         case '⓪':
/*      */         case '⓿':
/*      */         case '０':
/* 1558 */           output[(outputPos++)] = '0';
/* 1559 */           break;
/*      */         case '¹':
/*      */         case '₁':
/*      */         case '①':
/*      */         case '⓵':
/*      */         case '❶':
/*      */         case '➀':
/*      */         case '➊':
/*      */         case '１':
/* 1568 */           output[(outputPos++)] = '1';
/* 1569 */           break;
/*      */         case '⒈':
/* 1571 */           output[(outputPos++)] = '1';
/* 1572 */           output[(outputPos++)] = '.';
/* 1573 */           break;
/*      */         case '⑴':
/* 1575 */           output[(outputPos++)] = '(';
/* 1576 */           output[(outputPos++)] = '1';
/* 1577 */           output[(outputPos++)] = ')';
/* 1578 */           break;
/*      */         case '²':
/*      */         case '₂':
/*      */         case '②':
/*      */         case '⓶':
/*      */         case '❷':
/*      */         case '➁':
/*      */         case '➋':
/*      */         case '２':
/* 1587 */           output[(outputPos++)] = '2';
/* 1588 */           break;
/*      */         case '⒉':
/* 1590 */           output[(outputPos++)] = '2';
/* 1591 */           output[(outputPos++)] = '.';
/* 1592 */           break;
/*      */         case '⑵':
/* 1594 */           output[(outputPos++)] = '(';
/* 1595 */           output[(outputPos++)] = '2';
/* 1596 */           output[(outputPos++)] = ')';
/* 1597 */           break;
/*      */         case '³':
/*      */         case '₃':
/*      */         case '③':
/*      */         case '⓷':
/*      */         case '❸':
/*      */         case '➂':
/*      */         case '➌':
/*      */         case '３':
/* 1606 */           output[(outputPos++)] = '3';
/* 1607 */           break;
/*      */         case '⒊':
/* 1609 */           output[(outputPos++)] = '3';
/* 1610 */           output[(outputPos++)] = '.';
/* 1611 */           break;
/*      */         case '⑶':
/* 1613 */           output[(outputPos++)] = '(';
/* 1614 */           output[(outputPos++)] = '3';
/* 1615 */           output[(outputPos++)] = ')';
/* 1616 */           break;
/*      */         case '⁴':
/*      */         case '₄':
/*      */         case '④':
/*      */         case '⓸':
/*      */         case '❹':
/*      */         case '➃':
/*      */         case '➍':
/*      */         case '４':
/* 1625 */           output[(outputPos++)] = '4';
/* 1626 */           break;
/*      */         case '⒋':
/* 1628 */           output[(outputPos++)] = '4';
/* 1629 */           output[(outputPos++)] = '.';
/* 1630 */           break;
/*      */         case '⑷':
/* 1632 */           output[(outputPos++)] = '(';
/* 1633 */           output[(outputPos++)] = '4';
/* 1634 */           output[(outputPos++)] = ')';
/* 1635 */           break;
/*      */         case '⁵':
/*      */         case '₅':
/*      */         case '⑤':
/*      */         case '⓹':
/*      */         case '❺':
/*      */         case '➄':
/*      */         case '➎':
/*      */         case '５':
/* 1644 */           output[(outputPos++)] = '5';
/* 1645 */           break;
/*      */         case '⒌':
/* 1647 */           output[(outputPos++)] = '5';
/* 1648 */           output[(outputPos++)] = '.';
/* 1649 */           break;
/*      */         case '⑸':
/* 1651 */           output[(outputPos++)] = '(';
/* 1652 */           output[(outputPos++)] = '5';
/* 1653 */           output[(outputPos++)] = ')';
/* 1654 */           break;
/*      */         case '⁶':
/*      */         case '₆':
/*      */         case '⑥':
/*      */         case '⓺':
/*      */         case '❻':
/*      */         case '➅':
/*      */         case '➏':
/*      */         case '６':
/* 1663 */           output[(outputPos++)] = '6';
/* 1664 */           break;
/*      */         case '⒍':
/* 1666 */           output[(outputPos++)] = '6';
/* 1667 */           output[(outputPos++)] = '.';
/* 1668 */           break;
/*      */         case '⑹':
/* 1670 */           output[(outputPos++)] = '(';
/* 1671 */           output[(outputPos++)] = '6';
/* 1672 */           output[(outputPos++)] = ')';
/* 1673 */           break;
/*      */         case '⁷':
/*      */         case '₇':
/*      */         case '⑦':
/*      */         case '⓻':
/*      */         case '❼':
/*      */         case '➆':
/*      */         case '➐':
/*      */         case '７':
/* 1682 */           output[(outputPos++)] = '7';
/* 1683 */           break;
/*      */         case '⒎':
/* 1685 */           output[(outputPos++)] = '7';
/* 1686 */           output[(outputPos++)] = '.';
/* 1687 */           break;
/*      */         case '⑺':
/* 1689 */           output[(outputPos++)] = '(';
/* 1690 */           output[(outputPos++)] = '7';
/* 1691 */           output[(outputPos++)] = ')';
/* 1692 */           break;
/*      */         case '⁸':
/*      */         case '₈':
/*      */         case '⑧':
/*      */         case '⓼':
/*      */         case '❽':
/*      */         case '➇':
/*      */         case '➑':
/*      */         case '８':
/* 1701 */           output[(outputPos++)] = '8';
/* 1702 */           break;
/*      */         case '⒏':
/* 1704 */           output[(outputPos++)] = '8';
/* 1705 */           output[(outputPos++)] = '.';
/* 1706 */           break;
/*      */         case '⑻':
/* 1708 */           output[(outputPos++)] = '(';
/* 1709 */           output[(outputPos++)] = '8';
/* 1710 */           output[(outputPos++)] = ')';
/* 1711 */           break;
/*      */         case '⁹':
/*      */         case '₉':
/*      */         case '⑨':
/*      */         case '⓽':
/*      */         case '❾':
/*      */         case '➈':
/*      */         case '➒':
/*      */         case '９':
/* 1720 */           output[(outputPos++)] = '9';
/* 1721 */           break;
/*      */         case '⒐':
/* 1723 */           output[(outputPos++)] = '9';
/* 1724 */           output[(outputPos++)] = '.';
/* 1725 */           break;
/*      */         case '⑼':
/* 1727 */           output[(outputPos++)] = '(';
/* 1728 */           output[(outputPos++)] = '9';
/* 1729 */           output[(outputPos++)] = ')';
/* 1730 */           break;
/*      */         case '⑩':
/*      */         case '⓾':
/*      */         case '❿':
/*      */         case '➉':
/*      */         case '➓':
/* 1736 */           output[(outputPos++)] = '1';
/* 1737 */           output[(outputPos++)] = '0';
/* 1738 */           break;
/*      */         case '⒑':
/* 1740 */           output[(outputPos++)] = '1';
/* 1741 */           output[(outputPos++)] = '0';
/* 1742 */           output[(outputPos++)] = '.';
/* 1743 */           break;
/*      */         case '⑽':
/* 1745 */           output[(outputPos++)] = '(';
/* 1746 */           output[(outputPos++)] = '1';
/* 1747 */           output[(outputPos++)] = '0';
/* 1748 */           output[(outputPos++)] = ')';
/* 1749 */           break;
/*      */         case '⑪':
/*      */         case '⓫':
/* 1752 */           output[(outputPos++)] = '1';
/* 1753 */           output[(outputPos++)] = '1';
/* 1754 */           break;
/*      */         case '⒒':
/* 1756 */           output[(outputPos++)] = '1';
/* 1757 */           output[(outputPos++)] = '1';
/* 1758 */           output[(outputPos++)] = '.';
/* 1759 */           break;
/*      */         case '⑾':
/* 1761 */           output[(outputPos++)] = '(';
/* 1762 */           output[(outputPos++)] = '1';
/* 1763 */           output[(outputPos++)] = '1';
/* 1764 */           output[(outputPos++)] = ')';
/* 1765 */           break;
/*      */         case '⑫':
/*      */         case '⓬':
/* 1768 */           output[(outputPos++)] = '1';
/* 1769 */           output[(outputPos++)] = '2';
/* 1770 */           break;
/*      */         case '⒓':
/* 1772 */           output[(outputPos++)] = '1';
/* 1773 */           output[(outputPos++)] = '2';
/* 1774 */           output[(outputPos++)] = '.';
/* 1775 */           break;
/*      */         case '⑿':
/* 1777 */           output[(outputPos++)] = '(';
/* 1778 */           output[(outputPos++)] = '1';
/* 1779 */           output[(outputPos++)] = '2';
/* 1780 */           output[(outputPos++)] = ')';
/* 1781 */           break;
/*      */         case '⑬':
/*      */         case '⓭':
/* 1784 */           output[(outputPos++)] = '1';
/* 1785 */           output[(outputPos++)] = '3';
/* 1786 */           break;
/*      */         case '⒔':
/* 1788 */           output[(outputPos++)] = '1';
/* 1789 */           output[(outputPos++)] = '3';
/* 1790 */           output[(outputPos++)] = '.';
/* 1791 */           break;
/*      */         case '⒀':
/* 1793 */           output[(outputPos++)] = '(';
/* 1794 */           output[(outputPos++)] = '1';
/* 1795 */           output[(outputPos++)] = '3';
/* 1796 */           output[(outputPos++)] = ')';
/* 1797 */           break;
/*      */         case '⑭':
/*      */         case '⓮':
/* 1800 */           output[(outputPos++)] = '1';
/* 1801 */           output[(outputPos++)] = '4';
/* 1802 */           break;
/*      */         case '⒕':
/* 1804 */           output[(outputPos++)] = '1';
/* 1805 */           output[(outputPos++)] = '4';
/* 1806 */           output[(outputPos++)] = '.';
/* 1807 */           break;
/*      */         case '⒁':
/* 1809 */           output[(outputPos++)] = '(';
/* 1810 */           output[(outputPos++)] = '1';
/* 1811 */           output[(outputPos++)] = '4';
/* 1812 */           output[(outputPos++)] = ')';
/* 1813 */           break;
/*      */         case '⑮':
/*      */         case '⓯':
/* 1816 */           output[(outputPos++)] = '1';
/* 1817 */           output[(outputPos++)] = '5';
/* 1818 */           break;
/*      */         case '⒖':
/* 1820 */           output[(outputPos++)] = '1';
/* 1821 */           output[(outputPos++)] = '5';
/* 1822 */           output[(outputPos++)] = '.';
/* 1823 */           break;
/*      */         case '⒂':
/* 1825 */           output[(outputPos++)] = '(';
/* 1826 */           output[(outputPos++)] = '1';
/* 1827 */           output[(outputPos++)] = '5';
/* 1828 */           output[(outputPos++)] = ')';
/* 1829 */           break;
/*      */         case '⑯':
/*      */         case '⓰':
/* 1832 */           output[(outputPos++)] = '1';
/* 1833 */           output[(outputPos++)] = '6';
/* 1834 */           break;
/*      */         case '⒗':
/* 1836 */           output[(outputPos++)] = '1';
/* 1837 */           output[(outputPos++)] = '6';
/* 1838 */           output[(outputPos++)] = '.';
/* 1839 */           break;
/*      */         case '⒃':
/* 1841 */           output[(outputPos++)] = '(';
/* 1842 */           output[(outputPos++)] = '1';
/* 1843 */           output[(outputPos++)] = '6';
/* 1844 */           output[(outputPos++)] = ')';
/* 1845 */           break;
/*      */         case '⑰':
/*      */         case '⓱':
/* 1848 */           output[(outputPos++)] = '1';
/* 1849 */           output[(outputPos++)] = '7';
/* 1850 */           break;
/*      */         case '⒘':
/* 1852 */           output[(outputPos++)] = '1';
/* 1853 */           output[(outputPos++)] = '7';
/* 1854 */           output[(outputPos++)] = '.';
/* 1855 */           break;
/*      */         case '⒄':
/* 1857 */           output[(outputPos++)] = '(';
/* 1858 */           output[(outputPos++)] = '1';
/* 1859 */           output[(outputPos++)] = '7';
/* 1860 */           output[(outputPos++)] = ')';
/* 1861 */           break;
/*      */         case '⑱':
/*      */         case '⓲':
/* 1864 */           output[(outputPos++)] = '1';
/* 1865 */           output[(outputPos++)] = '8';
/* 1866 */           break;
/*      */         case '⒙':
/* 1868 */           output[(outputPos++)] = '1';
/* 1869 */           output[(outputPos++)] = '8';
/* 1870 */           output[(outputPos++)] = '.';
/* 1871 */           break;
/*      */         case '⒅':
/* 1873 */           output[(outputPos++)] = '(';
/* 1874 */           output[(outputPos++)] = '1';
/* 1875 */           output[(outputPos++)] = '8';
/* 1876 */           output[(outputPos++)] = ')';
/* 1877 */           break;
/*      */         case '⑲':
/*      */         case '⓳':
/* 1880 */           output[(outputPos++)] = '1';
/* 1881 */           output[(outputPos++)] = '9';
/* 1882 */           break;
/*      */         case '⒚':
/* 1884 */           output[(outputPos++)] = '1';
/* 1885 */           output[(outputPos++)] = '9';
/* 1886 */           output[(outputPos++)] = '.';
/* 1887 */           break;
/*      */         case '⒆':
/* 1889 */           output[(outputPos++)] = '(';
/* 1890 */           output[(outputPos++)] = '1';
/* 1891 */           output[(outputPos++)] = '9';
/* 1892 */           output[(outputPos++)] = ')';
/* 1893 */           break;
/*      */         case '⑳':
/*      */         case '⓴':
/* 1896 */           output[(outputPos++)] = '2';
/* 1897 */           output[(outputPos++)] = '0';
/* 1898 */           break;
/*      */         case '⒛':
/* 1900 */           output[(outputPos++)] = '2';
/* 1901 */           output[(outputPos++)] = '0';
/* 1902 */           output[(outputPos++)] = '.';
/* 1903 */           break;
/*      */         case '⒇':
/* 1905 */           output[(outputPos++)] = '(';
/* 1906 */           output[(outputPos++)] = '2';
/* 1907 */           output[(outputPos++)] = '0';
/* 1908 */           output[(outputPos++)] = ')';
/* 1909 */           break;
/*      */         case '«':
/*      */         case '»':
/*      */         case '“':
/*      */         case '”':
/*      */         case '„':
/*      */         case '″':
/*      */         case '‶':
/*      */         case '❝':
/*      */         case '❞':
/*      */         case '❮':
/*      */         case '❯':
/*      */         case '＂':
/* 1922 */           output[(outputPos++)] = '"';
/* 1923 */           break;
/*      */         case '‘':
/*      */         case '’':
/*      */         case '‚':
/*      */         case '‛':
/*      */         case '′':
/*      */         case '‵':
/*      */         case '‹':
/*      */         case '›':
/*      */         case '❛':
/*      */         case '❜':
/*      */         case '＇':
/* 1935 */           output[(outputPos++)] = '\'';
/* 1936 */           break;
/*      */         case '‐':
/*      */         case '‑':
/*      */         case '‒':
/*      */         case '–':
/*      */         case '—':
/*      */         case '⁻':
/*      */         case '₋':
/*      */         case '－':
/* 1945 */           output[(outputPos++)] = '-';
/* 1946 */           break;
/*      */         case '⁅':
/*      */         case '❲':
/*      */         case '［':
/* 1950 */           output[(outputPos++)] = '[';
/* 1951 */           break;
/*      */         case '⁆':
/*      */         case '❳':
/*      */         case '］':
/* 1955 */           output[(outputPos++)] = ']';
/* 1956 */           break;
/*      */         case '⁽':
/*      */         case '₍':
/*      */         case '❨':
/*      */         case '❪':
/*      */         case '（':
/* 1962 */           output[(outputPos++)] = '(';
/* 1963 */           break;
/*      */         case '⸨':
/* 1965 */           output[(outputPos++)] = '(';
/* 1966 */           output[(outputPos++)] = '(';
/* 1967 */           break;
/*      */         case '⁾':
/*      */         case '₎':
/*      */         case '❩':
/*      */         case '❫':
/*      */         case '）':
/* 1973 */           output[(outputPos++)] = ')';
/* 1974 */           break;
/*      */         case '⸩':
/* 1976 */           output[(outputPos++)] = ')';
/* 1977 */           output[(outputPos++)] = ')';
/* 1978 */           break;
/*      */         case '❬':
/*      */         case '❰':
/*      */         case '＜':
/* 1982 */           output[(outputPos++)] = '<';
/* 1983 */           break;
/*      */         case '❭':
/*      */         case '❱':
/*      */         case '＞':
/* 1987 */           output[(outputPos++)] = '>';
/* 1988 */           break;
/*      */         case '❴':
/*      */         case '｛':
/* 1991 */           output[(outputPos++)] = '{';
/* 1992 */           break;
/*      */         case '❵':
/*      */         case '｝':
/* 1995 */           output[(outputPos++)] = '}';
/* 1996 */           break;
/*      */         case '⁺':
/*      */         case '₊':
/*      */         case '＋':
/* 2000 */           output[(outputPos++)] = '+';
/* 2001 */           break;
/*      */         case '⁼':
/*      */         case '₌':
/*      */         case '＝':
/* 2005 */           output[(outputPos++)] = '=';
/* 2006 */           break;
/*      */         case '！':
/* 2008 */           output[(outputPos++)] = '!';
/* 2009 */           break;
/*      */         case '‼':
/* 2011 */           output[(outputPos++)] = '!';
/* 2012 */           output[(outputPos++)] = '!';
/* 2013 */           break;
/*      */         case '⁉':
/* 2015 */           output[(outputPos++)] = '!';
/* 2016 */           output[(outputPos++)] = '?';
/* 2017 */           break;
/*      */         case '＃':
/* 2019 */           output[(outputPos++)] = '#';
/* 2020 */           break;
/*      */         case '＄':
/* 2022 */           output[(outputPos++)] = '$';
/* 2023 */           break;
/*      */         case '⁒':
/*      */         case '％':
/* 2026 */           output[(outputPos++)] = '%';
/* 2027 */           break;
/*      */         case '＆':
/* 2029 */           output[(outputPos++)] = '&';
/* 2030 */           break;
/*      */         case '⁎':
/*      */         case '＊':
/* 2033 */           output[(outputPos++)] = '*';
/* 2034 */           break;
/*      */         case '，':
/* 2036 */           output[(outputPos++)] = ',';
/* 2037 */           break;
/*      */         case '．':
/* 2039 */           output[(outputPos++)] = '.';
/* 2040 */           break;
/*      */         case '⁄':
/*      */         case '／':
/* 2043 */           output[(outputPos++)] = '/';
/* 2044 */           break;
/*      */         case '：':
/* 2046 */           output[(outputPos++)] = ':';
/* 2047 */           break;
/*      */         case '⁏':
/*      */         case '；':
/* 2050 */           output[(outputPos++)] = ';';
/* 2051 */           break;
/*      */         case '？':
/* 2053 */           output[(outputPos++)] = '?';
/* 2054 */           break;
/*      */         case '⁇':
/* 2056 */           output[(outputPos++)] = '?';
/* 2057 */           output[(outputPos++)] = '?';
/* 2058 */           break;
/*      */         case '⁈':
/* 2060 */           output[(outputPos++)] = '?';
/* 2061 */           output[(outputPos++)] = '!';
/* 2062 */           break;
/*      */         case '＠':
/* 2064 */           output[(outputPos++)] = '@';
/* 2065 */           break;
/*      */         case '＼':
/* 2067 */           output[(outputPos++)] = '\\';
/* 2068 */           break;
/*      */         case '‸':
/*      */         case '＾':
/* 2071 */           output[(outputPos++)] = '^';
/* 2072 */           break;
/*      */         case '＿':
/* 2074 */           output[(outputPos++)] = '_';
/* 2075 */           break;
/*      */         case '⁓':
/*      */         case '～':
/* 2078 */           output[(outputPos++)] = '~';
/* 2079 */           break;
/*      */         default:
/* 2081 */           output[(outputPos++)] = c;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2086 */     return outputPos;
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.ASCIIFoldingFilter
 * JD-Core Version:    0.6.2
 */