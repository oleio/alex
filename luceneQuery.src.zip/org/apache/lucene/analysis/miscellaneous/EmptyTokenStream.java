/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ 
/*    */ public final class EmptyTokenStream extends TokenStream
/*    */ {
/*    */   public final boolean incrementToken()
/*    */   {
/* 29 */     return false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.EmptyTokenStream
 * JD-Core Version:    0.6.2
 */