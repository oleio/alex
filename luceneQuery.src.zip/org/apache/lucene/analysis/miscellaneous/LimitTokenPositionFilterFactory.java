/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class LimitTokenPositionFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public static final String MAX_TOKEN_POSITION_KEY = "maxTokenPosition";
/*    */   public static final String CONSUME_ALL_TOKENS_KEY = "consumeAllTokens";
/*    */   final int maxTokenPosition;
/*    */   final boolean consumeAllTokens;
/*    */ 
/*    */   public LimitTokenPositionFilterFactory(Map<String, String> args)
/*    */   {
/* 46 */     super(args);
/* 47 */     this.maxTokenPosition = requireInt(args, "maxTokenPosition");
/* 48 */     this.consumeAllTokens = getBoolean(args, "consumeAllTokens", false);
/* 49 */     if (!args.isEmpty())
/* 50 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 56 */     return new LimitTokenPositionFilter(input, this.maxTokenPosition, this.consumeAllTokens);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.LimitTokenPositionFilterFactory
 * JD-Core Version:    0.6.2
 */