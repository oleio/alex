/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class TrimFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   protected final boolean updateOffsets;
/*    */ 
/*    */   public TrimFilterFactory(Map<String, String> args)
/*    */   {
/* 44 */     super(args);
/* 45 */     this.updateOffsets = getBoolean(args, "updateOffsets", false);
/* 46 */     if (!args.isEmpty())
/* 47 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TrimFilter create(TokenStream input)
/*    */   {
/* 54 */     TrimFilter filter = new TrimFilter(this.luceneMatchVersion, input, this.updateOffsets);
/* 55 */     return filter;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.TrimFilterFactory
 * JD-Core Version:    0.6.2
 */