/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*    */ 
/*    */ public abstract class KeywordMarkerFilter extends TokenFilter
/*    */ {
/* 33 */   private final KeywordAttribute keywordAttr = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/*    */ 
/*    */   protected KeywordMarkerFilter(TokenStream in)
/*    */   {
/* 40 */     super(in);
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken() throws IOException
/*    */   {
/* 45 */     if (this.input.incrementToken()) {
/* 46 */       if (isKeyword()) {
/* 47 */         this.keywordAttr.setKeyword(true);
/*    */       }
/* 49 */       return true;
/*    */     }
/* 51 */     return false;
/*    */   }
/*    */ 
/*    */   protected abstract boolean isKeyword();
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.KeywordMarkerFilter
 * JD-Core Version:    0.6.2
 */