/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.util.FilteringTokenFilter;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class CodepointCountFilter extends FilteringTokenFilter
/*    */ {
/*    */   private final int min;
/*    */   private final int max;
/* 36 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */ 
/*    */   public CodepointCountFilter(Version version, TokenStream in, int min, int max)
/*    */   {
/* 48 */     super(version, in);
/* 49 */     this.min = min;
/* 50 */     this.max = max;
/*    */   }
/*    */ 
/*    */   public boolean accept()
/*    */   {
/* 55 */     int max32 = this.termAtt.length();
/* 56 */     int min32 = max32 >> 1;
/* 57 */     if ((min32 >= this.min) && (max32 <= this.max))
/*    */     {
/* 59 */       return true;
/* 60 */     }if ((min32 > this.max) || (max32 < this.min))
/*    */     {
/* 62 */       return false;
/*    */     }
/*    */ 
/* 65 */     int len = Character.codePointCount(this.termAtt.buffer(), 0, this.termAtt.length());
/* 66 */     return (len >= this.min) && (len <= this.max);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.CodepointCountFilter
 * JD-Core Version:    0.6.2
 */