/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.CharArraySet;
/*    */ import org.apache.lucene.analysis.util.ResourceLoader;
/*    */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class KeywordMarkerFilterFactory extends TokenFilterFactory
/*    */   implements ResourceLoaderAware
/*    */ {
/*    */   public static final String PROTECTED_TOKENS = "protected";
/*    */   public static final String PATTERN = "pattern";
/*    */   private final String wordFiles;
/*    */   private final String stringPattern;
/*    */   private final boolean ignoreCase;
/*    */   private Pattern pattern;
/*    */   private CharArraySet protectedWords;
/*    */ 
/*    */   public KeywordMarkerFilterFactory(Map<String, String> args)
/*    */   {
/* 51 */     super(args);
/* 52 */     this.wordFiles = get(args, "protected");
/* 53 */     this.stringPattern = get(args, "pattern");
/* 54 */     this.ignoreCase = getBoolean(args, "ignoreCase", false);
/* 55 */     if (!args.isEmpty())
/* 56 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public void inform(ResourceLoader loader)
/*    */     throws IOException
/*    */   {
/* 62 */     if (this.wordFiles != null) {
/* 63 */       this.protectedWords = getWordSet(loader, this.wordFiles, this.ignoreCase);
/*    */     }
/* 65 */     if (this.stringPattern != null)
/* 66 */       this.pattern = (this.ignoreCase ? Pattern.compile(this.stringPattern, 66) : Pattern.compile(this.stringPattern));
/*    */   }
/*    */ 
/*    */   public boolean isIgnoreCase()
/*    */   {
/* 71 */     return this.ignoreCase;
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 76 */     if (this.pattern != null) {
/* 77 */       input = new PatternKeywordMarkerFilter(input, this.pattern);
/*    */     }
/* 79 */     if (this.protectedWords != null) {
/* 80 */       input = new SetKeywordMarkerFilter(input, this.protectedWords);
/*    */     }
/* 82 */     return input;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.KeywordMarkerFilterFactory
 * JD-Core Version:    0.6.2
 */