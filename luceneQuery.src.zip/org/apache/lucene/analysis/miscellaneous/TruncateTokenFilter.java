/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*    */ 
/*    */ public final class TruncateTokenFilter extends TokenFilter
/*    */ {
/* 36 */   private final CharTermAttribute termAttribute = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 37 */   private final KeywordAttribute keywordAttr = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/*    */   private final int length;
/*    */ 
/*    */   public TruncateTokenFilter(TokenStream input, int length)
/*    */   {
/* 42 */     super(input);
/* 43 */     if (length < 1)
/* 44 */       throw new IllegalArgumentException("length parameter must be a positive number: " + length);
/* 45 */     this.length = length;
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken() throws IOException
/*    */   {
/* 50 */     if (this.input.incrementToken()) {
/* 51 */       if ((!this.keywordAttr.isKeyword()) && (this.termAttribute.length() > this.length))
/* 52 */         this.termAttribute.setLength(this.length);
/* 53 */       return true;
/*    */     }
/* 55 */     return false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.TruncateTokenFilter
 * JD-Core Version:    0.6.2
 */