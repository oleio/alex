/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*    */ import org.apache.lucene.util.AttributeSource.State;
/*    */ 
/*    */ public final class KeywordRepeatFilter extends TokenFilter
/*    */ {
/* 36 */   private final KeywordAttribute keywordAttribute = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/* 37 */   private final PositionIncrementAttribute posIncAttr = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*    */   private AttributeSource.State state;
/*    */ 
/*    */   public KeywordRepeatFilter(TokenStream input)
/*    */   {
/* 44 */     super(input);
/*    */   }
/*    */ 
/*    */   public boolean incrementToken() throws IOException
/*    */   {
/* 49 */     if (this.state != null) {
/* 50 */       restoreState(this.state);
/* 51 */       this.posIncAttr.setPositionIncrement(0);
/* 52 */       this.keywordAttribute.setKeyword(false);
/* 53 */       this.state = null;
/* 54 */       return true;
/*    */     }
/* 56 */     if (this.input.incrementToken()) {
/* 57 */       this.state = captureState();
/* 58 */       this.keywordAttribute.setKeyword(true);
/* 59 */       return true;
/*    */     }
/* 61 */     return false;
/*    */   }
/*    */ 
/*    */   public void reset() throws IOException
/*    */   {
/* 66 */     super.reset();
/* 67 */     this.state = null;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.KeywordRepeatFilter
 * JD-Core Version:    0.6.2
 */