/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class CodepointCountFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   final int min;
/*    */   final int max;
/*    */   public static final String MIN_KEY = "min";
/*    */   public static final String MAX_KEY = "max";
/*    */ 
/*    */   public CodepointCountFilterFactory(Map<String, String> args)
/*    */   {
/* 43 */     super(args);
/* 44 */     this.min = requireInt(args, "min");
/* 45 */     this.max = requireInt(args, "max");
/* 46 */     if (!args.isEmpty())
/* 47 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public CodepointCountFilter create(TokenStream input)
/*    */   {
/* 53 */     return new CodepointCountFilter(this.luceneMatchVersion, input, this.min, this.max);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.CodepointCountFilterFactory
 * JD-Core Version:    0.6.2
 */