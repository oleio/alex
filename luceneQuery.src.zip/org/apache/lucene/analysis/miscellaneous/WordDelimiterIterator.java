/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ public final class WordDelimiterIterator
/*     */ {
/*     */   public static final int DONE = -1;
/*  93 */   public static final byte[] DEFAULT_WORD_DELIM_TABLE = tab;
/*     */   char[] text;
/*     */   int length;
/*     */   int startBounds;
/*     */   int endBounds;
/*     */   int current;
/*     */   int end;
/*  47 */   private boolean hasFinalPossessive = false;
/*     */   final boolean splitOnCaseChange;
/*     */   final boolean splitOnNumerics;
/*     */   final boolean stemEnglishPossessive;
/*     */   private final byte[] charTypeTable;
/*  71 */   private boolean skipPossessive = false;
/*     */ 
/*     */   WordDelimiterIterator(byte[] charTypeTable, boolean splitOnCaseChange, boolean splitOnNumerics, boolean stemEnglishPossessive)
/*     */   {
/* 105 */     this.charTypeTable = charTypeTable;
/* 106 */     this.splitOnCaseChange = splitOnCaseChange;
/* 107 */     this.splitOnNumerics = splitOnNumerics;
/* 108 */     this.stemEnglishPossessive = stemEnglishPossessive;
/*     */   }
/*     */ 
/*     */   int next()
/*     */   {
/* 117 */     this.current = this.end;
/* 118 */     if (this.current == -1) {
/* 119 */       return -1;
/*     */     }
/*     */ 
/* 122 */     if (this.skipPossessive) {
/* 123 */       this.current += 2;
/* 124 */       this.skipPossessive = false;
/*     */     }
/*     */ 
/* 127 */     int lastType = 0;
/*     */ 
/* 129 */     while ((this.current < this.endBounds) && (WordDelimiterFilter.isSubwordDelim(lastType = charType(this.text[this.current])))) {
/* 130 */       this.current += 1;
/*     */     }
/*     */ 
/* 133 */     if (this.current >= this.endBounds) {
/* 134 */       return this.end = -1;
/*     */     }
/*     */ 
/* 137 */     for (this.end = (this.current + 1); this.end < this.endBounds; this.end += 1) {
/* 138 */       int type = charType(this.text[this.end]);
/* 139 */       if (isBreak(lastType, type)) {
/*     */         break;
/*     */       }
/* 142 */       lastType = type;
/*     */     }
/*     */ 
/* 145 */     if ((this.end < this.endBounds - 1) && (endsWithPossessive(this.end + 2))) {
/* 146 */       this.skipPossessive = true;
/*     */     }
/*     */ 
/* 149 */     return this.end;
/*     */   }
/*     */ 
/*     */   int type()
/*     */   {
/* 160 */     if (this.end == -1) {
/* 161 */       return 0;
/*     */     }
/*     */ 
/* 164 */     int type = charType(this.text[this.current]);
/* 165 */     switch (type)
/*     */     {
/*     */     case 1:
/*     */     case 2:
/* 169 */       return 3;
/*     */     }
/* 171 */     return type;
/*     */   }
/*     */ 
/*     */   void setText(char[] text, int length)
/*     */   {
/* 182 */     this.text = text;
/* 183 */     this.length = (this.endBounds = length);
/* 184 */     this.current = (this.startBounds = this.end = 0);
/* 185 */     this.skipPossessive = (this.hasFinalPossessive = 0);
/* 186 */     setBounds();
/*     */   }
/*     */ 
/*     */   private boolean isBreak(int lastType, int type)
/*     */   {
/* 199 */     if ((type & lastType) != 0) {
/* 200 */       return false;
/*     */     }
/*     */ 
/* 203 */     if ((!this.splitOnCaseChange) && (WordDelimiterFilter.isAlpha(lastType)) && (WordDelimiterFilter.isAlpha(type)))
/*     */     {
/* 205 */       return false;
/* 206 */     }if ((WordDelimiterFilter.isUpper(lastType)) && (WordDelimiterFilter.isAlpha(type)))
/*     */     {
/* 208 */       return false;
/* 209 */     }if ((!this.splitOnNumerics) && (((WordDelimiterFilter.isAlpha(lastType)) && (WordDelimiterFilter.isDigit(type))) || ((WordDelimiterFilter.isDigit(lastType)) && (WordDelimiterFilter.isAlpha(type)))))
/*     */     {
/* 211 */       return false;
/*     */     }
/*     */ 
/* 214 */     return true;
/*     */   }
/*     */ 
/*     */   boolean isSingleWord()
/*     */   {
/* 223 */     if (this.hasFinalPossessive) {
/* 224 */       return (this.current == this.startBounds) && (this.end == this.endBounds - 2);
/*     */     }
/*     */ 
/* 227 */     return (this.current == this.startBounds) && (this.end == this.endBounds);
/*     */   }
/*     */ 
/*     */   private void setBounds()
/*     */   {
/* 236 */     while ((this.startBounds < this.length) && (WordDelimiterFilter.isSubwordDelim(charType(this.text[this.startBounds])))) {
/* 237 */       this.startBounds += 1;
/*     */     }
/*     */ 
/* 240 */     while ((this.endBounds > this.startBounds) && (WordDelimiterFilter.isSubwordDelim(charType(this.text[(this.endBounds - 1)])))) {
/* 241 */       this.endBounds -= 1;
/*     */     }
/* 243 */     if (endsWithPossessive(this.endBounds)) {
/* 244 */       this.hasFinalPossessive = true;
/*     */     }
/* 246 */     this.current = this.startBounds;
/*     */   }
/*     */ 
/*     */   private boolean endsWithPossessive(int pos)
/*     */   {
/* 256 */     return (this.stemEnglishPossessive) && (pos > 2) && (this.text[(pos - 2)] == '\'') && ((this.text[(pos - 1)] == 's') || (this.text[(pos - 1)] == 'S')) && (WordDelimiterFilter.isAlpha(charType(this.text[(pos - 3)]))) && ((pos == this.endBounds) || (WordDelimiterFilter.isSubwordDelim(charType(this.text[pos]))));
/*     */   }
/*     */ 
/*     */   private int charType(int ch)
/*     */   {
/* 271 */     if (ch < this.charTypeTable.length) {
/* 272 */       return this.charTypeTable[ch];
/*     */     }
/* 274 */     return getType(ch);
/*     */   }
/*     */ 
/*     */   public static byte getType(int ch)
/*     */   {
/* 284 */     switch (Character.getType(ch)) { case 1:
/* 285 */       return 2;
/*     */     case 2:
/* 286 */       return 1;
/*     */     case 3:
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/* 294 */       return 3;
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/* 299 */       return 4;
/*     */     case 19:
/* 309 */       return 7;
/*     */     case 12:
/*     */     case 13:
/*     */     case 14:
/*     */     case 15:
/*     */     case 16:
/*     */     case 17:
/*     */     case 18:
/*     */     }
/*     */ 
/* 323 */     return 8;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  76 */     byte[] tab = new byte[256];
/*  77 */     for (int i = 0; i < 256; i++) {
/*  78 */       byte code = 0;
/*  79 */       if (Character.isLowerCase(i)) {
/*  80 */         code = (byte)(code | 0x1);
/*     */       }
/*  82 */       else if (Character.isUpperCase(i)) {
/*  83 */         code = (byte)(code | 0x2);
/*     */       }
/*  85 */       else if (Character.isDigit(i)) {
/*  86 */         code = (byte)(code | 0x4);
/*     */       }
/*  88 */       if (code == 0) {
/*  89 */         code = 8;
/*     */       }
/*  91 */       tab[i] = code;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.WordDelimiterIterator
 * JD-Core Version:    0.6.2
 */