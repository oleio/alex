/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.CharArraySet;
/*    */ import org.apache.lucene.analysis.util.ResourceLoader;
/*    */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class KeepWordFilterFactory extends TokenFilterFactory
/*    */   implements ResourceLoaderAware
/*    */ {
/*    */   private final boolean ignoreCase;
/*    */   private final boolean enablePositionIncrements;
/*    */   private final String wordFiles;
/*    */   private CharArraySet words;
/*    */ 
/*    */   public KeepWordFilterFactory(Map<String, String> args)
/*    */   {
/* 47 */     super(args);
/* 48 */     assureMatchVersion();
/* 49 */     this.wordFiles = get(args, "words");
/* 50 */     this.ignoreCase = getBoolean(args, "ignoreCase", false);
/* 51 */     this.enablePositionIncrements = getBoolean(args, "enablePositionIncrements", true);
/* 52 */     if (!args.isEmpty())
/* 53 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public void inform(ResourceLoader loader)
/*    */     throws IOException
/*    */   {
/* 59 */     if (this.wordFiles != null)
/* 60 */       this.words = getWordSet(loader, this.wordFiles, this.ignoreCase);
/*    */   }
/*    */ 
/*    */   public boolean isEnablePositionIncrements()
/*    */   {
/* 65 */     return this.enablePositionIncrements;
/*    */   }
/*    */ 
/*    */   public boolean isIgnoreCase() {
/* 69 */     return this.ignoreCase;
/*    */   }
/*    */ 
/*    */   public CharArraySet getWords() {
/* 73 */     return this.words;
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 79 */     if (this.words == null) {
/* 80 */       return input;
/*    */     }
/*    */ 
/* 83 */     TokenStream filter = new KeepWordFilter(this.luceneMatchVersion, this.enablePositionIncrements, input, this.words);
/* 84 */     return filter;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.KeepWordFilterFactory
 * JD-Core Version:    0.6.2
 */