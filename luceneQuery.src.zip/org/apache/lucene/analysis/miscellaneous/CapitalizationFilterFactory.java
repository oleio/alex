/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*     */ 
/*     */ public class CapitalizationFilterFactory extends TokenFilterFactory
/*     */ {
/*     */   public static final String KEEP = "keep";
/*     */   public static final String KEEP_IGNORE_CASE = "keepIgnoreCase";
/*     */   public static final String OK_PREFIX = "okPrefix";
/*     */   public static final String MIN_WORD_LENGTH = "minWordLength";
/*     */   public static final String MAX_WORD_COUNT = "maxWordCount";
/*     */   public static final String MAX_TOKEN_LENGTH = "maxTokenLength";
/*     */   public static final String ONLY_FIRST_WORD = "onlyFirstWord";
/*     */   public static final String FORCE_FIRST_LETTER = "forceFirstLetter";
/*     */   CharArraySet keep;
/*  70 */   Collection<char[]> okPrefix = Collections.emptyList();
/*     */   final int minWordLength;
/*     */   final int maxWordCount;
/*     */   final int maxTokenLength;
/*     */   final boolean onlyFirstWord;
/*     */   final boolean forceFirstLetter;
/*     */ 
/*     */   public CapitalizationFilterFactory(Map<String, String> args)
/*     */   {
/*  80 */     super(args);
/*  81 */     assureMatchVersion();
/*  82 */     boolean ignoreCase = getBoolean(args, "keepIgnoreCase", false);
/*  83 */     Set k = getSet(args, "keep");
/*  84 */     if (k != null) {
/*  85 */       this.keep = new CharArraySet(this.luceneMatchVersion, 10, ignoreCase);
/*  86 */       this.keep.addAll(k);
/*     */     }
/*     */ 
/*  89 */     k = getSet(args, "okPrefix");
/*  90 */     if (k != null) {
/*  91 */       this.okPrefix = new ArrayList();
/*  92 */       for (String item : k) {
/*  93 */         this.okPrefix.add(item.toCharArray());
/*     */       }
/*     */     }
/*     */ 
/*  97 */     this.minWordLength = getInt(args, "minWordLength", 0);
/*  98 */     this.maxWordCount = getInt(args, "maxWordCount", 2147483647);
/*  99 */     this.maxTokenLength = getInt(args, "maxTokenLength", 2147483647);
/* 100 */     this.onlyFirstWord = getBoolean(args, "onlyFirstWord", true);
/* 101 */     this.forceFirstLetter = getBoolean(args, "forceFirstLetter", true);
/* 102 */     if (!args.isEmpty())
/* 103 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*     */   }
/*     */ 
/*     */   public CapitalizationFilter create(TokenStream input)
/*     */   {
/* 109 */     return new CapitalizationFilter(input, this.onlyFirstWord, this.keep, this.forceFirstLetter, this.okPrefix, this.minWordLength, this.maxWordCount, this.maxTokenLength);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.CapitalizationFilterFactory
 * JD-Core Version:    0.6.2
 */