/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class LengthFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   final int min;
/*    */   final int max;
/*    */   final boolean enablePositionIncrements;
/*    */   public static final String MIN_KEY = "min";
/*    */   public static final String MAX_KEY = "max";
/*    */ 
/*    */   public LengthFilterFactory(Map<String, String> args)
/*    */   {
/* 44 */     super(args);
/* 45 */     this.min = requireInt(args, "min");
/* 46 */     this.max = requireInt(args, "max");
/* 47 */     this.enablePositionIncrements = getBoolean(args, "enablePositionIncrements", true);
/* 48 */     if (!args.isEmpty())
/* 49 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public LengthFilter create(TokenStream input)
/*    */   {
/* 56 */     LengthFilter filter = new LengthFilter(this.luceneMatchVersion, this.enablePositionIncrements, input, this.min, this.max);
/* 57 */     return filter;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.LengthFilterFactory
 * JD-Core Version:    0.6.2
 */