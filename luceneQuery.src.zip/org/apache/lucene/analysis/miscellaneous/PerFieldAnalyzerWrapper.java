/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.Analyzer;
/*    */ import org.apache.lucene.analysis.AnalyzerWrapper;
/*    */ 
/*    */ public final class PerFieldAnalyzerWrapper extends AnalyzerWrapper
/*    */ {
/*    */   private final Analyzer defaultAnalyzer;
/*    */   private final Map<String, Analyzer> fieldAnalyzers;
/*    */ 
/*    */   public PerFieldAnalyzerWrapper(Analyzer defaultAnalyzer)
/*    */   {
/* 62 */     this(defaultAnalyzer, null);
/*    */   }
/*    */ 
/*    */   public PerFieldAnalyzerWrapper(Analyzer defaultAnalyzer, Map<String, Analyzer> fieldAnalyzers)
/*    */   {
/* 76 */     super(PER_FIELD_REUSE_STRATEGY);
/* 77 */     this.defaultAnalyzer = defaultAnalyzer;
/* 78 */     this.fieldAnalyzers = (fieldAnalyzers != null ? fieldAnalyzers : Collections.emptyMap());
/*    */   }
/*    */ 
/*    */   protected Analyzer getWrappedAnalyzer(String fieldName)
/*    */   {
/* 83 */     Analyzer analyzer = (Analyzer)this.fieldAnalyzers.get(fieldName);
/* 84 */     return analyzer != null ? analyzer : this.defaultAnalyzer;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 89 */     return "PerFieldAnalyzerWrapper(" + this.fieldAnalyzers + ", default=" + this.defaultAnalyzer + ")";
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper
 * JD-Core Version:    0.6.2
 */