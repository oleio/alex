/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class TrimFilter extends TokenFilter
/*    */ {
/*    */   final boolean updateOffsets;
/* 36 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 37 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*    */ 
/*    */   @Deprecated
/*    */   public TrimFilter(Version version, TokenStream in, boolean updateOffsets)
/*    */   {
/* 48 */     super(in);
/* 49 */     if ((updateOffsets) && (version.onOrAfter(Version.LUCENE_44))) {
/* 50 */       throw new IllegalArgumentException("updateOffsets=true is not supported anymore as of Lucene 4.4");
/*    */     }
/* 52 */     this.updateOffsets = updateOffsets;
/*    */   }
/*    */ 
/*    */   public TrimFilter(Version version, TokenStream in)
/*    */   {
/* 57 */     this(version, in, false);
/*    */   }
/*    */ 
/*    */   public boolean incrementToken() throws IOException
/*    */   {
/* 62 */     if (!this.input.incrementToken()) return false;
/*    */ 
/* 64 */     char[] termBuffer = this.termAtt.buffer();
/* 65 */     int len = this.termAtt.length();
/*    */ 
/* 68 */     if (len == 0) {
/* 69 */       return true;
/*    */     }
/* 71 */     int start = 0;
/* 72 */     int end = 0;
/* 73 */     int endOff = 0;
/*    */ 
/* 76 */     for (start = 0; (start < len) && (Character.isWhitespace(termBuffer[start])); start++);
/* 79 */     for (end = len; (end >= start) && (Character.isWhitespace(termBuffer[(end - 1)])); end--) {
/* 80 */       endOff++;
/*    */     }
/* 82 */     if ((start > 0) || (end < len)) {
/* 83 */       if (start < end)
/* 84 */         this.termAtt.copyBuffer(termBuffer, start, end - start);
/*    */       else {
/* 86 */         this.termAtt.setEmpty();
/*    */       }
/* 88 */       if ((this.updateOffsets) && (len == this.offsetAtt.endOffset() - this.offsetAtt.startOffset())) {
/* 89 */         int newStart = this.offsetAtt.startOffset() + start;
/* 90 */         int newEnd = this.offsetAtt.endOffset() - (start < end ? endOff : 0);
/* 91 */         this.offsetAtt.setOffset(newStart, newEnd);
/*    */       }
/*    */     }
/*    */ 
/* 95 */     return true;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.TrimFilter
 * JD-Core Version:    0.6.2
 */