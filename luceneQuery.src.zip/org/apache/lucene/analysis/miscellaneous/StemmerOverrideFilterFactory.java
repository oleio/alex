/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.ResourceLoader;
/*    */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class StemmerOverrideFilterFactory extends TokenFilterFactory
/*    */   implements ResourceLoaderAware
/*    */ {
/*    */   private StemmerOverrideFilter.StemmerOverrideMap dictionary;
/*    */   private final String dictionaryFiles;
/*    */   private final boolean ignoreCase;
/*    */ 
/*    */   public StemmerOverrideFilterFactory(Map<String, String> args)
/*    */   {
/* 47 */     super(args);
/* 48 */     this.dictionaryFiles = get(args, "dictionary");
/* 49 */     this.ignoreCase = getBoolean(args, "ignoreCase", false);
/* 50 */     if (!args.isEmpty())
/* 51 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public void inform(ResourceLoader loader)
/*    */     throws IOException
/*    */   {
/* 57 */     if (this.dictionaryFiles != null) {
/* 58 */       assureMatchVersion();
/* 59 */       List files = splitFileNames(this.dictionaryFiles);
/* 60 */       if (files.size() > 0) {
/* 61 */         StemmerOverrideFilter.Builder builder = new StemmerOverrideFilter.Builder(this.ignoreCase);
/* 62 */         for (String file : files) {
/* 63 */           List list = getLines(loader, file.trim());
/* 64 */           for (String line : list) {
/* 65 */             String[] mapping = line.split("\t", 2);
/* 66 */             builder.add(mapping[0], mapping[1]);
/*    */           }
/*    */         }
/* 69 */         this.dictionary = builder.build();
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean isIgnoreCase() {
/* 75 */     return this.ignoreCase;
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 80 */     return this.dictionary == null ? input : new StemmerOverrideFilter(input, this.dictionary);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.StemmerOverrideFilterFactory
 * JD-Core Version:    0.6.2
 */