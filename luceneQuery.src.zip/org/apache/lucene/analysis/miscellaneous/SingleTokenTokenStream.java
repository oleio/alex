/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import org.apache.lucene.analysis.Token;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.util.AttributeImpl;
/*    */ 
/*    */ public final class SingleTokenTokenStream extends TokenStream
/*    */ {
/* 30 */   private boolean exhausted = false;
/*    */   private Token singleToken;
/*    */   private final AttributeImpl tokenAtt;
/*    */ 
/*    */   public SingleTokenTokenStream(Token token)
/*    */   {
/* 37 */     super(Token.TOKEN_ATTRIBUTE_FACTORY);
/*    */ 
/* 39 */     assert (token != null);
/* 40 */     this.singleToken = token.clone();
/*    */ 
/* 42 */     this.tokenAtt = ((AttributeImpl)addAttribute(CharTermAttribute.class));
/* 43 */     assert ((this.tokenAtt instanceof Token));
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken()
/*    */   {
/* 48 */     if (this.exhausted) {
/* 49 */       return false;
/*    */     }
/* 51 */     clearAttributes();
/* 52 */     this.singleToken.copyTo(this.tokenAtt);
/* 53 */     this.exhausted = true;
/* 54 */     return true;
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */   {
/* 60 */     this.exhausted = false;
/*    */   }
/*    */ 
/*    */   public Token getToken() {
/* 64 */     return this.singleToken.clone();
/*    */   }
/*    */ 
/*    */   public void setToken(Token token) {
/* 68 */     this.singleToken = token.clone();
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.SingleTokenTokenStream
 * JD-Core Version:    0.6.2
 */