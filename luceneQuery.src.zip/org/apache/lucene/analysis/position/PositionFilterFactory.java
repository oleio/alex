/*    */ package org.apache.lucene.analysis.position;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ @Deprecated
/*    */ public class PositionFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   private final int positionIncrement;
/*    */ 
/*    */   public PositionFilterFactory(Map<String, String> args)
/*    */   {
/* 49 */     super(args);
/* 50 */     this.positionIncrement = getInt(args, "positionIncrement", 0);
/* 51 */     if (!args.isEmpty()) {
/* 52 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */     }
/* 54 */     if ((this.luceneMatchVersion != null) && (this.luceneMatchVersion.onOrAfter(Version.LUCENE_44)))
/* 55 */       throw new IllegalArgumentException("PositionFilter is deprecated as of Lucene 4.4. You should either fix your code to not use it or use Lucene 4.3 version compatibility");
/*    */   }
/*    */ 
/*    */   public PositionFilter create(TokenStream input)
/*    */   {
/* 61 */     return new PositionFilter(input, this.positionIncrement);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.position.PositionFilterFactory
 * JD-Core Version:    0.6.2
 */