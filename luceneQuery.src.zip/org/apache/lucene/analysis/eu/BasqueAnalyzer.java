/*     */ package org.apache.lucene.analysis.eu;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.snowball.SnowballFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.tartarus.snowball.ext.BasqueStemmer;
/*     */ 
/*     */ public final class BasqueAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   private final CharArraySet stemExclusionSet;
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  51 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public BasqueAnalyzer(Version matchVersion)
/*     */   {
/*  77 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   public BasqueAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/*  87 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public BasqueAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/* 100 */     super(matchVersion, stopwords);
/* 101 */     this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 120 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 121 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/* 122 */     result = new LowerCaseFilter(this.matchVersion, result);
/* 123 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 124 */     if (!this.stemExclusionSet.isEmpty())
/* 125 */       result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
/* 126 */     result = new SnowballFilter(result, new BasqueStemmer());
/* 127 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  63 */         DEFAULT_STOP_SET = BasqueAnalyzer.loadStopwordSet(false, BasqueAnalyzer.class, "stopwords.txt", "#");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  68 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.eu.BasqueAnalyzer
 * JD-Core Version:    0.6.2
 */