/*     */ package org.apache.lucene.analysis.ckb;
/*     */ 
/*     */ import org.apache.lucene.analysis.util.StemmerUtil;
/*     */ 
/*     */ public class SoraniNormalizer
/*     */ {
/*     */   static final char YEH = 'ي';
/*     */   static final char DOTLESS_YEH = 'ى';
/*     */   static final char FARSI_YEH = 'ی';
/*     */   static final char KAF = 'ك';
/*     */   static final char KEHEH = 'ک';
/*     */   static final char HEH = 'ه';
/*     */   static final char AE = 'ە';
/*     */   static final char ZWNJ = '‌';
/*     */   static final char HEH_DOACHASHMEE = 'ھ';
/*     */   static final char TEH_MARBUTA = 'ة';
/*     */   static final char REH = 'ر';
/*     */   static final char RREH = 'ڕ';
/*     */   static final char RREH_ABOVE = 'ڒ';
/*     */   static final char TATWEEL = 'ـ';
/*     */   static final char FATHATAN = 'ً';
/*     */   static final char DAMMATAN = 'ٌ';
/*     */   static final char KASRATAN = 'ٍ';
/*     */   static final char FATHA = 'َ';
/*     */   static final char DAMMA = 'ُ';
/*     */   static final char KASRA = 'ِ';
/*     */   static final char SHADDA = 'ّ';
/*     */   static final char SUKUN = 'ْ';
/*     */ 
/*     */   public int normalize(char[] s, int len)
/*     */   {
/*  71 */     for (int i = 0; i < len; i++)
/*  72 */       switch (s[i]) {
/*     */       case 'ى':
/*     */       case 'ي':
/*  75 */         s[i] = 'ی';
/*  76 */         break;
/*     */       case 'ك':
/*  78 */         s[i] = 'ک';
/*  79 */         break;
/*     */       case '‌':
/*  81 */         if ((i > 0) && (s[(i - 1)] == 'ه')) {
/*  82 */           s[(i - 1)] = 'ە';
/*     */         }
/*  84 */         len = StemmerUtil.delete(s, i, len);
/*  85 */         i--;
/*  86 */         break;
/*     */       case 'ه':
/*  88 */         if (i == len - 1)
/*  89 */           s[i] = 'ە'; break;
/*     */       case 'ة':
/*  93 */         s[i] = 'ە';
/*  94 */         break;
/*     */       case 'ھ':
/*  96 */         s[i] = 'ه';
/*  97 */         break;
/*     */       case 'ر':
/*  99 */         if (i == 0)
/* 100 */           s[i] = 'ڕ'; break;
/*     */       case 'ڒ':
/* 104 */         s[i] = 'ڕ';
/* 105 */         break;
/*     */       case 'ـ':
/*     */       case 'ً':
/*     */       case 'ٌ':
/*     */       case 'ٍ':
/*     */       case 'َ':
/*     */       case 'ُ':
/*     */       case 'ِ':
/*     */       case 'ّ':
/*     */       case 'ْ':
/* 115 */         len = StemmerUtil.delete(s, i, len);
/* 116 */         i--;
/* 117 */         break;
/*     */       default:
/* 119 */         if (Character.getType(s[i]) == 16) {
/* 120 */           len = StemmerUtil.delete(s, i, len);
/* 121 */           i--;
/*     */         }
/*     */         break;
/*     */       }
/* 125 */     return len;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ckb.SoraniNormalizer
 * JD-Core Version:    0.6.2
 */