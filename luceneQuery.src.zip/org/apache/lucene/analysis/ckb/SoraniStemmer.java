/*     */ package org.apache.lucene.analysis.ckb;
/*     */ 
/*     */ import org.apache.lucene.analysis.util.StemmerUtil;
/*     */ 
/*     */ public class SoraniStemmer
/*     */ {
/*     */   public int stem(char[] s, int len)
/*     */   {
/*  36 */     if ((len > 5) && (StemmerUtil.endsWith(s, len, "دا")))
/*  37 */       len -= 2;
/*  38 */     else if ((len > 4) && (StemmerUtil.endsWith(s, len, "نا")))
/*  39 */       len--;
/*  40 */     else if ((len > 6) && (StemmerUtil.endsWith(s, len, "ەوە"))) {
/*  41 */       len -= 3;
/*     */     }
/*     */ 
/*  45 */     if ((len > 6) && ((StemmerUtil.endsWith(s, len, "مان")) || (StemmerUtil.endsWith(s, len, "یان")) || (StemmerUtil.endsWith(s, len, "تان")))) {
/*  46 */       len -= 3;
/*     */     }
/*     */ 
/*  50 */     if ((len > 6) && (StemmerUtil.endsWith(s, len, "ێکی")))
/*  51 */       return len - 3;
/*  52 */     if ((len > 7) && (StemmerUtil.endsWith(s, len, "یەکی"))) {
/*  53 */       return len - 4;
/*     */     }
/*     */ 
/*  56 */     if ((len > 5) && (StemmerUtil.endsWith(s, len, "ێک")))
/*  57 */       return len - 2;
/*  58 */     if ((len > 6) && (StemmerUtil.endsWith(s, len, "یەک"))) {
/*  59 */       return len - 3;
/*     */     }
/*     */ 
/*  62 */     if ((len > 6) && (StemmerUtil.endsWith(s, len, "ەکە")))
/*  63 */       return len - 3;
/*  64 */     if ((len > 5) && (StemmerUtil.endsWith(s, len, "کە"))) {
/*  65 */       return len - 2;
/*     */     }
/*     */ 
/*  68 */     if ((len > 7) && (StemmerUtil.endsWith(s, len, "ەکان")))
/*  69 */       return len - 4;
/*  70 */     if ((len > 6) && (StemmerUtil.endsWith(s, len, "کان"))) {
/*  71 */       return len - 3;
/*     */     }
/*     */ 
/*  74 */     if ((len > 7) && (StemmerUtil.endsWith(s, len, "یانی")))
/*  75 */       return len - 4;
/*  76 */     if ((len > 6) && (StemmerUtil.endsWith(s, len, "انی"))) {
/*  77 */       return len - 3;
/*     */     }
/*     */ 
/*  80 */     if ((len > 6) && (StemmerUtil.endsWith(s, len, "یان")))
/*  81 */       return len - 3;
/*  82 */     if ((len > 5) && (StemmerUtil.endsWith(s, len, "ان"))) {
/*  83 */       return len - 2;
/*     */     }
/*     */ 
/*  86 */     if ((len > 7) && (StemmerUtil.endsWith(s, len, "یانە")))
/*  87 */       return len - 4;
/*  88 */     if ((len > 6) && (StemmerUtil.endsWith(s, len, "انە"))) {
/*  89 */       return len - 3;
/*     */     }
/*     */ 
/*  92 */     if ((len > 5) && ((StemmerUtil.endsWith(s, len, "ایە")) || (StemmerUtil.endsWith(s, len, "ەیە"))))
/*  93 */       return len - 2;
/*  94 */     if ((len > 4) && (StemmerUtil.endsWith(s, len, "ە"))) {
/*  95 */       return len - 1;
/*     */     }
/*     */ 
/*  98 */     if ((len > 4) && (StemmerUtil.endsWith(s, len, "ی"))) {
/*  99 */       return len - 1;
/*     */     }
/* 101 */     return len;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ckb.SoraniStemmer
 * JD-Core Version:    0.6.2
 */