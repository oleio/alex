/*    */ package org.apache.lucene.analysis.ckb;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ 
/*    */ public final class SoraniNormalizationFilter extends TokenFilter
/*    */ {
/* 31 */   private final SoraniNormalizer normalizer = new SoraniNormalizer();
/* 32 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */ 
/*    */   public SoraniNormalizationFilter(TokenStream input) {
/* 35 */     super(input);
/*    */   }
/*    */ 
/*    */   public boolean incrementToken() throws IOException
/*    */   {
/* 40 */     if (this.input.incrementToken()) {
/* 41 */       int newlen = this.normalizer.normalize(this.termAtt.buffer(), this.termAtt.length());
/* 42 */       this.termAtt.setLength(newlen);
/* 43 */       return true;
/*    */     }
/* 45 */     return false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ckb.SoraniNormalizationFilter
 * JD-Core Version:    0.6.2
 */