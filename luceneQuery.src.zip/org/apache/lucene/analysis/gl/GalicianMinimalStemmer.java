/*    */ package org.apache.lucene.analysis.gl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.pt.RSLPStemmerBase;
/*    */ import org.apache.lucene.analysis.pt.RSLPStemmerBase.Step;
/*    */ 
/*    */ public class GalicianMinimalStemmer extends RSLPStemmerBase
/*    */ {
/* 32 */   private static final RSLPStemmerBase.Step pluralStep = (RSLPStemmerBase.Step)parse(GalicianMinimalStemmer.class, "galician.rslp").get("Plural");
/*    */ 
/*    */   public int stem(char[] s, int len)
/*    */   {
/* 36 */     return pluralStep.apply(s, len);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.gl.GalicianMinimalStemmer
 * JD-Core Version:    0.6.2
 */