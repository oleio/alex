/*    */ package org.apache.lucene.analysis.ga;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ 
/*    */ public final class IrishLowerCaseFilter extends TokenFilter
/*    */ {
/* 31 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */ 
/*    */   public IrishLowerCaseFilter(TokenStream in)
/*    */   {
/* 37 */     super(in);
/*    */   }
/*    */ 
/*    */   public boolean incrementToken() throws IOException
/*    */   {
/* 42 */     if (this.input.incrementToken()) {
/* 43 */       char[] chArray = this.termAtt.buffer();
/* 44 */       int chLen = this.termAtt.length();
/* 45 */       int idx = 0;
/*    */ 
/* 47 */       if ((chLen > 1) && ((chArray[0] == 'n') || (chArray[0] == 't')) && (isUpperVowel(chArray[1]))) {
/* 48 */         chArray = this.termAtt.resizeBuffer(chLen + 1);
/* 49 */         for (int i = chLen; i > 1; i--) {
/* 50 */           chArray[i] = chArray[(i - 1)];
/*    */         }
/* 52 */         chArray[1] = '-';
/* 53 */         this.termAtt.setLength(chLen + 1);
/* 54 */         idx = 2;
/* 55 */         chLen += 1;
/*    */       }
/*    */ 
/* 58 */       for (int i = idx; i < chLen; ) {
/* 59 */         i += Character.toChars(Character.toLowerCase(chArray[i]), chArray, i);
/*    */       }
/* 61 */       return true;
/*    */     }
/* 63 */     return false;
/*    */   }
/*    */ 
/*    */   private boolean isUpperVowel(int v)
/*    */   {
/* 68 */     switch (v)
/*    */     {
/*    */     case 65:
/*    */     case 69:
/*    */     case 73:
/*    */     case 79:
/*    */     case 85:
/*    */     case 193:
/*    */     case 201:
/*    */     case 205:
/*    */     case 211:
/*    */     case 218:
/* 80 */       return true;
/*    */     }
/* 82 */     return false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ga.IrishLowerCaseFilter
 * JD-Core Version:    0.6.2
 */