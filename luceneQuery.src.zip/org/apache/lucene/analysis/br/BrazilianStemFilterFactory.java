/*    */ package org.apache.lucene.analysis.br;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class BrazilianStemFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public BrazilianStemFilterFactory(Map<String, String> args)
/*    */   {
/* 41 */     super(args);
/* 42 */     if (!args.isEmpty())
/* 43 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public BrazilianStemFilter create(TokenStream in)
/*    */   {
/* 49 */     return new BrazilianStemFilter(in);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.br.BrazilianStemFilterFactory
 * JD-Core Version:    0.6.2
 */