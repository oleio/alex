/*      */ package org.apache.lucene.analysis.br;
/*      */ 
/*      */ import java.util.Locale;
/*      */ 
/*      */ public class BrazilianStemmer
/*      */ {
/*   26 */   private static final Locale locale = new Locale("pt", "BR");
/*      */   private String TERM;
/*      */   private String CT;
/*      */   private String R1;
/*      */   private String R2;
/*      */   private String RV;
/*      */ 
/*      */   protected String stem(String term)
/*      */   {
/*   48 */     boolean altered = false;
/*      */ 
/*   51 */     createCT(term);
/*      */ 
/*   53 */     if (!isIndexable(this.CT)) {
/*   54 */       return null;
/*      */     }
/*   56 */     if (!isStemmable(this.CT)) {
/*   57 */       return this.CT;
/*      */     }
/*      */ 
/*   60 */     this.R1 = getR1(this.CT);
/*   61 */     this.R2 = getR1(this.R1);
/*   62 */     this.RV = getRV(this.CT);
/*   63 */     this.TERM = (term + ";" + this.CT);
/*      */ 
/*   65 */     altered = step1();
/*   66 */     if (!altered) {
/*   67 */       altered = step2();
/*      */     }
/*      */ 
/*   70 */     if (altered)
/*   71 */       step3();
/*      */     else {
/*   73 */       step4();
/*      */     }
/*      */ 
/*   76 */     step5();
/*      */ 
/*   78 */     return this.CT;
/*      */   }
/*      */ 
/*      */   private boolean isStemmable(String term)
/*      */   {
/*   87 */     for (int c = 0; c < term.length(); c++)
/*      */     {
/*   89 */       if (!Character.isLetter(term.charAt(c))) {
/*   90 */         return false;
/*      */       }
/*      */     }
/*   93 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean isIndexable(String term)
/*      */   {
/*  102 */     return (term.length() < 30) && (term.length() > 2);
/*      */   }
/*      */ 
/*      */   private boolean isVowel(char value)
/*      */   {
/*  111 */     return (value == 'a') || (value == 'e') || (value == 'i') || (value == 'o') || (value == 'u');
/*      */   }
/*      */ 
/*      */   private String getR1(String value)
/*      */   {
/*  132 */     if (value == null) {
/*  133 */       return null;
/*      */     }
/*      */ 
/*  137 */     int i = value.length() - 1;
/*  138 */     for (int j = 0; (j < i) && 
/*  139 */       (!isVowel(value.charAt(j))); j++);
/*  144 */     if (j >= i) {
/*  145 */       return null;
/*      */     }
/*      */ 
/*  149 */     while ((j < i) && 
/*  150 */       (isVowel(value.charAt(j)))) {
/*  149 */       j++;
/*      */     }
/*      */ 
/*  155 */     if (j >= i) {
/*  156 */       return null;
/*      */     }
/*      */ 
/*  159 */     return value.substring(j + 1);
/*      */   }
/*      */ 
/*      */   private String getRV(String value)
/*      */   {
/*  184 */     if (value == null) {
/*  185 */       return null;
/*      */     }
/*      */ 
/*  188 */     int i = value.length() - 1;
/*      */ 
/*  192 */     if ((i > 0) && (!isVowel(value.charAt(1))))
/*      */     {
/*  194 */       for (int j = 2; (j < i) && 
/*  195 */         (!isVowel(value.charAt(j))); j++);
/*  200 */       if (j < i) {
/*  201 */         return value.substring(j + 1);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  208 */     if ((i > 1) && (isVowel(value.charAt(0))) && (isVowel(value.charAt(1))))
/*      */     {
/*  212 */       for (int j = 2; (j < i) && 
/*  213 */         (isVowel(value.charAt(j))); j++);
/*  218 */       if (j < i) {
/*  219 */         return value.substring(j + 1);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  225 */     if (i > 2) {
/*  226 */       return value.substring(3);
/*      */     }
/*      */ 
/*  229 */     return null;
/*      */   }
/*      */ 
/*      */   private String changeTerm(String value)
/*      */   {
/*  242 */     String r = "";
/*      */ 
/*  245 */     if (value == null) {
/*  246 */       return null;
/*      */     }
/*      */ 
/*  249 */     value = value.toLowerCase(locale);
/*  250 */     for (int j = 0; j < value.length(); j++) {
/*  251 */       if ((value.charAt(j) == 'á') || (value.charAt(j) == 'â') || (value.charAt(j) == 'ã'))
/*      */       {
/*  254 */         r = r + "a";
/*      */       }
/*  256 */       else if ((value.charAt(j) == 'é') || (value.charAt(j) == 'ê'))
/*      */       {
/*  258 */         r = r + "e";
/*      */       }
/*  260 */       else if (value.charAt(j) == 'í') {
/*  261 */         r = r + "i";
/*      */       }
/*  263 */       else if ((value.charAt(j) == 'ó') || (value.charAt(j) == 'ô') || (value.charAt(j) == 'õ'))
/*      */       {
/*  266 */         r = r + "o";
/*      */       }
/*  268 */       else if ((value.charAt(j) == 'ú') || (value.charAt(j) == 'ü'))
/*      */       {
/*  270 */         r = r + "u";
/*      */       }
/*  272 */       else if (value.charAt(j) == 'ç') {
/*  273 */         r = r + "c";
/*      */       }
/*  275 */       else if (value.charAt(j) == 'ñ') {
/*  276 */         r = r + "n";
/*      */       }
/*      */       else {
/*  279 */         r = r + value.charAt(j);
/*      */       }
/*      */     }
/*  282 */     return r;
/*      */   }
/*      */ 
/*      */   private boolean suffix(String value, String suffix)
/*      */   {
/*  293 */     if ((value == null) || (suffix == null)) {
/*  294 */       return false;
/*      */     }
/*      */ 
/*  297 */     if (suffix.length() > value.length()) {
/*  298 */       return false;
/*      */     }
/*      */ 
/*  301 */     return value.substring(value.length() - suffix.length()).equals(suffix);
/*      */   }
/*      */ 
/*      */   private String replaceSuffix(String value, String toReplace, String changeTo)
/*      */   {
/*  313 */     if ((value == null) || (toReplace == null) || (changeTo == null))
/*      */     {
/*  316 */       return value;
/*      */     }
/*      */ 
/*  319 */     String vvalue = removeSuffix(value, toReplace);
/*      */ 
/*  321 */     if (value.equals(vvalue)) {
/*  322 */       return value;
/*      */     }
/*  324 */     return vvalue + changeTo;
/*      */   }
/*      */ 
/*      */   private String removeSuffix(String value, String toRemove)
/*      */   {
/*  335 */     if ((value == null) || (toRemove == null) || (!suffix(value, toRemove)))
/*      */     {
/*  338 */       return value;
/*      */     }
/*      */ 
/*  341 */     return value.substring(0, value.length() - toRemove.length());
/*      */   }
/*      */ 
/*      */   private boolean suffixPreceded(String value, String suffix, String preceded)
/*      */   {
/*  351 */     if ((value == null) || (suffix == null) || (preceded == null) || (!suffix(value, suffix)))
/*      */     {
/*  355 */       return false;
/*      */     }
/*      */ 
/*  358 */     return suffix(removeSuffix(value, suffix), preceded);
/*      */   }
/*      */ 
/*      */   private void createCT(String term)
/*      */   {
/*  365 */     this.CT = changeTerm(term);
/*      */ 
/*  367 */     if (this.CT.length() < 2) return;
/*      */ 
/*  370 */     if ((this.CT.charAt(0) == '"') || (this.CT.charAt(0) == '\'') || (this.CT.charAt(0) == '-') || (this.CT.charAt(0) == ',') || (this.CT.charAt(0) == ';') || (this.CT.charAt(0) == '.') || (this.CT.charAt(0) == '?') || (this.CT.charAt(0) == '!'))
/*      */     {
/*  379 */       this.CT = this.CT.substring(1);
/*      */     }
/*      */ 
/*  382 */     if (this.CT.length() < 2) return;
/*      */ 
/*  385 */     if ((this.CT.charAt(this.CT.length() - 1) == '-') || (this.CT.charAt(this.CT.length() - 1) == ',') || (this.CT.charAt(this.CT.length() - 1) == ';') || (this.CT.charAt(this.CT.length() - 1) == '.') || (this.CT.charAt(this.CT.length() - 1) == '?') || (this.CT.charAt(this.CT.length() - 1) == '!') || (this.CT.charAt(this.CT.length() - 1) == '\'') || (this.CT.charAt(this.CT.length() - 1) == '"'))
/*      */     {
/*  394 */       this.CT = this.CT.substring(0, this.CT.length() - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean step1()
/*      */   {
/*  407 */     if (this.CT == null) return false;
/*      */ 
/*  410 */     if ((suffix(this.CT, "uciones")) && (suffix(this.R2, "uciones"))) {
/*  411 */       this.CT = replaceSuffix(this.CT, "uciones", "u"); return true;
/*      */     }
/*      */ 
/*  415 */     if (this.CT.length() >= 6) {
/*  416 */       if ((suffix(this.CT, "imentos")) && (suffix(this.R2, "imentos"))) {
/*  417 */         this.CT = removeSuffix(this.CT, "imentos"); return true;
/*      */       }
/*  419 */       if ((suffix(this.CT, "amentos")) && (suffix(this.R2, "amentos"))) {
/*  420 */         this.CT = removeSuffix(this.CT, "amentos"); return true;
/*      */       }
/*  422 */       if ((suffix(this.CT, "adores")) && (suffix(this.R2, "adores"))) {
/*  423 */         this.CT = removeSuffix(this.CT, "adores"); return true;
/*      */       }
/*  425 */       if ((suffix(this.CT, "adoras")) && (suffix(this.R2, "adoras"))) {
/*  426 */         this.CT = removeSuffix(this.CT, "adoras"); return true;
/*      */       }
/*  428 */       if ((suffix(this.CT, "logias")) && (suffix(this.R2, "logias"))) {
/*  429 */         replaceSuffix(this.CT, "logias", "log"); return true;
/*      */       }
/*  431 */       if ((suffix(this.CT, "encias")) && (suffix(this.R2, "encias"))) {
/*  432 */         this.CT = replaceSuffix(this.CT, "encias", "ente"); return true;
/*      */       }
/*  434 */       if ((suffix(this.CT, "amente")) && (suffix(this.R1, "amente"))) {
/*  435 */         this.CT = removeSuffix(this.CT, "amente"); return true;
/*      */       }
/*  437 */       if ((suffix(this.CT, "idades")) && (suffix(this.R2, "idades"))) {
/*  438 */         this.CT = removeSuffix(this.CT, "idades"); return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  443 */     if (this.CT.length() >= 5) {
/*  444 */       if ((suffix(this.CT, "acoes")) && (suffix(this.R2, "acoes"))) {
/*  445 */         this.CT = removeSuffix(this.CT, "acoes"); return true;
/*      */       }
/*  447 */       if ((suffix(this.CT, "imento")) && (suffix(this.R2, "imento"))) {
/*  448 */         this.CT = removeSuffix(this.CT, "imento"); return true;
/*      */       }
/*  450 */       if ((suffix(this.CT, "amento")) && (suffix(this.R2, "amento"))) {
/*  451 */         this.CT = removeSuffix(this.CT, "amento"); return true;
/*      */       }
/*  453 */       if ((suffix(this.CT, "adora")) && (suffix(this.R2, "adora"))) {
/*  454 */         this.CT = removeSuffix(this.CT, "adora"); return true;
/*      */       }
/*  456 */       if ((suffix(this.CT, "ismos")) && (suffix(this.R2, "ismos"))) {
/*  457 */         this.CT = removeSuffix(this.CT, "ismos"); return true;
/*      */       }
/*  459 */       if ((suffix(this.CT, "istas")) && (suffix(this.R2, "istas"))) {
/*  460 */         this.CT = removeSuffix(this.CT, "istas"); return true;
/*      */       }
/*  462 */       if ((suffix(this.CT, "logia")) && (suffix(this.R2, "logia"))) {
/*  463 */         this.CT = replaceSuffix(this.CT, "logia", "log"); return true;
/*      */       }
/*  465 */       if ((suffix(this.CT, "ucion")) && (suffix(this.R2, "ucion"))) {
/*  466 */         this.CT = replaceSuffix(this.CT, "ucion", "u"); return true;
/*      */       }
/*  468 */       if ((suffix(this.CT, "encia")) && (suffix(this.R2, "encia"))) {
/*  469 */         this.CT = replaceSuffix(this.CT, "encia", "ente"); return true;
/*      */       }
/*  471 */       if ((suffix(this.CT, "mente")) && (suffix(this.R2, "mente"))) {
/*  472 */         this.CT = removeSuffix(this.CT, "mente"); return true;
/*      */       }
/*  474 */       if ((suffix(this.CT, "idade")) && (suffix(this.R2, "idade"))) {
/*  475 */         this.CT = removeSuffix(this.CT, "idade"); return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  480 */     if (this.CT.length() >= 4) {
/*  481 */       if ((suffix(this.CT, "acao")) && (suffix(this.R2, "acao"))) {
/*  482 */         this.CT = removeSuffix(this.CT, "acao"); return true;
/*      */       }
/*  484 */       if ((suffix(this.CT, "ezas")) && (suffix(this.R2, "ezas"))) {
/*  485 */         this.CT = removeSuffix(this.CT, "ezas"); return true;
/*      */       }
/*  487 */       if ((suffix(this.CT, "icos")) && (suffix(this.R2, "icos"))) {
/*  488 */         this.CT = removeSuffix(this.CT, "icos"); return true;
/*      */       }
/*  490 */       if ((suffix(this.CT, "icas")) && (suffix(this.R2, "icas"))) {
/*  491 */         this.CT = removeSuffix(this.CT, "icas"); return true;
/*      */       }
/*  493 */       if ((suffix(this.CT, "ismo")) && (suffix(this.R2, "ismo"))) {
/*  494 */         this.CT = removeSuffix(this.CT, "ismo"); return true;
/*      */       }
/*  496 */       if ((suffix(this.CT, "avel")) && (suffix(this.R2, "avel"))) {
/*  497 */         this.CT = removeSuffix(this.CT, "avel"); return true;
/*      */       }
/*  499 */       if ((suffix(this.CT, "ivel")) && (suffix(this.R2, "ivel"))) {
/*  500 */         this.CT = removeSuffix(this.CT, "ivel"); return true;
/*      */       }
/*  502 */       if ((suffix(this.CT, "ista")) && (suffix(this.R2, "ista"))) {
/*  503 */         this.CT = removeSuffix(this.CT, "ista"); return true;
/*      */       }
/*  505 */       if ((suffix(this.CT, "osos")) && (suffix(this.R2, "osos"))) {
/*  506 */         this.CT = removeSuffix(this.CT, "osos"); return true;
/*      */       }
/*  508 */       if ((suffix(this.CT, "osas")) && (suffix(this.R2, "osas"))) {
/*  509 */         this.CT = removeSuffix(this.CT, "osas"); return true;
/*      */       }
/*  511 */       if ((suffix(this.CT, "ador")) && (suffix(this.R2, "ador"))) {
/*  512 */         this.CT = removeSuffix(this.CT, "ador"); return true;
/*      */       }
/*  514 */       if ((suffix(this.CT, "ivas")) && (suffix(this.R2, "ivas"))) {
/*  515 */         this.CT = removeSuffix(this.CT, "ivas"); return true;
/*      */       }
/*  517 */       if ((suffix(this.CT, "ivos")) && (suffix(this.R2, "ivos"))) {
/*  518 */         this.CT = removeSuffix(this.CT, "ivos"); return true;
/*      */       }
/*  520 */       if ((suffix(this.CT, "iras")) && (suffix(this.RV, "iras")) && (suffixPreceded(this.CT, "iras", "e")))
/*      */       {
/*  523 */         this.CT = replaceSuffix(this.CT, "iras", "ir"); return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  528 */     if (this.CT.length() >= 3) {
/*  529 */       if ((suffix(this.CT, "eza")) && (suffix(this.R2, "eza"))) {
/*  530 */         this.CT = removeSuffix(this.CT, "eza"); return true;
/*      */       }
/*  532 */       if ((suffix(this.CT, "ico")) && (suffix(this.R2, "ico"))) {
/*  533 */         this.CT = removeSuffix(this.CT, "ico"); return true;
/*      */       }
/*  535 */       if ((suffix(this.CT, "ica")) && (suffix(this.R2, "ica"))) {
/*  536 */         this.CT = removeSuffix(this.CT, "ica"); return true;
/*      */       }
/*  538 */       if ((suffix(this.CT, "oso")) && (suffix(this.R2, "oso"))) {
/*  539 */         this.CT = removeSuffix(this.CT, "oso"); return true;
/*      */       }
/*  541 */       if ((suffix(this.CT, "osa")) && (suffix(this.R2, "osa"))) {
/*  542 */         this.CT = removeSuffix(this.CT, "osa"); return true;
/*      */       }
/*  544 */       if ((suffix(this.CT, "iva")) && (suffix(this.R2, "iva"))) {
/*  545 */         this.CT = removeSuffix(this.CT, "iva"); return true;
/*      */       }
/*  547 */       if ((suffix(this.CT, "ivo")) && (suffix(this.R2, "ivo"))) {
/*  548 */         this.CT = removeSuffix(this.CT, "ivo"); return true;
/*      */       }
/*  550 */       if ((suffix(this.CT, "ira")) && (suffix(this.RV, "ira")) && (suffixPreceded(this.CT, "ira", "e")))
/*      */       {
/*  553 */         this.CT = replaceSuffix(this.CT, "ira", "ir"); return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  558 */     return false;
/*      */   }
/*      */ 
/*      */   private boolean step2()
/*      */   {
/*  571 */     if (this.RV == null) return false;
/*      */ 
/*  574 */     if (this.RV.length() >= 7) {
/*  575 */       if (suffix(this.RV, "issemos")) {
/*  576 */         this.CT = removeSuffix(this.CT, "issemos"); return true;
/*      */       }
/*  578 */       if (suffix(this.RV, "essemos")) {
/*  579 */         this.CT = removeSuffix(this.CT, "essemos"); return true;
/*      */       }
/*  581 */       if (suffix(this.RV, "assemos")) {
/*  582 */         this.CT = removeSuffix(this.CT, "assemos"); return true;
/*      */       }
/*  584 */       if (suffix(this.RV, "ariamos")) {
/*  585 */         this.CT = removeSuffix(this.CT, "ariamos"); return true;
/*      */       }
/*  587 */       if (suffix(this.RV, "eriamos")) {
/*  588 */         this.CT = removeSuffix(this.CT, "eriamos"); return true;
/*      */       }
/*  590 */       if (suffix(this.RV, "iriamos")) {
/*  591 */         this.CT = removeSuffix(this.CT, "iriamos"); return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  596 */     if (this.RV.length() >= 6) {
/*  597 */       if (suffix(this.RV, "iremos")) {
/*  598 */         this.CT = removeSuffix(this.CT, "iremos"); return true;
/*      */       }
/*  600 */       if (suffix(this.RV, "eremos")) {
/*  601 */         this.CT = removeSuffix(this.CT, "eremos"); return true;
/*      */       }
/*  603 */       if (suffix(this.RV, "aremos")) {
/*  604 */         this.CT = removeSuffix(this.CT, "aremos"); return true;
/*      */       }
/*  606 */       if (suffix(this.RV, "avamos")) {
/*  607 */         this.CT = removeSuffix(this.CT, "avamos"); return true;
/*      */       }
/*  609 */       if (suffix(this.RV, "iramos")) {
/*  610 */         this.CT = removeSuffix(this.CT, "iramos"); return true;
/*      */       }
/*  612 */       if (suffix(this.RV, "eramos")) {
/*  613 */         this.CT = removeSuffix(this.CT, "eramos"); return true;
/*      */       }
/*  615 */       if (suffix(this.RV, "aramos")) {
/*  616 */         this.CT = removeSuffix(this.CT, "aramos"); return true;
/*      */       }
/*  618 */       if (suffix(this.RV, "asseis")) {
/*  619 */         this.CT = removeSuffix(this.CT, "asseis"); return true;
/*      */       }
/*  621 */       if (suffix(this.RV, "esseis")) {
/*  622 */         this.CT = removeSuffix(this.CT, "esseis"); return true;
/*      */       }
/*  624 */       if (suffix(this.RV, "isseis")) {
/*  625 */         this.CT = removeSuffix(this.CT, "isseis"); return true;
/*      */       }
/*  627 */       if (suffix(this.RV, "arieis")) {
/*  628 */         this.CT = removeSuffix(this.CT, "arieis"); return true;
/*      */       }
/*  630 */       if (suffix(this.RV, "erieis")) {
/*  631 */         this.CT = removeSuffix(this.CT, "erieis"); return true;
/*      */       }
/*  633 */       if (suffix(this.RV, "irieis")) {
/*  634 */         this.CT = removeSuffix(this.CT, "irieis"); return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  640 */     if (this.RV.length() >= 5) {
/*  641 */       if (suffix(this.RV, "irmos")) {
/*  642 */         this.CT = removeSuffix(this.CT, "irmos"); return true;
/*      */       }
/*  644 */       if (suffix(this.RV, "iamos")) {
/*  645 */         this.CT = removeSuffix(this.CT, "iamos"); return true;
/*      */       }
/*  647 */       if (suffix(this.RV, "armos")) {
/*  648 */         this.CT = removeSuffix(this.CT, "armos"); return true;
/*      */       }
/*  650 */       if (suffix(this.RV, "ermos")) {
/*  651 */         this.CT = removeSuffix(this.CT, "ermos"); return true;
/*      */       }
/*  653 */       if (suffix(this.RV, "areis")) {
/*  654 */         this.CT = removeSuffix(this.CT, "areis"); return true;
/*      */       }
/*  656 */       if (suffix(this.RV, "ereis")) {
/*  657 */         this.CT = removeSuffix(this.CT, "ereis"); return true;
/*      */       }
/*  659 */       if (suffix(this.RV, "ireis")) {
/*  660 */         this.CT = removeSuffix(this.CT, "ireis"); return true;
/*      */       }
/*  662 */       if (suffix(this.RV, "asses")) {
/*  663 */         this.CT = removeSuffix(this.CT, "asses"); return true;
/*      */       }
/*  665 */       if (suffix(this.RV, "esses")) {
/*  666 */         this.CT = removeSuffix(this.CT, "esses"); return true;
/*      */       }
/*  668 */       if (suffix(this.RV, "isses")) {
/*  669 */         this.CT = removeSuffix(this.CT, "isses"); return true;
/*      */       }
/*  671 */       if (suffix(this.RV, "astes")) {
/*  672 */         this.CT = removeSuffix(this.CT, "astes"); return true;
/*      */       }
/*  674 */       if (suffix(this.RV, "assem")) {
/*  675 */         this.CT = removeSuffix(this.CT, "assem"); return true;
/*      */       }
/*  677 */       if (suffix(this.RV, "essem")) {
/*  678 */         this.CT = removeSuffix(this.CT, "essem"); return true;
/*      */       }
/*  680 */       if (suffix(this.RV, "issem")) {
/*  681 */         this.CT = removeSuffix(this.CT, "issem"); return true;
/*      */       }
/*  683 */       if (suffix(this.RV, "ardes")) {
/*  684 */         this.CT = removeSuffix(this.CT, "ardes"); return true;
/*      */       }
/*  686 */       if (suffix(this.RV, "erdes")) {
/*  687 */         this.CT = removeSuffix(this.CT, "erdes"); return true;
/*      */       }
/*  689 */       if (suffix(this.RV, "irdes")) {
/*  690 */         this.CT = removeSuffix(this.CT, "irdes"); return true;
/*      */       }
/*  692 */       if (suffix(this.RV, "ariam")) {
/*  693 */         this.CT = removeSuffix(this.CT, "ariam"); return true;
/*      */       }
/*  695 */       if (suffix(this.RV, "eriam")) {
/*  696 */         this.CT = removeSuffix(this.CT, "eriam"); return true;
/*      */       }
/*  698 */       if (suffix(this.RV, "iriam")) {
/*  699 */         this.CT = removeSuffix(this.CT, "iriam"); return true;
/*      */       }
/*  701 */       if (suffix(this.RV, "arias")) {
/*  702 */         this.CT = removeSuffix(this.CT, "arias"); return true;
/*      */       }
/*  704 */       if (suffix(this.RV, "erias")) {
/*  705 */         this.CT = removeSuffix(this.CT, "erias"); return true;
/*      */       }
/*  707 */       if (suffix(this.RV, "irias")) {
/*  708 */         this.CT = removeSuffix(this.CT, "irias"); return true;
/*      */       }
/*  710 */       if (suffix(this.RV, "estes")) {
/*  711 */         this.CT = removeSuffix(this.CT, "estes"); return true;
/*      */       }
/*  713 */       if (suffix(this.RV, "istes")) {
/*  714 */         this.CT = removeSuffix(this.CT, "istes"); return true;
/*      */       }
/*  716 */       if (suffix(this.RV, "areis")) {
/*  717 */         this.CT = removeSuffix(this.CT, "areis"); return true;
/*      */       }
/*  719 */       if (suffix(this.RV, "aveis")) {
/*  720 */         this.CT = removeSuffix(this.CT, "aveis"); return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  725 */     if (this.RV.length() >= 4) {
/*  726 */       if (suffix(this.RV, "aria")) {
/*  727 */         this.CT = removeSuffix(this.CT, "aria"); return true;
/*      */       }
/*  729 */       if (suffix(this.RV, "eria")) {
/*  730 */         this.CT = removeSuffix(this.CT, "eria"); return true;
/*      */       }
/*  732 */       if (suffix(this.RV, "iria")) {
/*  733 */         this.CT = removeSuffix(this.CT, "iria"); return true;
/*      */       }
/*  735 */       if (suffix(this.RV, "asse")) {
/*  736 */         this.CT = removeSuffix(this.CT, "asse"); return true;
/*      */       }
/*  738 */       if (suffix(this.RV, "esse")) {
/*  739 */         this.CT = removeSuffix(this.CT, "esse"); return true;
/*      */       }
/*  741 */       if (suffix(this.RV, "isse")) {
/*  742 */         this.CT = removeSuffix(this.CT, "isse"); return true;
/*      */       }
/*  744 */       if (suffix(this.RV, "aste")) {
/*  745 */         this.CT = removeSuffix(this.CT, "aste"); return true;
/*      */       }
/*  747 */       if (suffix(this.RV, "este")) {
/*  748 */         this.CT = removeSuffix(this.CT, "este"); return true;
/*      */       }
/*  750 */       if (suffix(this.RV, "iste")) {
/*  751 */         this.CT = removeSuffix(this.CT, "iste"); return true;
/*      */       }
/*  753 */       if (suffix(this.RV, "arei")) {
/*  754 */         this.CT = removeSuffix(this.CT, "arei"); return true;
/*      */       }
/*  756 */       if (suffix(this.RV, "erei")) {
/*  757 */         this.CT = removeSuffix(this.CT, "erei"); return true;
/*      */       }
/*  759 */       if (suffix(this.RV, "irei")) {
/*  760 */         this.CT = removeSuffix(this.CT, "irei"); return true;
/*      */       }
/*  762 */       if (suffix(this.RV, "aram")) {
/*  763 */         this.CT = removeSuffix(this.CT, "aram"); return true;
/*      */       }
/*  765 */       if (suffix(this.RV, "eram")) {
/*  766 */         this.CT = removeSuffix(this.CT, "eram"); return true;
/*      */       }
/*  768 */       if (suffix(this.RV, "iram")) {
/*  769 */         this.CT = removeSuffix(this.CT, "iram"); return true;
/*      */       }
/*  771 */       if (suffix(this.RV, "avam")) {
/*  772 */         this.CT = removeSuffix(this.CT, "avam"); return true;
/*      */       }
/*  774 */       if (suffix(this.RV, "arem")) {
/*  775 */         this.CT = removeSuffix(this.CT, "arem"); return true;
/*      */       }
/*  777 */       if (suffix(this.RV, "erem")) {
/*  778 */         this.CT = removeSuffix(this.CT, "erem"); return true;
/*      */       }
/*  780 */       if (suffix(this.RV, "irem")) {
/*  781 */         this.CT = removeSuffix(this.CT, "irem"); return true;
/*      */       }
/*  783 */       if (suffix(this.RV, "ando")) {
/*  784 */         this.CT = removeSuffix(this.CT, "ando"); return true;
/*      */       }
/*  786 */       if (suffix(this.RV, "endo")) {
/*  787 */         this.CT = removeSuffix(this.CT, "endo"); return true;
/*      */       }
/*  789 */       if (suffix(this.RV, "indo")) {
/*  790 */         this.CT = removeSuffix(this.CT, "indo"); return true;
/*      */       }
/*  792 */       if (suffix(this.RV, "arao")) {
/*  793 */         this.CT = removeSuffix(this.CT, "arao"); return true;
/*      */       }
/*  795 */       if (suffix(this.RV, "erao")) {
/*  796 */         this.CT = removeSuffix(this.CT, "erao"); return true;
/*      */       }
/*  798 */       if (suffix(this.RV, "irao")) {
/*  799 */         this.CT = removeSuffix(this.CT, "irao"); return true;
/*      */       }
/*  801 */       if (suffix(this.RV, "adas")) {
/*  802 */         this.CT = removeSuffix(this.CT, "adas"); return true;
/*      */       }
/*  804 */       if (suffix(this.RV, "idas")) {
/*  805 */         this.CT = removeSuffix(this.CT, "idas"); return true;
/*      */       }
/*  807 */       if (suffix(this.RV, "aras")) {
/*  808 */         this.CT = removeSuffix(this.CT, "aras"); return true;
/*      */       }
/*  810 */       if (suffix(this.RV, "eras")) {
/*  811 */         this.CT = removeSuffix(this.CT, "eras"); return true;
/*      */       }
/*  813 */       if (suffix(this.RV, "iras")) {
/*  814 */         this.CT = removeSuffix(this.CT, "iras"); return true;
/*      */       }
/*  816 */       if (suffix(this.RV, "avas")) {
/*  817 */         this.CT = removeSuffix(this.CT, "avas"); return true;
/*      */       }
/*  819 */       if (suffix(this.RV, "ares")) {
/*  820 */         this.CT = removeSuffix(this.CT, "ares"); return true;
/*      */       }
/*  822 */       if (suffix(this.RV, "eres")) {
/*  823 */         this.CT = removeSuffix(this.CT, "eres"); return true;
/*      */       }
/*  825 */       if (suffix(this.RV, "ires")) {
/*  826 */         this.CT = removeSuffix(this.CT, "ires"); return true;
/*      */       }
/*  828 */       if (suffix(this.RV, "ados")) {
/*  829 */         this.CT = removeSuffix(this.CT, "ados"); return true;
/*      */       }
/*  831 */       if (suffix(this.RV, "idos")) {
/*  832 */         this.CT = removeSuffix(this.CT, "idos"); return true;
/*      */       }
/*  834 */       if (suffix(this.RV, "amos")) {
/*  835 */         this.CT = removeSuffix(this.CT, "amos"); return true;
/*      */       }
/*  837 */       if (suffix(this.RV, "emos")) {
/*  838 */         this.CT = removeSuffix(this.CT, "emos"); return true;
/*      */       }
/*  840 */       if (suffix(this.RV, "imos")) {
/*  841 */         this.CT = removeSuffix(this.CT, "imos"); return true;
/*      */       }
/*  843 */       if (suffix(this.RV, "iras")) {
/*  844 */         this.CT = removeSuffix(this.CT, "iras"); return true;
/*      */       }
/*  846 */       if (suffix(this.RV, "ieis")) {
/*  847 */         this.CT = removeSuffix(this.CT, "ieis"); return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  852 */     if (this.RV.length() >= 3) {
/*  853 */       if (suffix(this.RV, "ada")) {
/*  854 */         this.CT = removeSuffix(this.CT, "ada"); return true;
/*      */       }
/*  856 */       if (suffix(this.RV, "ida")) {
/*  857 */         this.CT = removeSuffix(this.CT, "ida"); return true;
/*      */       }
/*  859 */       if (suffix(this.RV, "ara")) {
/*  860 */         this.CT = removeSuffix(this.CT, "ara"); return true;
/*      */       }
/*  862 */       if (suffix(this.RV, "era")) {
/*  863 */         this.CT = removeSuffix(this.CT, "era"); return true;
/*      */       }
/*  865 */       if (suffix(this.RV, "ira")) {
/*  866 */         this.CT = removeSuffix(this.CT, "ava"); return true;
/*      */       }
/*  868 */       if (suffix(this.RV, "iam")) {
/*  869 */         this.CT = removeSuffix(this.CT, "iam"); return true;
/*      */       }
/*  871 */       if (suffix(this.RV, "ado")) {
/*  872 */         this.CT = removeSuffix(this.CT, "ado"); return true;
/*      */       }
/*  874 */       if (suffix(this.RV, "ido")) {
/*  875 */         this.CT = removeSuffix(this.CT, "ido"); return true;
/*      */       }
/*  877 */       if (suffix(this.RV, "ias")) {
/*  878 */         this.CT = removeSuffix(this.CT, "ias"); return true;
/*      */       }
/*  880 */       if (suffix(this.RV, "ais")) {
/*  881 */         this.CT = removeSuffix(this.CT, "ais"); return true;
/*      */       }
/*  883 */       if (suffix(this.RV, "eis")) {
/*  884 */         this.CT = removeSuffix(this.CT, "eis"); return true;
/*      */       }
/*  886 */       if (suffix(this.RV, "ira")) {
/*  887 */         this.CT = removeSuffix(this.CT, "ira"); return true;
/*      */       }
/*  889 */       if (suffix(this.RV, "ear")) {
/*  890 */         this.CT = removeSuffix(this.CT, "ear"); return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  895 */     if (this.RV.length() >= 2) {
/*  896 */       if (suffix(this.RV, "ia")) {
/*  897 */         this.CT = removeSuffix(this.CT, "ia"); return true;
/*      */       }
/*  899 */       if (suffix(this.RV, "ei")) {
/*  900 */         this.CT = removeSuffix(this.CT, "ei"); return true;
/*      */       }
/*  902 */       if (suffix(this.RV, "am")) {
/*  903 */         this.CT = removeSuffix(this.CT, "am"); return true;
/*      */       }
/*  905 */       if (suffix(this.RV, "em")) {
/*  906 */         this.CT = removeSuffix(this.CT, "em"); return true;
/*      */       }
/*  908 */       if (suffix(this.RV, "ar")) {
/*  909 */         this.CT = removeSuffix(this.CT, "ar"); return true;
/*      */       }
/*  911 */       if (suffix(this.RV, "er")) {
/*  912 */         this.CT = removeSuffix(this.CT, "er"); return true;
/*      */       }
/*  914 */       if (suffix(this.RV, "ir")) {
/*  915 */         this.CT = removeSuffix(this.CT, "ir"); return true;
/*      */       }
/*  917 */       if (suffix(this.RV, "as")) {
/*  918 */         this.CT = removeSuffix(this.CT, "as"); return true;
/*      */       }
/*  920 */       if (suffix(this.RV, "es")) {
/*  921 */         this.CT = removeSuffix(this.CT, "es"); return true;
/*      */       }
/*  923 */       if (suffix(this.RV, "is")) {
/*  924 */         this.CT = removeSuffix(this.CT, "is"); return true;
/*      */       }
/*  926 */       if (suffix(this.RV, "eu")) {
/*  927 */         this.CT = removeSuffix(this.CT, "eu"); return true;
/*      */       }
/*  929 */       if (suffix(this.RV, "iu")) {
/*  930 */         this.CT = removeSuffix(this.CT, "iu"); return true;
/*      */       }
/*  932 */       if (suffix(this.RV, "iu")) {
/*  933 */         this.CT = removeSuffix(this.CT, "iu"); return true;
/*      */       }
/*  935 */       if (suffix(this.RV, "ou")) {
/*  936 */         this.CT = removeSuffix(this.CT, "ou"); return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  941 */     return false;
/*      */   }
/*      */ 
/*      */   private void step3()
/*      */   {
/*  949 */     if (this.RV == null) return;
/*      */ 
/*  951 */     if ((suffix(this.RV, "i")) && (suffixPreceded(this.RV, "i", "c")))
/*  952 */       this.CT = removeSuffix(this.CT, "i");
/*      */   }
/*      */ 
/*      */   private void step4()
/*      */   {
/*  965 */     if (this.RV == null) return;
/*      */ 
/*  967 */     if (suffix(this.RV, "os")) {
/*  968 */       this.CT = removeSuffix(this.CT, "os"); return;
/*      */     }
/*  970 */     if (suffix(this.RV, "a")) {
/*  971 */       this.CT = removeSuffix(this.CT, "a"); return;
/*      */     }
/*  973 */     if (suffix(this.RV, "i")) {
/*  974 */       this.CT = removeSuffix(this.CT, "i"); return;
/*      */     }
/*  976 */     if (suffix(this.RV, "o")) {
/*  977 */       this.CT = removeSuffix(this.CT, "o"); return;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void step5()
/*      */   {
/*  991 */     if (this.RV == null) return;
/*      */ 
/*  993 */     if (suffix(this.RV, "e")) {
/*  994 */       if (suffixPreceded(this.RV, "e", "gu")) {
/*  995 */         this.CT = removeSuffix(this.CT, "e");
/*  996 */         this.CT = removeSuffix(this.CT, "u");
/*  997 */         return;
/*      */       }
/*      */ 
/* 1000 */       if (suffixPreceded(this.RV, "e", "ci")) {
/* 1001 */         this.CT = removeSuffix(this.CT, "e");
/* 1002 */         this.CT = removeSuffix(this.CT, "i");
/* 1003 */         return;
/*      */       }
/*      */ 
/* 1006 */       this.CT = removeSuffix(this.CT, "e"); return;
/*      */     }
/*      */   }
/*      */ 
/*      */   public String log()
/*      */   {
/* 1016 */     return " (TERM = " + this.TERM + ")" + " (CT = " + this.CT + ")" + " (RV = " + this.RV + ")" + " (R1 = " + this.R1 + ")" + " (R2 = " + this.R2 + ")";
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.br.BrazilianStemmer
 * JD-Core Version:    0.6.2
 */