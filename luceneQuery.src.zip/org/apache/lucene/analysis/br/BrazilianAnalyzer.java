/*     */ package org.apache.lucene.analysis.br;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.analysis.util.WordlistLoader;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class BrazilianAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*  81 */   private CharArraySet excltable = CharArraySet.EMPTY_SET;
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  59 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public BrazilianAnalyzer(Version matchVersion)
/*     */   {
/*  87 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   public BrazilianAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/*  99 */     super(matchVersion, stopwords);
/*     */   }
/*     */ 
/*     */   public BrazilianAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/* 112 */     this(matchVersion, stopwords);
/* 113 */     this.excltable = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 130 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 131 */     TokenStream result = new LowerCaseFilter(this.matchVersion, source);
/* 132 */     result = new StandardFilter(this.matchVersion, result);
/* 133 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 134 */     if ((this.excltable != null) && (!this.excltable.isEmpty()))
/* 135 */       result = new SetKeywordMarkerFilter(result, this.excltable);
/* 136 */     return new Analyzer.TokenStreamComponents(source, new BrazilianStemFilter(result));
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  67 */         DEFAULT_STOP_SET = WordlistLoader.getWordSet(IOUtils.getDecodingReader(BrazilianAnalyzer.class, "stopwords.txt", StandardCharsets.UTF_8), "#", Version.LUCENE_CURRENT);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  72 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.br.BrazilianAnalyzer
 * JD-Core Version:    0.6.2
 */