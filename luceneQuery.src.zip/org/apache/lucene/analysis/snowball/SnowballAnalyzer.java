/*    */ package org.apache.lucene.analysis.snowball;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.Analyzer;
/*    */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.Tokenizer;
/*    */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*    */ import org.apache.lucene.analysis.core.StopFilter;
/*    */ import org.apache.lucene.analysis.en.EnglishPossessiveFilter;
/*    */ import org.apache.lucene.analysis.standard.StandardFilter;
/*    */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*    */ import org.apache.lucene.analysis.tr.TurkishLowerCaseFilter;
/*    */ import org.apache.lucene.analysis.util.CharArraySet;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ @Deprecated
/*    */ public final class SnowballAnalyzer extends Analyzer
/*    */ {
/*    */   private String name;
/*    */   private CharArraySet stopSet;
/*    */   private final Version matchVersion;
/*    */ 
/*    */   public SnowballAnalyzer(Version matchVersion, String name)
/*    */   {
/* 55 */     this.name = name;
/* 56 */     this.matchVersion = matchVersion;
/*    */   }
/*    */ 
/*    */   public SnowballAnalyzer(Version matchVersion, String name, CharArraySet stopWords)
/*    */   {
/* 61 */     this(matchVersion, name);
/* 62 */     this.stopSet = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stopWords));
/*    */   }
/*    */ 
/*    */   public Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*    */   {
/* 71 */     Tokenizer tokenizer = new StandardTokenizer(this.matchVersion, reader);
/* 72 */     TokenStream result = new StandardFilter(this.matchVersion, tokenizer);
/*    */ 
/* 74 */     if ((this.matchVersion.onOrAfter(Version.LUCENE_31)) && ((this.name.equals("English")) || (this.name.equals("Porter")) || (this.name.equals("Lovins"))))
/*    */     {
/* 76 */       result = new EnglishPossessiveFilter(result);
/*    */     }
/* 78 */     if ((this.matchVersion.onOrAfter(Version.LUCENE_31)) && (this.name.equals("Turkish")))
/* 79 */       result = new TurkishLowerCaseFilter(result);
/*    */     else
/* 81 */       result = new LowerCaseFilter(this.matchVersion, result);
/* 82 */     if (this.stopSet != null) {
/* 83 */       result = new StopFilter(this.matchVersion, result, this.stopSet);
/*    */     }
/* 85 */     result = new SnowballFilter(result, this.name);
/* 86 */     return new Analyzer.TokenStreamComponents(tokenizer, result);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.snowball.SnowballAnalyzer
 * JD-Core Version:    0.6.2
 */