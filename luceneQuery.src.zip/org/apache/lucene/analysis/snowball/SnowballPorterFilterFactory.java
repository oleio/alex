/*    */ package org.apache.lucene.analysis.snowball;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*    */ import org.apache.lucene.analysis.util.CharArraySet;
/*    */ import org.apache.lucene.analysis.util.ResourceLoader;
/*    */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ import org.tartarus.snowball.SnowballProgram;
/*    */ 
/*    */ public class SnowballPorterFilterFactory extends TokenFilterFactory
/*    */   implements ResourceLoaderAware
/*    */ {
/*    */   public static final String PROTECTED_TOKENS = "protected";
/*    */   private final String language;
/*    */   private final String wordFiles;
/*    */   private Class<? extends SnowballProgram> stemClass;
/* 51 */   private CharArraySet protectedWords = null;
/*    */ 
/*    */   public SnowballPorterFilterFactory(Map<String, String> args)
/*    */   {
/* 55 */     super(args);
/* 56 */     this.language = get(args, "language", "English");
/* 57 */     this.wordFiles = get(args, "protected");
/* 58 */     if (!args.isEmpty())
/* 59 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public void inform(ResourceLoader loader)
/*    */     throws IOException
/*    */   {
/* 65 */     String className = "org.tartarus.snowball.ext." + this.language + "Stemmer";
/* 66 */     this.stemClass = ((SnowballProgram)loader.newInstance(className, SnowballProgram.class)).getClass();
/*    */ 
/* 68 */     if (this.wordFiles != null)
/* 69 */       this.protectedWords = getWordSet(loader, this.wordFiles, false);
/*    */   }
/*    */ 
/*    */   public TokenFilter create(TokenStream input)
/*    */   {
/*    */     SnowballProgram program;
/*    */     try
/*    */     {
/* 77 */       program = (SnowballProgram)this.stemClass.newInstance();
/*    */     } catch (Exception e) {
/* 79 */       throw new RuntimeException("Error instantiating stemmer for language " + this.language + "from class " + this.stemClass, e);
/*    */     }
/*    */ 
/* 82 */     if (this.protectedWords != null)
/* 83 */       input = new SetKeywordMarkerFilter(input, this.protectedWords);
/* 84 */     return new SnowballFilter(input, program);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.snowball.SnowballPorterFilterFactory
 * JD-Core Version:    0.6.2
 */