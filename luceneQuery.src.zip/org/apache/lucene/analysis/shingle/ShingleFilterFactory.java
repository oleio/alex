/*    */ package org.apache.lucene.analysis.shingle;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class ShingleFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   private final int minShingleSize;
/*    */   private final int maxShingleSize;
/*    */   private final boolean outputUnigrams;
/*    */   private final boolean outputUnigramsIfNoShingles;
/*    */   private final String tokenSeparator;
/*    */   private final String fillerToken;
/*    */ 
/*    */   public ShingleFilterFactory(Map<String, String> args)
/*    */   {
/* 46 */     super(args);
/* 47 */     this.maxShingleSize = getInt(args, "maxShingleSize", 2);
/* 48 */     if (this.maxShingleSize < 2) {
/* 49 */       throw new IllegalArgumentException("Invalid maxShingleSize (" + this.maxShingleSize + ") - must be at least 2");
/*    */     }
/* 51 */     this.minShingleSize = getInt(args, "minShingleSize", 2);
/* 52 */     if (this.minShingleSize < 2) {
/* 53 */       throw new IllegalArgumentException("Invalid minShingleSize (" + this.minShingleSize + ") - must be at least 2");
/*    */     }
/* 55 */     if (this.minShingleSize > this.maxShingleSize) {
/* 56 */       throw new IllegalArgumentException("Invalid minShingleSize (" + this.minShingleSize + ") - must be no greater than maxShingleSize (" + this.maxShingleSize + ")");
/*    */     }
/*    */ 
/* 59 */     this.outputUnigrams = getBoolean(args, "outputUnigrams", true);
/* 60 */     this.outputUnigramsIfNoShingles = getBoolean(args, "outputUnigramsIfNoShingles", false);
/* 61 */     this.tokenSeparator = get(args, "tokenSeparator", " ");
/* 62 */     this.fillerToken = get(args, "fillerToken", "_");
/* 63 */     if (!args.isEmpty())
/* 64 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ShingleFilter create(TokenStream input)
/*    */   {
/* 70 */     ShingleFilter r = new ShingleFilter(input, this.minShingleSize, this.maxShingleSize);
/* 71 */     r.setOutputUnigrams(this.outputUnigrams);
/* 72 */     r.setOutputUnigramsIfNoShingles(this.outputUnigramsIfNoShingles);
/* 73 */     r.setTokenSeparator(this.tokenSeparator);
/* 74 */     r.setFillerToken(this.fillerToken);
/* 75 */     return r;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.shingle.ShingleFilterFactory
 * JD-Core Version:    0.6.2
 */