/*     */ package org.apache.lucene.analysis.shingle;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionLengthAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.AttributeSource;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ 
/*     */ public final class ShingleFilter extends TokenFilter
/*     */ {
/*     */   public static final String DEFAULT_FILLER_TOKEN = "_";
/*     */   public static final int DEFAULT_MAX_SHINGLE_SIZE = 2;
/*     */   public static final int DEFAULT_MIN_SHINGLE_SIZE = 2;
/*     */   public static final String DEFAULT_TOKEN_TYPE = "shingle";
/*     */   public static final String DEFAULT_TOKEN_SEPARATOR = " ";
/*  76 */   private LinkedList<InputWindowToken> inputWindow = new LinkedList();
/*     */   private CircularSequence gramSize;
/*  88 */   private StringBuilder gramBuilder = new StringBuilder();
/*     */ 
/*  93 */   private String tokenType = "shingle";
/*     */ 
/*  98 */   private String tokenSeparator = " ";
/*     */ 
/* 104 */   private char[] fillerToken = "_".toCharArray();
/*     */ 
/* 110 */   private boolean outputUnigrams = true;
/*     */ 
/* 115 */   private boolean outputUnigramsIfNoShingles = false;
/*     */   private int maxShingleSize;
/*     */   private int minShingleSize;
/*     */   private int numFillerTokensToInsert;
/*     */   private AttributeSource nextInputStreamToken;
/* 144 */   private boolean isNextInputStreamToken = false;
/*     */ 
/* 150 */   private boolean isOutputHere = false;
/*     */ 
/* 155 */   boolean noShingleOutput = true;
/*     */   private AttributeSource.State endState;
/* 163 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 164 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 165 */   private final PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/* 166 */   private final PositionLengthAttribute posLenAtt = (PositionLengthAttribute)addAttribute(PositionLengthAttribute.class);
/* 167 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/*     */   private boolean exhausted;
/*     */ 
/*     */   public ShingleFilter(TokenStream input, int minShingleSize, int maxShingleSize)
/*     */   {
/* 179 */     super(input);
/* 180 */     setMaxShingleSize(maxShingleSize);
/* 181 */     setMinShingleSize(minShingleSize);
/*     */   }
/*     */ 
/*     */   public ShingleFilter(TokenStream input, int maxShingleSize)
/*     */   {
/* 192 */     this(input, 2, maxShingleSize);
/*     */   }
/*     */ 
/*     */   public ShingleFilter(TokenStream input)
/*     */   {
/* 201 */     this(input, 2, 2);
/*     */   }
/*     */ 
/*     */   public ShingleFilter(TokenStream input, String tokenType)
/*     */   {
/* 212 */     this(input, 2, 2);
/* 213 */     setTokenType(tokenType);
/*     */   }
/*     */ 
/*     */   public void setTokenType(String tokenType)
/*     */   {
/* 223 */     this.tokenType = tokenType;
/*     */   }
/*     */ 
/*     */   public void setOutputUnigrams(boolean outputUnigrams)
/*     */   {
/* 234 */     this.outputUnigrams = outputUnigrams;
/* 235 */     this.gramSize = new CircularSequence();
/*     */   }
/*     */ 
/*     */   public void setOutputUnigramsIfNoShingles(boolean outputUnigramsIfNoShingles)
/*     */   {
/* 249 */     this.outputUnigramsIfNoShingles = outputUnigramsIfNoShingles;
/*     */   }
/*     */ 
/*     */   public void setMaxShingleSize(int maxShingleSize)
/*     */   {
/* 258 */     if (maxShingleSize < 2) {
/* 259 */       throw new IllegalArgumentException("Max shingle size must be >= 2");
/*     */     }
/* 261 */     this.maxShingleSize = maxShingleSize;
/*     */   }
/*     */ 
/*     */   public void setMinShingleSize(int minShingleSize)
/*     */   {
/* 274 */     if (minShingleSize < 2) {
/* 275 */       throw new IllegalArgumentException("Min shingle size must be >= 2");
/*     */     }
/* 277 */     if (minShingleSize > this.maxShingleSize) {
/* 278 */       throw new IllegalArgumentException("Min shingle size must be <= max shingle size");
/*     */     }
/*     */ 
/* 281 */     this.minShingleSize = minShingleSize;
/* 282 */     this.gramSize = new CircularSequence();
/*     */   }
/*     */ 
/*     */   public void setTokenSeparator(String tokenSeparator)
/*     */   {
/* 290 */     this.tokenSeparator = (null == tokenSeparator ? "" : tokenSeparator);
/*     */   }
/*     */ 
/*     */   public void setFillerToken(String fillerToken)
/*     */   {
/* 300 */     this.fillerToken = (null == fillerToken ? new char[0] : fillerToken.toCharArray());
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/* 305 */     boolean tokenAvailable = false;
/* 306 */     int builtGramSize = 0;
/* 307 */     if ((this.gramSize.atMinValue()) || (this.inputWindow.size() < this.gramSize.getValue())) {
/* 308 */       shiftInputWindow();
/* 309 */       this.gramBuilder.setLength(0);
/*     */     } else {
/* 311 */       builtGramSize = this.gramSize.getPreviousValue();
/*     */     }
/* 313 */     if (this.inputWindow.size() >= this.gramSize.getValue()) {
/* 314 */       boolean isAllFiller = true;
/* 315 */       InputWindowToken nextToken = null;
/* 316 */       Iterator iter = this.inputWindow.iterator();
/* 317 */       for (int gramNum = 1; 
/* 318 */         (iter.hasNext()) && (builtGramSize < this.gramSize.getValue()); 
/* 319 */         gramNum++) {
/* 320 */         nextToken = (InputWindowToken)iter.next();
/* 321 */         if (builtGramSize < gramNum) {
/* 322 */           if (builtGramSize > 0) {
/* 323 */             this.gramBuilder.append(this.tokenSeparator);
/*     */           }
/* 325 */           this.gramBuilder.append(nextToken.termAtt.buffer(), 0, nextToken.termAtt.length());
/*     */ 
/* 327 */           builtGramSize++;
/*     */         }
/* 329 */         if ((isAllFiller) && (nextToken.isFiller)) {
/* 330 */           if (gramNum == this.gramSize.getValue())
/* 331 */             this.gramSize.advance();
/*     */         }
/*     */         else {
/* 334 */           isAllFiller = false;
/*     */         }
/*     */       }
/* 337 */       if ((!isAllFiller) && (builtGramSize == this.gramSize.getValue())) {
/* 338 */         ((InputWindowToken)this.inputWindow.getFirst()).attSource.copyTo(this);
/* 339 */         this.posIncrAtt.setPositionIncrement(this.isOutputHere ? 0 : 1);
/* 340 */         this.termAtt.setEmpty().append(this.gramBuilder);
/* 341 */         if (this.gramSize.getValue() > 1) {
/* 342 */           this.typeAtt.setType(this.tokenType);
/* 343 */           this.noShingleOutput = false;
/*     */         }
/* 345 */         this.offsetAtt.setOffset(this.offsetAtt.startOffset(), nextToken.offsetAtt.endOffset());
/* 346 */         this.posLenAtt.setPositionLength(builtGramSize);
/* 347 */         this.isOutputHere = true;
/* 348 */         this.gramSize.advance();
/* 349 */         tokenAvailable = true;
/*     */       }
/*     */     }
/* 352 */     return tokenAvailable;
/*     */   }
/*     */ 
/*     */   private InputWindowToken getNextToken(InputWindowToken target)
/*     */     throws IOException
/*     */   {
/* 368 */     InputWindowToken newTarget = target;
/* 369 */     if (this.numFillerTokensToInsert > 0) {
/* 370 */       if (null == target)
/* 371 */         newTarget = new InputWindowToken(this.nextInputStreamToken.cloneAttributes());
/*     */       else {
/* 373 */         this.nextInputStreamToken.copyTo(target.attSource);
/*     */       }
/*     */ 
/* 376 */       newTarget.offsetAtt.setOffset(newTarget.offsetAtt.startOffset(), newTarget.offsetAtt.startOffset());
/*     */ 
/* 378 */       newTarget.termAtt.copyBuffer(this.fillerToken, 0, this.fillerToken.length);
/* 379 */       newTarget.isFiller = true;
/* 380 */       this.numFillerTokensToInsert -= 1;
/* 381 */     } else if (this.isNextInputStreamToken) {
/* 382 */       if (null == target)
/* 383 */         newTarget = new InputWindowToken(this.nextInputStreamToken.cloneAttributes());
/*     */       else {
/* 385 */         this.nextInputStreamToken.copyTo(target.attSource);
/*     */       }
/* 387 */       this.isNextInputStreamToken = false;
/* 388 */       newTarget.isFiller = false;
/* 389 */     } else if (!this.exhausted) {
/* 390 */       if (this.input.incrementToken()) {
/* 391 */         if (null == target)
/* 392 */           newTarget = new InputWindowToken(cloneAttributes());
/*     */         else {
/* 394 */           copyTo(target.attSource);
/*     */         }
/* 396 */         if (this.posIncrAtt.getPositionIncrement() > 1)
/*     */         {
/* 399 */           this.numFillerTokensToInsert = Math.min(this.posIncrAtt.getPositionIncrement() - 1, this.maxShingleSize - 1);
/*     */ 
/* 401 */           if (null == this.nextInputStreamToken)
/* 402 */             this.nextInputStreamToken = cloneAttributes();
/*     */           else {
/* 404 */             copyTo(this.nextInputStreamToken);
/*     */           }
/* 406 */           this.isNextInputStreamToken = true;
/*     */ 
/* 408 */           newTarget.offsetAtt.setOffset(this.offsetAtt.startOffset(), this.offsetAtt.startOffset());
/* 409 */           newTarget.termAtt.copyBuffer(this.fillerToken, 0, this.fillerToken.length);
/* 410 */           newTarget.isFiller = true;
/* 411 */           this.numFillerTokensToInsert -= 1;
/*     */         } else {
/* 413 */           newTarget.isFiller = false;
/*     */         }
/*     */       } else {
/* 416 */         this.exhausted = true;
/* 417 */         this.input.end();
/* 418 */         this.endState = captureState();
/* 419 */         this.numFillerTokensToInsert = Math.min(this.posIncrAtt.getPositionIncrement(), this.maxShingleSize - 1);
/* 420 */         if (this.numFillerTokensToInsert > 0) {
/* 421 */           this.nextInputStreamToken = new AttributeSource(getAttributeFactory());
/* 422 */           this.nextInputStreamToken.addAttribute(CharTermAttribute.class);
/* 423 */           OffsetAttribute newOffsetAtt = (OffsetAttribute)this.nextInputStreamToken.addAttribute(OffsetAttribute.class);
/* 424 */           newOffsetAtt.setOffset(this.offsetAtt.endOffset(), this.offsetAtt.endOffset());
/*     */ 
/* 426 */           return getNextToken(target);
/*     */         }
/* 428 */         newTarget = null;
/*     */       }
/*     */     }
/*     */     else {
/* 432 */       newTarget = null;
/*     */     }
/* 434 */     return newTarget;
/*     */   }
/*     */ 
/*     */   public void end() throws IOException
/*     */   {
/* 439 */     if (!this.exhausted)
/* 440 */       super.end();
/*     */     else
/* 442 */       restoreState(this.endState);
/*     */   }
/*     */ 
/*     */   private void shiftInputWindow()
/*     */     throws IOException
/*     */   {
/* 454 */     InputWindowToken firstToken = null;
/* 455 */     if (this.inputWindow.size() > 0) {
/* 456 */       firstToken = (InputWindowToken)this.inputWindow.removeFirst();
/*     */     }
/* 458 */     while (this.inputWindow.size() < this.maxShingleSize) {
/* 459 */       if (null != firstToken) {
/* 460 */         if (null == getNextToken(firstToken)) break;
/* 461 */         this.inputWindow.add(firstToken);
/* 462 */         firstToken = null;
/*     */       }
/*     */       else
/*     */       {
/* 467 */         InputWindowToken nextToken = getNextToken(null);
/* 468 */         if (null == nextToken) break;
/* 469 */         this.inputWindow.add(nextToken);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 475 */     if ((this.outputUnigramsIfNoShingles) && (this.noShingleOutput) && (this.gramSize.minValue > 1) && (this.inputWindow.size() < this.minShingleSize))
/*     */     {
/* 477 */       this.gramSize.minValue = 1;
/*     */     }
/* 479 */     this.gramSize.reset();
/* 480 */     this.isOutputHere = false;
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 485 */     super.reset();
/* 486 */     this.gramSize.reset();
/* 487 */     this.inputWindow.clear();
/* 488 */     this.nextInputStreamToken = null;
/* 489 */     this.isNextInputStreamToken = false;
/* 490 */     this.numFillerTokensToInsert = 0;
/* 491 */     this.isOutputHere = false;
/* 492 */     this.noShingleOutput = true;
/* 493 */     this.exhausted = false;
/* 494 */     this.endState = null;
/* 495 */     if ((this.outputUnigramsIfNoShingles) && (!this.outputUnigrams))
/*     */     {
/* 497 */       this.gramSize.minValue = this.minShingleSize;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class InputWindowToken
/*     */   {
/*     */     final AttributeSource attSource;
/*     */     final CharTermAttribute termAtt;
/*     */     final OffsetAttribute offsetAtt;
/* 585 */     boolean isFiller = false;
/*     */ 
/*     */     public InputWindowToken(AttributeSource attSource) {
/* 588 */       this.attSource = attSource;
/* 589 */       this.termAtt = ((CharTermAttribute)attSource.getAttribute(CharTermAttribute.class));
/* 590 */       this.offsetAtt = ((OffsetAttribute)attSource.getAttribute(OffsetAttribute.class));
/*     */     }
/*     */   }
/*     */ 
/*     */   private class CircularSequence
/*     */   {
/*     */     private int value;
/*     */     private int previousValue;
/*     */     private int minValue;
/*     */ 
/*     */     public CircularSequence()
/*     */     {
/* 517 */       this.minValue = (ShingleFilter.this.outputUnigrams ? 1 : ShingleFilter.this.minShingleSize);
/* 518 */       reset();
/*     */     }
/*     */ 
/*     */     public int getValue()
/*     */     {
/* 526 */       return this.value;
/*     */     }
/*     */ 
/*     */     public void advance()
/*     */     {
/* 538 */       this.previousValue = this.value;
/* 539 */       if (this.value == 1)
/* 540 */         this.value = ShingleFilter.this.minShingleSize;
/* 541 */       else if (this.value == ShingleFilter.this.maxShingleSize)
/* 542 */         reset();
/*     */       else
/* 544 */         this.value += 1;
/*     */     }
/*     */ 
/*     */     public void reset()
/*     */     {
/* 557 */       this.previousValue = (this.value = this.minValue);
/*     */     }
/*     */ 
/*     */     public boolean atMinValue()
/*     */     {
/* 570 */       return this.value == this.minValue;
/*     */     }
/*     */ 
/*     */     public int getPreviousValue()
/*     */     {
/* 577 */       return this.previousValue;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.shingle.ShingleFilter
 * JD-Core Version:    0.6.2
 */