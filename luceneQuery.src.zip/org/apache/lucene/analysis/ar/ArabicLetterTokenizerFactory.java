/*    */ package org.apache.lucene.analysis.ar;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ @Deprecated
/*    */ public class ArabicLetterTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   public ArabicLetterTokenizerFactory(Map<String, String> args)
/*    */   {
/* 36 */     super(args);
/* 37 */     assureMatchVersion();
/* 38 */     if (!args.isEmpty())
/* 39 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ArabicLetterTokenizer create(AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 45 */     return new ArabicLetterTokenizer(this.luceneMatchVersion, factory, input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ar.ArabicLetterTokenizerFactory
 * JD-Core Version:    0.6.2
 */