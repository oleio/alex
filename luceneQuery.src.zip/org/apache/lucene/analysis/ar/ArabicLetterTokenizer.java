/*    */ package org.apache.lucene.analysis.ar;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.core.LetterTokenizer;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ @Deprecated
/*    */ public class ArabicLetterTokenizer extends LetterTokenizer
/*    */ {
/*    */   public ArabicLetterTokenizer(Version matchVersion, Reader in)
/*    */   {
/* 54 */     super(matchVersion, in);
/*    */   }
/*    */ 
/*    */   public ArabicLetterTokenizer(Version matchVersion, AttributeSource.AttributeFactory factory, Reader in)
/*    */   {
/* 69 */     super(matchVersion, factory, in);
/*    */   }
/*    */ 
/*    */   protected boolean isTokenChar(int c)
/*    */   {
/* 78 */     return (super.isTokenChar(c)) || (Character.getType(c) == 6);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ar.ArabicLetterTokenizer
 * JD-Core Version:    0.6.2
 */