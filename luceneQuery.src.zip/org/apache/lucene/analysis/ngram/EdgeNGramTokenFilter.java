/*     */ package org.apache.lucene.analysis.ngram;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionLengthAttribute;
/*     */ import org.apache.lucene.analysis.util.CharacterUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class EdgeNGramTokenFilter extends TokenFilter
/*     */ {
/*  42 */   public static final Side DEFAULT_SIDE = Side.FRONT;
/*     */   public static final int DEFAULT_MAX_GRAM_SIZE = 1;
/*     */   public static final int DEFAULT_MIN_GRAM_SIZE = 1;
/*     */   private final Version version;
/*     */   private final CharacterUtils charUtils;
/*     */   private final int minGram;
/*     */   private final int maxGram;
/*     */   private Side side;
/*     */   private char[] curTermBuffer;
/*     */   private int curTermLength;
/*     */   private int curCodePointCount;
/*     */   private int curGramSize;
/*     */   private int tokStart;
/*     */   private int tokEnd;
/*     */   private boolean updateOffsets;
/*     */   private int savePosIncr;
/*     */   private int savePosLen;
/*  91 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  92 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*  93 */   private final PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*  94 */   private final PositionLengthAttribute posLenAtt = (PositionLengthAttribute)addAttribute(PositionLengthAttribute.class);
/*     */ 
/*     */   @Deprecated
/*     */   public EdgeNGramTokenFilter(Version version, TokenStream input, Side side, int minGram, int maxGram)
/*     */   {
/* 107 */     super(input);
/*     */ 
/* 109 */     if (version == null) {
/* 110 */       throw new IllegalArgumentException("version must not be null");
/*     */     }
/*     */ 
/* 113 */     if ((version.onOrAfter(Version.LUCENE_44)) && (side == Side.BACK)) {
/* 114 */       throw new IllegalArgumentException("Side.BACK is not supported anymore as of Lucene 4.4, use ReverseStringFilter up-front and afterward");
/*     */     }
/*     */ 
/* 117 */     if (side == null) {
/* 118 */       throw new IllegalArgumentException("sideLabel must be either front or back");
/*     */     }
/*     */ 
/* 121 */     if (minGram < 1) {
/* 122 */       throw new IllegalArgumentException("minGram must be greater than zero");
/*     */     }
/*     */ 
/* 125 */     if (minGram > maxGram) {
/* 126 */       throw new IllegalArgumentException("minGram must not be greater than maxGram");
/*     */     }
/*     */ 
/* 129 */     this.version = version;
/* 130 */     this.charUtils = (version.onOrAfter(Version.LUCENE_44) ? CharacterUtils.getInstance(version) : CharacterUtils.getJava4Instance());
/*     */ 
/* 133 */     this.minGram = minGram;
/* 134 */     this.maxGram = maxGram;
/* 135 */     this.side = side;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public EdgeNGramTokenFilter(Version version, TokenStream input, String sideLabel, int minGram, int maxGram)
/*     */   {
/* 149 */     this(version, input, Side.getSide(sideLabel), minGram, maxGram);
/*     */   }
/*     */ 
/*     */   public EdgeNGramTokenFilter(Version version, TokenStream input, int minGram, int maxGram)
/*     */   {
/* 161 */     this(version, input, Side.FRONT, minGram, maxGram);
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken() throws IOException
/*     */   {
/*     */     while (true) {
/* 167 */       if (this.curTermBuffer == null) {
/* 168 */         if (!this.input.incrementToken()) {
/* 169 */           return false;
/*     */         }
/* 171 */         this.curTermBuffer = ((char[])this.termAtt.buffer().clone());
/* 172 */         this.curTermLength = this.termAtt.length();
/* 173 */         this.curCodePointCount = this.charUtils.codePointCount(this.termAtt);
/* 174 */         this.curGramSize = this.minGram;
/* 175 */         this.tokStart = this.offsetAtt.startOffset();
/* 176 */         this.tokEnd = this.offsetAtt.endOffset();
/* 177 */         if (this.version.onOrAfter(Version.LUCENE_44))
/*     */         {
/* 179 */           this.updateOffsets = false;
/*     */         }
/*     */         else
/*     */         {
/* 183 */           this.updateOffsets = (this.tokStart + this.curTermLength == this.tokEnd);
/*     */         }
/* 185 */         this.savePosIncr += this.posIncrAtt.getPositionIncrement();
/* 186 */         this.savePosLen = this.posLenAtt.getPositionLength();
/*     */       }
/*     */ 
/* 189 */       if ((this.curGramSize <= this.maxGram) && 
/* 190 */         (this.curGramSize <= this.curCodePointCount))
/*     */       {
/* 192 */         int start = this.side == Side.FRONT ? 0 : this.charUtils.offsetByCodePoints(this.curTermBuffer, 0, this.curTermLength, this.curTermLength, -this.curGramSize);
/* 193 */         int end = this.charUtils.offsetByCodePoints(this.curTermBuffer, 0, this.curTermLength, start, this.curGramSize);
/* 194 */         clearAttributes();
/* 195 */         if (this.updateOffsets)
/* 196 */           this.offsetAtt.setOffset(this.tokStart + start, this.tokStart + end);
/*     */         else {
/* 198 */           this.offsetAtt.setOffset(this.tokStart, this.tokEnd);
/*     */         }
/*     */ 
/* 201 */         if (this.curGramSize == this.minGram) {
/* 202 */           this.posIncrAtt.setPositionIncrement(this.savePosIncr);
/* 203 */           this.savePosIncr = 0;
/*     */         } else {
/* 205 */           this.posIncrAtt.setPositionIncrement(0);
/*     */         }
/* 207 */         this.posLenAtt.setPositionLength(this.savePosLen);
/* 208 */         this.termAtt.copyBuffer(this.curTermBuffer, start, end - start);
/* 209 */         this.curGramSize += 1;
/* 210 */         return true;
/*     */       }
/*     */ 
/* 213 */       this.curTermBuffer = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 219 */     super.reset();
/* 220 */     this.curTermBuffer = null;
/* 221 */     this.savePosIncr = 0;
/*     */   }
/*     */ 
/*     */   public static abstract enum Side
/*     */   {
/*  50 */     FRONT, 
/*     */ 
/*  56 */     BACK;
/*     */ 
/*     */     public abstract String getLabel();
/*     */ 
/*     */     public static Side getSide(String sideName)
/*     */     {
/*  66 */       if (FRONT.getLabel().equals(sideName)) {
/*  67 */         return FRONT;
/*     */       }
/*  69 */       if (BACK.getLabel().equals(sideName)) {
/*  70 */         return BACK;
/*     */       }
/*  72 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ngram.EdgeNGramTokenFilter
 * JD-Core Version:    0.6.2
 */