/*    */ package org.apache.lucene.analysis.ngram;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.Tokenizer;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public class NGramTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   private final int maxGramSize;
/*    */   private final int minGramSize;
/*    */ 
/*    */   public NGramTokenizerFactory(Map<String, String> args)
/*    */   {
/* 44 */     super(args);
/* 45 */     this.minGramSize = getInt(args, "minGramSize", 1);
/* 46 */     this.maxGramSize = getInt(args, "maxGramSize", 2);
/* 47 */     if (!args.isEmpty())
/* 48 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public Tokenizer create(AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 55 */     if (this.luceneMatchVersion.onOrAfter(Version.LUCENE_44)) {
/* 56 */       return new NGramTokenizer(this.luceneMatchVersion, factory, input, this.minGramSize, this.maxGramSize);
/*    */     }
/* 58 */     return new Lucene43NGramTokenizer(factory, input, this.minGramSize, this.maxGramSize);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ngram.NGramTokenizerFactory
 * JD-Core Version:    0.6.2
 */