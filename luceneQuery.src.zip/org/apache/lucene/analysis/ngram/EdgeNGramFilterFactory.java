/*    */ package org.apache.lucene.analysis.ngram;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class EdgeNGramFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   private final int maxGramSize;
/*    */   private final int minGramSize;
/*    */   private final String side;
/*    */ 
/*    */   public EdgeNGramFilterFactory(Map<String, String> args)
/*    */   {
/* 41 */     super(args);
/* 42 */     this.minGramSize = getInt(args, "minGramSize", 1);
/* 43 */     this.maxGramSize = getInt(args, "maxGramSize", 1);
/* 44 */     this.side = get(args, "side", EdgeNGramTokenFilter.Side.FRONT.getLabel());
/* 45 */     if (!args.isEmpty())
/* 46 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public EdgeNGramTokenFilter create(TokenStream input)
/*    */   {
/* 52 */     return new EdgeNGramTokenFilter(this.luceneMatchVersion, input, this.side, this.minGramSize, this.maxGramSize);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ngram.EdgeNGramFilterFactory
 * JD-Core Version:    0.6.2
 */