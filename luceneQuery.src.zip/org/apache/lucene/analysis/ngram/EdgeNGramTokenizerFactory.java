/*    */ package org.apache.lucene.analysis.ngram;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.Tokenizer;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public class EdgeNGramTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   private final int maxGramSize;
/*    */   private final int minGramSize;
/*    */   private final String side;
/*    */ 
/*    */   public EdgeNGramTokenizerFactory(Map<String, String> args)
/*    */   {
/* 44 */     super(args);
/* 45 */     this.minGramSize = getInt(args, "minGramSize", 1);
/* 46 */     this.maxGramSize = getInt(args, "maxGramSize", 1);
/* 47 */     this.side = get(args, "side", EdgeNGramTokenFilter.Side.FRONT.getLabel());
/* 48 */     if (!args.isEmpty())
/* 49 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public Tokenizer create(AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 55 */     if (this.luceneMatchVersion.onOrAfter(Version.LUCENE_44)) {
/* 56 */       if (!EdgeNGramTokenFilter.Side.FRONT.getLabel().equals(this.side)) {
/* 57 */         throw new IllegalArgumentException(EdgeNGramTokenizer.class.getSimpleName() + " does not support backward n-grams as of Lucene 4.4");
/*    */       }
/* 59 */       return new EdgeNGramTokenizer(this.luceneMatchVersion, input, this.minGramSize, this.maxGramSize);
/*    */     }
/* 61 */     return new Lucene43EdgeNGramTokenizer(this.luceneMatchVersion, input, this.side, this.minGramSize, this.maxGramSize);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ngram.EdgeNGramTokenizerFactory
 * JD-Core Version:    0.6.2
 */