/*     */ package org.apache.lucene.analysis.ngram;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.util.ArrayUtil;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ @Deprecated
/*     */ public final class Lucene43EdgeNGramTokenizer extends Tokenizer
/*     */ {
/*  36 */   public static final Side DEFAULT_SIDE = Side.FRONT;
/*     */   public static final int DEFAULT_MAX_GRAM_SIZE = 1;
/*     */   public static final int DEFAULT_MIN_GRAM_SIZE = 1;
/*  40 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  41 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*  42 */   private final PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*     */   private int minGram;
/*     */   private int maxGram;
/*     */   private int gramSize;
/*     */   private Side side;
/*     */   private boolean started;
/*     */   private int inLen;
/*     */   private int charsRead;
/*     */   private String inStr;
/*     */ 
/*     */   @Deprecated
/*     */   public Lucene43EdgeNGramTokenizer(Version version, Reader input, Side side, int minGram, int maxGram)
/*     */   {
/*  94 */     super(input);
/*  95 */     init(version, side, minGram, maxGram);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Lucene43EdgeNGramTokenizer(Version version, AttributeSource.AttributeFactory factory, Reader input, Side side, int minGram, int maxGram)
/*     */   {
/* 110 */     super(factory, input);
/* 111 */     init(version, side, minGram, maxGram);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Lucene43EdgeNGramTokenizer(Version version, Reader input, String sideLabel, int minGram, int maxGram)
/*     */   {
/* 125 */     this(version, input, Side.getSide(sideLabel), minGram, maxGram);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Lucene43EdgeNGramTokenizer(Version version, AttributeSource.AttributeFactory factory, Reader input, String sideLabel, int minGram, int maxGram)
/*     */   {
/* 140 */     this(version, factory, input, Side.getSide(sideLabel), minGram, maxGram);
/*     */   }
/*     */ 
/*     */   public Lucene43EdgeNGramTokenizer(Version version, Reader input, int minGram, int maxGram)
/*     */   {
/* 152 */     this(version, input, Side.FRONT, minGram, maxGram);
/*     */   }
/*     */ 
/*     */   public Lucene43EdgeNGramTokenizer(Version version, AttributeSource.AttributeFactory factory, Reader input, int minGram, int maxGram)
/*     */   {
/* 165 */     this(version, factory, input, Side.FRONT, minGram, maxGram);
/*     */   }
/*     */ 
/*     */   private void init(Version version, Side side, int minGram, int maxGram) {
/* 169 */     if (version == null) {
/* 170 */       throw new IllegalArgumentException("version must not be null");
/*     */     }
/*     */ 
/* 173 */     if (side == null) {
/* 174 */       throw new IllegalArgumentException("sideLabel must be either front or back");
/*     */     }
/*     */ 
/* 177 */     if (minGram < 1) {
/* 178 */       throw new IllegalArgumentException("minGram must be greater than zero");
/*     */     }
/*     */ 
/* 181 */     if (minGram > maxGram) {
/* 182 */       throw new IllegalArgumentException("minGram must not be greater than maxGram");
/*     */     }
/*     */ 
/* 185 */     if (version.onOrAfter(Version.LUCENE_44)) {
/* 186 */       if (side == Side.BACK)
/* 187 */         throw new IllegalArgumentException("Side.BACK is not supported anymore as of Lucene 4.4");
/*     */     }
/*     */     else {
/* 190 */       maxGram = Math.min(maxGram, 1024);
/*     */     }
/*     */ 
/* 193 */     this.minGram = minGram;
/* 194 */     this.maxGram = maxGram;
/* 195 */     this.side = side;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 201 */     clearAttributes();
/*     */ 
/* 203 */     if (!this.started) {
/* 204 */       this.started = true;
/* 205 */       this.gramSize = this.minGram;
/* 206 */       int limit = this.side == Side.FRONT ? this.maxGram : 1024;
/* 207 */       char[] chars = new char[Math.min(1024, limit)];
/* 208 */       this.charsRead = 0;
/*     */ 
/* 210 */       boolean exhausted = false;
/* 211 */       while (this.charsRead < limit) {
/* 212 */         int inc = this.input.read(chars, this.charsRead, chars.length - this.charsRead);
/* 213 */         if (inc == -1) {
/* 214 */           exhausted = true;
/* 215 */           break;
/*     */         }
/* 217 */         this.charsRead += inc;
/* 218 */         if ((this.charsRead == chars.length) && (this.charsRead < limit)) {
/* 219 */           chars = ArrayUtil.grow(chars);
/*     */         }
/*     */       }
/*     */ 
/* 223 */       this.inStr = new String(chars, 0, this.charsRead);
/* 224 */       this.inStr = this.inStr.trim();
/*     */ 
/* 226 */       if (!exhausted)
/*     */       {
/* 229 */         char[] throwaway = new char[1024];
/*     */         while (true) {
/* 231 */           int inc = this.input.read(throwaway, 0, throwaway.length);
/* 232 */           if (inc == -1) {
/*     */             break;
/*     */           }
/* 235 */           this.charsRead += inc;
/*     */         }
/*     */       }
/*     */ 
/* 239 */       this.inLen = this.inStr.length();
/* 240 */       if (this.inLen == 0) {
/* 241 */         return false;
/*     */       }
/* 243 */       this.posIncrAtt.setPositionIncrement(1);
/*     */     } else {
/* 245 */       this.posIncrAtt.setPositionIncrement(0);
/*     */     }
/*     */ 
/* 249 */     if (this.gramSize > this.inLen) {
/* 250 */       return false;
/*     */     }
/*     */ 
/* 254 */     if ((this.gramSize > this.maxGram) || (this.gramSize > this.inLen)) {
/* 255 */       return false;
/*     */     }
/*     */ 
/* 259 */     int start = this.side == Side.FRONT ? 0 : this.inLen - this.gramSize;
/* 260 */     int end = start + this.gramSize;
/* 261 */     this.termAtt.setEmpty().append(this.inStr, start, end);
/* 262 */     this.offsetAtt.setOffset(correctOffset(start), correctOffset(end));
/* 263 */     this.gramSize += 1;
/* 264 */     return true;
/*     */   }
/*     */ 
/*     */   public void end() throws IOException
/*     */   {
/* 269 */     super.end();
/*     */ 
/* 271 */     int finalOffset = correctOffset(this.charsRead);
/* 272 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 277 */     super.reset();
/* 278 */     this.started = false;
/*     */   }
/*     */ 
/*     */   public static abstract enum Side
/*     */   {
/*  48 */     FRONT, 
/*     */ 
/*  54 */     BACK;
/*     */ 
/*     */     public abstract String getLabel();
/*     */ 
/*     */     public static Side getSide(String sideName)
/*     */     {
/*  63 */       if (FRONT.getLabel().equals(sideName)) {
/*  64 */         return FRONT;
/*     */       }
/*  66 */       if (BACK.getLabel().equals(sideName)) {
/*  67 */         return BACK;
/*     */       }
/*  69 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ngram.Lucene43EdgeNGramTokenizer
 * JD-Core Version:    0.6.2
 */