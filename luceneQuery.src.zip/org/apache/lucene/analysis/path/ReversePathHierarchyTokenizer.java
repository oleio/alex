/*     */ package org.apache.lucene.analysis.path;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ public class ReversePathHierarchyTokenizer extends Tokenizer
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 1024;
/*     */   public static final char DEFAULT_DELIMITER = '/';
/*     */   public static final int DEFAULT_SKIP = 0;
/*     */   private final char delimiter;
/*     */   private final char replacement;
/*     */   private final int skip;
/* 112 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 113 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 114 */   private final PositionIncrementAttribute posAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*     */ 
/* 116 */   private int endPosition = 0;
/* 117 */   private int finalOffset = 0;
/* 118 */   private int skipped = 0;
/*     */   private StringBuilder resultToken;
/*     */   private List<Integer> delimiterPositions;
/* 122 */   private int delimitersCount = -1;
/*     */   private char[] resultTokenBuffer;
/*     */ 
/*     */   public ReversePathHierarchyTokenizer(Reader input)
/*     */   {
/*  51 */     this(input, 1024, '/', '/', 0);
/*     */   }
/*     */ 
/*     */   public ReversePathHierarchyTokenizer(Reader input, int skip) {
/*  55 */     this(input, 1024, '/', '/', skip);
/*     */   }
/*     */ 
/*     */   public ReversePathHierarchyTokenizer(Reader input, int bufferSize, char delimiter) {
/*  59 */     this(input, bufferSize, delimiter, delimiter, 0);
/*     */   }
/*     */ 
/*     */   public ReversePathHierarchyTokenizer(Reader input, char delimiter, char replacement) {
/*  63 */     this(input, 1024, delimiter, replacement, 0);
/*     */   }
/*     */ 
/*     */   public ReversePathHierarchyTokenizer(Reader input, int bufferSize, char delimiter, char replacement) {
/*  67 */     this(input, bufferSize, delimiter, replacement, 0);
/*     */   }
/*     */ 
/*     */   public ReversePathHierarchyTokenizer(Reader input, char delimiter, int skip) {
/*  71 */     this(input, 1024, delimiter, delimiter, skip);
/*     */   }
/*     */ 
/*     */   public ReversePathHierarchyTokenizer(Reader input, char delimiter, char replacement, int skip) {
/*  75 */     this(input, 1024, delimiter, replacement, skip);
/*     */   }
/*     */ 
/*     */   public ReversePathHierarchyTokenizer(AttributeSource.AttributeFactory factory, Reader input, char delimiter, char replacement, int skip)
/*     */   {
/*  80 */     this(factory, input, 1024, delimiter, replacement, skip);
/*     */   }
/*     */ 
/*     */   public ReversePathHierarchyTokenizer(Reader input, int bufferSize, char delimiter, char replacement, int skip) {
/*  84 */     this(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY, input, bufferSize, delimiter, replacement, skip);
/*     */   }
/*     */ 
/*     */   public ReversePathHierarchyTokenizer(AttributeSource.AttributeFactory factory, Reader input, int bufferSize, char delimiter, char replacement, int skip) {
/*  88 */     super(factory, input);
/*  89 */     if (bufferSize < 0) {
/*  90 */       throw new IllegalArgumentException("bufferSize cannot be negative");
/*     */     }
/*  92 */     if (skip < 0) {
/*  93 */       throw new IllegalArgumentException("skip cannot be negative");
/*     */     }
/*  95 */     this.termAtt.resizeBuffer(bufferSize);
/*  96 */     this.delimiter = delimiter;
/*  97 */     this.replacement = replacement;
/*  98 */     this.skip = skip;
/*  99 */     this.resultToken = new StringBuilder(bufferSize);
/* 100 */     this.resultTokenBuffer = new char[bufferSize];
/* 101 */     this.delimiterPositions = new ArrayList(bufferSize / 10);
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 127 */     clearAttributes();
/* 128 */     if (this.delimitersCount == -1) {
/* 129 */       int length = 0;
/* 130 */       this.delimiterPositions.add(Integer.valueOf(0));
/*     */       while (true) {
/* 132 */         int c = this.input.read();
/* 133 */         if (c < 0) {
/*     */           break;
/*     */         }
/* 136 */         length++;
/* 137 */         if (c == this.delimiter) {
/* 138 */           this.delimiterPositions.add(Integer.valueOf(length));
/* 139 */           this.resultToken.append(this.replacement);
/*     */         }
/*     */         else {
/* 142 */           this.resultToken.append((char)c);
/*     */         }
/*     */       }
/* 145 */       this.delimitersCount = this.delimiterPositions.size();
/* 146 */       if (((Integer)this.delimiterPositions.get(this.delimitersCount - 1)).intValue() < length) {
/* 147 */         this.delimiterPositions.add(Integer.valueOf(length));
/* 148 */         this.delimitersCount += 1;
/*     */       }
/* 150 */       if (this.resultTokenBuffer.length < this.resultToken.length()) {
/* 151 */         this.resultTokenBuffer = new char[this.resultToken.length()];
/*     */       }
/* 153 */       this.resultToken.getChars(0, this.resultToken.length(), this.resultTokenBuffer, 0);
/* 154 */       this.resultToken.setLength(0);
/* 155 */       int idx = this.delimitersCount - 1 - this.skip;
/* 156 */       if (idx >= 0)
/*     */       {
/* 158 */         this.endPosition = ((Integer)this.delimiterPositions.get(idx)).intValue();
/*     */       }
/* 160 */       this.finalOffset = correctOffset(length);
/* 161 */       this.posAtt.setPositionIncrement(1);
/*     */     }
/*     */     else {
/* 164 */       this.posAtt.setPositionIncrement(0);
/*     */     }
/*     */ 
/* 167 */     if (this.skipped < this.delimitersCount - this.skip - 1) {
/* 168 */       int start = ((Integer)this.delimiterPositions.get(this.skipped)).intValue();
/* 169 */       this.termAtt.copyBuffer(this.resultTokenBuffer, start, this.endPosition - start);
/* 170 */       this.offsetAtt.setOffset(correctOffset(start), correctOffset(this.endPosition));
/* 171 */       this.skipped += 1;
/* 172 */       return true;
/*     */     }
/*     */ 
/* 175 */     return false;
/*     */   }
/*     */ 
/*     */   public final void end() throws IOException
/*     */   {
/* 180 */     super.end();
/*     */ 
/* 182 */     this.offsetAtt.setOffset(this.finalOffset, this.finalOffset);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 187 */     super.reset();
/* 188 */     this.resultToken.setLength(0);
/* 189 */     this.finalOffset = 0;
/* 190 */     this.endPosition = 0;
/* 191 */     this.skipped = 0;
/* 192 */     this.delimitersCount = -1;
/* 193 */     this.delimiterPositions.clear();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.path.ReversePathHierarchyTokenizer
 * JD-Core Version:    0.6.2
 */