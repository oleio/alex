/*    */ package org.apache.lucene.analysis.path;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.Tokenizer;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public class PathHierarchyTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   private final char delimiter;
/*    */   private final char replacement;
/*    */   private final boolean reverse;
/*    */   private final int skip;
/*    */ 
/*    */   public PathHierarchyTokenizerFactory(Map<String, String> args)
/*    */   {
/* 79 */     super(args);
/* 80 */     this.delimiter = getChar(args, "delimiter", '/');
/* 81 */     this.replacement = getChar(args, "replace", this.delimiter);
/* 82 */     this.reverse = getBoolean(args, "reverse", false);
/* 83 */     this.skip = getInt(args, "skip", 0);
/* 84 */     if (!args.isEmpty())
/* 85 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public Tokenizer create(AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 91 */     if (this.reverse) {
/* 92 */       return new ReversePathHierarchyTokenizer(factory, input, this.delimiter, this.replacement, this.skip);
/*    */     }
/* 94 */     return new PathHierarchyTokenizer(factory, input, this.delimiter, this.replacement, this.skip);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.path.PathHierarchyTokenizerFactory
 * JD-Core Version:    0.6.2
 */