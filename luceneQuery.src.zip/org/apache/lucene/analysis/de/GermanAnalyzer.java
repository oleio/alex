/*     */ package org.apache.lucene.analysis.de;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.snowball.SnowballFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.analysis.util.WordlistLoader;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.tartarus.snowball.ext.German2Stemmer;
/*     */ 
/*     */ public final class GermanAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */ 
/*     */   @Deprecated
/*  71 */   private static final String[] GERMAN_STOP_WORDS = { "einer", "eine", "eines", "einem", "einen", "der", "die", "das", "dass", "daß", "du", "er", "sie", "es", "was", "wer", "wie", "wir", "und", "oder", "ohne", "mit", "am", "im", "in", "aus", "auf", "ist", "sein", "war", "wird", "ihr", "ihre", "ihres", "als", "für", "von", "mit", "dich", "dir", "mich", "mir", "mein", "sein", "kein", "durch", "wegen", "wird" };
/*     */   public static final String DEFAULT_STOPWORD_FILE = "german_stop.txt";
/*     */   private final CharArraySet exclusionSet;
/*     */ 
/*     */   public static final CharArraySet getDefaultStopSet()
/*     */   {
/*  94 */     return DefaultSetHolder.DEFAULT_SET;
/*     */   }
/*     */ 
/*     */   public GermanAnalyzer(Version matchVersion)
/*     */   {
/* 129 */     this(matchVersion, matchVersion.onOrAfter(Version.LUCENE_31) ? DefaultSetHolder.DEFAULT_SET : DefaultSetHolder.DEFAULT_SET_30);
/*     */   }
/*     */ 
/*     */   public GermanAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/* 143 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public GermanAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/* 157 */     super(matchVersion, stopwords);
/* 158 */     this.exclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 175 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 176 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/* 177 */     result = new LowerCaseFilter(this.matchVersion, result);
/* 178 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 179 */     result = new SetKeywordMarkerFilter(result, this.exclusionSet);
/* 180 */     if (this.matchVersion.onOrAfter(Version.LUCENE_36)) {
/* 181 */       result = new GermanNormalizationFilter(result);
/* 182 */       result = new GermanLightStemFilter(result);
/* 183 */     } else if (this.matchVersion.onOrAfter(Version.LUCENE_31)) {
/* 184 */       result = new SnowballFilter(result, new German2Stemmer());
/*     */     } else {
/* 186 */       result = new GermanStemFilter(result);
/*     */     }
/* 188 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */ 
/*     */     @Deprecated
/* 100 */     private static final CharArraySet DEFAULT_SET_30 = CharArraySet.unmodifiableSet(new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(GermanAnalyzer.GERMAN_STOP_WORDS), false));
/*     */     private static final CharArraySet DEFAULT_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/* 105 */         DEFAULT_SET = WordlistLoader.getSnowballWordSet(IOUtils.getDecodingReader(SnowballFilter.class, "german_stop.txt", StandardCharsets.UTF_8), Version.LUCENE_CURRENT);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 110 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.de.GermanAnalyzer
 * JD-Core Version:    0.6.2
 */