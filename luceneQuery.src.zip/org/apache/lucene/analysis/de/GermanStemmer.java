/*     */ package org.apache.lucene.analysis.de;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class GermanStemmer
/*     */ {
/*  37 */   private StringBuilder sb = new StringBuilder();
/*     */ 
/*  42 */   private int substCount = 0;
/*     */ 
/*  44 */   private static final Locale locale = new Locale("de", "DE");
/*     */ 
/*     */   protected String stem(String term)
/*     */   {
/*  55 */     term = term.toLowerCase(locale);
/*  56 */     if (!isStemmable(term)) {
/*  57 */       return term;
/*     */     }
/*  59 */     this.sb.delete(0, this.sb.length());
/*  60 */     this.sb.insert(0, term);
/*     */ 
/*  62 */     substitute(this.sb);
/*  63 */     strip(this.sb);
/*  64 */     optimize(this.sb);
/*  65 */     resubstitute(this.sb);
/*  66 */     removeParticleDenotion(this.sb);
/*  67 */     return this.sb.toString();
/*     */   }
/*     */ 
/*     */   private boolean isStemmable(String term)
/*     */   {
/*  77 */     for (int c = 0; c < term.length(); c++) {
/*  78 */       if (!Character.isLetter(term.charAt(c)))
/*  79 */         return false;
/*     */     }
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */   private void strip(StringBuilder buffer)
/*     */   {
/*  94 */     boolean doMore = true;
/*  95 */     while ((doMore) && (buffer.length() > 3))
/*  96 */       if ((buffer.length() + this.substCount > 5) && (buffer.substring(buffer.length() - 2, buffer.length()).equals("nd")))
/*     */       {
/*  99 */         buffer.delete(buffer.length() - 2, buffer.length());
/*     */       }
/* 101 */       else if ((buffer.length() + this.substCount > 4) && (buffer.substring(buffer.length() - 2, buffer.length()).equals("em")))
/*     */       {
/* 103 */         buffer.delete(buffer.length() - 2, buffer.length());
/*     */       }
/* 105 */       else if ((buffer.length() + this.substCount > 4) && (buffer.substring(buffer.length() - 2, buffer.length()).equals("er")))
/*     */       {
/* 107 */         buffer.delete(buffer.length() - 2, buffer.length());
/*     */       }
/* 109 */       else if (buffer.charAt(buffer.length() - 1) == 'e') {
/* 110 */         buffer.deleteCharAt(buffer.length() - 1);
/*     */       }
/* 112 */       else if (buffer.charAt(buffer.length() - 1) == 's') {
/* 113 */         buffer.deleteCharAt(buffer.length() - 1);
/*     */       }
/* 115 */       else if (buffer.charAt(buffer.length() - 1) == 'n') {
/* 116 */         buffer.deleteCharAt(buffer.length() - 1);
/*     */       }
/* 119 */       else if (buffer.charAt(buffer.length() - 1) == 't') {
/* 120 */         buffer.deleteCharAt(buffer.length() - 1);
/*     */       }
/*     */       else
/* 123 */         doMore = false;
/*     */   }
/*     */ 
/*     */   private void optimize(StringBuilder buffer)
/*     */   {
/* 135 */     if ((buffer.length() > 5) && (buffer.substring(buffer.length() - 5, buffer.length()).equals("erin*"))) {
/* 136 */       buffer.deleteCharAt(buffer.length() - 1);
/* 137 */       strip(buffer);
/*     */     }
/*     */ 
/* 141 */     if ((buffer.length() > 0) && (buffer.charAt(buffer.length() - 1) == 'z'))
/* 142 */       buffer.setCharAt(buffer.length() - 1, 'x');
/*     */   }
/*     */ 
/*     */   private void removeParticleDenotion(StringBuilder buffer)
/*     */   {
/* 151 */     if (buffer.length() > 4)
/* 152 */       for (int c = 0; c < buffer.length() - 3; c++)
/* 153 */         if (buffer.substring(c, c + 4).equals("gege")) {
/* 154 */           buffer.delete(c, c + 2);
/* 155 */           return;
/*     */         }
/*     */   }
/*     */ 
/*     */   private void substitute(StringBuilder buffer)
/*     */   {
/* 173 */     this.substCount = 0;
/* 174 */     for (int c = 0; c < buffer.length(); c++)
/*     */     {
/* 176 */       if ((c > 0) && (buffer.charAt(c) == buffer.charAt(c - 1))) {
/* 177 */         buffer.setCharAt(c, '*');
/*     */       }
/* 180 */       else if (buffer.charAt(c) == 'ä') {
/* 181 */         buffer.setCharAt(c, 'a');
/*     */       }
/* 183 */       else if (buffer.charAt(c) == 'ö') {
/* 184 */         buffer.setCharAt(c, 'o');
/*     */       }
/* 186 */       else if (buffer.charAt(c) == 'ü') {
/* 187 */         buffer.setCharAt(c, 'u');
/*     */       }
/* 190 */       else if (buffer.charAt(c) == 'ß') {
/* 191 */         buffer.setCharAt(c, 's');
/* 192 */         buffer.insert(c + 1, 's');
/* 193 */         this.substCount += 1;
/*     */       }
/*     */ 
/* 196 */       if (c < buffer.length() - 1)
/*     */       {
/* 198 */         if ((c < buffer.length() - 2) && (buffer.charAt(c) == 's') && (buffer.charAt(c + 1) == 'c') && (buffer.charAt(c + 2) == 'h'))
/*     */         {
/* 201 */           buffer.setCharAt(c, '$');
/* 202 */           buffer.delete(c + 1, c + 3);
/* 203 */           this.substCount = 2;
/*     */         }
/* 205 */         else if ((buffer.charAt(c) == 'c') && (buffer.charAt(c + 1) == 'h')) {
/* 206 */           buffer.setCharAt(c, '§');
/* 207 */           buffer.deleteCharAt(c + 1);
/* 208 */           this.substCount += 1;
/*     */         }
/* 210 */         else if ((buffer.charAt(c) == 'e') && (buffer.charAt(c + 1) == 'i')) {
/* 211 */           buffer.setCharAt(c, '%');
/* 212 */           buffer.deleteCharAt(c + 1);
/* 213 */           this.substCount += 1;
/*     */         }
/* 215 */         else if ((buffer.charAt(c) == 'i') && (buffer.charAt(c + 1) == 'e')) {
/* 216 */           buffer.setCharAt(c, '&');
/* 217 */           buffer.deleteCharAt(c + 1);
/* 218 */           this.substCount += 1;
/*     */         }
/* 220 */         else if ((buffer.charAt(c) == 'i') && (buffer.charAt(c + 1) == 'g')) {
/* 221 */           buffer.setCharAt(c, '#');
/* 222 */           buffer.deleteCharAt(c + 1);
/* 223 */           this.substCount += 1;
/*     */         }
/* 225 */         else if ((buffer.charAt(c) == 's') && (buffer.charAt(c + 1) == 't')) {
/* 226 */           buffer.setCharAt(c, '!');
/* 227 */           buffer.deleteCharAt(c + 1);
/* 228 */           this.substCount += 1;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void resubstitute(StringBuilder buffer)
/*     */   {
/* 241 */     for (int c = 0; c < buffer.length(); c++)
/* 242 */       if (buffer.charAt(c) == '*') {
/* 243 */         char x = buffer.charAt(c - 1);
/* 244 */         buffer.setCharAt(c, x);
/*     */       }
/* 246 */       else if (buffer.charAt(c) == '$') {
/* 247 */         buffer.setCharAt(c, 's');
/* 248 */         buffer.insert(c + 1, new char[] { 'c', 'h' }, 0, 2);
/*     */       }
/* 250 */       else if (buffer.charAt(c) == '§') {
/* 251 */         buffer.setCharAt(c, 'c');
/* 252 */         buffer.insert(c + 1, 'h');
/*     */       }
/* 254 */       else if (buffer.charAt(c) == '%') {
/* 255 */         buffer.setCharAt(c, 'e');
/* 256 */         buffer.insert(c + 1, 'i');
/*     */       }
/* 258 */       else if (buffer.charAt(c) == '&') {
/* 259 */         buffer.setCharAt(c, 'i');
/* 260 */         buffer.insert(c + 1, 'e');
/*     */       }
/* 262 */       else if (buffer.charAt(c) == '#') {
/* 263 */         buffer.setCharAt(c, 'i');
/* 264 */         buffer.insert(c + 1, 'g');
/*     */       }
/* 266 */       else if (buffer.charAt(c) == '!') {
/* 267 */         buffer.setCharAt(c, 's');
/* 268 */         buffer.insert(c + 1, 't');
/*     */       }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.de.GermanStemmer
 * JD-Core Version:    0.6.2
 */