/*     */ package org.apache.lucene.analysis.wikipedia;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.FlagsAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ 
/*     */ public final class WikipediaTokenizer extends Tokenizer
/*     */ {
/*     */   public static final String INTERNAL_LINK = "il";
/*     */   public static final String EXTERNAL_LINK = "el";
/*     */   public static final String EXTERNAL_LINK_URL = "elu";
/*     */   public static final String CITATION = "ci";
/*     */   public static final String CATEGORY = "c";
/*     */   public static final String BOLD = "b";
/*     */   public static final String ITALICS = "i";
/*     */   public static final String BOLD_ITALICS = "bi";
/*     */   public static final String HEADING = "h";
/*     */   public static final String SUB_HEADING = "sh";
/*     */   public static final int ALPHANUM_ID = 0;
/*     */   public static final int APOSTROPHE_ID = 1;
/*     */   public static final int ACRONYM_ID = 2;
/*     */   public static final int COMPANY_ID = 3;
/*     */   public static final int EMAIL_ID = 4;
/*     */   public static final int HOST_ID = 5;
/*     */   public static final int NUM_ID = 6;
/*     */   public static final int CJ_ID = 7;
/*     */   public static final int INTERNAL_LINK_ID = 8;
/*     */   public static final int EXTERNAL_LINK_ID = 9;
/*     */   public static final int CITATION_ID = 10;
/*     */   public static final int CATEGORY_ID = 11;
/*     */   public static final int BOLD_ID = 12;
/*     */   public static final int ITALICS_ID = 13;
/*     */   public static final int BOLD_ITALICS_ID = 14;
/*     */   public static final int HEADING_ID = 15;
/*     */   public static final int SUB_HEADING_ID = 16;
/*     */   public static final int EXTERNAL_LINK_URL_ID = 17;
/*  73 */   public static final String[] TOKEN_TYPES = { "<ALPHANUM>", "<APOSTROPHE>", "<ACRONYM>", "<COMPANY>", "<EMAIL>", "<HOST>", "<NUM>", "<CJ>", "il", "el", "ci", "c", "b", "i", "bi", "h", "sh", "elu" };
/*     */   public static final int TOKENS_ONLY = 0;
/*     */   public static final int UNTOKENIZED_ONLY = 1;
/*     */   public static final int BOTH = 2;
/*     */   public static final int UNTOKENIZED_TOKEN_FLAG = 1;
/*     */   private final WikipediaTokenizerImpl scanner;
/* 115 */   private int tokenOutput = 0;
/* 116 */   private Set<String> untokenizedTypes = Collections.emptySet();
/* 117 */   private Iterator<AttributeSource.State> tokens = null;
/*     */ 
/* 119 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 120 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/* 121 */   private final PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/* 122 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 123 */   private final FlagsAttribute flagsAtt = (FlagsAttribute)addAttribute(FlagsAttribute.class);
/*     */   private boolean first;
/*     */ 
/*     */   public WikipediaTokenizer(Reader input)
/*     */   {
/* 134 */     this(input, 0, Collections.emptySet());
/*     */   }
/*     */ 
/*     */   public WikipediaTokenizer(Reader input, int tokenOutput, Set<String> untokenizedTypes)
/*     */   {
/* 145 */     super(input);
/* 146 */     this.scanner = new WikipediaTokenizerImpl(this.input);
/* 147 */     init(tokenOutput, untokenizedTypes);
/*     */   }
/*     */ 
/*     */   public WikipediaTokenizer(AttributeSource.AttributeFactory factory, Reader input, int tokenOutput, Set<String> untokenizedTypes)
/*     */   {
/* 158 */     super(factory, input);
/* 159 */     this.scanner = new WikipediaTokenizerImpl(this.input);
/* 160 */     init(tokenOutput, untokenizedTypes);
/*     */   }
/*     */ 
/*     */   private void init(int tokenOutput, Set<String> untokenizedTypes)
/*     */   {
/* 165 */     if ((tokenOutput != 0) && (tokenOutput != 1) && (tokenOutput != 2))
/*     */     {
/* 168 */       throw new IllegalArgumentException("tokenOutput must be TOKENS_ONLY, UNTOKENIZED_ONLY or BOTH");
/*     */     }
/* 170 */     this.tokenOutput = tokenOutput;
/* 171 */     this.untokenizedTypes = untokenizedTypes;
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 181 */     if ((this.tokens != null) && (this.tokens.hasNext())) {
/* 182 */       AttributeSource.State state = (AttributeSource.State)this.tokens.next();
/* 183 */       restoreState(state);
/* 184 */       return true;
/*     */     }
/* 186 */     clearAttributes();
/* 187 */     int tokenType = this.scanner.getNextToken();
/*     */ 
/* 189 */     if (tokenType == -1) {
/* 190 */       return false;
/*     */     }
/* 192 */     String type = WikipediaTokenizerImpl.TOKEN_TYPES[tokenType];
/* 193 */     if ((this.tokenOutput == 0) || (!this.untokenizedTypes.contains(type)))
/* 194 */       setupToken();
/* 195 */     else if ((this.tokenOutput == 1) && (this.untokenizedTypes.contains(type) == true)) {
/* 196 */       collapseTokens(tokenType);
/*     */     }
/* 199 */     else if (this.tokenOutput == 2)
/*     */     {
/* 202 */       collapseAndSaveTokens(tokenType, type);
/*     */     }
/* 204 */     int posinc = this.scanner.getPositionIncrement();
/* 205 */     if ((this.first) && (posinc == 0)) {
/* 206 */       posinc = 1;
/*     */     }
/* 208 */     this.posIncrAtt.setPositionIncrement(posinc);
/* 209 */     this.typeAtt.setType(type);
/* 210 */     this.first = false;
/* 211 */     return true;
/*     */   }
/*     */ 
/*     */   private void collapseAndSaveTokens(int tokenType, String type) throws IOException
/*     */   {
/* 216 */     StringBuilder buffer = new StringBuilder(32);
/* 217 */     int numAdded = this.scanner.setText(buffer);
/*     */ 
/* 219 */     int theStart = this.scanner.yychar();
/* 220 */     int lastPos = theStart + numAdded;
/*     */ 
/* 222 */     int numSeen = 0;
/* 223 */     List tmp = new ArrayList();
/* 224 */     setupSavedToken(0, type);
/* 225 */     tmp.add(captureState());
/*     */     int tmpTokType;
/* 227 */     while (((tmpTokType = this.scanner.getNextToken()) != -1) && (tmpTokType == tokenType) && (this.scanner.getNumWikiTokensSeen() > numSeen)) {
/* 228 */       int currPos = this.scanner.yychar();
/*     */ 
/* 230 */       for (int i = 0; i < currPos - lastPos; i++) {
/* 231 */         buffer.append(' ');
/*     */       }
/* 233 */       numAdded = this.scanner.setText(buffer);
/* 234 */       setupSavedToken(this.scanner.getPositionIncrement(), type);
/* 235 */       tmp.add(captureState());
/* 236 */       numSeen++;
/* 237 */       lastPos = currPos + numAdded;
/*     */     }
/*     */ 
/* 241 */     String s = buffer.toString().trim();
/* 242 */     this.termAtt.setEmpty().append(s);
/* 243 */     this.offsetAtt.setOffset(correctOffset(theStart), correctOffset(theStart + s.length()));
/* 244 */     this.flagsAtt.setFlags(1);
/*     */ 
/* 246 */     if (tmpTokType != -1) {
/* 247 */       this.scanner.yypushback(this.scanner.yylength());
/*     */     }
/* 249 */     this.tokens = tmp.iterator();
/*     */   }
/*     */ 
/*     */   private void setupSavedToken(int positionInc, String type) {
/* 253 */     setupToken();
/* 254 */     this.posIncrAtt.setPositionIncrement(positionInc);
/* 255 */     this.typeAtt.setType(type);
/*     */   }
/*     */ 
/*     */   private void collapseTokens(int tokenType) throws IOException
/*     */   {
/* 260 */     StringBuilder buffer = new StringBuilder(32);
/* 261 */     int numAdded = this.scanner.setText(buffer);
/*     */ 
/* 263 */     int theStart = this.scanner.yychar();
/* 264 */     int lastPos = theStart + numAdded;
/*     */ 
/* 266 */     int numSeen = 0;
/*     */     int tmpTokType;
/* 268 */     while (((tmpTokType = this.scanner.getNextToken()) != -1) && (tmpTokType == tokenType) && (this.scanner.getNumWikiTokensSeen() > numSeen)) {
/* 269 */       int currPos = this.scanner.yychar();
/*     */ 
/* 271 */       for (int i = 0; i < currPos - lastPos; i++) {
/* 272 */         buffer.append(' ');
/*     */       }
/* 274 */       numAdded = this.scanner.setText(buffer);
/* 275 */       numSeen++;
/* 276 */       lastPos = currPos + numAdded;
/*     */     }
/*     */ 
/* 280 */     String s = buffer.toString().trim();
/* 281 */     this.termAtt.setEmpty().append(s);
/* 282 */     this.offsetAtt.setOffset(correctOffset(theStart), correctOffset(theStart + s.length()));
/* 283 */     this.flagsAtt.setFlags(1);
/*     */ 
/* 285 */     if (tmpTokType != -1)
/* 286 */       this.scanner.yypushback(this.scanner.yylength());
/*     */     else
/* 288 */       this.tokens = null;
/*     */   }
/*     */ 
/*     */   private void setupToken()
/*     */   {
/* 293 */     this.scanner.getText(this.termAtt);
/* 294 */     int start = this.scanner.yychar();
/* 295 */     this.offsetAtt.setOffset(correctOffset(start), correctOffset(start + this.termAtt.length()));
/*     */   }
/*     */ 
/*     */   public void close() throws IOException
/*     */   {
/* 300 */     super.close();
/* 301 */     this.scanner.yyreset(this.input);
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 311 */     super.reset();
/* 312 */     this.scanner.yyreset(this.input);
/* 313 */     this.tokens = null;
/* 314 */     this.scanner.reset();
/* 315 */     this.first = true;
/*     */   }
/*     */ 
/*     */   public void end() throws IOException
/*     */   {
/* 320 */     super.end();
/*     */ 
/* 322 */     int finalOffset = correctOffset(this.scanner.yychar() + this.scanner.yylength());
/* 323 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.wikipedia.WikipediaTokenizer
 * JD-Core Version:    0.6.2
 */