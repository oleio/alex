/*     */ package org.apache.lucene.analysis.wikipedia;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ 
/*     */ class WikipediaTokenizerImpl
/*     */ {
/*     */   public static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 4096;
/*     */   public static final int YYINITIAL = 0;
/*     */   public static final int CATEGORY_STATE = 2;
/*     */   public static final int INTERNAL_LINK_STATE = 4;
/*     */   public static final int EXTERNAL_LINK_STATE = 6;
/*     */   public static final int TWO_SINGLE_QUOTES_STATE = 8;
/*     */   public static final int THREE_SINGLE_QUOTES_STATE = 10;
/*     */   public static final int FIVE_SINGLE_QUOTES_STATE = 12;
/*     */   public static final int DOUBLE_EQUALS_STATE = 14;
/*     */   public static final int DOUBLE_BRACE_STATE = 16;
/*     */   public static final int STRING = 18;
/*  54 */   private static final int[] ZZ_LEXSTATE = { 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9 };
/*     */   private static final String ZZ_CMAP_PACKED = "";
/*  79 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*     */ 
/*  84 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */   private static final String ZZ_ACTION_PACKED_0 = "";
/* 122 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/* 170 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */   private static final String ZZ_TRANS_PACKED_0 = "";
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/* 342 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*     */ 
/* 351 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/* 389 */   private int zzLexicalState = 0;
/*     */ 
/* 393 */   private char[] zzBuffer = new char[4096];
/*     */   private int zzMarkedPos;
/*     */   private int zzCurrentPos;
/*     */   private int zzStartRead;
/*     */   private int zzEndRead;
/*     */   private int yyline;
/*     */   private int yychar;
/*     */   private int yycolumn;
/* 423 */   private boolean zzAtBOL = true;
/*     */   private boolean zzAtEOF;
/*     */   private boolean zzEOFDone;
/*     */   public static final int ALPHANUM = 0;
/*     */   public static final int APOSTROPHE = 1;
/*     */   public static final int ACRONYM = 2;
/*     */   public static final int COMPANY = 3;
/*     */   public static final int EMAIL = 4;
/*     */   public static final int HOST = 5;
/*     */   public static final int NUM = 6;
/*     */   public static final int CJ = 7;
/*     */   public static final int INTERNAL_LINK = 8;
/*     */   public static final int EXTERNAL_LINK = 9;
/*     */   public static final int CITATION = 10;
/*     */   public static final int CATEGORY = 11;
/*     */   public static final int BOLD = 12;
/*     */   public static final int ITALICS = 13;
/*     */   public static final int BOLD_ITALICS = 14;
/*     */   public static final int HEADING = 15;
/*     */   public static final int SUB_HEADING = 16;
/*     */   public static final int EXTERNAL_LINK_URL = 17;
/*     */   private int currentTokType;
/* 454 */   private int numBalanced = 0;
/* 455 */   private int positionInc = 1;
/* 456 */   private int numLinkToks = 0;
/*     */ 
/* 460 */   private int numWikiTokensSeen = 0;
/*     */ 
/* 462 */   public static final String[] TOKEN_TYPES = WikipediaTokenizer.TOKEN_TYPES;
/*     */ 
/*     */   private static int[] zzUnpackAction()
/*     */   {
/* 100 */     int[] result = new int['µ'];
/* 101 */     int offset = 0;
/* 102 */     offset = zzUnpackAction("", offset, result);
/* 103 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/* 107 */     int i = 0;
/* 108 */     int j = offset;
/* 109 */     int l = packed.length();
/*     */     int count;
/* 113 */     for (; i < l; 
/* 113 */       count > 0)
/*     */     {
/* 111 */       count = packed.charAt(i++);
/* 112 */       int value = packed.charAt(i++);
/* 113 */       result[(j++)] = value; count--;
/*     */     }
/* 115 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackRowMap()
/*     */   {
/* 150 */     int[] result = new int['µ'];
/* 151 */     int offset = 0;
/* 152 */     offset = zzUnpackRowMap("", offset, result);
/* 153 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 157 */     int i = 0;
/* 158 */     int j = offset;
/* 159 */     int l = packed.length();
/* 160 */     while (i < l) {
/* 161 */       int high = packed.charAt(i++) << '\020';
/* 162 */       result[(j++)] = (high | packed.charAt(i++));
/*     */     }
/* 164 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackTrans()
/*     */   {
/* 316 */     int[] result = new int[6908];
/* 317 */     int offset = 0;
/* 318 */     offset = zzUnpackTrans("", offset, result);
/* 319 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 323 */     int i = 0;
/* 324 */     int j = offset;
/* 325 */     int l = packed.length();
/*     */     int count;
/* 330 */     for (; i < l; 
/* 330 */       count > 0)
/*     */     {
/* 327 */       count = packed.charAt(i++);
/* 328 */       int value = packed.charAt(i++);
/* 329 */       value--;
/* 330 */       result[(j++)] = value; count--;
/*     */     }
/* 332 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackAttribute()
/*     */   {
/* 364 */     int[] result = new int['µ'];
/* 365 */     int offset = 0;
/* 366 */     offset = zzUnpackAttribute("", offset, result);
/* 367 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 371 */     int i = 0;
/* 372 */     int j = offset;
/* 373 */     int l = packed.length();
/*     */     int count;
/* 377 */     for (; i < l; 
/* 377 */       count > 0)
/*     */     {
/* 375 */       count = packed.charAt(i++);
/* 376 */       int value = packed.charAt(i++);
/* 377 */       result[(j++)] = value; count--;
/*     */     }
/* 379 */     return j;
/*     */   }
/*     */ 
/*     */   public final int getNumWikiTokensSeen()
/*     */   {
/* 469 */     return this.numWikiTokensSeen;
/*     */   }
/*     */ 
/*     */   public final int yychar()
/*     */   {
/* 474 */     return this.yychar;
/*     */   }
/*     */ 
/*     */   public final int getPositionIncrement() {
/* 478 */     return this.positionInc;
/*     */   }
/*     */ 
/*     */   final void getText(CharTermAttribute t)
/*     */   {
/* 485 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */   final int setText(StringBuilder buffer) {
/* 489 */     int length = this.zzMarkedPos - this.zzStartRead;
/* 490 */     buffer.append(this.zzBuffer, this.zzStartRead, length);
/* 491 */     return length;
/*     */   }
/*     */ 
/*     */   final void reset() {
/* 495 */     this.currentTokType = 0;
/* 496 */     this.numBalanced = 0;
/* 497 */     this.positionInc = 1;
/* 498 */     this.numLinkToks = 0;
/* 499 */     this.numWikiTokensSeen = 0;
/*     */   }
/*     */ 
/*     */   WikipediaTokenizerImpl(Reader in)
/*     */   {
/* 511 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */   private static char[] zzUnpackCMap(String packed)
/*     */   {
/* 522 */     char[] map = new char[65536];
/* 523 */     int i = 0;
/* 524 */     int j = 0;
/*     */     int count;
/* 528 */     for (; i < 230; 
/* 528 */       count > 0)
/*     */     {
/* 526 */       count = packed.charAt(i++);
/* 527 */       char value = packed.charAt(i++);
/* 528 */       map[(j++)] = value; count--;
/*     */     }
/* 530 */     return map;
/*     */   }
/*     */ 
/*     */   private boolean zzRefill()
/*     */     throws IOException
/*     */   {
/* 544 */     if (this.zzStartRead > 0) {
/* 545 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*     */ 
/* 550 */       this.zzEndRead -= this.zzStartRead;
/* 551 */       this.zzCurrentPos -= this.zzStartRead;
/* 552 */       this.zzMarkedPos -= this.zzStartRead;
/* 553 */       this.zzStartRead = 0;
/*     */     }
/*     */ 
/* 557 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*     */     {
/* 559 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 560 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 561 */       this.zzBuffer = newBuffer;
/*     */     }
/*     */ 
/* 565 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*     */ 
/* 568 */     if (numRead > 0) {
/* 569 */       this.zzEndRead += numRead;
/* 570 */       return false;
/*     */     }
/*     */ 
/* 573 */     if (numRead == 0) {
/* 574 */       int c = this.zzReader.read();
/* 575 */       if (c == -1) {
/* 576 */         return true;
/*     */       }
/* 578 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 579 */       return false;
/*     */     }
/*     */ 
/* 584 */     return true;
/*     */   }
/*     */ 
/*     */   public final void yyclose()
/*     */     throws IOException
/*     */   {
/* 592 */     this.zzAtEOF = true;
/* 593 */     this.zzEndRead = this.zzStartRead;
/*     */ 
/* 595 */     if (this.zzReader != null)
/* 596 */       this.zzReader.close();
/*     */   }
/*     */ 
/*     */   public final void yyreset(Reader reader)
/*     */   {
/* 613 */     this.zzReader = reader;
/* 614 */     this.zzAtBOL = true;
/* 615 */     this.zzAtEOF = false;
/* 616 */     this.zzEOFDone = false;
/* 617 */     this.zzEndRead = (this.zzStartRead = 0);
/* 618 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/* 619 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 620 */     this.zzLexicalState = 0;
/* 621 */     if (this.zzBuffer.length > 4096)
/* 622 */       this.zzBuffer = new char[4096];
/*     */   }
/*     */ 
/*     */   public final int yystate()
/*     */   {
/* 630 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */   public final void yybegin(int newState)
/*     */   {
/* 640 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */   public final String yytext()
/*     */   {
/* 648 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */   public final char yycharat(int pos)
/*     */   {
/* 664 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*     */   }
/*     */ 
/*     */   public final int yylength()
/*     */   {
/* 672 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */   private void zzScanError(int errorCode)
/*     */   {
/*     */     String message;
/*     */     try
/*     */     {
/* 693 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 696 */       message = ZZ_ERROR_MSG[0];
/*     */     }
/*     */ 
/* 699 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */   public void yypushback(int number)
/*     */   {
/* 712 */     if (number > yylength()) {
/* 713 */       zzScanError(2);
/*     */     }
/* 715 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */   public int getNextToken()
/*     */     throws IOException
/*     */   {
/* 733 */     int zzEndReadL = this.zzEndRead;
/* 734 */     char[] zzBufferL = this.zzBuffer;
/* 735 */     char[] zzCMapL = ZZ_CMAP;
/*     */ 
/* 737 */     int[] zzTransL = ZZ_TRANS;
/* 738 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 739 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*     */     while (true)
/*     */     {
/* 742 */       int zzMarkedPosL = this.zzMarkedPos;
/*     */ 
/* 744 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*     */ 
/* 746 */       int zzAction = -1;
/*     */ 
/* 748 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */ 
/* 750 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*     */ 
/* 753 */       int zzAttributes = zzAttrL[this.zzState];
/* 754 */       if ((zzAttributes & 0x1) == 1)
/* 755 */         zzAction = this.zzState;
/*     */       int zzInput;
/*     */       while (true)
/*     */       {
/*     */         int zzInput;
/* 762 */         if (zzCurrentPosL < zzEndReadL) {
/* 763 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 764 */           if (this.zzAtEOF) {
/* 765 */             int zzInput = -1;
/* 766 */             break;
/*     */           }
/*     */ 
/* 770 */           this.zzCurrentPos = zzCurrentPosL;
/* 771 */           this.zzMarkedPos = zzMarkedPosL;
/* 772 */           boolean eof = zzRefill();
/*     */ 
/* 774 */           zzCurrentPosL = this.zzCurrentPos;
/* 775 */           zzMarkedPosL = this.zzMarkedPos;
/* 776 */           zzBufferL = this.zzBuffer;
/* 777 */           zzEndReadL = this.zzEndRead;
/* 778 */           if (eof) {
/* 779 */             int zzInput = -1;
/* 780 */             break;
/*     */           }
/*     */ 
/* 783 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*     */         }
/*     */ 
/* 786 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 787 */         if (zzNext == -1) break;
/* 788 */         this.zzState = zzNext;
/*     */ 
/* 790 */         zzAttributes = zzAttrL[this.zzState];
/* 791 */         if ((zzAttributes & 0x1) == 1) {
/* 792 */           zzAction = this.zzState;
/* 793 */           zzMarkedPosL = zzCurrentPosL;
/* 794 */           if ((zzAttributes & 0x8) == 8)
/*     */           {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 801 */       this.zzMarkedPos = zzMarkedPosL;
/*     */ 
/* 803 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*     */       case 1:
/* 805 */         this.numWikiTokensSeen = 0; this.positionInc = 1; break;
/*     */       case 47:
/* 807 */         break;
/*     */       case 2:
/* 809 */         this.positionInc = 1; return 0;
/*     */       case 48:
/* 811 */         break;
/*     */       case 3:
/* 813 */         this.positionInc = 1; return 7;
/*     */       case 49:
/* 815 */         break;
/*     */       case 4:
/* 817 */         this.numWikiTokensSeen = 0; this.positionInc = 1; this.currentTokType = 17; yybegin(6); break;
/*     */       case 50:
/* 819 */         break;
/*     */       case 5:
/* 821 */         this.positionInc = 1; break;
/*     */       case 51:
/* 823 */         break;
/*     */       case 6:
/* 825 */         yybegin(2); this.numWikiTokensSeen += 1; return this.currentTokType;
/*     */       case 52:
/* 827 */         break;
/*     */       case 7:
/* 829 */         yybegin(4); this.numWikiTokensSeen += 1; return this.currentTokType;
/*     */       case 53:
/* 831 */         break;
/*     */       case 8:
/* 833 */         break;
/*     */       case 54:
/* 835 */         break;
/*     */       case 9:
/* 837 */         if (this.numLinkToks == 0) this.positionInc = 0; else this.positionInc = 1; this.numWikiTokensSeen += 1; this.currentTokType = 9; yybegin(6); this.numLinkToks += 1; return this.currentTokType;
/*     */       case 55:
/* 839 */         break;
/*     */       case 10:
/* 841 */         this.numLinkToks = 0; this.positionInc = 0; yybegin(0); break;
/*     */       case 56:
/* 843 */         break;
/*     */       case 11:
/* 845 */         this.currentTokType = 12; yybegin(10); break;
/*     */       case 57:
/* 847 */         break;
/*     */       case 12:
/* 849 */         this.currentTokType = 13; this.numWikiTokensSeen += 1; yybegin(18); return this.currentTokType;
/*     */       case 58:
/* 851 */         break;
/*     */       case 13:
/* 853 */         this.currentTokType = 9; this.numWikiTokensSeen = 0; yybegin(6); break;
/*     */       case 59:
/* 855 */         break;
/*     */       case 14:
/* 857 */         yybegin(18); this.numWikiTokensSeen += 1; return this.currentTokType;
/*     */       case 60:
/* 859 */         break;
/*     */       case 15:
/* 861 */         this.currentTokType = 16; this.numWikiTokensSeen = 0; yybegin(18); break;
/*     */       case 61:
/* 863 */         break;
/*     */       case 16:
/* 865 */         this.currentTokType = 15; yybegin(14); this.numWikiTokensSeen += 1; return this.currentTokType;
/*     */       case 62:
/* 867 */         break;
/*     */       case 17:
/* 869 */         yybegin(16); this.numWikiTokensSeen = 0; return this.currentTokType;
/*     */       case 63:
/* 871 */         break;
/*     */       case 18:
/* 873 */         break;
/*     */       case 64:
/* 875 */         break;
/*     */       case 19:
/* 877 */         yybegin(18); this.numWikiTokensSeen += 1; return this.currentTokType;
/*     */       case 65:
/* 879 */         break;
/*     */       case 20:
/* 881 */         this.numBalanced = 0; this.numWikiTokensSeen = 0; this.currentTokType = 9; yybegin(6); break;
/*     */       case 66:
/* 883 */         break;
/*     */       case 21:
/* 885 */         yybegin(18); return this.currentTokType;
/*     */       case 67:
/* 887 */         break;
/*     */       case 22:
/* 889 */         this.numWikiTokensSeen = 0; this.positionInc = 1; if (this.numBalanced == 0) { this.numBalanced += 1; yybegin(8); } else { this.numBalanced = 0; } break;
/*     */       case 68:
/* 891 */         break;
/*     */       case 23:
/* 893 */         this.numWikiTokensSeen = 0; this.positionInc = 1; yybegin(14); break;
/*     */       case 69:
/* 895 */         break;
/*     */       case 24:
/* 897 */         this.numWikiTokensSeen = 0; this.positionInc = 1; this.currentTokType = 8; yybegin(4); break;
/*     */       case 70:
/* 899 */         break;
/*     */       case 25:
/* 901 */         this.numWikiTokensSeen = 0; this.positionInc = 1; this.currentTokType = 10; yybegin(16); break;
/*     */       case 71:
/* 903 */         break;
/*     */       case 26:
/* 905 */         yybegin(0); break;
/*     */       case 72:
/* 907 */         break;
/*     */       case 27:
/* 909 */         this.numLinkToks = 0; yybegin(0); break;
/*     */       case 73:
/* 911 */         break;
/*     */       case 28:
/* 913 */         this.currentTokType = 8; this.numWikiTokensSeen = 0; yybegin(4); break;
/*     */       case 74:
/* 915 */         break;
/*     */       case 29:
/* 917 */         this.currentTokType = 8; this.numWikiTokensSeen = 0; yybegin(4); break;
/*     */       case 75:
/* 919 */         break;
/*     */       case 30:
/* 921 */         yybegin(0); break;
/*     */       case 76:
/* 923 */         break;
/*     */       case 31:
/* 925 */         this.numBalanced = 0; this.currentTokType = 0; yybegin(0); break;
/*     */       case 77:
/* 927 */         break;
/*     */       case 32:
/* 929 */         this.numBalanced = 0; this.numWikiTokensSeen = 0; this.currentTokType = 8; yybegin(4); break;
/*     */       case 78:
/* 931 */         break;
/*     */       case 33:
/* 933 */         this.positionInc = 1; return 1;
/*     */       case 79:
/* 935 */         break;
/*     */       case 34:
/* 937 */         this.positionInc = 1; return 5;
/*     */       case 80:
/* 939 */         break;
/*     */       case 35:
/* 941 */         this.positionInc = 1; return 6;
/*     */       case 81:
/* 943 */         break;
/*     */       case 36:
/* 945 */         this.positionInc = 1; return 3;
/*     */       case 82:
/* 947 */         break;
/*     */       case 37:
/* 949 */         this.currentTokType = 14; yybegin(12); break;
/*     */       case 83:
/* 951 */         break;
/*     */       case 38:
/* 953 */         this.numBalanced = 0; this.currentTokType = 0; yybegin(0); break;
/*     */       case 84:
/* 955 */         break;
/*     */       case 39:
/* 957 */         this.numBalanced = 0; this.currentTokType = 0; yybegin(0); break;
/*     */       case 85:
/* 959 */         break;
/*     */       case 40:
/* 961 */         this.positionInc = 1; return 2;
/*     */       case 86:
/* 963 */         break;
/*     */       case 41:
/* 965 */         this.positionInc = 1; return 4;
/*     */       case 87:
/* 967 */         break;
/*     */       case 42:
/* 969 */         this.numBalanced = 0; this.currentTokType = 0; yybegin(0); break;
/*     */       case 88:
/* 971 */         break;
/*     */       case 43:
/* 973 */         this.positionInc = 1; this.numWikiTokensSeen += 1; yybegin(6); return this.currentTokType;
/*     */       case 89:
/* 975 */         break;
/*     */       case 44:
/* 977 */         this.numWikiTokensSeen = 0; this.positionInc = 1; this.currentTokType = 11; yybegin(2); break;
/*     */       case 90:
/* 979 */         break;
/*     */       case 45:
/* 981 */         this.currentTokType = 11; this.numWikiTokensSeen = 0; yybegin(2); break;
/*     */       case 91:
/* 983 */         break;
/*     */       case 46:
/* 985 */         this.numBalanced = 0; this.numWikiTokensSeen = 0; this.currentTokType = 11; yybegin(2); break;
/*     */       case 92:
/* 987 */         break;
/*     */       default:
/* 989 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 990 */           this.zzAtEOF = true;
/* 991 */           return -1;
/*     */         }
/*     */ 
/* 994 */         zzScanError(1);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.wikipedia.WikipediaTokenizerImpl
 * JD-Core Version:    0.6.2
 */