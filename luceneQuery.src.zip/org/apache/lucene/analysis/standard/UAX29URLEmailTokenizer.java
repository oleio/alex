/*     */ package org.apache.lucene.analysis.standard;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.standard.std31.UAX29URLEmailTokenizerImpl31;
/*     */ import org.apache.lucene.analysis.standard.std34.UAX29URLEmailTokenizerImpl34;
/*     */ import org.apache.lucene.analysis.standard.std36.UAX29URLEmailTokenizerImpl36;
/*     */ import org.apache.lucene.analysis.standard.std40.UAX29URLEmailTokenizerImpl40;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class UAX29URLEmailTokenizer extends Tokenizer
/*     */ {
/*     */   private final StandardTokenizerInterface scanner;
/*     */   public static final int ALPHANUM = 0;
/*     */   public static final int NUM = 1;
/*     */   public static final int SOUTHEAST_ASIAN = 2;
/*     */   public static final int IDEOGRAPHIC = 3;
/*     */   public static final int HIRAGANA = 4;
/*     */   public static final int KATAKANA = 5;
/*     */   public static final int HANGUL = 6;
/*     */   public static final int URL = 7;
/*     */   public static final int EMAIL = 8;
/*  76 */   public static final String[] TOKEN_TYPES = { StandardTokenizer.TOKEN_TYPES[0], StandardTokenizer.TOKEN_TYPES[6], StandardTokenizer.TOKEN_TYPES[9], StandardTokenizer.TOKEN_TYPES[10], StandardTokenizer.TOKEN_TYPES[11], StandardTokenizer.TOKEN_TYPES[12], StandardTokenizer.TOKEN_TYPES[13], "<URL>", "<EMAIL>" };
/*     */   private int skippedPositions;
/*  90 */   private int maxTokenLength = 255;
/*     */ 
/* 142 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 143 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 144 */   private final PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/* 145 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/*     */ 
/*     */   public void setMaxTokenLength(int length)
/*     */   {
/*  95 */     if (length < 1) {
/*  96 */       throw new IllegalArgumentException("maxTokenLength must be greater than zero");
/*     */     }
/*  98 */     this.maxTokenLength = length;
/*     */   }
/*     */ 
/*     */   public int getMaxTokenLength()
/*     */   {
/* 103 */     return this.maxTokenLength;
/*     */   }
/*     */ 
/*     */   public UAX29URLEmailTokenizer(Version matchVersion, Reader input)
/*     */   {
/* 113 */     super(input);
/* 114 */     this.scanner = getScannerFor(matchVersion);
/*     */   }
/*     */ 
/*     */   public UAX29URLEmailTokenizer(Version matchVersion, AttributeSource.AttributeFactory factory, Reader input)
/*     */   {
/* 121 */     super(factory, input);
/* 122 */     this.scanner = getScannerFor(matchVersion);
/*     */   }
/*     */ 
/*     */   private StandardTokenizerInterface getScannerFor(Version matchVersion)
/*     */   {
/* 127 */     if (matchVersion.onOrAfter(Version.LUCENE_47))
/* 128 */       return new UAX29URLEmailTokenizerImpl(this.input);
/* 129 */     if (matchVersion.onOrAfter(Version.LUCENE_40))
/* 130 */       return new UAX29URLEmailTokenizerImpl40(this.input);
/* 131 */     if (matchVersion.onOrAfter(Version.LUCENE_36))
/* 132 */       return new UAX29URLEmailTokenizerImpl36(this.input);
/* 133 */     if (matchVersion.onOrAfter(Version.LUCENE_34)) {
/* 134 */       return new UAX29URLEmailTokenizerImpl34(this.input);
/*     */     }
/* 136 */     return new UAX29URLEmailTokenizerImpl31(this.input);
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 149 */     clearAttributes();
/* 150 */     this.skippedPositions = 0;
/*     */     while (true)
/*     */     {
/* 153 */       int tokenType = this.scanner.getNextToken();
/*     */ 
/* 155 */       if (tokenType == -1) {
/* 156 */         return false;
/*     */       }
/*     */ 
/* 159 */       if (this.scanner.yylength() <= this.maxTokenLength) {
/* 160 */         this.posIncrAtt.setPositionIncrement(this.skippedPositions + 1);
/* 161 */         this.scanner.getText(this.termAtt);
/* 162 */         int start = this.scanner.yychar();
/* 163 */         this.offsetAtt.setOffset(correctOffset(start), correctOffset(start + this.termAtt.length()));
/* 164 */         this.typeAtt.setType(TOKEN_TYPES[tokenType]);
/* 165 */         return true;
/*     */       }
/*     */ 
/* 169 */       this.skippedPositions += 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void end() throws IOException
/*     */   {
/* 175 */     super.end();
/*     */ 
/* 177 */     int finalOffset = correctOffset(this.scanner.yychar() + this.scanner.yylength());
/* 178 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */ 
/* 180 */     this.posIncrAtt.setPositionIncrement(this.posIncrAtt.getPositionIncrement() + this.skippedPositions);
/*     */   }
/*     */ 
/*     */   public void close() throws IOException
/*     */   {
/* 185 */     super.close();
/* 186 */     this.scanner.yyreset(this.input);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 191 */     super.reset();
/* 192 */     this.scanner.yyreset(this.input);
/* 193 */     this.skippedPositions = 0;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.UAX29URLEmailTokenizer
 * JD-Core Version:    0.6.2
 */