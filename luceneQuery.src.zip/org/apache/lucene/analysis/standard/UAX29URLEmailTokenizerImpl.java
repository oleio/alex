/*      */ package org.apache.lucene.analysis.standard;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*      */ 
/*      */ public final class UAX29URLEmailTokenizerImpl
/*      */   implements StandardTokenizerInterface
/*      */ {
/*      */   public static final int YYEOF = -1;
/*      */   private static final int ZZ_BUFFERSIZE = 4096;
/*      */   public static final int YYINITIAL = 0;
/*      */   public static final int AVOID_BAD_URL = 2;
/*   63 */   private static final int[] ZZ_LEXSTATE = { 0, 0, 1, 1 };
/*      */   private static final String ZZ_CMAP_PACKED = "";
/*  227 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*      */ 
/*  232 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*      */   private static final String ZZ_ACTION_PACKED_0 = "";
/*  297 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*      */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/*  712 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*      */   private static final String ZZ_TRANS_PACKED_0 = "";
/*      */   private static final String ZZ_TRANS_PACKED_1 = "";
/*      */   private static final String ZZ_TRANS_PACKED_2 = "";
/*      */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*      */   private static final int ZZ_NO_MATCH = 1;
/*      */   private static final int ZZ_PUSHBACK_2BIG = 2;
/* 8988 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*      */ 
/* 8997 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*      */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*      */   private Reader zzReader;
/*      */   private int zzState;
/* 9056 */   private int zzLexicalState = 0;
/*      */ 
/* 9060 */   private char[] zzBuffer = new char[4096];
/*      */   private int zzMarkedPos;
/*      */   private int zzCurrentPos;
/*      */   private int zzStartRead;
/*      */   private int zzEndRead;
/*      */   private int yyline;
/*      */   private int yychar;
/*      */   private int yycolumn;
/* 9090 */   private boolean zzAtBOL = true;
/*      */   private boolean zzAtEOF;
/*      */   private boolean zzEOFDone;
/*      */   public static final int WORD_TYPE = 0;
/*      */   public static final int NUMERIC_TYPE = 1;
/*      */   public static final int SOUTH_EAST_ASIAN_TYPE = 2;
/*      */   public static final int IDEOGRAPHIC_TYPE = 3;
/*      */   public static final int HIRAGANA_TYPE = 4;
/*      */   public static final int KATAKANA_TYPE = 5;
/*      */   public static final int HANGUL_TYPE = 6;
/*      */   public static final int EMAIL_TYPE = 8;
/*      */   public static final int URL_TYPE = 7;
/*      */ 
/*      */   private static int[] zzUnpackAction()
/*      */   {
/*  275 */     int[] result = new int[3116];
/*  276 */     int offset = 0;
/*  277 */     offset = zzUnpackAction("", offset, result);
/*  278 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  282 */     int i = 0;
/*  283 */     int j = offset;
/*  284 */     int l = packed.length();
/*      */     int count;
/*  288 */     for (; i < l; 
/*  288 */       count > 0)
/*      */     {
/*  286 */       count = packed.charAt(i++);
/*  287 */       int value = packed.charAt(i++);
/*  288 */       result[(j++)] = value; count--;
/*      */     }
/*  290 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackRowMap()
/*      */   {
/*  692 */     int[] result = new int[3116];
/*  693 */     int offset = 0;
/*  694 */     offset = zzUnpackRowMap("", offset, result);
/*  695 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/*  699 */     int i = 0;
/*  700 */     int j = offset;
/*  701 */     int l = packed.length();
/*  702 */     while (i < l) {
/*  703 */       int high = packed.charAt(i++) << '\020';
/*  704 */       result[(j++)] = (high | packed.charAt(i++));
/*      */     }
/*  706 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackTrans()
/*      */   {
/* 8960 */     int[] result = new int[614169];
/* 8961 */     int offset = 0;
/* 8962 */     offset = zzUnpackTrans("", offset, result);
/* 8963 */     offset = zzUnpackTrans("", offset, result);
/* 8964 */     offset = zzUnpackTrans("", offset, result);
/* 8965 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 8969 */     int i = 0;
/* 8970 */     int j = offset;
/* 8971 */     int l = packed.length();
/*      */     int count;
/* 8976 */     for (; i < l; 
/* 8976 */       count > 0)
/*      */     {
/* 8973 */       count = packed.charAt(i++);
/* 8974 */       int value = packed.charAt(i++);
/* 8975 */       value--;
/* 8976 */       result[(j++)] = value; count--;
/*      */     }
/* 8978 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackAttribute()
/*      */   {
/* 9031 */     int[] result = new int[3116];
/* 9032 */     int offset = 0;
/* 9033 */     offset = zzUnpackAttribute("", offset, result);
/* 9034 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 9038 */     int i = 0;
/* 9039 */     int j = offset;
/* 9040 */     int l = packed.length();
/*      */     int count;
/* 9044 */     for (; i < l; 
/* 9044 */       count > 0)
/*      */     {
/* 9042 */       count = packed.charAt(i++);
/* 9043 */       int value = packed.charAt(i++);
/* 9044 */       result[(j++)] = value; count--;
/*      */     }
/* 9046 */     return j;
/*      */   }
/*      */ 
/*      */   public final int yychar()
/*      */   {
/* 9129 */     return this.yychar;
/*      */   }
/*      */ 
/*      */   public final void getText(CharTermAttribute t)
/*      */   {
/* 9136 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public UAX29URLEmailTokenizerImpl(Reader in)
/*      */   {
/* 9146 */     this.zzReader = in;
/*      */   }
/*      */ 
/*      */   private static char[] zzUnpackCMap(String packed)
/*      */   {
/* 9157 */     char[] map = new char[65536];
/* 9158 */     int i = 0;
/* 9159 */     int j = 0;
/*      */     int count;
/* 9163 */     for (; i < 3030; 
/* 9163 */       count > 0)
/*      */     {
/* 9161 */       count = packed.charAt(i++);
/* 9162 */       char value = packed.charAt(i++);
/* 9163 */       map[(j++)] = value; count--;
/*      */     }
/* 9165 */     return map;
/*      */   }
/*      */ 
/*      */   private boolean zzRefill()
/*      */     throws IOException
/*      */   {
/* 9179 */     if (this.zzStartRead > 0) {
/* 9180 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*      */ 
/* 9185 */       this.zzEndRead -= this.zzStartRead;
/* 9186 */       this.zzCurrentPos -= this.zzStartRead;
/* 9187 */       this.zzMarkedPos -= this.zzStartRead;
/* 9188 */       this.zzStartRead = 0;
/*      */     }
/*      */ 
/* 9192 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*      */     {
/* 9194 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 9195 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 9196 */       this.zzBuffer = newBuffer;
/*      */     }
/*      */ 
/* 9200 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*      */ 
/* 9203 */     if (numRead > 0) {
/* 9204 */       this.zzEndRead += numRead;
/* 9205 */       return false;
/*      */     }
/*      */ 
/* 9208 */     if (numRead == 0) {
/* 9209 */       int c = this.zzReader.read();
/* 9210 */       if (c == -1) {
/* 9211 */         return true;
/*      */       }
/* 9213 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 9214 */       return false;
/*      */     }
/*      */ 
/* 9219 */     return true;
/*      */   }
/*      */ 
/*      */   public final void yyclose()
/*      */     throws IOException
/*      */   {
/* 9227 */     this.zzAtEOF = true;
/* 9228 */     this.zzEndRead = this.zzStartRead;
/*      */ 
/* 9230 */     if (this.zzReader != null)
/* 9231 */       this.zzReader.close();
/*      */   }
/*      */ 
/*      */   public final void yyreset(Reader reader)
/*      */   {
/* 9248 */     this.zzReader = reader;
/* 9249 */     this.zzAtBOL = true;
/* 9250 */     this.zzAtEOF = false;
/* 9251 */     this.zzEOFDone = false;
/* 9252 */     this.zzEndRead = (this.zzStartRead = 0);
/* 9253 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/* 9254 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 9255 */     this.zzLexicalState = 0;
/* 9256 */     if (this.zzBuffer.length > 4096)
/* 9257 */       this.zzBuffer = new char[4096];
/*      */   }
/*      */ 
/*      */   public final int yystate()
/*      */   {
/* 9265 */     return this.zzLexicalState;
/*      */   }
/*      */ 
/*      */   public final void yybegin(int newState)
/*      */   {
/* 9275 */     this.zzLexicalState = newState;
/*      */   }
/*      */ 
/*      */   public final String yytext()
/*      */   {
/* 9283 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public final char yycharat(int pos)
/*      */   {
/* 9299 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*      */   }
/*      */ 
/*      */   public final int yylength()
/*      */   {
/* 9307 */     return this.zzMarkedPos - this.zzStartRead;
/*      */   }
/*      */ 
/*      */   private void zzScanError(int errorCode)
/*      */   {
/*      */     String message;
/*      */     try
/*      */     {
/* 9328 */       message = ZZ_ERROR_MSG[errorCode];
/*      */     }
/*      */     catch (ArrayIndexOutOfBoundsException e) {
/* 9331 */       message = ZZ_ERROR_MSG[0];
/*      */     }
/*      */ 
/* 9334 */     throw new Error(message);
/*      */   }
/*      */ 
/*      */   public void yypushback(int number)
/*      */   {
/* 9347 */     if (number > yylength()) {
/* 9348 */       zzScanError(2);
/*      */     }
/* 9350 */     this.zzMarkedPos -= number;
/*      */   }
/*      */ 
/*      */   public int getNextToken()
/*      */     throws IOException
/*      */   {
/* 9368 */     int zzEndReadL = this.zzEndRead;
/* 9369 */     char[] zzBufferL = this.zzBuffer;
/* 9370 */     char[] zzCMapL = ZZ_CMAP;
/*      */ 
/* 9372 */     int[] zzTransL = ZZ_TRANS;
/* 9373 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 9374 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*      */     while (true)
/*      */     {
/* 9377 */       int zzMarkedPosL = this.zzMarkedPos;
/*      */ 
/* 9379 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*      */ 
/* 9381 */       int zzAction = -1;
/*      */ 
/* 9383 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*      */ 
/* 9385 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*      */ 
/* 9388 */       int zzAttributes = zzAttrL[this.zzState];
/* 9389 */       if ((zzAttributes & 0x1) == 1)
/* 9390 */         zzAction = this.zzState;
/*      */       int zzInput;
/*      */       while (true)
/*      */       {
/*      */         int zzInput;
/* 9397 */         if (zzCurrentPosL < zzEndReadL) {
/* 9398 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 9399 */           if (this.zzAtEOF) {
/* 9400 */             int zzInput = -1;
/* 9401 */             break;
/*      */           }
/*      */ 
/* 9405 */           this.zzCurrentPos = zzCurrentPosL;
/* 9406 */           this.zzMarkedPos = zzMarkedPosL;
/* 9407 */           boolean eof = zzRefill();
/*      */ 
/* 9409 */           zzCurrentPosL = this.zzCurrentPos;
/* 9410 */           zzMarkedPosL = this.zzMarkedPos;
/* 9411 */           zzBufferL = this.zzBuffer;
/* 9412 */           zzEndReadL = this.zzEndRead;
/* 9413 */           if (eof) {
/* 9414 */             int zzInput = -1;
/* 9415 */             break;
/*      */           }
/*      */ 
/* 9418 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*      */         }
/*      */ 
/* 9421 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 9422 */         if (zzNext == -1) break;
/* 9423 */         this.zzState = zzNext;
/*      */ 
/* 9425 */         zzAttributes = zzAttrL[this.zzState];
/* 9426 */         if ((zzAttributes & 0x1) == 1) {
/* 9427 */           zzAction = this.zzState;
/* 9428 */           zzMarkedPosL = zzCurrentPosL;
/* 9429 */           if ((zzAttributes & 0x8) == 8)
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 9436 */       this.zzMarkedPos = zzMarkedPosL;
/*      */ 
/* 9438 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*      */       case 1:
/* 9440 */         yybegin(0);
/*      */       case 15:
/* 9442 */         break;
/*      */       case 2:
/* 9444 */         yybegin(0); return 0;
/*      */       case 16:
/* 9446 */         break;
/*      */       case 3:
/* 9448 */         yybegin(0); return 1;
/*      */       case 17:
/* 9450 */         break;
/*      */       case 4:
/* 9452 */         yybegin(0); return 5;
/*      */       case 18:
/* 9454 */         break;
/*      */       case 5:
/* 9456 */         yybegin(0); return 2;
/*      */       case 19:
/* 9458 */         break;
/*      */       case 6:
/* 9460 */         yybegin(0); return 3;
/*      */       case 20:
/* 9462 */         break;
/*      */       case 7:
/* 9464 */         yybegin(0); return 4;
/*      */       case 21:
/* 9466 */         break;
/*      */       case 8:
/* 9468 */         yybegin(0); return 6;
/*      */       case 22:
/* 9470 */         break;
/*      */       case 9:
/* 9472 */         yybegin(0); return 8;
/*      */       case 23:
/* 9474 */         break;
/*      */       case 10:
/* 9476 */         return 7;
/*      */       case 24:
/* 9478 */         break;
/*      */       case 11:
/* 9481 */         yypushback(1);
/* 9482 */         yybegin(0); return 7;
/*      */       case 25:
/* 9484 */         break;
/*      */       case 12:
/* 9487 */         yypushback(1);
/* 9488 */         yybegin(2); yypushback(yylength());
/*      */       case 26:
/* 9490 */         break;
/*      */       case 13:
/* 9492 */         yybegin(0); return 7;
/*      */       case 27:
/* 9494 */         break;
/*      */       case 14:
/* 9497 */         this.zzMarkedPos = (this.zzStartRead + 6);
/* 9498 */         yybegin(0); return 0;
/*      */       case 28:
/* 9500 */         break;
/*      */       default:
/* 9502 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos))
/* 9503 */           this.zzAtEOF = true;
/* 9504 */         switch (this.zzLexicalState) {
/*      */         case 0:
/* 9506 */           return -1;
/*      */         case 3117:
/* 9508 */           break;
/*      */         case 2:
/* 9510 */           return -1;
/*      */         case 3118:
/* 9512 */           break;
/*      */         default:
/* 9514 */           return -1;
/*      */ 
/* 9518 */           zzScanError(1);
/*      */         }
/*      */         break;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.UAX29URLEmailTokenizerImpl
 * JD-Core Version:    0.6.2
 */