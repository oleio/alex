/*     */ package org.apache.lucene.analysis.standard.std31;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizerInterface;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ 
/*     */ @Deprecated
/*     */ public final class StandardTokenizerImpl31
/*     */   implements StandardTokenizerInterface
/*     */ {
/*     */ 
/*     */   /** @deprecated */
/*     */   public static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 4096;
/*     */   public static final int YYINITIAL = 0;
/*  51 */   private static final int[] ZZ_LEXSTATE = { 0, 0 };
/*     */   private static final String ZZ_CMAP_PACKED = "";
/* 196 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*     */ 
/* 201 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */   private static final String ZZ_ACTION_PACKED_0 = "";
/* 231 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/* 271 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */   private static final String ZZ_TRANS_PACKED_0 = "";
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/* 606 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*     */ 
/* 615 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/* 647 */   private int zzLexicalState = 0;
/*     */ 
/* 651 */   private char[] zzBuffer = new char[4096];
/*     */   private int zzMarkedPos;
/*     */   private int zzCurrentPos;
/*     */   private int zzStartRead;
/*     */   private int zzEndRead;
/*     */   private int yyline;
/*     */   private int yychar;
/*     */   private int yycolumn;
/* 681 */   private boolean zzAtBOL = true;
/*     */   private boolean zzAtEOF;
/*     */   private boolean zzEOFDone;
/*     */   public static final int WORD_TYPE = 0;
/*     */   public static final int NUMERIC_TYPE = 6;
/*     */   public static final int SOUTH_EAST_ASIAN_TYPE = 9;
/*     */   public static final int IDEOGRAPHIC_TYPE = 10;
/*     */   public static final int HIRAGANA_TYPE = 11;
/*     */   public static final int KATAKANA_TYPE = 12;
/*     */   public static final int HANGUL_TYPE = 13;
/*     */ 
/*     */   private static int[] zzUnpackAction()
/*     */   {
/* 209 */     int[] result = new int[114];
/* 210 */     int offset = 0;
/* 211 */     offset = zzUnpackAction("", offset, result);
/* 212 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/* 216 */     int i = 0;
/* 217 */     int j = offset;
/* 218 */     int l = packed.length();
/*     */     int count;
/* 222 */     for (; i < l; 
/* 222 */       count > 0)
/*     */     {
/* 220 */       count = packed.charAt(i++);
/* 221 */       int value = packed.charAt(i++);
/* 222 */       result[(j++)] = value; count--;
/*     */     }
/* 224 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackRowMap()
/*     */   {
/* 251 */     int[] result = new int[114];
/* 252 */     int offset = 0;
/* 253 */     offset = zzUnpackRowMap("", offset, result);
/* 254 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 258 */     int i = 0;
/* 259 */     int j = offset;
/* 260 */     int l = packed.length();
/* 261 */     while (i < l) {
/* 262 */       int high = packed.charAt(i++) << '\020';
/* 263 */       result[(j++)] = (high | packed.charAt(i++));
/*     */     }
/* 265 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackTrans()
/*     */   {
/* 580 */     int[] result = new int[10609];
/* 581 */     int offset = 0;
/* 582 */     offset = zzUnpackTrans("", offset, result);
/* 583 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 587 */     int i = 0;
/* 588 */     int j = offset;
/* 589 */     int l = packed.length();
/*     */     int count;
/* 594 */     for (; i < l; 
/* 594 */       count > 0)
/*     */     {
/* 591 */       count = packed.charAt(i++);
/* 592 */       int value = packed.charAt(i++);
/* 593 */       value--;
/* 594 */       result[(j++)] = value; count--;
/*     */     }
/* 596 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackAttribute()
/*     */   {
/* 622 */     int[] result = new int[114];
/* 623 */     int offset = 0;
/* 624 */     offset = zzUnpackAttribute("", offset, result);
/* 625 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 629 */     int i = 0;
/* 630 */     int j = offset;
/* 631 */     int l = packed.length();
/*     */     int count;
/* 635 */     for (; i < l; 
/* 635 */       count > 0)
/*     */     {
/* 633 */       count = packed.charAt(i++);
/* 634 */       int value = packed.charAt(i++);
/* 635 */       result[(j++)] = value; count--;
/*     */     }
/* 637 */     return j;
/*     */   }
/*     */ 
/*     */   public final int yychar()
/*     */   {
/* 716 */     return this.yychar;
/*     */   }
/*     */ 
/*     */   public final void getText(CharTermAttribute t)
/*     */   {
/* 723 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */   public StandardTokenizerImpl31(Reader in)
/*     */   {
/* 733 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */   private static char[] zzUnpackCMap(String packed)
/*     */   {
/* 744 */     char[] map = new char[65536];
/* 745 */     int i = 0;
/* 746 */     int j = 0;
/*     */     int count;
/* 750 */     for (; i < 2650; 
/* 750 */       count > 0)
/*     */     {
/* 748 */       count = packed.charAt(i++);
/* 749 */       char value = packed.charAt(i++);
/* 750 */       map[(j++)] = value; count--;
/*     */     }
/* 752 */     return map;
/*     */   }
/*     */ 
/*     */   private boolean zzRefill()
/*     */     throws IOException
/*     */   {
/* 766 */     if (this.zzStartRead > 0) {
/* 767 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*     */ 
/* 772 */       this.zzEndRead -= this.zzStartRead;
/* 773 */       this.zzCurrentPos -= this.zzStartRead;
/* 774 */       this.zzMarkedPos -= this.zzStartRead;
/* 775 */       this.zzStartRead = 0;
/*     */     }
/*     */ 
/* 779 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*     */     {
/* 781 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 782 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 783 */       this.zzBuffer = newBuffer;
/*     */     }
/*     */ 
/* 787 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*     */ 
/* 790 */     if (numRead > 0) {
/* 791 */       this.zzEndRead += numRead;
/* 792 */       return false;
/*     */     }
/*     */ 
/* 795 */     if (numRead == 0) {
/* 796 */       int c = this.zzReader.read();
/* 797 */       if (c == -1) {
/* 798 */         return true;
/*     */       }
/* 800 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 801 */       return false;
/*     */     }
/*     */ 
/* 806 */     return true;
/*     */   }
/*     */ 
/*     */   public final void yyclose()
/*     */     throws IOException
/*     */   {
/* 814 */     this.zzAtEOF = true;
/* 815 */     this.zzEndRead = this.zzStartRead;
/*     */ 
/* 817 */     if (this.zzReader != null)
/* 818 */       this.zzReader.close();
/*     */   }
/*     */ 
/*     */   public final void yyreset(Reader reader)
/*     */   {
/* 835 */     this.zzReader = reader;
/* 836 */     this.zzAtBOL = true;
/* 837 */     this.zzAtEOF = false;
/* 838 */     this.zzEOFDone = false;
/* 839 */     this.zzEndRead = (this.zzStartRead = 0);
/* 840 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/* 841 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 842 */     this.zzLexicalState = 0;
/* 843 */     if (this.zzBuffer.length > 4096)
/* 844 */       this.zzBuffer = new char[4096];
/*     */   }
/*     */ 
/*     */   public final int yystate()
/*     */   {
/* 852 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */   public final void yybegin(int newState)
/*     */   {
/* 862 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */   public final String yytext()
/*     */   {
/* 870 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */   public final char yycharat(int pos)
/*     */   {
/* 886 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*     */   }
/*     */ 
/*     */   public final int yylength()
/*     */   {
/* 894 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */   private void zzScanError(int errorCode)
/*     */   {
/*     */     String message;
/*     */     try
/*     */     {
/* 915 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 918 */       message = ZZ_ERROR_MSG[0];
/*     */     }
/*     */ 
/* 921 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */   public void yypushback(int number)
/*     */   {
/* 934 */     if (number > yylength()) {
/* 935 */       zzScanError(2);
/*     */     }
/* 937 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */   public int getNextToken()
/*     */     throws IOException
/*     */   {
/* 955 */     int zzEndReadL = this.zzEndRead;
/* 956 */     char[] zzBufferL = this.zzBuffer;
/* 957 */     char[] zzCMapL = ZZ_CMAP;
/*     */ 
/* 959 */     int[] zzTransL = ZZ_TRANS;
/* 960 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 961 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*     */     while (true)
/*     */     {
/* 964 */       int zzMarkedPosL = this.zzMarkedPos;
/*     */ 
/* 966 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*     */ 
/* 968 */       int zzAction = -1;
/*     */ 
/* 970 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */ 
/* 972 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*     */ 
/* 975 */       int zzAttributes = zzAttrL[this.zzState];
/* 976 */       if ((zzAttributes & 0x1) == 1)
/* 977 */         zzAction = this.zzState;
/*     */       int zzInput;
/*     */       while (true)
/*     */       {
/*     */         int zzInput;
/* 984 */         if (zzCurrentPosL < zzEndReadL) {
/* 985 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 986 */           if (this.zzAtEOF) {
/* 987 */             int zzInput = -1;
/* 988 */             break;
/*     */           }
/*     */ 
/* 992 */           this.zzCurrentPos = zzCurrentPosL;
/* 993 */           this.zzMarkedPos = zzMarkedPosL;
/* 994 */           boolean eof = zzRefill();
/*     */ 
/* 996 */           zzCurrentPosL = this.zzCurrentPos;
/* 997 */           zzMarkedPosL = this.zzMarkedPos;
/* 998 */           zzBufferL = this.zzBuffer;
/* 999 */           zzEndReadL = this.zzEndRead;
/* 1000 */           if (eof) {
/* 1001 */             int zzInput = -1;
/* 1002 */             break;
/*     */           }
/*     */ 
/* 1005 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*     */         }
/*     */ 
/* 1008 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 1009 */         if (zzNext == -1) break;
/* 1010 */         this.zzState = zzNext;
/*     */ 
/* 1012 */         zzAttributes = zzAttrL[this.zzState];
/* 1013 */         if ((zzAttributes & 0x1) == 1) {
/* 1014 */           zzAction = this.zzState;
/* 1015 */           zzMarkedPosL = zzCurrentPosL;
/* 1016 */           if ((zzAttributes & 0x8) == 8)
/*     */           {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 1023 */       this.zzMarkedPos = zzMarkedPosL;
/*     */ 
/* 1025 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*     */       case 1:
/* 1027 */         break;
/*     */       case 9:
/* 1029 */         break;
/*     */       case 2:
/* 1031 */         return 0;
/*     */       case 10:
/* 1033 */         break;
/*     */       case 3:
/* 1035 */         return 6;
/*     */       case 11:
/* 1037 */         break;
/*     */       case 4:
/* 1039 */         return 12;
/*     */       case 12:
/* 1041 */         break;
/*     */       case 5:
/* 1043 */         return 9;
/*     */       case 13:
/* 1045 */         break;
/*     */       case 6:
/* 1047 */         return 10;
/*     */       case 14:
/* 1049 */         break;
/*     */       case 7:
/* 1051 */         return 11;
/*     */       case 15:
/* 1053 */         break;
/*     */       case 8:
/* 1055 */         return 13;
/*     */       case 16:
/* 1057 */         break;
/*     */       default:
/* 1059 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 1060 */           this.zzAtEOF = true;
/*     */ 
/* 1062 */           return -1;
/*     */         }
/*     */ 
/* 1066 */         zzScanError(1);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.std31.StandardTokenizerImpl31
 * JD-Core Version:    0.6.2
 */