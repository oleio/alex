/*      */ package org.apache.lucene.analysis.standard.std34;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import org.apache.lucene.analysis.standard.StandardTokenizerInterface;
/*      */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*      */ 
/*      */ @Deprecated
/*      */ public final class UAX29URLEmailTokenizerImpl34
/*      */   implements StandardTokenizerInterface
/*      */ {
/*      */ 
/*      */   /** @deprecated */
/*      */   public static final int YYEOF = -1;
/*      */   private static final int ZZ_BUFFERSIZE = 4096;
/*      */   public static final int YYINITIAL = 0;
/*   52 */   private static final int[] ZZ_LEXSTATE = { 0, 0 };
/*      */   private static final String ZZ_CMAP_PACKED = "";
/*  205 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*      */ 
/*  210 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*      */   private static final String ZZ_ACTION_PACKED_0 = "";
/*  254 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*      */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/*  452 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*      */   private static final String ZZ_TRANS_PACKED_0 = "";
/*      */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*      */   private static final int ZZ_NO_MATCH = 1;
/*      */   private static final int ZZ_PUSHBACK_2BIG = 2;
/* 3253 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*      */ 
/* 3262 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*      */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*      */   private Reader zzReader;
/*      */   private int zzState;
/* 3306 */   private int zzLexicalState = 0;
/*      */ 
/* 3310 */   private char[] zzBuffer = new char[4096];
/*      */   private int zzMarkedPos;
/*      */   private int zzCurrentPos;
/*      */   private int zzStartRead;
/*      */   private int zzEndRead;
/*      */   private int yyline;
/*      */   private int yychar;
/*      */   private int yycolumn;
/* 3340 */   private boolean zzAtBOL = true;
/*      */   private boolean zzAtEOF;
/*      */   private boolean zzEOFDone;
/*      */   public static final int WORD_TYPE = 0;
/*      */   public static final int NUMERIC_TYPE = 1;
/*      */   public static final int SOUTH_EAST_ASIAN_TYPE = 2;
/*      */   public static final int IDEOGRAPHIC_TYPE = 3;
/*      */   public static final int HIRAGANA_TYPE = 4;
/*      */   public static final int KATAKANA_TYPE = 5;
/*      */   public static final int HANGUL_TYPE = 6;
/*      */   public static final int EMAIL_TYPE = 8;
/*      */   public static final int URL_TYPE = 7;
/*      */ 
/*      */   private static int[] zzUnpackAction()
/*      */   {
/*  232 */     int[] result = new int[1380];
/*  233 */     int offset = 0;
/*  234 */     offset = zzUnpackAction("", offset, result);
/*  235 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  239 */     int i = 0;
/*  240 */     int j = offset;
/*  241 */     int l = packed.length();
/*      */     int count;
/*  245 */     for (; i < l; 
/*  245 */       count > 0)
/*      */     {
/*  243 */       count = packed.charAt(i++);
/*  244 */       int value = packed.charAt(i++);
/*  245 */       result[(j++)] = value; count--;
/*      */     }
/*  247 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackRowMap()
/*      */   {
/*  432 */     int[] result = new int[1380];
/*  433 */     int offset = 0;
/*  434 */     offset = zzUnpackRowMap("", offset, result);
/*  435 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/*  439 */     int i = 0;
/*  440 */     int j = offset;
/*  441 */     int l = packed.length();
/*  442 */     while (i < l) {
/*  443 */       int high = packed.charAt(i++) << '\020';
/*  444 */       result[(j++)] = (high | packed.charAt(i++));
/*      */     }
/*  446 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackTrans()
/*      */   {
/* 3227 */     int[] result = new int[222495];
/* 3228 */     int offset = 0;
/* 3229 */     offset = zzUnpackTrans("", offset, result);
/* 3230 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 3234 */     int i = 0;
/* 3235 */     int j = offset;
/* 3236 */     int l = packed.length();
/*      */     int count;
/* 3241 */     for (; i < l; 
/* 3241 */       count > 0)
/*      */     {
/* 3238 */       count = packed.charAt(i++);
/* 3239 */       int value = packed.charAt(i++);
/* 3240 */       value--;
/* 3241 */       result[(j++)] = value; count--;
/*      */     }
/* 3243 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackAttribute()
/*      */   {
/* 3281 */     int[] result = new int[1380];
/* 3282 */     int offset = 0;
/* 3283 */     offset = zzUnpackAttribute("", offset, result);
/* 3284 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 3288 */     int i = 0;
/* 3289 */     int j = offset;
/* 3290 */     int l = packed.length();
/*      */     int count;
/* 3294 */     for (; i < l; 
/* 3294 */       count > 0)
/*      */     {
/* 3292 */       count = packed.charAt(i++);
/* 3293 */       int value = packed.charAt(i++);
/* 3294 */       result[(j++)] = value; count--;
/*      */     }
/* 3296 */     return j;
/*      */   }
/*      */ 
/*      */   public final int yychar()
/*      */   {
/* 3379 */     return this.yychar;
/*      */   }
/*      */ 
/*      */   public final void getText(CharTermAttribute t)
/*      */   {
/* 3386 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public UAX29URLEmailTokenizerImpl34(Reader in)
/*      */   {
/* 3396 */     this.zzReader = in;
/*      */   }
/*      */ 
/*      */   private static char[] zzUnpackCMap(String packed)
/*      */   {
/* 3407 */     char[] map = new char[65536];
/* 3408 */     int i = 0;
/* 3409 */     int j = 0;
/*      */     int count;
/* 3413 */     for (; i < 2812; 
/* 3413 */       count > 0)
/*      */     {
/* 3411 */       count = packed.charAt(i++);
/* 3412 */       char value = packed.charAt(i++);
/* 3413 */       map[(j++)] = value; count--;
/*      */     }
/* 3415 */     return map;
/*      */   }
/*      */ 
/*      */   private boolean zzRefill()
/*      */     throws IOException
/*      */   {
/* 3429 */     if (this.zzStartRead > 0) {
/* 3430 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*      */ 
/* 3435 */       this.zzEndRead -= this.zzStartRead;
/* 3436 */       this.zzCurrentPos -= this.zzStartRead;
/* 3437 */       this.zzMarkedPos -= this.zzStartRead;
/* 3438 */       this.zzStartRead = 0;
/*      */     }
/*      */ 
/* 3442 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*      */     {
/* 3444 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 3445 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 3446 */       this.zzBuffer = newBuffer;
/*      */     }
/*      */ 
/* 3450 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*      */ 
/* 3453 */     if (numRead > 0) {
/* 3454 */       this.zzEndRead += numRead;
/* 3455 */       return false;
/*      */     }
/*      */ 
/* 3458 */     if (numRead == 0) {
/* 3459 */       int c = this.zzReader.read();
/* 3460 */       if (c == -1) {
/* 3461 */         return true;
/*      */       }
/* 3463 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 3464 */       return false;
/*      */     }
/*      */ 
/* 3469 */     return true;
/*      */   }
/*      */ 
/*      */   public final void yyclose()
/*      */     throws IOException
/*      */   {
/* 3477 */     this.zzAtEOF = true;
/* 3478 */     this.zzEndRead = this.zzStartRead;
/*      */ 
/* 3480 */     if (this.zzReader != null)
/* 3481 */       this.zzReader.close();
/*      */   }
/*      */ 
/*      */   public final void yyreset(Reader reader)
/*      */   {
/* 3498 */     this.zzReader = reader;
/* 3499 */     this.zzAtBOL = true;
/* 3500 */     this.zzAtEOF = false;
/* 3501 */     this.zzEOFDone = false;
/* 3502 */     this.zzEndRead = (this.zzStartRead = 0);
/* 3503 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/* 3504 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 3505 */     this.zzLexicalState = 0;
/* 3506 */     if (this.zzBuffer.length > 4096)
/* 3507 */       this.zzBuffer = new char[4096];
/*      */   }
/*      */ 
/*      */   public final int yystate()
/*      */   {
/* 3515 */     return this.zzLexicalState;
/*      */   }
/*      */ 
/*      */   public final void yybegin(int newState)
/*      */   {
/* 3525 */     this.zzLexicalState = newState;
/*      */   }
/*      */ 
/*      */   public final String yytext()
/*      */   {
/* 3533 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public final char yycharat(int pos)
/*      */   {
/* 3549 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*      */   }
/*      */ 
/*      */   public final int yylength()
/*      */   {
/* 3557 */     return this.zzMarkedPos - this.zzStartRead;
/*      */   }
/*      */ 
/*      */   private void zzScanError(int errorCode)
/*      */   {
/*      */     String message;
/*      */     try
/*      */     {
/* 3578 */       message = ZZ_ERROR_MSG[errorCode];
/*      */     }
/*      */     catch (ArrayIndexOutOfBoundsException e) {
/* 3581 */       message = ZZ_ERROR_MSG[0];
/*      */     }
/*      */ 
/* 3584 */     throw new Error(message);
/*      */   }
/*      */ 
/*      */   public void yypushback(int number)
/*      */   {
/* 3597 */     if (number > yylength()) {
/* 3598 */       zzScanError(2);
/*      */     }
/* 3600 */     this.zzMarkedPos -= number;
/*      */   }
/*      */ 
/*      */   public int getNextToken()
/*      */     throws IOException
/*      */   {
/* 3618 */     int zzEndReadL = this.zzEndRead;
/* 3619 */     char[] zzBufferL = this.zzBuffer;
/* 3620 */     char[] zzCMapL = ZZ_CMAP;
/*      */ 
/* 3622 */     int[] zzTransL = ZZ_TRANS;
/* 3623 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 3624 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*      */     while (true)
/*      */     {
/* 3627 */       int zzMarkedPosL = this.zzMarkedPos;
/*      */ 
/* 3629 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*      */ 
/* 3631 */       int zzAction = -1;
/*      */ 
/* 3633 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*      */ 
/* 3635 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*      */ 
/* 3638 */       int zzAttributes = zzAttrL[this.zzState];
/* 3639 */       if ((zzAttributes & 0x1) == 1)
/* 3640 */         zzAction = this.zzState;
/*      */       int zzInput;
/*      */       while (true)
/*      */       {
/*      */         int zzInput;
/* 3647 */         if (zzCurrentPosL < zzEndReadL) {
/* 3648 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 3649 */           if (this.zzAtEOF) {
/* 3650 */             int zzInput = -1;
/* 3651 */             break;
/*      */           }
/*      */ 
/* 3655 */           this.zzCurrentPos = zzCurrentPosL;
/* 3656 */           this.zzMarkedPos = zzMarkedPosL;
/* 3657 */           boolean eof = zzRefill();
/*      */ 
/* 3659 */           zzCurrentPosL = this.zzCurrentPos;
/* 3660 */           zzMarkedPosL = this.zzMarkedPos;
/* 3661 */           zzBufferL = this.zzBuffer;
/* 3662 */           zzEndReadL = this.zzEndRead;
/* 3663 */           if (eof) {
/* 3664 */             int zzInput = -1;
/* 3665 */             break;
/*      */           }
/*      */ 
/* 3668 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*      */         }
/*      */ 
/* 3671 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 3672 */         if (zzNext == -1) break;
/* 3673 */         this.zzState = zzNext;
/*      */ 
/* 3675 */         zzAttributes = zzAttrL[this.zzState];
/* 3676 */         if ((zzAttributes & 0x1) == 1) {
/* 3677 */           zzAction = this.zzState;
/* 3678 */           zzMarkedPosL = zzCurrentPosL;
/* 3679 */           if ((zzAttributes & 0x8) == 8)
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 3686 */       this.zzMarkedPos = zzMarkedPosL;
/*      */ 
/* 3688 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*      */       case 1:
/* 3690 */         break;
/*      */       case 11:
/* 3692 */         break;
/*      */       case 2:
/* 3694 */         return 0;
/*      */       case 12:
/* 3696 */         break;
/*      */       case 3:
/* 3698 */         return 1;
/*      */       case 13:
/* 3700 */         break;
/*      */       case 4:
/* 3702 */         return 5;
/*      */       case 14:
/* 3704 */         break;
/*      */       case 5:
/* 3706 */         return 2;
/*      */       case 15:
/* 3708 */         break;
/*      */       case 6:
/* 3710 */         return 3;
/*      */       case 16:
/* 3712 */         break;
/*      */       case 7:
/* 3714 */         return 4;
/*      */       case 17:
/* 3716 */         break;
/*      */       case 8:
/* 3718 */         return 6;
/*      */       case 18:
/* 3720 */         break;
/*      */       case 9:
/* 3722 */         return 8;
/*      */       case 19:
/* 3724 */         break;
/*      */       case 10:
/* 3726 */         return 7;
/*      */       case 20:
/* 3728 */         break;
/*      */       default:
/* 3730 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 3731 */           this.zzAtEOF = true;
/*      */ 
/* 3733 */           return -1;
/*      */         }
/*      */ 
/* 3737 */         zzScanError(1);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.std34.UAX29URLEmailTokenizerImpl34
 * JD-Core Version:    0.6.2
 */