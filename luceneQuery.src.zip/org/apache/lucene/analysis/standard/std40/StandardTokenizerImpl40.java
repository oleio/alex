/*      */ package org.apache.lucene.analysis.standard.std40;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import org.apache.lucene.analysis.standard.StandardTokenizerInterface;
/*      */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*      */ 
/*      */ @Deprecated
/*      */ public final class StandardTokenizerImpl40
/*      */   implements StandardTokenizerInterface
/*      */ {
/*      */ 
/*      */   /** @deprecated */
/*      */   public static final int YYEOF = -1;
/*      */   private static final int ZZ_BUFFERSIZE = 4096;
/*      */   public static final int YYINITIAL = 0;
/*   49 */   private static final int[] ZZ_LEXSTATE = { 0, 0 };
/*      */   private static final String ZZ_CMAP_PACKED = "";
/*  204 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*      */ 
/*  209 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*      */   private static final String ZZ_ACTION_PACKED_0 = "";
/*  239 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*      */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/*  284 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*      */   private static final String ZZ_TRANS_PACKED_0 = "";
/*      */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*      */   private static final int ZZ_NO_MATCH = 1;
/*      */   private static final int ZZ_PUSHBACK_2BIG = 2;
/*  730 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*      */ 
/*  739 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*      */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*      */   private Reader zzReader;
/*      */   private int zzState;
/*  771 */   private int zzLexicalState = 0;
/*      */ 
/*  775 */   private char[] zzBuffer = new char[4096];
/*      */   private int zzMarkedPos;
/*      */   private int zzCurrentPos;
/*      */   private int zzStartRead;
/*      */   private int zzEndRead;
/*      */   private int yyline;
/*      */   private int yychar;
/*      */   private int yycolumn;
/*  805 */   private boolean zzAtBOL = true;
/*      */   private boolean zzAtEOF;
/*      */   private boolean zzEOFDone;
/*      */   public static final int WORD_TYPE = 0;
/*      */   public static final int NUMERIC_TYPE = 6;
/*      */   public static final int SOUTH_EAST_ASIAN_TYPE = 9;
/*      */   public static final int IDEOGRAPHIC_TYPE = 10;
/*      */   public static final int HIRAGANA_TYPE = 11;
/*      */   public static final int KATAKANA_TYPE = 12;
/*      */   public static final int HANGUL_TYPE = 13;
/*      */ 
/*      */   private static int[] zzUnpackAction()
/*      */   {
/*  217 */     int[] result = new int[''];
/*  218 */     int offset = 0;
/*  219 */     offset = zzUnpackAction("", offset, result);
/*  220 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  224 */     int i = 0;
/*  225 */     int j = offset;
/*  226 */     int l = packed.length();
/*      */     int count;
/*  230 */     for (; i < l; 
/*  230 */       count > 0)
/*      */     {
/*  228 */       count = packed.charAt(i++);
/*  229 */       int value = packed.charAt(i++);
/*  230 */       result[(j++)] = value; count--;
/*      */     }
/*  232 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackRowMap()
/*      */   {
/*  264 */     int[] result = new int[''];
/*  265 */     int offset = 0;
/*  266 */     offset = zzUnpackRowMap("", offset, result);
/*  267 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/*  271 */     int i = 0;
/*  272 */     int j = offset;
/*  273 */     int l = packed.length();
/*  274 */     while (i < l) {
/*  275 */       int high = packed.charAt(i++) << '\020';
/*  276 */       result[(j++)] = (high | packed.charAt(i++));
/*      */     }
/*  278 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackTrans()
/*      */   {
/*  704 */     int[] result = new int[20002];
/*  705 */     int offset = 0;
/*  706 */     offset = zzUnpackTrans("", offset, result);
/*  707 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/*  711 */     int i = 0;
/*  712 */     int j = offset;
/*  713 */     int l = packed.length();
/*      */     int count;
/*  718 */     for (; i < l; 
/*  718 */       count > 0)
/*      */     {
/*  715 */       count = packed.charAt(i++);
/*  716 */       int value = packed.charAt(i++);
/*  717 */       value--;
/*  718 */       result[(j++)] = value; count--;
/*      */     }
/*  720 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackAttribute()
/*      */   {
/*  746 */     int[] result = new int[''];
/*  747 */     int offset = 0;
/*  748 */     offset = zzUnpackAttribute("", offset, result);
/*  749 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/*  753 */     int i = 0;
/*  754 */     int j = offset;
/*  755 */     int l = packed.length();
/*      */     int count;
/*  759 */     for (; i < l; 
/*  759 */       count > 0)
/*      */     {
/*  757 */       count = packed.charAt(i++);
/*  758 */       int value = packed.charAt(i++);
/*  759 */       result[(j++)] = value; count--;
/*      */     }
/*  761 */     return j;
/*      */   }
/*      */ 
/*      */   public final int yychar()
/*      */   {
/*  840 */     return this.yychar;
/*      */   }
/*      */ 
/*      */   public final void getText(CharTermAttribute t)
/*      */   {
/*  847 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public StandardTokenizerImpl40(Reader in)
/*      */   {
/*  857 */     this.zzReader = in;
/*      */   }
/*      */ 
/*      */   private static char[] zzUnpackCMap(String packed)
/*      */   {
/*  868 */     char[] map = new char[65536];
/*  869 */     int i = 0;
/*  870 */     int j = 0;
/*      */     int count;
/*  874 */     for (; i < 2848; 
/*  874 */       count > 0)
/*      */     {
/*  872 */       count = packed.charAt(i++);
/*  873 */       char value = packed.charAt(i++);
/*  874 */       map[(j++)] = value; count--;
/*      */     }
/*  876 */     return map;
/*      */   }
/*      */ 
/*      */   private boolean zzRefill()
/*      */     throws IOException
/*      */   {
/*  890 */     if (this.zzStartRead > 0) {
/*  891 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*      */ 
/*  896 */       this.zzEndRead -= this.zzStartRead;
/*  897 */       this.zzCurrentPos -= this.zzStartRead;
/*  898 */       this.zzMarkedPos -= this.zzStartRead;
/*  899 */       this.zzStartRead = 0;
/*      */     }
/*      */ 
/*  903 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*      */     {
/*  905 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/*  906 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/*  907 */       this.zzBuffer = newBuffer;
/*      */     }
/*      */ 
/*  911 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*      */ 
/*  914 */     if (numRead > 0) {
/*  915 */       this.zzEndRead += numRead;
/*  916 */       return false;
/*      */     }
/*      */ 
/*  919 */     if (numRead == 0) {
/*  920 */       int c = this.zzReader.read();
/*  921 */       if (c == -1) {
/*  922 */         return true;
/*      */       }
/*  924 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/*  925 */       return false;
/*      */     }
/*      */ 
/*  930 */     return true;
/*      */   }
/*      */ 
/*      */   public final void yyclose()
/*      */     throws IOException
/*      */   {
/*  938 */     this.zzAtEOF = true;
/*  939 */     this.zzEndRead = this.zzStartRead;
/*      */ 
/*  941 */     if (this.zzReader != null)
/*  942 */       this.zzReader.close();
/*      */   }
/*      */ 
/*      */   public final void yyreset(Reader reader)
/*      */   {
/*  959 */     this.zzReader = reader;
/*  960 */     this.zzAtBOL = true;
/*  961 */     this.zzAtEOF = false;
/*  962 */     this.zzEOFDone = false;
/*  963 */     this.zzEndRead = (this.zzStartRead = 0);
/*  964 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/*  965 */     this.yyline = (this.yychar = this.yycolumn = 0);
/*  966 */     this.zzLexicalState = 0;
/*  967 */     if (this.zzBuffer.length > 4096)
/*  968 */       this.zzBuffer = new char[4096];
/*      */   }
/*      */ 
/*      */   public final int yystate()
/*      */   {
/*  976 */     return this.zzLexicalState;
/*      */   }
/*      */ 
/*      */   public final void yybegin(int newState)
/*      */   {
/*  986 */     this.zzLexicalState = newState;
/*      */   }
/*      */ 
/*      */   public final String yytext()
/*      */   {
/*  994 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public final char yycharat(int pos)
/*      */   {
/* 1010 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*      */   }
/*      */ 
/*      */   public final int yylength()
/*      */   {
/* 1018 */     return this.zzMarkedPos - this.zzStartRead;
/*      */   }
/*      */ 
/*      */   private void zzScanError(int errorCode)
/*      */   {
/*      */     String message;
/*      */     try
/*      */     {
/* 1039 */       message = ZZ_ERROR_MSG[errorCode];
/*      */     }
/*      */     catch (ArrayIndexOutOfBoundsException e) {
/* 1042 */       message = ZZ_ERROR_MSG[0];
/*      */     }
/*      */ 
/* 1045 */     throw new Error(message);
/*      */   }
/*      */ 
/*      */   public void yypushback(int number)
/*      */   {
/* 1058 */     if (number > yylength()) {
/* 1059 */       zzScanError(2);
/*      */     }
/* 1061 */     this.zzMarkedPos -= number;
/*      */   }
/*      */ 
/*      */   public int getNextToken()
/*      */     throws IOException
/*      */   {
/* 1079 */     int zzEndReadL = this.zzEndRead;
/* 1080 */     char[] zzBufferL = this.zzBuffer;
/* 1081 */     char[] zzCMapL = ZZ_CMAP;
/*      */ 
/* 1083 */     int[] zzTransL = ZZ_TRANS;
/* 1084 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 1085 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*      */     while (true)
/*      */     {
/* 1088 */       int zzMarkedPosL = this.zzMarkedPos;
/*      */ 
/* 1090 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*      */ 
/* 1092 */       int zzAction = -1;
/*      */ 
/* 1094 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*      */ 
/* 1096 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*      */ 
/* 1099 */       int zzAttributes = zzAttrL[this.zzState];
/* 1100 */       if ((zzAttributes & 0x1) == 1)
/* 1101 */         zzAction = this.zzState;
/*      */       int zzInput;
/*      */       while (true)
/*      */       {
/*      */         int zzInput;
/* 1108 */         if (zzCurrentPosL < zzEndReadL) {
/* 1109 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 1110 */           if (this.zzAtEOF) {
/* 1111 */             int zzInput = -1;
/* 1112 */             break;
/*      */           }
/*      */ 
/* 1116 */           this.zzCurrentPos = zzCurrentPosL;
/* 1117 */           this.zzMarkedPos = zzMarkedPosL;
/* 1118 */           boolean eof = zzRefill();
/*      */ 
/* 1120 */           zzCurrentPosL = this.zzCurrentPos;
/* 1121 */           zzMarkedPosL = this.zzMarkedPos;
/* 1122 */           zzBufferL = this.zzBuffer;
/* 1123 */           zzEndReadL = this.zzEndRead;
/* 1124 */           if (eof) {
/* 1125 */             int zzInput = -1;
/* 1126 */             break;
/*      */           }
/*      */ 
/* 1129 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*      */         }
/*      */ 
/* 1132 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 1133 */         if (zzNext == -1) break;
/* 1134 */         this.zzState = zzNext;
/*      */ 
/* 1136 */         zzAttributes = zzAttrL[this.zzState];
/* 1137 */         if ((zzAttributes & 0x1) == 1) {
/* 1138 */           zzAction = this.zzState;
/* 1139 */           zzMarkedPosL = zzCurrentPosL;
/* 1140 */           if ((zzAttributes & 0x8) == 8)
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1147 */       this.zzMarkedPos = zzMarkedPosL;
/*      */ 
/* 1149 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*      */       case 1:
/* 1151 */         break;
/*      */       case 9:
/* 1153 */         break;
/*      */       case 2:
/* 1155 */         return 0;
/*      */       case 10:
/* 1157 */         break;
/*      */       case 3:
/* 1159 */         return 6;
/*      */       case 11:
/* 1161 */         break;
/*      */       case 4:
/* 1163 */         return 12;
/*      */       case 12:
/* 1165 */         break;
/*      */       case 5:
/* 1167 */         return 9;
/*      */       case 13:
/* 1169 */         break;
/*      */       case 6:
/* 1171 */         return 10;
/*      */       case 14:
/* 1173 */         break;
/*      */       case 7:
/* 1175 */         return 11;
/*      */       case 15:
/* 1177 */         break;
/*      */       case 8:
/* 1179 */         return 13;
/*      */       case 16:
/* 1181 */         break;
/*      */       default:
/* 1183 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 1184 */           this.zzAtEOF = true;
/*      */ 
/* 1186 */           return -1;
/*      */         }
/*      */ 
/* 1190 */         zzScanError(1);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.std40.StandardTokenizerImpl40
 * JD-Core Version:    0.6.2
 */