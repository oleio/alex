/*    */ package org.apache.lucene.analysis.standard;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public class ClassicTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   private final int maxTokenLength;
/*    */ 
/*    */   public ClassicTokenizerFactory(Map<String, String> args)
/*    */   {
/* 40 */     super(args);
/* 41 */     assureMatchVersion();
/* 42 */     this.maxTokenLength = getInt(args, "maxTokenLength", 255);
/* 43 */     if (!args.isEmpty())
/* 44 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ClassicTokenizer create(AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 50 */     ClassicTokenizer tokenizer = new ClassicTokenizer(this.luceneMatchVersion, factory, input);
/* 51 */     tokenizer.setMaxTokenLength(this.maxTokenLength);
/* 52 */     return tokenizer;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.ClassicTokenizerFactory
 * JD-Core Version:    0.6.2
 */