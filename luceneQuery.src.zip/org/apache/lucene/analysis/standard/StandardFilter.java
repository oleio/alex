/*    */ package org.apache.lucene.analysis.standard;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public class StandardFilter extends TokenFilter
/*    */ {
/*    */   private final Version matchVersion;
/* 39 */   private static final String APOSTROPHE_TYPE = ClassicTokenizer.TOKEN_TYPES[1];
/* 40 */   private static final String ACRONYM_TYPE = ClassicTokenizer.TOKEN_TYPES[2];
/*    */ 
/* 43 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/* 44 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */ 
/*    */   public StandardFilter(Version matchVersion, TokenStream in)
/*    */   {
/* 35 */     super(in);
/* 36 */     this.matchVersion = matchVersion;
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken()
/*    */     throws IOException
/*    */   {
/* 48 */     if (this.matchVersion.onOrAfter(Version.LUCENE_31)) {
/* 49 */       return this.input.incrementToken();
/*    */     }
/* 51 */     return incrementTokenClassic();
/*    */   }
/*    */ 
/*    */   public final boolean incrementTokenClassic() throws IOException {
/* 55 */     if (!this.input.incrementToken()) {
/* 56 */       return false;
/*    */     }
/*    */ 
/* 59 */     char[] buffer = this.termAtt.buffer();
/* 60 */     int bufferLength = this.termAtt.length();
/* 61 */     String type = this.typeAtt.type();
/*    */ 
/* 63 */     if ((type == APOSTROPHE_TYPE) && (bufferLength >= 2) && (buffer[(bufferLength - 2)] == '\'') && ((buffer[(bufferLength - 1)] == 's') || (buffer[(bufferLength - 1)] == 'S')))
/*    */     {
/* 68 */       this.termAtt.setLength(bufferLength - 2);
/* 69 */     } else if (type == ACRONYM_TYPE) {
/* 70 */       int upto = 0;
/* 71 */       for (int i = 0; i < bufferLength; i++) {
/* 72 */         char c = buffer[i];
/* 73 */         if (c != '.')
/* 74 */           buffer[(upto++)] = c;
/*    */       }
/* 76 */       this.termAtt.setLength(upto);
/*    */     }
/*    */ 
/* 79 */     return true;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.StandardFilter
 * JD-Core Version:    0.6.2
 */