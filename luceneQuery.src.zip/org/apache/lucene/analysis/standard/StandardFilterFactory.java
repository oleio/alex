/*    */ package org.apache.lucene.analysis.standard;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class StandardFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public StandardFilterFactory(Map<String, String> args)
/*    */   {
/* 40 */     super(args);
/* 41 */     assureMatchVersion();
/* 42 */     if (!args.isEmpty())
/* 43 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public StandardFilter create(TokenStream input)
/*    */   {
/* 49 */     return new StandardFilter(this.luceneMatchVersion, input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.StandardFilterFactory
 * JD-Core Version:    0.6.2
 */