/*     */ package org.apache.lucene.analysis.standard;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ 
/*     */ class ClassicTokenizerImpl
/*     */   implements StandardTokenizerInterface
/*     */ {
/*     */   public static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 4096;
/*     */   public static final int YYINITIAL = 0;
/*  53 */   private static final int[] ZZ_LEXSTATE = { 0, 0 };
/*     */   private static final String ZZ_CMAP_PACKED = "";
/* 122 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*     */ 
/* 127 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */   private static final String ZZ_ACTION_PACKED_0 = "";
/* 157 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/* 189 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */   private static final String ZZ_TRANS_PACKED_0 = "";
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/* 260 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*     */ 
/* 269 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/* 301 */   private int zzLexicalState = 0;
/*     */ 
/* 305 */   private char[] zzBuffer = new char[4096];
/*     */   private int zzMarkedPos;
/*     */   private int zzCurrentPos;
/*     */   private int zzStartRead;
/*     */   private int zzEndRead;
/*     */   private int yyline;
/*     */   private int yychar;
/*     */   private int yycolumn;
/* 335 */   private boolean zzAtBOL = true;
/*     */   private boolean zzAtEOF;
/*     */   private boolean zzEOFDone;
/*     */   public static final int ALPHANUM = 0;
/*     */   public static final int APOSTROPHE = 1;
/*     */   public static final int ACRONYM = 2;
/*     */   public static final int COMPANY = 3;
/*     */   public static final int EMAIL = 4;
/*     */   public static final int HOST = 5;
/*     */   public static final int NUM = 6;
/*     */   public static final int CJ = 7;
/*     */   public static final int ACRONYM_DEP = 8;
/* 355 */   public static final String[] TOKEN_TYPES = StandardTokenizer.TOKEN_TYPES;
/*     */ 
/*     */   private static int[] zzUnpackAction()
/*     */   {
/* 135 */     int[] result = new int[50];
/* 136 */     int offset = 0;
/* 137 */     offset = zzUnpackAction("", offset, result);
/* 138 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/* 142 */     int i = 0;
/* 143 */     int j = offset;
/* 144 */     int l = packed.length();
/*     */     int count;
/* 148 */     for (; i < l; 
/* 148 */       count > 0)
/*     */     {
/* 146 */       count = packed.charAt(i++);
/* 147 */       int value = packed.charAt(i++);
/* 148 */       result[(j++)] = value; count--;
/*     */     }
/* 150 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackRowMap()
/*     */   {
/* 169 */     int[] result = new int[50];
/* 170 */     int offset = 0;
/* 171 */     offset = zzUnpackRowMap("", offset, result);
/* 172 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 176 */     int i = 0;
/* 177 */     int j = offset;
/* 178 */     int l = packed.length();
/* 179 */     while (i < l) {
/* 180 */       int high = packed.charAt(i++) << '\020';
/* 181 */       result[(j++)] = (high | packed.charAt(i++));
/*     */     }
/* 183 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackTrans()
/*     */   {
/* 234 */     int[] result = new int[552];
/* 235 */     int offset = 0;
/* 236 */     offset = zzUnpackTrans("", offset, result);
/* 237 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 241 */     int i = 0;
/* 242 */     int j = offset;
/* 243 */     int l = packed.length();
/*     */     int count;
/* 248 */     for (; i < l; 
/* 248 */       count > 0)
/*     */     {
/* 245 */       count = packed.charAt(i++);
/* 246 */       int value = packed.charAt(i++);
/* 247 */       value--;
/* 248 */       result[(j++)] = value; count--;
/*     */     }
/* 250 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackAttribute()
/*     */   {
/* 276 */     int[] result = new int[50];
/* 277 */     int offset = 0;
/* 278 */     offset = zzUnpackAttribute("", offset, result);
/* 279 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 283 */     int i = 0;
/* 284 */     int j = offset;
/* 285 */     int l = packed.length();
/*     */     int count;
/* 289 */     for (; i < l; 
/* 289 */       count > 0)
/*     */     {
/* 287 */       count = packed.charAt(i++);
/* 288 */       int value = packed.charAt(i++);
/* 289 */       result[(j++)] = value; count--;
/*     */     }
/* 291 */     return j;
/*     */   }
/*     */ 
/*     */   public final int yychar()
/*     */   {
/* 359 */     return this.yychar;
/*     */   }
/*     */ 
/*     */   public final void getText(CharTermAttribute t)
/*     */   {
/* 366 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */   ClassicTokenizerImpl(Reader in)
/*     */   {
/* 377 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */   private static char[] zzUnpackCMap(String packed)
/*     */   {
/* 388 */     char[] map = new char[65536];
/* 389 */     int i = 0;
/* 390 */     int j = 0;
/*     */     int count;
/* 394 */     for (; i < 1138; 
/* 394 */       count > 0)
/*     */     {
/* 392 */       count = packed.charAt(i++);
/* 393 */       char value = packed.charAt(i++);
/* 394 */       map[(j++)] = value; count--;
/*     */     }
/* 396 */     return map;
/*     */   }
/*     */ 
/*     */   private boolean zzRefill()
/*     */     throws IOException
/*     */   {
/* 410 */     if (this.zzStartRead > 0) {
/* 411 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*     */ 
/* 416 */       this.zzEndRead -= this.zzStartRead;
/* 417 */       this.zzCurrentPos -= this.zzStartRead;
/* 418 */       this.zzMarkedPos -= this.zzStartRead;
/* 419 */       this.zzStartRead = 0;
/*     */     }
/*     */ 
/* 423 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*     */     {
/* 425 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 426 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 427 */       this.zzBuffer = newBuffer;
/*     */     }
/*     */ 
/* 431 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*     */ 
/* 434 */     if (numRead > 0) {
/* 435 */       this.zzEndRead += numRead;
/* 436 */       return false;
/*     */     }
/*     */ 
/* 439 */     if (numRead == 0) {
/* 440 */       int c = this.zzReader.read();
/* 441 */       if (c == -1) {
/* 442 */         return true;
/*     */       }
/* 444 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 445 */       return false;
/*     */     }
/*     */ 
/* 450 */     return true;
/*     */   }
/*     */ 
/*     */   public final void yyclose()
/*     */     throws IOException
/*     */   {
/* 458 */     this.zzAtEOF = true;
/* 459 */     this.zzEndRead = this.zzStartRead;
/*     */ 
/* 461 */     if (this.zzReader != null)
/* 462 */       this.zzReader.close();
/*     */   }
/*     */ 
/*     */   public final void yyreset(Reader reader)
/*     */   {
/* 479 */     this.zzReader = reader;
/* 480 */     this.zzAtBOL = true;
/* 481 */     this.zzAtEOF = false;
/* 482 */     this.zzEOFDone = false;
/* 483 */     this.zzEndRead = (this.zzStartRead = 0);
/* 484 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/* 485 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 486 */     this.zzLexicalState = 0;
/* 487 */     if (this.zzBuffer.length > 4096)
/* 488 */       this.zzBuffer = new char[4096];
/*     */   }
/*     */ 
/*     */   public final int yystate()
/*     */   {
/* 496 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */   public final void yybegin(int newState)
/*     */   {
/* 506 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */   public final String yytext()
/*     */   {
/* 514 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */   public final char yycharat(int pos)
/*     */   {
/* 530 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*     */   }
/*     */ 
/*     */   public final int yylength()
/*     */   {
/* 538 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */   private void zzScanError(int errorCode)
/*     */   {
/*     */     String message;
/*     */     try
/*     */     {
/* 559 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 562 */       message = ZZ_ERROR_MSG[0];
/*     */     }
/*     */ 
/* 565 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */   public void yypushback(int number)
/*     */   {
/* 578 */     if (number > yylength()) {
/* 579 */       zzScanError(2);
/*     */     }
/* 581 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */   public int getNextToken()
/*     */     throws IOException
/*     */   {
/* 599 */     int zzEndReadL = this.zzEndRead;
/* 600 */     char[] zzBufferL = this.zzBuffer;
/* 601 */     char[] zzCMapL = ZZ_CMAP;
/*     */ 
/* 603 */     int[] zzTransL = ZZ_TRANS;
/* 604 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 605 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*     */     while (true)
/*     */     {
/* 608 */       int zzMarkedPosL = this.zzMarkedPos;
/*     */ 
/* 610 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*     */ 
/* 612 */       int zzAction = -1;
/*     */ 
/* 614 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */ 
/* 616 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*     */ 
/* 619 */       int zzAttributes = zzAttrL[this.zzState];
/* 620 */       if ((zzAttributes & 0x1) == 1)
/* 621 */         zzAction = this.zzState;
/*     */       int zzInput;
/*     */       while (true)
/*     */       {
/*     */         int zzInput;
/* 628 */         if (zzCurrentPosL < zzEndReadL) {
/* 629 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 630 */           if (this.zzAtEOF) {
/* 631 */             int zzInput = -1;
/* 632 */             break;
/*     */           }
/*     */ 
/* 636 */           this.zzCurrentPos = zzCurrentPosL;
/* 637 */           this.zzMarkedPos = zzMarkedPosL;
/* 638 */           boolean eof = zzRefill();
/*     */ 
/* 640 */           zzCurrentPosL = this.zzCurrentPos;
/* 641 */           zzMarkedPosL = this.zzMarkedPos;
/* 642 */           zzBufferL = this.zzBuffer;
/* 643 */           zzEndReadL = this.zzEndRead;
/* 644 */           if (eof) {
/* 645 */             int zzInput = -1;
/* 646 */             break;
/*     */           }
/*     */ 
/* 649 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*     */         }
/*     */ 
/* 652 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 653 */         if (zzNext == -1) break;
/* 654 */         this.zzState = zzNext;
/*     */ 
/* 656 */         zzAttributes = zzAttrL[this.zzState];
/* 657 */         if ((zzAttributes & 0x1) == 1) {
/* 658 */           zzAction = this.zzState;
/* 659 */           zzMarkedPosL = zzCurrentPosL;
/* 660 */           if ((zzAttributes & 0x8) == 8)
/*     */           {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 667 */       this.zzMarkedPos = zzMarkedPosL;
/*     */ 
/* 669 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*     */       case 1:
/* 671 */         break;
/*     */       case 11:
/* 673 */         break;
/*     */       case 2:
/* 675 */         return 0;
/*     */       case 12:
/* 677 */         break;
/*     */       case 3:
/* 679 */         return 7;
/*     */       case 13:
/* 681 */         break;
/*     */       case 4:
/* 683 */         return 5;
/*     */       case 14:
/* 685 */         break;
/*     */       case 5:
/* 687 */         return 6;
/*     */       case 15:
/* 689 */         break;
/*     */       case 6:
/* 691 */         return 1;
/*     */       case 16:
/* 693 */         break;
/*     */       case 7:
/* 695 */         return 3;
/*     */       case 17:
/* 697 */         break;
/*     */       case 8:
/* 699 */         return 8;
/*     */       case 18:
/* 701 */         break;
/*     */       case 9:
/* 703 */         return 2;
/*     */       case 19:
/* 705 */         break;
/*     */       case 10:
/* 707 */         return 4;
/*     */       case 20:
/* 709 */         break;
/*     */       default:
/* 711 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 712 */           this.zzAtEOF = true;
/* 713 */           return -1;
/*     */         }
/*     */ 
/* 716 */         zzScanError(1);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.ClassicTokenizerImpl
 * JD-Core Version:    0.6.2
 */