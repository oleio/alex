/*     */ package org.apache.lucene.analysis;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionLengthAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TermToBytesRefAttribute;
/*     */ import org.apache.lucene.util.BytesRef;
/*     */ import org.apache.lucene.util.RollingBuffer;
/*     */ import org.apache.lucene.util.RollingBuffer.Resettable;
/*     */ import org.apache.lucene.util.automaton.Automaton;
/*     */ import org.apache.lucene.util.automaton.State;
/*     */ import org.apache.lucene.util.automaton.Transition;
/*     */ 
/*     */ public class TokenStreamToAutomaton
/*     */ {
/*     */   private boolean preservePositionIncrements;
/*     */   private boolean unicodeArcs;
/*     */   public static final int POS_SEP = 31;
/*     */   public static final int HOLE = 30;
/*     */ 
/*     */   public TokenStreamToAutomaton()
/*     */   {
/*  48 */     this.preservePositionIncrements = true;
/*     */   }
/*     */ 
/*     */   public void setPreservePositionIncrements(boolean enablePositionIncrements)
/*     */   {
/*  53 */     this.preservePositionIncrements = enablePositionIncrements;
/*     */   }
/*     */ 
/*     */   public void setUnicodeArcs(boolean unicodeArcs)
/*     */   {
/*  59 */     this.unicodeArcs = unicodeArcs;
/*     */   }
/*     */ 
/*     */   protected BytesRef changeToken(BytesRef in)
/*     */   {
/*  87 */     return in;
/*     */   }
/*     */ 
/*     */   public Automaton toAutomaton(TokenStream in)
/*     */     throws IOException
/*     */   {
/* 102 */     Automaton a = new Automaton();
/* 103 */     boolean deterministic = true;
/*     */ 
/* 105 */     TermToBytesRefAttribute termBytesAtt = (TermToBytesRefAttribute)in.addAttribute(TermToBytesRefAttribute.class);
/* 106 */     PositionIncrementAttribute posIncAtt = (PositionIncrementAttribute)in.addAttribute(PositionIncrementAttribute.class);
/* 107 */     PositionLengthAttribute posLengthAtt = (PositionLengthAttribute)in.addAttribute(PositionLengthAttribute.class);
/* 108 */     OffsetAttribute offsetAtt = (OffsetAttribute)in.addAttribute(OffsetAttribute.class);
/*     */ 
/* 110 */     BytesRef term = termBytesAtt.getBytesRef();
/*     */ 
/* 112 */     in.reset();
/*     */ 
/* 117 */     RollingBuffer positions = new Positions(null);
/*     */ 
/* 119 */     int pos = -1;
/* 120 */     Position posData = null;
/* 121 */     int maxOffset = 0;
/* 122 */     while (in.incrementToken()) {
/* 123 */       int posInc = posIncAtt.getPositionIncrement();
/* 124 */       if ((!this.preservePositionIncrements) && (posInc > 1)) {
/* 125 */         posInc = 1;
/*     */       }
/* 127 */       assert ((pos > -1) || (posInc > 0));
/*     */ 
/* 129 */       if (posInc > 0)
/*     */       {
/* 132 */         pos += posInc;
/*     */ 
/* 134 */         posData = (Position)positions.get(pos);
/* 135 */         assert (posData.leaving == null);
/*     */ 
/* 137 */         if (posData.arriving == null)
/*     */         {
/* 139 */           if (pos == 0)
/*     */           {
/* 141 */             posData.leaving = a.getInitialState();
/*     */           }
/*     */           else
/*     */           {
/* 145 */             posData.leaving = new State();
/* 146 */             addHoles(a.getInitialState(), positions, pos);
/*     */           }
/*     */         } else {
/* 149 */           posData.leaving = new State();
/* 150 */           posData.arriving.addTransition(new Transition(31, posData.leaving));
/* 151 */           if (posInc > 1)
/*     */           {
/* 154 */             addHoles(a.getInitialState(), positions, pos);
/*     */           }
/*     */         }
/* 157 */         positions.freeBefore(pos);
/*     */       }
/*     */       else
/*     */       {
/* 162 */         deterministic = false;
/*     */       }
/*     */ 
/* 165 */       int endPos = pos + posLengthAtt.getPositionLength();
/*     */ 
/* 167 */       termBytesAtt.fillBytesRef();
/* 168 */       BytesRef termUTF8 = changeToken(term);
/* 169 */       int[] termUnicode = null;
/* 170 */       Position endPosData = (Position)positions.get(endPos);
/* 171 */       if (endPosData.arriving == null) {
/* 172 */         endPosData.arriving = new State();
/*     */       }
/*     */ 
/* 175 */       State state = posData.leaving;
/*     */       int termLen;
/* 177 */       if (this.unicodeArcs) {
/* 178 */         String utf16 = termUTF8.utf8ToString();
/* 179 */         termUnicode = new int[utf16.codePointCount(0, utf16.length())];
/* 180 */         int termLen = termUnicode.length;
/* 181 */         int i = 0;
/*     */         int cp;
/* 181 */         for (int j = 0; i < utf16.length(); i += Character.charCount(cp))
/*     */         {
/*     */           int tmp440_437 = utf16.codePointAt(i); cp = tmp440_437; termUnicode[(j++)] = tmp440_437;
/*     */         }
/*     */       } else { termLen = termUTF8.length; }
/*     */ 
/*     */ 
/* 187 */       for (int byteIDX = 0; byteIDX < termLen; byteIDX++) {
/* 188 */         State nextState = byteIDX == termLen - 1 ? endPosData.arriving : new State();
/*     */         int c;
/*     */         int c;
/* 190 */         if (this.unicodeArcs)
/* 191 */           c = termUnicode[byteIDX];
/*     */         else {
/* 193 */           c = termUTF8.bytes[(termUTF8.offset + byteIDX)] & 0xFF;
/*     */         }
/* 195 */         state.addTransition(new Transition(c, nextState));
/* 196 */         state = nextState;
/*     */       }
/*     */ 
/* 199 */       maxOffset = Math.max(maxOffset, offsetAtt.endOffset());
/*     */     }
/*     */ 
/* 202 */     in.end();
/* 203 */     State endState = null;
/* 204 */     if (offsetAtt.endOffset() > maxOffset) {
/* 205 */       endState = new State();
/* 206 */       endState.setAccept(true);
/*     */     }
/*     */ 
/* 209 */     pos++;
/* 210 */     while (pos <= positions.getMaxPos()) {
/* 211 */       posData = (Position)positions.get(pos);
/* 212 */       if (posData.arriving != null) {
/* 213 */         if (endState != null)
/* 214 */           posData.arriving.addTransition(new Transition(31, endState));
/*     */         else {
/* 216 */           posData.arriving.setAccept(true);
/*     */         }
/*     */       }
/* 219 */       pos++;
/*     */     }
/*     */ 
/* 223 */     a.setDeterministic(deterministic);
/* 224 */     return a;
/*     */   }
/*     */ 
/*     */   private static void addHoles(State startState, RollingBuffer<Position> positions, int pos)
/*     */   {
/* 239 */     Position posData = (Position)positions.get(pos);
/* 240 */     Position prevPosData = (Position)positions.get(pos - 1);
/*     */ 
/* 242 */     while ((posData.arriving == null) || (prevPosData.leaving == null)) {
/* 243 */       if (posData.arriving == null) {
/* 244 */         posData.arriving = new State();
/* 245 */         posData.arriving.addTransition(new Transition(31, posData.leaving));
/*     */       }
/* 247 */       if (prevPosData.leaving == null) {
/* 248 */         if (pos == 1)
/* 249 */           prevPosData.leaving = startState;
/*     */         else {
/* 251 */           prevPosData.leaving = new State();
/*     */         }
/* 253 */         if (prevPosData.arriving != null) {
/* 254 */           prevPosData.arriving.addTransition(new Transition(31, prevPosData.leaving));
/*     */         }
/*     */       }
/* 257 */       prevPosData.leaving.addTransition(new Transition(30, posData.arriving));
/* 258 */       pos--;
/* 259 */       if (pos <= 0) {
/*     */         break;
/*     */       }
/* 262 */       posData = prevPosData;
/* 263 */       prevPosData = (Position)positions.get(pos - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Positions extends RollingBuffer<TokenStreamToAutomaton.Position>
/*     */   {
/*     */     protected TokenStreamToAutomaton.Position newInstance()
/*     */     {
/*  79 */       return new TokenStreamToAutomaton.Position(null);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Position
/*     */     implements RollingBuffer.Resettable
/*     */   {
/*     */     State arriving;
/*     */     State leaving;
/*     */ 
/*     */     public void reset()
/*     */     {
/*  71 */       this.arriving = null;
/*  72 */       this.leaving = null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.TokenStreamToAutomaton
 * JD-Core Version:    0.6.2
 */