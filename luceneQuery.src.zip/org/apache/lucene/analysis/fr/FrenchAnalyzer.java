/*     */ package org.apache.lucene.analysis.fr;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.snowball.SnowballFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.ElisionFilter;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.analysis.util.WordlistLoader;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.tartarus.snowball.ext.FrenchStemmer;
/*     */ 
/*     */ public final class FrenchAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */ 
/*     */   @Deprecated
/*  74 */   private static final String[] FRENCH_STOP_WORDS = { "a", "afin", "ai", "ainsi", "après", "attendu", "au", "aujourd", "auquel", "aussi", "autre", "autres", "aux", "auxquelles", "auxquels", "avait", "avant", "avec", "avoir", "c", "car", "ce", "ceci", "cela", "celle", "celles", "celui", "cependant", "certain", "certaine", "certaines", "certains", "ces", "cet", "cette", "ceux", "chez", "ci", "combien", "comme", "comment", "concernant", "contre", "d", "dans", "de", "debout", "dedans", "dehors", "delà", "depuis", "derrière", "des", "désormais", "desquelles", "desquels", "dessous", "dessus", "devant", "devers", "devra", "divers", "diverse", "diverses", "doit", "donc", "dont", "du", "duquel", "durant", "dès", "elle", "elles", "en", "entre", "environ", "est", "et", "etc", "etre", "eu", "eux", "excepté", "hormis", "hors", "hélas", "hui", "il", "ils", "j", "je", "jusqu", "jusque", "l", "la", "laquelle", "le", "lequel", "les", "lesquelles", "lesquels", "leur", "leurs", "lorsque", "lui", "là", "ma", "mais", "malgré", "me", "merci", "mes", "mien", "mienne", "miennes", "miens", "moi", "moins", "mon", "moyennant", "même", "mêmes", "n", "ne", "ni", "non", "nos", "notre", "nous", "néanmoins", "nôtre", "nôtres", "on", "ont", "ou", "outre", "où", "par", "parmi", "partant", "pas", "passé", "pendant", "plein", "plus", "plusieurs", "pour", "pourquoi", "proche", "près", "puisque", "qu", "quand", "que", "quel", "quelle", "quelles", "quels", "qui", "quoi", "quoique", "revoici", "revoilà", "s", "sa", "sans", "sauf", "se", "selon", "seront", "ses", "si", "sien", "sienne", "siennes", "siens", "sinon", "soi", "soit", "son", "sont", "sous", "suivant", "sur", "ta", "te", "tes", "tien", "tienne", "tiennes", "tiens", "toi", "ton", "tous", "tout", "toute", "toutes", "tu", "un", "une", "va", "vers", "voici", "voilà", "vos", "votre", "vous", "vu", "vôtre", "vôtres", "y", "à", "ça", "ès", "été", "être", "ô" };
/*     */   public static final String DEFAULT_STOPWORD_FILE = "french_stop.txt";
/* 103 */   public static final CharArraySet DEFAULT_ARTICLES = CharArraySet.unmodifiableSet(new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "l", "m", "t", "qu", "n", "s", "j", "d", "c", "jusqu", "quoiqu", "lorsqu", "puisqu" }), true));
/*     */   private final CharArraySet excltable;
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/* 117 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public FrenchAnalyzer(Version matchVersion)
/*     */   {
/* 143 */     this(matchVersion, matchVersion.onOrAfter(Version.LUCENE_31) ? DefaultSetHolder.DEFAULT_STOP_SET : DefaultSetHolder.DEFAULT_STOP_SET_30);
/*     */   }
/*     */ 
/*     */   public FrenchAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/* 157 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public FrenchAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclutionSet)
/*     */   {
/* 172 */     super(matchVersion, stopwords);
/* 173 */     this.excltable = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclutionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 192 */     if (this.matchVersion.onOrAfter(Version.LUCENE_31)) {
/* 193 */       Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 194 */       TokenStream result = new StandardFilter(this.matchVersion, source);
/* 195 */       result = new ElisionFilter(result, DEFAULT_ARTICLES);
/* 196 */       result = new LowerCaseFilter(this.matchVersion, result);
/* 197 */       result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 198 */       if (!this.excltable.isEmpty())
/* 199 */         result = new SetKeywordMarkerFilter(result, this.excltable);
/* 200 */       if (this.matchVersion.onOrAfter(Version.LUCENE_36))
/* 201 */         result = new FrenchLightStemFilter(result);
/*     */       else {
/* 203 */         result = new SnowballFilter(result, new FrenchStemmer());
/*     */       }
/* 205 */       return new Analyzer.TokenStreamComponents(source, result);
/*     */     }
/* 207 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 208 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/* 209 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 210 */     if (!this.excltable.isEmpty())
/* 211 */       result = new SetKeywordMarkerFilter(result, this.excltable);
/* 212 */     result = new FrenchStemFilter(result);
/*     */ 
/* 214 */     return new Analyzer.TokenStreamComponents(source, new LowerCaseFilter(this.matchVersion, result));
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */ 
/*     */     @Deprecated
/* 123 */     static final CharArraySet DEFAULT_STOP_SET_30 = CharArraySet.unmodifiableSet(new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(FrenchAnalyzer.FRENCH_STOP_WORDS), false));
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/* 129 */         DEFAULT_STOP_SET = WordlistLoader.getSnowballWordSet(IOUtils.getDecodingReader(SnowballFilter.class, "french_stop.txt", StandardCharsets.UTF_8), Version.LUCENE_CURRENT);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 134 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.fr.FrenchAnalyzer
 * JD-Core Version:    0.6.2
 */