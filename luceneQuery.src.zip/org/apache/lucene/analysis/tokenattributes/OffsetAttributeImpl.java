/*    */ package org.apache.lucene.analysis.tokenattributes;
/*    */ 
/*    */ import org.apache.lucene.util.AttributeImpl;
/*    */ 
/*    */ public class OffsetAttributeImpl extends AttributeImpl
/*    */   implements OffsetAttribute, Cloneable
/*    */ {
/*    */   private int startOffset;
/*    */   private int endOffset;
/*    */ 
/*    */   public int startOffset()
/*    */   {
/* 32 */     return this.startOffset;
/*    */   }
/*    */ 
/*    */   public void setOffset(int startOffset, int endOffset)
/*    */   {
/* 44 */     if ((startOffset < 0) || (endOffset < startOffset)) {
/* 45 */       throw new IllegalArgumentException("startOffset must be non-negative, and endOffset must be >= startOffset, startOffset=" + startOffset + ",endOffset=" + endOffset);
/*    */     }
/*    */ 
/* 49 */     this.startOffset = startOffset;
/* 50 */     this.endOffset = endOffset;
/*    */   }
/*    */ 
/*    */   public int endOffset()
/*    */   {
/* 55 */     return this.endOffset;
/*    */   }
/*    */ 
/*    */   public void clear()
/*    */   {
/* 63 */     this.startOffset = 0;
/* 64 */     this.endOffset = 0;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 69 */     if (other == this) {
/* 70 */       return true;
/*    */     }
/*    */ 
/* 73 */     if ((other instanceof OffsetAttributeImpl)) {
/* 74 */       OffsetAttributeImpl o = (OffsetAttributeImpl)other;
/* 75 */       return (o.startOffset == this.startOffset) && (o.endOffset == this.endOffset);
/*    */     }
/*    */ 
/* 78 */     return false;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 83 */     int code = this.startOffset;
/* 84 */     code = code * 31 + this.endOffset;
/* 85 */     return code;
/*    */   }
/*    */ 
/*    */   public void copyTo(AttributeImpl target)
/*    */   {
/* 90 */     OffsetAttribute t = (Cloneable)target;
/* 91 */     t.setOffset(this.startOffset, this.endOffset);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.tokenattributes.OffsetAttributeImpl
 * JD-Core Version:    0.6.2
 */