/*     */ package org.apache.lucene.analysis.commongrams;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionLengthAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class CommonGramsFilter extends TokenFilter
/*     */ {
/*     */   public static final String GRAM_TYPE = "gram";
/*     */   private static final char SEPARATOR = '_';
/*     */   private final CharArraySet commonWords;
/*  60 */   private final StringBuilder buffer = new StringBuilder();
/*     */ 
/*  62 */   private final CharTermAttribute termAttribute = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  63 */   private final OffsetAttribute offsetAttribute = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*  64 */   private final TypeAttribute typeAttribute = (TypeAttribute)addAttribute(TypeAttribute.class);
/*  65 */   private final PositionIncrementAttribute posIncAttribute = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*  66 */   private final PositionLengthAttribute posLenAttribute = (PositionLengthAttribute)addAttribute(PositionLengthAttribute.class);
/*     */   private int lastStartOffset;
/*     */   private boolean lastWasCommon;
/*     */   private AttributeSource.State savedState;
/*     */ 
/*     */   public CommonGramsFilter(Version matchVersion, TokenStream input, CharArraySet commonWords)
/*     */   {
/*  82 */     super(input);
/*  83 */     this.commonWords = commonWords;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 105 */     if (this.savedState != null) {
/* 106 */       restoreState(this.savedState);
/* 107 */       this.savedState = null;
/* 108 */       saveTermBuffer();
/* 109 */       return true;
/* 110 */     }if (!this.input.incrementToken()) {
/* 111 */       return false;
/*     */     }
/*     */ 
/* 118 */     if ((this.lastWasCommon) || ((isCommon()) && (this.buffer.length() > 0))) {
/* 119 */       this.savedState = captureState();
/* 120 */       gramToken();
/* 121 */       return true;
/*     */     }
/*     */ 
/* 124 */     saveTermBuffer();
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 133 */     super.reset();
/* 134 */     this.lastWasCommon = false;
/* 135 */     this.savedState = null;
/* 136 */     this.buffer.setLength(0);
/*     */   }
/*     */ 
/*     */   private boolean isCommon()
/*     */   {
/* 147 */     return (this.commonWords != null) && (this.commonWords.contains(this.termAttribute.buffer(), 0, this.termAttribute.length()));
/*     */   }
/*     */ 
/*     */   private void saveTermBuffer()
/*     */   {
/* 154 */     this.buffer.setLength(0);
/* 155 */     this.buffer.append(this.termAttribute.buffer(), 0, this.termAttribute.length());
/* 156 */     this.buffer.append('_');
/* 157 */     this.lastStartOffset = this.offsetAttribute.startOffset();
/* 158 */     this.lastWasCommon = isCommon();
/*     */   }
/*     */ 
/*     */   private void gramToken()
/*     */   {
/* 165 */     this.buffer.append(this.termAttribute.buffer(), 0, this.termAttribute.length());
/* 166 */     int endOffset = this.offsetAttribute.endOffset();
/*     */ 
/* 168 */     clearAttributes();
/*     */ 
/* 170 */     int length = this.buffer.length();
/* 171 */     char[] termText = this.termAttribute.buffer();
/* 172 */     if (length > termText.length) {
/* 173 */       termText = this.termAttribute.resizeBuffer(length);
/*     */     }
/*     */ 
/* 176 */     this.buffer.getChars(0, length, termText, 0);
/* 177 */     this.termAttribute.setLength(length);
/* 178 */     this.posIncAttribute.setPositionIncrement(0);
/* 179 */     this.posLenAttribute.setPositionLength(2);
/* 180 */     this.offsetAttribute.setOffset(this.lastStartOffset, endOffset);
/* 181 */     this.typeAttribute.setType("gram");
/* 182 */     this.buffer.setLength(0);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.commongrams.CommonGramsFilter
 * JD-Core Version:    0.6.2
 */