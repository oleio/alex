/*    */ package org.apache.lucene.analysis.commongrams;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.core.StopAnalyzer;
/*    */ import org.apache.lucene.analysis.util.CharArraySet;
/*    */ import org.apache.lucene.analysis.util.ResourceLoader;
/*    */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class CommonGramsFilterFactory extends TokenFilterFactory
/*    */   implements ResourceLoaderAware
/*    */ {
/*    */   private CharArraySet commonWords;
/*    */   private final String commonWordFiles;
/*    */   private final String format;
/*    */   private final boolean ignoreCase;
/*    */ 
/*    */   public CommonGramsFilterFactory(Map<String, String> args)
/*    */   {
/* 47 */     super(args);
/* 48 */     this.commonWordFiles = get(args, "words");
/* 49 */     this.format = get(args, "format");
/* 50 */     this.ignoreCase = getBoolean(args, "ignoreCase", false);
/* 51 */     if (!args.isEmpty())
/* 52 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public void inform(ResourceLoader loader)
/*    */     throws IOException
/*    */   {
/* 58 */     if (this.commonWordFiles != null) {
/* 59 */       if ("snowball".equalsIgnoreCase(this.format))
/* 60 */         this.commonWords = getSnowballWordSet(loader, this.commonWordFiles, this.ignoreCase);
/*    */       else
/* 62 */         this.commonWords = getWordSet(loader, this.commonWordFiles, this.ignoreCase);
/*    */     }
/*    */     else
/* 65 */       this.commonWords = StopAnalyzer.ENGLISH_STOP_WORDS_SET;
/*    */   }
/*    */ 
/*    */   public boolean isIgnoreCase()
/*    */   {
/* 70 */     return this.ignoreCase;
/*    */   }
/*    */ 
/*    */   public CharArraySet getCommonWords() {
/* 74 */     return this.commonWords;
/*    */   }
/*    */ 
/*    */   public TokenFilter create(TokenStream input)
/*    */   {
/* 79 */     CommonGramsFilter commonGrams = new CommonGramsFilter(this.luceneMatchVersion, input, this.commonWords);
/* 80 */     return commonGrams;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.commongrams.CommonGramsFilterFactory
 * JD-Core Version:    0.6.2
 */