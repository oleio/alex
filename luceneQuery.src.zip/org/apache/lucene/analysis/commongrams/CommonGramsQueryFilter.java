/*     */ package org.apache.lucene.analysis.commongrams;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ 
/*     */ public final class CommonGramsQueryFilter extends TokenFilter
/*     */ {
/*  47 */   private final TypeAttribute typeAttribute = (TypeAttribute)addAttribute(TypeAttribute.class);
/*  48 */   private final PositionIncrementAttribute posIncAttribute = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*     */   private AttributeSource.State previous;
/*     */   private String previousType;
/*     */   private boolean exhausted;
/*     */ 
/*     */   public CommonGramsQueryFilter(CommonGramsFilter input)
/*     */   {
/*  60 */     super(input);
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/*  68 */     super.reset();
/*  69 */     this.previous = null;
/*  70 */     this.previousType = null;
/*  71 */     this.exhausted = false;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*  84 */     while ((!this.exhausted) && (this.input.incrementToken())) {
/*  85 */       AttributeSource.State current = captureState();
/*     */ 
/*  87 */       if ((this.previous != null) && (!isGramType())) {
/*  88 */         restoreState(this.previous);
/*  89 */         this.previous = current;
/*  90 */         this.previousType = this.typeAttribute.type();
/*     */ 
/*  92 */         if (isGramType()) {
/*  93 */           this.posIncAttribute.setPositionIncrement(1);
/*     */         }
/*  95 */         return true;
/*     */       }
/*     */ 
/*  98 */       this.previous = current;
/*     */     }
/*     */ 
/* 101 */     this.exhausted = true;
/*     */ 
/* 103 */     if ((this.previous == null) || ("gram".equals(this.previousType))) {
/* 104 */       return false;
/*     */     }
/*     */ 
/* 107 */     restoreState(this.previous);
/* 108 */     this.previous = null;
/*     */ 
/* 110 */     if (isGramType()) {
/* 111 */       this.posIncAttribute.setPositionIncrement(1);
/*     */     }
/* 113 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isGramType()
/*     */   {
/* 124 */     return "gram".equals(this.typeAttribute.type());
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.commongrams.CommonGramsQueryFilter
 * JD-Core Version:    0.6.2
 */