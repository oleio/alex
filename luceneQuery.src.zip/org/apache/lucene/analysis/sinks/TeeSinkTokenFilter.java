/*     */ package org.apache.lucene.analysis.sinks;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.util.AttributeImpl;
/*     */ import org.apache.lucene.util.AttributeSource;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ 
/*     */ public final class TeeSinkTokenFilter extends TokenFilter
/*     */ {
/*  78 */   private final List<WeakReference<SinkTokenStream>> sinks = new LinkedList();
/*     */ 
/* 243 */   private static final SinkFilter ACCEPT_ALL_FILTER = new SinkFilter()
/*     */   {
/*     */     public boolean accept(AttributeSource source) {
/* 246 */       return true;
/*     */     }
/* 243 */   };
/*     */ 
/*     */   public TeeSinkTokenFilter(TokenStream input)
/*     */   {
/*  84 */     super(input);
/*     */   }
/*     */ 
/*     */   public SinkTokenStream newSinkTokenStream()
/*     */   {
/*  91 */     return newSinkTokenStream(ACCEPT_ALL_FILTER);
/*     */   }
/*     */ 
/*     */   public SinkTokenStream newSinkTokenStream(SinkFilter filter)
/*     */   {
/* 100 */     SinkTokenStream sink = new SinkTokenStream(cloneAttributes(), filter, null);
/* 101 */     this.sinks.add(new WeakReference(sink));
/* 102 */     return sink;
/*     */   }
/*     */ 
/*     */   public void addSinkTokenStream(SinkTokenStream sink)
/*     */   {
/* 112 */     if (!getAttributeFactory().equals(sink.getAttributeFactory())) {
/* 113 */       throw new IllegalArgumentException("The supplied sink is not compatible to this tee");
/*     */     }
/*     */ 
/* 116 */     for (Iterator it = cloneAttributes().getAttributeImplsIterator(); it.hasNext(); ) {
/* 117 */       sink.addAttributeImpl((AttributeImpl)it.next());
/*     */     }
/* 119 */     this.sinks.add(new WeakReference(sink));
/*     */   }
/*     */ 
/*     */   public void consumeAllTokens()
/*     */     throws IOException
/*     */   {
/* 129 */     while (incrementToken());
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 134 */     if (this.input.incrementToken())
/*     */     {
/* 136 */       AttributeSource.State state = null;
/* 137 */       for (WeakReference ref : this.sinks) {
/* 138 */         SinkTokenStream sink = (SinkTokenStream)ref.get();
/* 139 */         if ((sink != null) && 
/* 140 */           (sink.accept(this))) {
/* 141 */           if (state == null) {
/* 142 */             state = captureState();
/*     */           }
/* 144 */           sink.addState(state);
/*     */         }
/*     */       }
/*     */ 
/* 148 */       return true;
/*     */     }
/*     */ 
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */   public final void end() throws IOException
/*     */   {
/* 156 */     super.end();
/* 157 */     AttributeSource.State finalState = captureState();
/* 158 */     for (WeakReference ref : this.sinks) {
/* 159 */       SinkTokenStream sink = (SinkTokenStream)ref.get();
/* 160 */       if (sink != null)
/* 161 */         sink.setFinalState(finalState);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class SinkTokenStream extends TokenStream
/*     */   {
/* 189 */     private final List<AttributeSource.State> cachedStates = new LinkedList();
/*     */     private AttributeSource.State finalState;
/* 191 */     private Iterator<AttributeSource.State> it = null;
/*     */     private TeeSinkTokenFilter.SinkFilter filter;
/*     */ 
/*     */     private SinkTokenStream(AttributeSource source, TeeSinkTokenFilter.SinkFilter filter)
/*     */     {
/* 195 */       super();
/* 196 */       this.filter = filter;
/*     */     }
/*     */ 
/*     */     private boolean accept(AttributeSource source) {
/* 200 */       return this.filter.accept(source);
/*     */     }
/*     */ 
/*     */     private void addState(AttributeSource.State state) {
/* 204 */       if (this.it != null) {
/* 205 */         throw new IllegalStateException("The tee must be consumed before sinks are consumed.");
/*     */       }
/* 207 */       this.cachedStates.add(state);
/*     */     }
/*     */ 
/*     */     private void setFinalState(AttributeSource.State finalState) {
/* 211 */       this.finalState = finalState;
/*     */     }
/*     */ 
/*     */     public final boolean incrementToken()
/*     */     {
/* 217 */       if (this.it == null) {
/* 218 */         this.it = this.cachedStates.iterator();
/*     */       }
/*     */ 
/* 221 */       if (!this.it.hasNext()) {
/* 222 */         return false;
/*     */       }
/*     */ 
/* 225 */       AttributeSource.State state = (AttributeSource.State)this.it.next();
/* 226 */       restoreState(state);
/* 227 */       return true;
/*     */     }
/*     */ 
/*     */     public final void end()
/*     */     {
/* 232 */       if (this.finalState != null)
/* 233 */         restoreState(this.finalState);
/*     */     }
/*     */ 
/*     */     public final void reset()
/*     */     {
/* 239 */       this.it = this.cachedStates.iterator();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class SinkFilter
/*     */   {
/*     */     public abstract boolean accept(AttributeSource paramAttributeSource);
/*     */ 
/*     */     public void reset()
/*     */       throws IOException
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.sinks.TeeSinkTokenFilter
 * JD-Core Version:    0.6.2
 */