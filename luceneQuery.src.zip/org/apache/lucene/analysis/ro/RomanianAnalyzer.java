/*     */ package org.apache.lucene.analysis.ro;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.snowball.SnowballFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.tartarus.snowball.ext.RomanianStemmer;
/*     */ 
/*     */ public final class RomanianAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   private final CharArraySet stemExclusionSet;
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*     */   private static final String STOPWORDS_COMMENT = "#";
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  56 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public RomanianAnalyzer(Version matchVersion)
/*     */   {
/*  82 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   public RomanianAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/*  92 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public RomanianAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/* 105 */     super(matchVersion, stopwords);
/* 106 */     this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 125 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 126 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/* 127 */     result = new LowerCaseFilter(this.matchVersion, result);
/* 128 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 129 */     if (!this.stemExclusionSet.isEmpty())
/* 130 */       result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
/* 131 */     result = new SnowballFilter(result, new RomanianStemmer());
/* 132 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  68 */         DEFAULT_STOP_SET = RomanianAnalyzer.loadStopwordSet(false, RomanianAnalyzer.class, "stopwords.txt", "#");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  73 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ro.RomanianAnalyzer
 * JD-Core Version:    0.6.2
 */