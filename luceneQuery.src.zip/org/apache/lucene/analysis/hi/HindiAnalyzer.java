/*     */ package org.apache.lucene.analysis.hi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.in.IndicNormalizationFilter;
/*     */ import org.apache.lucene.analysis.in.IndicTokenizer;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class HindiAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   private final CharArraySet stemExclusionSet;
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*     */   private static final String STOPWORDS_COMMENT = "#";
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  62 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public HindiAnalyzer(Version version, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/*  91 */     super(version, stopwords);
/*  92 */     this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(this.matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   public HindiAnalyzer(Version version, CharArraySet stopwords)
/*     */   {
/* 103 */     this(version, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public HindiAnalyzer(Version version)
/*     */   {
/* 111 */     this(version, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/*     */     Tokenizer source;
/*     */     Tokenizer source;
/* 130 */     if (this.matchVersion.onOrAfter(Version.LUCENE_36))
/* 131 */       source = new StandardTokenizer(this.matchVersion, reader);
/*     */     else {
/* 133 */       source = new IndicTokenizer(this.matchVersion, reader);
/*     */     }
/* 135 */     TokenStream result = new LowerCaseFilter(this.matchVersion, source);
/* 136 */     if (!this.stemExclusionSet.isEmpty())
/* 137 */       result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
/* 138 */     result = new IndicNormalizationFilter(result);
/* 139 */     result = new HindiNormalizationFilter(result);
/* 140 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 141 */     result = new HindiStemFilter(result);
/* 142 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  74 */         DEFAULT_STOP_SET = HindiAnalyzer.loadStopwordSet(false, HindiAnalyzer.class, "stopwords.txt", "#");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  78 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.hi.HindiAnalyzer
 * JD-Core Version:    0.6.2
 */