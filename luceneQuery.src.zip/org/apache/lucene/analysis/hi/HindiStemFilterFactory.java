/*    */ package org.apache.lucene.analysis.hi;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class HindiStemFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public HindiStemFilterFactory(Map<String, String> args)
/*    */   {
/* 40 */     super(args);
/* 41 */     if (!args.isEmpty())
/* 42 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 48 */     return new HindiStemFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.hi.HindiStemFilterFactory
 * JD-Core Version:    0.6.2
 */