/*     */ package org.apache.lucene.analysis.cn.smart;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ @Deprecated
/*     */ public final class SentenceTokenizer extends Tokenizer
/*     */ {
/*     */   private static final String PUNCTION = "。，！？；,!?;";
/*  44 */   private final StringBuilder buffer = new StringBuilder();
/*     */ 
/*  46 */   private int tokenStart = 0; private int tokenEnd = 0;
/*     */ 
/*  48 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  49 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*  50 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/*     */ 
/*     */   public SentenceTokenizer(Reader reader) {
/*  53 */     super(reader);
/*     */   }
/*     */ 
/*     */   public SentenceTokenizer(AttributeSource.AttributeFactory factory, Reader reader) {
/*  57 */     super(factory, reader);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  62 */     clearAttributes();
/*  63 */     this.buffer.setLength(0);
/*     */ 
/*  66 */     boolean atBegin = true;
/*  67 */     this.tokenStart = this.tokenEnd;
/*  68 */     int ci = this.input.read();
/*  69 */     char ch = (char)ci;
/*     */ 
/*  72 */     while (ci != -1)
/*     */     {
/*  74 */       if ("。，！？；,!?;".indexOf(ch) != -1)
/*     */       {
/*  76 */         this.buffer.append(ch);
/*  77 */         this.tokenEnd += 1;
/*     */       }
/*  79 */       else if ((atBegin) && (" 　\t\r\n".indexOf(ch) != -1)) {
/*  80 */         this.tokenStart += 1;
/*  81 */         this.tokenEnd += 1;
/*  82 */         ci = this.input.read();
/*  83 */         ch = (char)ci;
/*     */       } else {
/*  85 */         this.buffer.append(ch);
/*  86 */         atBegin = false;
/*  87 */         this.tokenEnd += 1;
/*  88 */         char pch = ch;
/*  89 */         ci = this.input.read();
/*  90 */         ch = (char)ci;
/*     */ 
/*  92 */         if ((" 　\t\r\n".indexOf(ch) != -1) && (" 　\t\r\n".indexOf(pch) != -1))
/*     */         {
/*  95 */           this.tokenEnd += 1;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 100 */     if (this.buffer.length() == 0) {
/* 101 */       return false;
/*     */     }
/* 103 */     this.termAtt.setEmpty().append(this.buffer);
/* 104 */     this.offsetAtt.setOffset(correctOffset(this.tokenStart), correctOffset(this.tokenEnd));
/* 105 */     this.typeAtt.setType("sentence");
/* 106 */     return true;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 112 */     super.reset();
/* 113 */     this.tokenStart = (this.tokenEnd = 0);
/*     */   }
/*     */ 
/*     */   public void end() throws IOException
/*     */   {
/* 118 */     super.end();
/*     */ 
/* 120 */     int finalOffset = correctOffset(this.tokenEnd);
/* 121 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.SentenceTokenizer
 * JD-Core Version:    0.6.2
 */