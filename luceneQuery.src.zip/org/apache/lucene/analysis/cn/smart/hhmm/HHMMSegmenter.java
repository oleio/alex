/*     */ package org.apache.lucene.analysis.cn.smart.hhmm;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.lucene.analysis.cn.smart.Utility;
/*     */ 
/*     */ public class HHMMSegmenter
/*     */ {
/*  33 */   private static WordDictionary wordDict = WordDictionary.getInstance();
/*     */ 
/*     */   private SegGraph createSegGraph(String sentence)
/*     */   {
/*  43 */     int i = 0;
/*  44 */     int length = sentence.length();
/*     */ 
/*  46 */     int[] charTypeArray = getCharTypes(sentence);
/*  47 */     StringBuilder wordBuf = new StringBuilder();
/*     */ 
/*  49 */     int frequency = 0;
/*     */ 
/*  54 */     SegGraph segGraph = new SegGraph();
/*  55 */     while (i < length) {
/*  56 */       boolean hasFullWidth = false;
/*     */       int j;
/*     */       char[] charArray;
/*     */       SegToken token;
/*     */       int wordType;
/*  57 */       switch (charTypeArray[i]) {
/*     */       case 4:
/*  59 */         i++;
/*  60 */         break;
/*     */       case 3:
/*  62 */         j = i + 1;
/*  63 */         wordBuf.delete(0, wordBuf.length());
/*     */ 
/*  67 */         wordBuf.append(sentence.charAt(i));
/*  68 */         charArray = new char[] { sentence.charAt(i) };
/*  69 */         frequency = wordDict.getFrequency(charArray);
/*  70 */         token = new SegToken(charArray, i, j, 2, frequency);
/*     */ 
/*  72 */         segGraph.addToken(token);
/*     */ 
/*  74 */         int foundIndex = wordDict.getPrefixMatch(charArray);
/*  75 */         while ((j <= length) && (foundIndex != -1)) {
/*  76 */           if ((wordDict.isEqual(charArray, foundIndex)) && (charArray.length > 1))
/*     */           {
/*  79 */             frequency = wordDict.getFrequency(charArray);
/*  80 */             token = new SegToken(charArray, i, j, 2, frequency);
/*     */ 
/*  82 */             segGraph.addToken(token);
/*     */           }
/*     */ 
/*  85 */           while ((j < length) && (charTypeArray[j] == 4)) {
/*  86 */             j++;
/*     */           }
/*  88 */           if ((j >= length) || (charTypeArray[j] != 3)) break;
/*  89 */           wordBuf.append(sentence.charAt(j));
/*  90 */           charArray = new char[wordBuf.length()];
/*  91 */           wordBuf.getChars(0, charArray.length, charArray, 0);
/*     */ 
/*  95 */           foundIndex = wordDict.getPrefixMatch(charArray, foundIndex);
/*  96 */           j++;
/*     */         }
/*     */ 
/* 101 */         i++;
/* 102 */         break;
/*     */       case 5:
/* 104 */         hasFullWidth = true;
/*     */       case 1:
/* 106 */         j = i + 1;
/*     */ 
/* 108 */         while ((j < length) && ((charTypeArray[j] == 1) || (charTypeArray[j] == 5))) {
/* 109 */           if (charTypeArray[j] == 5)
/* 110 */             hasFullWidth = true;
/* 111 */           j++;
/*     */         }
/*     */ 
/* 114 */         charArray = Utility.STRING_CHAR_ARRAY;
/* 115 */         frequency = wordDict.getFrequency(charArray);
/* 116 */         wordType = hasFullWidth ? 6 : 3;
/* 117 */         token = new SegToken(charArray, i, j, wordType, frequency);
/* 118 */         segGraph.addToken(token);
/* 119 */         i = j;
/* 120 */         break;
/*     */       case 6:
/* 122 */         hasFullWidth = true;
/*     */       case 2:
/* 124 */         j = i + 1;
/*     */ 
/* 126 */         while ((j < length) && ((charTypeArray[j] == 2) || (charTypeArray[j] == 6))) {
/* 127 */           if (charTypeArray[j] == 6)
/* 128 */             hasFullWidth = true;
/* 129 */           j++;
/*     */         }
/*     */ 
/* 132 */         charArray = Utility.NUMBER_CHAR_ARRAY;
/* 133 */         frequency = wordDict.getFrequency(charArray);
/* 134 */         wordType = hasFullWidth ? 7 : 4;
/* 135 */         token = new SegToken(charArray, i, j, wordType, frequency);
/* 136 */         segGraph.addToken(token);
/* 137 */         i = j;
/* 138 */         break;
/*     */       case 0:
/* 140 */         j = i + 1;
/*     */ 
/* 142 */         frequency = 2159997;
/* 143 */         charArray = new char[] { sentence.charAt(i) };
/* 144 */         token = new SegToken(charArray, i, j, 5, frequency);
/* 145 */         segGraph.addToken(token);
/* 146 */         i = j;
/* 147 */         break;
/*     */       default:
/* 149 */         j = i + 1;
/*     */ 
/* 152 */         charArray = Utility.STRING_CHAR_ARRAY;
/* 153 */         frequency = wordDict.getFrequency(charArray);
/* 154 */         token = new SegToken(charArray, i, j, 3, frequency);
/* 155 */         segGraph.addToken(token);
/* 156 */         i = j;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 162 */     char[] charArray = Utility.START_CHAR_ARRAY;
/* 163 */     frequency = wordDict.getFrequency(charArray);
/* 164 */     SegToken token = new SegToken(charArray, -1, 0, 0, frequency);
/* 165 */     segGraph.addToken(token);
/*     */ 
/* 168 */     charArray = Utility.END_CHAR_ARRAY;
/* 169 */     frequency = wordDict.getFrequency(charArray);
/* 170 */     token = new SegToken(charArray, length, length + 1, 1, frequency);
/*     */ 
/* 172 */     segGraph.addToken(token);
/*     */ 
/* 174 */     return segGraph;
/*     */   }
/*     */ 
/*     */   private static int[] getCharTypes(String sentence)
/*     */   {
/* 185 */     int length = sentence.length();
/* 186 */     int[] charTypeArray = new int[length];
/*     */ 
/* 188 */     for (int i = 0; i < length; i++) {
/* 189 */       charTypeArray[i] = Utility.getCharType(sentence.charAt(i));
/*     */     }
/*     */ 
/* 192 */     return charTypeArray;
/*     */   }
/*     */ 
/*     */   public List<SegToken> process(String sentence)
/*     */   {
/* 201 */     SegGraph segGraph = createSegGraph(sentence);
/* 202 */     BiSegGraph biSegGraph = new BiSegGraph(segGraph);
/* 203 */     List shortPath = biSegGraph.getShortPath();
/* 204 */     return shortPath;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.hhmm.HHMMSegmenter
 * JD-Core Version:    0.6.2
 */