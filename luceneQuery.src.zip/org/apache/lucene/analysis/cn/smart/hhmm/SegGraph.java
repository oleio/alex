/*     */ package org.apache.lucene.analysis.cn.smart.hhmm;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ class SegGraph
/*     */ {
/*  37 */   private Map<Integer, ArrayList<SegToken>> tokenListTable = new HashMap();
/*     */ 
/*  39 */   private int maxStart = -1;
/*     */ 
/*     */   public boolean isStartExist(int s)
/*     */   {
/*  48 */     return this.tokenListTable.get(Integer.valueOf(s)) != null;
/*     */   }
/*     */ 
/*     */   public List<SegToken> getStartList(int s)
/*     */   {
/*  58 */     return (List)this.tokenListTable.get(Integer.valueOf(s));
/*     */   }
/*     */ 
/*     */   public int getMaxStart()
/*     */   {
/*  67 */     return this.maxStart;
/*     */   }
/*     */ 
/*     */   public List<SegToken> makeIndex()
/*     */   {
/*  75 */     List result = new ArrayList();
/*  76 */     int s = -1; int count = 0; int size = this.tokenListTable.size();
/*     */ 
/*  78 */     int index = 0;
/*  79 */     while (count < size) {
/*  80 */       if (isStartExist(s)) {
/*  81 */         List tokenList = (List)this.tokenListTable.get(Integer.valueOf(s));
/*  82 */         for (SegToken st : tokenList) {
/*  83 */           st.index = index;
/*  84 */           result.add(st);
/*  85 */           index++;
/*     */         }
/*  87 */         count++;
/*     */       }
/*  89 */       s++;
/*     */     }
/*  91 */     return result;
/*     */   }
/*     */ 
/*     */   public void addToken(SegToken token)
/*     */   {
/*  99 */     int s = token.startOffset;
/* 100 */     if (!isStartExist(s)) {
/* 101 */       ArrayList newlist = new ArrayList();
/* 102 */       newlist.add(token);
/* 103 */       this.tokenListTable.put(Integer.valueOf(s), newlist);
/*     */     } else {
/* 105 */       List tokenList = (List)this.tokenListTable.get(Integer.valueOf(s));
/* 106 */       tokenList.add(token);
/*     */     }
/* 108 */     if (s > this.maxStart)
/* 109 */       this.maxStart = s;
/*     */   }
/*     */ 
/*     */   public List<SegToken> toTokenList()
/*     */   {
/* 118 */     List result = new ArrayList();
/* 119 */     int s = -1; int count = 0; int size = this.tokenListTable.size();
/*     */ 
/* 122 */     while (count < size) {
/* 123 */       if (isStartExist(s)) {
/* 124 */         List tokenList = (List)this.tokenListTable.get(Integer.valueOf(s));
/* 125 */         for (SegToken st : tokenList) {
/* 126 */           result.add(st);
/*     */         }
/* 128 */         count++;
/*     */       }
/* 130 */       s++;
/*     */     }
/* 132 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 137 */     List tokenList = toTokenList();
/* 138 */     StringBuilder sb = new StringBuilder();
/* 139 */     for (SegToken t : tokenList) {
/* 140 */       sb.append(new StringBuilder().append(t).append("\n").toString());
/*     */     }
/* 142 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.hhmm.SegGraph
 * JD-Core Version:    0.6.2
 */