/*    */ package org.apache.lucene.analysis.cn.smart.hhmm;
/*    */ 
/*    */ import org.apache.lucene.analysis.cn.smart.Utility;
/*    */ 
/*    */ public class SegTokenFilter
/*    */ {
/*    */   public SegToken filter(SegToken token)
/*    */   {
/* 43 */     switch (token.wordType) {
/*    */     case 6:
/*    */     case 7:
/* 46 */       for (int i = 0; i < token.charArray.length; i++) {
/* 47 */         if (token.charArray[i] >= 65296)
/*    */         {
/*    */           int tmp67_66 = i;
/*    */           char[] tmp67_63 = token.charArray; tmp67_63[tmp67_66] = ((char)(tmp67_63[tmp67_66] - 65248));
/*    */         }
/* 50 */         if ((token.charArray[i] >= 'A') && (token.charArray[i] <= 'Z'))
/*    */         {
/*    */           int tmp101_100 = i;
/*    */           char[] tmp101_97 = token.charArray; tmp101_97[tmp101_100] = ((char)(tmp101_97[tmp101_100] + ' '));
/*    */         }
/*    */       }
/* 53 */       break;
/*    */     case 3:
/* 55 */       for (int i = 0; i < token.charArray.length; i++)
/* 56 */         if ((token.charArray[i] >= 'A') && (token.charArray[i] <= 'Z'))
/*    */         {
/*    */           int tmp155_154 = i;
/*    */           char[] tmp155_151 = token.charArray; tmp155_151[tmp155_154] = ((char)(tmp155_151[tmp155_154] + ' '));
/*    */         }
/* 59 */       break;
/*    */     case 5:
/* 61 */       token.charArray = Utility.COMMON_DELIMITER;
/* 62 */       break;
/*    */     case 4:
/*    */     }
/*    */ 
/* 66 */     return token;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.hhmm.SegTokenFilter
 * JD-Core Version:    0.6.2
 */