/*     */ package org.apache.lucene.analysis.cn.smart.hhmm;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class SegToken
/*     */ {
/*     */   public char[] charArray;
/*     */   public int startOffset;
/*     */   public int endOffset;
/*     */   public int wordType;
/*     */   public int weight;
/*     */   public int index;
/*     */ 
/*     */   public SegToken(char[] idArray, int start, int end, int wordType, int weight)
/*     */   {
/*  69 */     this.charArray = idArray;
/*  70 */     this.startOffset = start;
/*  71 */     this.endOffset = end;
/*  72 */     this.wordType = wordType;
/*  73 */     this.weight = weight;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  81 */     int prime = 31;
/*  82 */     int result = 1;
/*  83 */     for (int i = 0; i < this.charArray.length; i++) {
/*  84 */       result = 31 * result + this.charArray[i];
/*     */     }
/*  86 */     result = 31 * result + this.endOffset;
/*  87 */     result = 31 * result + this.index;
/*  88 */     result = 31 * result + this.startOffset;
/*  89 */     result = 31 * result + this.weight;
/*  90 */     result = 31 * result + this.wordType;
/*  91 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  99 */     if (this == obj)
/* 100 */       return true;
/* 101 */     if (obj == null)
/* 102 */       return false;
/* 103 */     if (getClass() != obj.getClass())
/* 104 */       return false;
/* 105 */     SegToken other = (SegToken)obj;
/* 106 */     if (!Arrays.equals(this.charArray, other.charArray))
/* 107 */       return false;
/* 108 */     if (this.endOffset != other.endOffset)
/* 109 */       return false;
/* 110 */     if (this.index != other.index)
/* 111 */       return false;
/* 112 */     if (this.startOffset != other.startOffset)
/* 113 */       return false;
/* 114 */     if (this.weight != other.weight)
/* 115 */       return false;
/* 116 */     if (this.wordType != other.wordType)
/* 117 */       return false;
/* 118 */     return true;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.hhmm.SegToken
 * JD-Core Version:    0.6.2
 */