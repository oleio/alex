/*     */ package org.apache.lucene.analysis.cn.smart.hhmm;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import org.apache.lucene.analysis.cn.smart.AnalyzerProfile;
/*     */ import org.apache.lucene.analysis.cn.smart.Utility;
/*     */ 
/*     */ class WordDictionary extends AbstractDictionary
/*     */ {
/*     */   private static WordDictionary singleInstance;
/*     */   public static final int PRIME_INDEX_LENGTH = 12071;
/*     */   private short[] wordIndexTable;
/*     */   private char[] charIndexTable;
/*     */   private char[][][] wordItem_charArrayTable;
/*     */   private int[][] wordItem_frequencyTable;
/*     */ 
/*     */   public static synchronized WordDictionary getInstance()
/*     */   {
/*  83 */     if (singleInstance == null) {
/*  84 */       singleInstance = new WordDictionary();
/*     */       try {
/*  86 */         singleInstance.load();
/*     */       } catch (IOException e) {
/*  88 */         String wordDictRoot = AnalyzerProfile.ANALYSIS_DATA_DIR;
/*  89 */         singleInstance.load(wordDictRoot);
/*     */       } catch (ClassNotFoundException e) {
/*  91 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*  94 */     return singleInstance;
/*     */   }
/*     */ 
/*     */   public void load(String dctFileRoot)
/*     */   {
/* 103 */     String dctFilePath = dctFileRoot + "/coredict.dct";
/* 104 */     File serialObj = new File(dctFileRoot + "/coredict.mem");
/*     */ 
/* 106 */     if ((!serialObj.exists()) || (!loadFromObj(serialObj)))
/*     */     {
/*     */       try
/*     */       {
/* 110 */         this.wordIndexTable = new short[12071];
/* 111 */         this.charIndexTable = new char[12071];
/* 112 */         for (int i = 0; i < 12071; i++) {
/* 113 */           this.charIndexTable[i] = '\000';
/* 114 */           this.wordIndexTable[i] = -1;
/*     */         }
/* 116 */         this.wordItem_charArrayTable = new char[8178][][];
/* 117 */         this.wordItem_frequencyTable = new int[8178][];
/*     */ 
/* 119 */         loadMainDataFromFile(dctFilePath);
/* 120 */         expandDelimiterData();
/* 121 */         mergeSameWords();
/* 122 */         sortEachItems();
/*     */       }
/*     */       catch (IOException e) {
/* 125 */         throw new RuntimeException(e.getMessage());
/*     */       }
/*     */ 
/* 128 */       saveToObj(serialObj);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void load()
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 139 */     InputStream input = getClass().getResourceAsStream("coredict.mem");
/* 140 */     loadFromObjectInputStream(input);
/*     */   }
/*     */ 
/*     */   private boolean loadFromObj(File serialObj) {
/*     */     try {
/* 145 */       loadFromObjectInputStream(new FileInputStream(serialObj));
/* 146 */       return true;
/*     */     } catch (Exception e) {
/* 148 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadFromObjectInputStream(InputStream serialObjectInputStream) throws IOException, ClassNotFoundException
/*     */   {
/* 154 */     ObjectInputStream input = new ObjectInputStream(serialObjectInputStream);
/* 155 */     this.wordIndexTable = ((short[])input.readObject());
/* 156 */     this.charIndexTable = ((char[])input.readObject());
/* 157 */     this.wordItem_charArrayTable = ((char[][][])input.readObject());
/* 158 */     this.wordItem_frequencyTable = ((int[][])input.readObject());
/*     */ 
/* 160 */     input.close();
/*     */   }
/*     */ 
/*     */   private void saveToObj(File serialObj) {
/*     */     try {
/* 165 */       ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(serialObj));
/*     */ 
/* 167 */       output.writeObject(this.wordIndexTable);
/* 168 */       output.writeObject(this.charIndexTable);
/* 169 */       output.writeObject(this.wordItem_charArrayTable);
/* 170 */       output.writeObject(this.wordItem_frequencyTable);
/* 171 */       output.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private int loadMainDataFromFile(String dctFilePath)
/*     */     throws IOException
/*     */   {
/* 186 */     int total = 0;
/*     */ 
/* 189 */     int[] buffer = new int[3];
/* 190 */     byte[] intBuffer = new byte[4];
/*     */ 
/* 192 */     RandomAccessFile dctFile = new RandomAccessFile(dctFilePath, "r");
/*     */ 
/* 195 */     for (int i = 1410; i < 8178; i++)
/*     */     {
/* 199 */       dctFile.read(intBuffer);
/*     */ 
/* 201 */       int cnt = ByteBuffer.wrap(intBuffer).order(ByteOrder.LITTLE_ENDIAN).getInt();
/* 202 */       if (cnt <= 0) {
/* 203 */         this.wordItem_charArrayTable[i] = ((char[][])null);
/* 204 */         this.wordItem_frequencyTable[i] = null;
/*     */       }
/*     */       else {
/* 207 */         this.wordItem_charArrayTable[i] = new char[cnt][];
/* 208 */         this.wordItem_frequencyTable[i] = new int[cnt];
/* 209 */         total += cnt;
/* 210 */         int j = 0;
/* 211 */         while (j < cnt)
/*     */         {
/* 213 */           dctFile.read(intBuffer);
/* 214 */           buffer[0] = ByteBuffer.wrap(intBuffer).order(ByteOrder.LITTLE_ENDIAN).getInt();
/*     */ 
/* 216 */           dctFile.read(intBuffer);
/* 217 */           buffer[1] = ByteBuffer.wrap(intBuffer).order(ByteOrder.LITTLE_ENDIAN).getInt();
/*     */ 
/* 219 */           dctFile.read(intBuffer);
/* 220 */           buffer[2] = ByteBuffer.wrap(intBuffer).order(ByteOrder.LITTLE_ENDIAN).getInt();
/*     */ 
/* 224 */           this.wordItem_frequencyTable[i][j] = buffer[0];
/*     */ 
/* 226 */           int length = buffer[1];
/* 227 */           if (length > 0) {
/* 228 */             byte[] lchBuffer = new byte[length];
/* 229 */             dctFile.read(lchBuffer);
/* 230 */             String tmpword = new String(lchBuffer, "GB2312");
/*     */ 
/* 233 */             this.wordItem_charArrayTable[i][j] = tmpword.toCharArray();
/*     */           }
/*     */           else {
/* 236 */             this.wordItem_charArrayTable[i][j] = null;
/*     */           }
/*     */ 
/* 239 */           j++;
/*     */         }
/*     */ 
/* 242 */         String str = getCCByGB2312Id(i);
/* 243 */         setTableIndex(str.charAt(0), i);
/*     */       }
/*     */     }
/* 245 */     dctFile.close();
/* 246 */     return total;
/*     */   }
/*     */ 
/*     */   private void expandDelimiterData()
/*     */   {
/* 259 */     int delimiterIndex = 5165;
/* 260 */     int i = 0;
/* 261 */     while (i < this.wordItem_charArrayTable[delimiterIndex].length) {
/* 262 */       char c = this.wordItem_charArrayTable[delimiterIndex][i][0];
/* 263 */       int j = getGB2312Id(c);
/* 264 */       if (this.wordItem_charArrayTable[j] == null)
/*     */       {
/* 266 */         int k = i;
/*     */ 
/* 269 */         while ((k < this.wordItem_charArrayTable[delimiterIndex].length) && (this.wordItem_charArrayTable[delimiterIndex][k][0] == c)) {
/* 270 */           k++;
/*     */         }
/*     */ 
/* 274 */         int cnt = k - i;
/* 275 */         if (cnt != 0) {
/* 276 */           this.wordItem_charArrayTable[j] = new char[cnt][];
/* 277 */           this.wordItem_frequencyTable[j] = new int[cnt];
/*     */         }
/*     */ 
/* 281 */         for (k = 0; k < cnt; i++)
/*     */         {
/* 283 */           this.wordItem_frequencyTable[j][k] = this.wordItem_frequencyTable[delimiterIndex][i];
/* 284 */           this.wordItem_charArrayTable[j][k] = new char[this.wordItem_charArrayTable[delimiterIndex][i].length - 1];
/* 285 */           System.arraycopy(this.wordItem_charArrayTable[delimiterIndex][i], 1, this.wordItem_charArrayTable[j][k], 0, this.wordItem_charArrayTable[j][k].length);
/*     */ 
/* 281 */           k++;
/*     */         }
/*     */ 
/* 289 */         setTableIndex(c, j);
/*     */       }
/*     */     }
/*     */ 
/* 293 */     this.wordItem_charArrayTable[delimiterIndex] = ((char[][])null);
/* 294 */     this.wordItem_frequencyTable[delimiterIndex] = null;
/*     */   }
/*     */ 
/*     */   private void mergeSameWords()
/*     */   {
/* 302 */     for (int i = 0; i < 8178; i++)
/* 303 */       if (this.wordItem_charArrayTable[i] != null)
/*     */       {
/* 305 */         int len = 1;
/* 306 */         for (int j = 1; j < this.wordItem_charArrayTable[i].length; j++) {
/* 307 */           if (Utility.compareArray(this.wordItem_charArrayTable[i][j], 0, this.wordItem_charArrayTable[i][(j - 1)], 0) != 0)
/*     */           {
/* 309 */             len++;
/*     */           }
/*     */         }
/* 312 */         if (len < this.wordItem_charArrayTable[i].length) {
/* 313 */           char[][] tempArray = new char[len][];
/* 314 */           int[] tempFreq = new int[len];
/* 315 */           int k = 0;
/* 316 */           tempArray[0] = this.wordItem_charArrayTable[i][0];
/* 317 */           tempFreq[0] = this.wordItem_frequencyTable[i][0];
/* 318 */           for (int j = 1; j < this.wordItem_charArrayTable[i].length; j++) {
/* 319 */             if (Utility.compareArray(this.wordItem_charArrayTable[i][j], 0, tempArray[k], 0) != 0)
/*     */             {
/* 321 */               k++;
/*     */ 
/* 323 */               tempArray[k] = this.wordItem_charArrayTable[i][j];
/* 324 */               tempFreq[k] = this.wordItem_frequencyTable[i][j];
/*     */             }
/*     */             else {
/* 327 */               tempFreq[k] += this.wordItem_frequencyTable[i][j];
/*     */             }
/*     */           }
/*     */ 
/* 331 */           this.wordItem_charArrayTable[i] = tempArray;
/* 332 */           this.wordItem_frequencyTable[i] = tempFreq;
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   private void sortEachItems()
/*     */   {
/* 340 */     for (int i = 0; i < this.wordItem_charArrayTable.length; i++)
/* 341 */       if ((this.wordItem_charArrayTable[i] != null) && (this.wordItem_charArrayTable[i].length > 1))
/*     */       {
/* 343 */         for (int j = 0; j < this.wordItem_charArrayTable[i].length - 1; j++)
/* 344 */           for (int j2 = j + 1; j2 < this.wordItem_charArrayTable[i].length; j2++)
/* 345 */             if (Utility.compareArray(this.wordItem_charArrayTable[i][j], 0, this.wordItem_charArrayTable[i][j2], 0) > 0)
/*     */             {
/* 347 */               char[] tmpArray = this.wordItem_charArrayTable[i][j];
/* 348 */               int tmpFreq = this.wordItem_frequencyTable[i][j];
/* 349 */               this.wordItem_charArrayTable[i][j] = this.wordItem_charArrayTable[i][j2];
/* 350 */               this.wordItem_frequencyTable[i][j] = this.wordItem_frequencyTable[i][j2];
/* 351 */               this.wordItem_charArrayTable[i][j2] = tmpArray;
/* 352 */               this.wordItem_frequencyTable[i][j2] = tmpFreq;
/*     */             }
/*     */       }
/*     */   }
/*     */ 
/*     */   private boolean setTableIndex(char c, int j)
/*     */   {
/* 365 */     int index = getAvaliableTableIndex(c);
/* 366 */     if (index != -1) {
/* 367 */       this.charIndexTable[index] = c;
/* 368 */       this.wordIndexTable[index] = ((short)j);
/* 369 */       return true;
/*     */     }
/* 371 */     return false;
/*     */   }
/*     */ 
/*     */   private short getAvaliableTableIndex(char c) {
/* 375 */     int hash1 = (int)(hash1(c) % 12071L);
/* 376 */     int hash2 = hash2(c) % 12071;
/* 377 */     if (hash1 < 0)
/* 378 */       hash1 = 12071 + hash1;
/* 379 */     if (hash2 < 0)
/* 380 */       hash2 = 12071 + hash2;
/* 381 */     int index = hash1;
/* 382 */     int i = 1;
/*     */ 
/* 384 */     while ((this.charIndexTable[index] != 0) && (this.charIndexTable[index] != c) && (i < 12071)) {
/* 385 */       index = (hash1 + i * hash2) % 12071;
/* 386 */       i++;
/*     */     }
/*     */ 
/* 390 */     if ((i < 12071) && ((this.charIndexTable[index] == 0) || (this.charIndexTable[index] == c)))
/*     */     {
/* 392 */       return (short)index;
/*     */     }
/* 394 */     return -1;
/*     */   }
/*     */ 
/*     */   private short getWordItemTableIndex(char c) {
/* 398 */     int hash1 = (int)(hash1(c) % 12071L);
/* 399 */     int hash2 = hash2(c) % 12071;
/* 400 */     if (hash1 < 0)
/* 401 */       hash1 = 12071 + hash1;
/* 402 */     if (hash2 < 0)
/* 403 */       hash2 = 12071 + hash2;
/* 404 */     int index = hash1;
/* 405 */     int i = 1;
/*     */ 
/* 407 */     while ((this.charIndexTable[index] != 0) && (this.charIndexTable[index] != c) && (i < 12071)) {
/* 408 */       index = (hash1 + i * hash2) % 12071;
/* 409 */       i++;
/*     */     }
/*     */ 
/* 412 */     if ((i < 12071) && (this.charIndexTable[index] == c)) {
/* 413 */       return (short)index;
/*     */     }
/* 415 */     return -1;
/*     */   }
/*     */ 
/*     */   private int findInTable(short knownHashIndex, char[] charArray)
/*     */   {
/* 429 */     if ((charArray == null) || (charArray.length == 0)) {
/* 430 */       return -1;
/*     */     }
/* 432 */     char[][] items = this.wordItem_charArrayTable[this.wordIndexTable[knownHashIndex]];
/* 433 */     int start = 0; int end = items.length - 1;
/* 434 */     int mid = (start + end) / 2;
/*     */ 
/* 437 */     while (start <= end) {
/* 438 */       int cmpResult = Utility.compareArray(items[mid], 0, charArray, 1);
/*     */ 
/* 440 */       if (cmpResult == 0)
/* 441 */         return mid;
/* 442 */       if (cmpResult < 0)
/* 443 */         start = mid + 1;
/* 444 */       else if (cmpResult > 0) {
/* 445 */         end = mid - 1;
/*     */       }
/* 447 */       mid = (start + end) / 2;
/*     */     }
/* 449 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getPrefixMatch(char[] charArray)
/*     */   {
/* 460 */     return getPrefixMatch(charArray, 0);
/*     */   }
/*     */ 
/*     */   public int getPrefixMatch(char[] charArray, int knownStart)
/*     */   {
/* 472 */     short index = getWordItemTableIndex(charArray[0]);
/* 473 */     if (index == -1)
/* 474 */       return -1;
/* 475 */     char[][] items = this.wordItem_charArrayTable[this.wordIndexTable[index]];
/* 476 */     int start = knownStart; int end = items.length - 1;
/*     */ 
/* 478 */     int mid = (start + end) / 2;
/*     */ 
/* 481 */     while (start <= end) {
/* 482 */       int cmpResult = Utility.compareArrayByPrefix(charArray, 1, items[mid], 0);
/* 483 */       if (cmpResult == 0)
/*     */       {
/* 486 */         while ((mid >= 0) && (Utility.compareArrayByPrefix(charArray, 1, items[mid], 0) == 0))
/* 487 */           mid--;
/* 488 */         mid++;
/* 489 */         return mid;
/* 490 */       }if (cmpResult < 0)
/* 491 */         end = mid - 1;
/*     */       else
/* 493 */         start = mid + 1;
/* 494 */       mid = (start + end) / 2;
/*     */     }
/* 496 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getFrequency(char[] charArray)
/*     */   {
/* 506 */     short hashIndex = getWordItemTableIndex(charArray[0]);
/* 507 */     if (hashIndex == -1)
/* 508 */       return 0;
/* 509 */     int itemIndex = findInTable(hashIndex, charArray);
/* 510 */     if (itemIndex != -1)
/* 511 */       return this.wordItem_frequencyTable[this.wordIndexTable[hashIndex]][itemIndex];
/* 512 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean isEqual(char[] charArray, int itemIndex)
/*     */   {
/* 524 */     short hashIndex = getWordItemTableIndex(charArray[0]);
/* 525 */     return Utility.compareArray(charArray, 1, this.wordItem_charArrayTable[this.wordIndexTable[hashIndex]][itemIndex], 0) == 0;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.hhmm.WordDictionary
 * JD-Core Version:    0.6.2
 */