/*    */ package org.apache.lucene.analysis.cn.smart;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.apache.lucene.analysis.cn.smart.hhmm.HHMMSegmenter;
/*    */ import org.apache.lucene.analysis.cn.smart.hhmm.SegToken;
/*    */ import org.apache.lucene.analysis.cn.smart.hhmm.SegTokenFilter;
/*    */ 
/*    */ class WordSegmenter
/*    */ {
/* 33 */   private HHMMSegmenter hhmmSegmenter = new HHMMSegmenter();
/*    */ 
/* 35 */   private SegTokenFilter tokenFilter = new SegTokenFilter();
/*    */ 
/*    */   public List<SegToken> segmentSentence(String sentence, int startOffset)
/*    */   {
/* 46 */     List segTokenList = this.hhmmSegmenter.process(sentence);
/*    */ 
/* 48 */     List result = Collections.emptyList();
/*    */ 
/* 50 */     if (segTokenList.size() > 2) {
/* 51 */       result = segTokenList.subList(1, segTokenList.size() - 1);
/*    */     }
/* 53 */     for (SegToken st : result) {
/* 54 */       convertSegToken(st, sentence, startOffset);
/*    */     }
/* 56 */     return result;
/*    */   }
/*    */ 
/*    */   public SegToken convertSegToken(SegToken st, String sentence, int sentenceStartOffset)
/*    */   {
/* 72 */     switch (st.wordType) {
/*    */     case 3:
/*    */     case 4:
/*    */     case 6:
/*    */     case 7:
/* 77 */       st.charArray = sentence.substring(st.startOffset, st.endOffset).toCharArray();
/*    */ 
/* 79 */       break;
/*    */     case 5:
/*    */     }
/*    */ 
/* 84 */     st = this.tokenFilter.filter(st);
/* 85 */     st.startOffset += sentenceStartOffset;
/* 86 */     st.endOffset += sentenceStartOffset;
/* 87 */     return st;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.WordSegmenter
 * JD-Core Version:    0.6.2
 */