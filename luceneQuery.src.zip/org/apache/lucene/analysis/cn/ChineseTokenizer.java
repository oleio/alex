/*     */ package org.apache.lucene.analysis.cn;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ @Deprecated
/*     */ public final class ChineseTokenizer extends Tokenizer
/*     */ {
/*  69 */   private int offset = 0; private int bufferIndex = 0; private int dataLen = 0;
/*     */   private static final int MAX_WORD_LEN = 255;
/*     */   private static final int IO_BUFFER_SIZE = 1024;
/*  72 */   private final char[] buffer = new char['ÿ'];
/*  73 */   private final char[] ioBuffer = new char[1024];
/*     */   private int length;
/*     */   private int start;
/*  79 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  80 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */ 
/*     */   public ChineseTokenizer(Reader in)
/*     */   {
/*  62 */     super(in);
/*     */   }
/*     */ 
/*     */   public ChineseTokenizer(AttributeSource.AttributeFactory factory, Reader in) {
/*  66 */     super(factory, in);
/*     */   }
/*     */ 
/*     */   private final void push(char c)
/*     */   {
/*  84 */     if (this.length == 0) this.start = (this.offset - 1);
/*  85 */     this.buffer[(this.length++)] = Character.toLowerCase(c);
/*     */   }
/*     */ 
/*     */   private final boolean flush()
/*     */   {
/*  91 */     if (this.length > 0)
/*     */     {
/*  94 */       this.termAtt.copyBuffer(this.buffer, 0, this.length);
/*  95 */       this.offsetAtt.setOffset(correctOffset(this.start), correctOffset(this.start + this.length));
/*  96 */       return true;
/*     */     }
/*     */ 
/*  99 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/* 104 */     clearAttributes();
/*     */ 
/* 106 */     this.length = 0;
/* 107 */     this.start = this.offset;
/*     */     while (true)
/*     */     {
/* 113 */       this.offset += 1;
/*     */ 
/* 115 */       if (this.bufferIndex >= this.dataLen) {
/* 116 */         this.dataLen = this.input.read(this.ioBuffer);
/* 117 */         this.bufferIndex = 0;
/*     */       }
/*     */ 
/* 120 */       if (this.dataLen == -1) {
/* 121 */         this.offset -= 1;
/* 122 */         return flush();
/*     */       }
/* 124 */       char c = this.ioBuffer[(this.bufferIndex++)];
/*     */ 
/* 127 */       switch (Character.getType(c))
/*     */       {
/*     */       case 1:
/*     */       case 2:
/*     */       case 9:
/* 132 */         push(c);
/* 133 */         if (this.length == 255) return flush();
/*     */ 
/*     */         break;
/*     */       case 5:
/* 137 */         if (this.length > 0) {
/* 138 */           this.bufferIndex -= 1;
/* 139 */           this.offset -= 1;
/* 140 */           return flush();
/*     */         }
/* 142 */         push(c);
/* 143 */         return flush();
/*     */       case 3:
/*     */       case 4:
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/*     */       default:
/* 146 */         if (this.length > 0) return flush(); break;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void end()
/*     */     throws IOException
/*     */   {
/* 154 */     super.end();
/*     */ 
/* 156 */     int finalOffset = correctOffset(this.offset);
/* 157 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 162 */     super.reset();
/* 163 */     this.offset = (this.bufferIndex = this.dataLen = 0);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.ChineseTokenizer
 * JD-Core Version:    0.6.2
 */