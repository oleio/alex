/*     */ package org.apache.lucene.analysis.cn;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ @Deprecated
/*     */ public final class ChineseFilter extends TokenFilter
/*     */ {
/*  52 */   public static final String[] STOP_WORDS = { "and", "are", "as", "at", "be", "but", "by", "for", "if", "in", "into", "is", "it", "no", "not", "of", "on", "or", "such", "that", "the", "their", "then", "there", "these", "they", "this", "to", "was", "will", "with" };
/*     */   private CharArraySet stopTable;
/*  63 */   private CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */ 
/*     */   public ChineseFilter(TokenStream in) {
/*  66 */     super(in);
/*     */ 
/*  68 */     this.stopTable = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(STOP_WORDS), false);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*  74 */     while (this.input.incrementToken()) {
/*  75 */       char[] text = this.termAtt.buffer();
/*  76 */       int termLength = this.termAtt.length();
/*     */ 
/*  79 */       if (!this.stopTable.contains(text, 0, termLength)) {
/*  80 */         switch (Character.getType(text[0]))
/*     */         {
/*     */         case 1:
/*     */         case 2:
/*  86 */           if (termLength > 1) {
/*  87 */             return true;
/*     */           }
/*     */ 
/*     */           break;
/*     */         case 5:
/*  95 */           return true;
/*     */         case 3:
/*     */         case 4:
/*     */         }
/*     */       }
/*     */     }
/* 101 */     return false;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.ChineseFilter
 * JD-Core Version:    0.6.2
 */