/*    */ package org.apache.lucene.analysis.cn;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ @Deprecated
/*    */ public class ChineseFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public ChineseFilterFactory(Map<String, String> args)
/*    */   {
/* 36 */     super(args);
/* 37 */     if (!args.isEmpty())
/* 38 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ChineseFilter create(TokenStream in)
/*    */   {
/* 43 */     return new ChineseFilter(in);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.ChineseFilterFactory
 * JD-Core Version:    0.6.2
 */