/*    */ package org.apache.lucene.analysis.cn;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.Analyzer;
/*    */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*    */ import org.apache.lucene.analysis.Tokenizer;
/*    */ 
/*    */ @Deprecated
/*    */ public final class ChineseAnalyzer extends Analyzer
/*    */ {
/*    */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*    */   {
/* 47 */     Tokenizer source = new ChineseTokenizer(reader);
/* 48 */     return new Analyzer.TokenStreamComponents(source, new ChineseFilter(source));
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.ChineseAnalyzer
 * JD-Core Version:    0.6.2
 */