/*     */ package org.apache.lucene.analysis.en;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardAnalyzer;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class EnglishAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   private final CharArraySet stemExclusionSet;
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  46 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public EnglishAnalyzer(Version matchVersion)
/*     */   {
/*  61 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   public EnglishAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/*  71 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public EnglishAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/*  84 */     super(matchVersion, stopwords);
/*  85 */     this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 105 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 106 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/*     */ 
/* 108 */     if (this.matchVersion.onOrAfter(Version.LUCENE_31))
/* 109 */       result = new EnglishPossessiveFilter(this.matchVersion, result);
/* 110 */     result = new LowerCaseFilter(this.matchVersion, result);
/* 111 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 112 */     if (!this.stemExclusionSet.isEmpty())
/* 113 */       result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
/* 114 */     result = new PorterStemFilter(result);
/* 115 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*  54 */     static final CharArraySet DEFAULT_STOP_SET = StandardAnalyzer.STOP_WORDS_SET;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.en.EnglishAnalyzer
 * JD-Core Version:    0.6.2
 */