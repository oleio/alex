/*    */ package org.apache.lucene.analysis.en;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*    */ 
/*    */ public final class KStemFilter extends TokenFilter
/*    */ {
/* 50 */   private final KStemmer stemmer = new KStemmer();
/* 51 */   private final CharTermAttribute termAttribute = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 52 */   private final KeywordAttribute keywordAtt = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/*    */ 
/*    */   public KStemFilter(TokenStream in) {
/* 55 */     super(in);
/*    */   }
/*    */ 
/*    */   public boolean incrementToken()
/*    */     throws IOException
/*    */   {
/* 64 */     if (!this.input.incrementToken()) {
/* 65 */       return false;
/*    */     }
/* 67 */     char[] term = this.termAttribute.buffer();
/* 68 */     int len = this.termAttribute.length();
/* 69 */     if ((!this.keywordAtt.isKeyword()) && (this.stemmer.stem(term, len))) {
/* 70 */       this.termAttribute.setEmpty().append(this.stemmer.asCharSequence());
/*    */     }
/*    */ 
/* 73 */     return true;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.en.KStemFilter
 * JD-Core Version:    0.6.2
 */