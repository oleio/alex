/*    */ package org.apache.lucene.analysis.en;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class EnglishPossessiveFilter extends TokenFilter
/*    */ {
/* 39 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */   private Version matchVersion;
/*    */ 
/*    */   @Deprecated
/*    */   public EnglishPossessiveFilter(TokenStream input)
/*    */   {
/* 47 */     this(Version.LUCENE_35, input);
/*    */   }
/*    */ 
/*    */   public EnglishPossessiveFilter(Version version, TokenStream input) {
/* 51 */     super(input);
/* 52 */     this.matchVersion = version;
/*    */   }
/*    */ 
/*    */   public boolean incrementToken() throws IOException
/*    */   {
/* 57 */     if (!this.input.incrementToken()) {
/* 58 */       return false;
/*    */     }
/*    */ 
/* 61 */     char[] buffer = this.termAtt.buffer();
/* 62 */     int bufferLength = this.termAtt.length();
/*    */ 
/* 64 */     if ((bufferLength >= 2) && ((buffer[(bufferLength - 2)] == '\'') || ((this.matchVersion.onOrAfter(Version.LUCENE_36)) && ((buffer[(bufferLength - 2)] == '’') || (buffer[(bufferLength - 2)] == 65287)))) && ((buffer[(bufferLength - 1)] == 's') || (buffer[(bufferLength - 1)] == 'S')))
/*    */     {
/* 68 */       this.termAtt.setLength(bufferLength - 2);
/*    */     }
/*    */ 
/* 71 */     return true;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.en.EnglishPossessiveFilter
 * JD-Core Version:    0.6.2
 */