/*    */ package org.apache.lucene.analysis.en;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*    */ 
/*    */ public final class PorterStemFilter extends TokenFilter
/*    */ {
/* 57 */   private final PorterStemmer stemmer = new PorterStemmer();
/* 58 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 59 */   private final KeywordAttribute keywordAttr = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/*    */ 
/*    */   public PorterStemFilter(TokenStream in) {
/* 62 */     super(in);
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken() throws IOException
/*    */   {
/* 67 */     if (!this.input.incrementToken()) {
/* 68 */       return false;
/*    */     }
/* 70 */     if ((!this.keywordAttr.isKeyword()) && (this.stemmer.stem(this.termAtt.buffer(), 0, this.termAtt.length())))
/* 71 */       this.termAtt.copyBuffer(this.stemmer.getResultBuffer(), 0, this.stemmer.getResultLength());
/* 72 */     return true;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.en.PorterStemFilter
 * JD-Core Version:    0.6.2
 */