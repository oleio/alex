/*     */ package org.apache.lucene.analysis.fa;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.ar.ArabicLetterTokenizer;
/*     */ import org.apache.lucene.analysis.ar.ArabicNormalizationFilter;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class PersianAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*     */   public static final String STOPWORDS_COMMENT = "#";
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  66 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public PersianAnalyzer(Version matchVersion)
/*     */   {
/*  92 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   public PersianAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/* 104 */     super(matchVersion, stopwords);
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/*     */     Tokenizer source;
/*     */     Tokenizer source;
/* 121 */     if (this.matchVersion.onOrAfter(Version.LUCENE_31))
/* 122 */       source = new StandardTokenizer(this.matchVersion, reader);
/*     */     else {
/* 124 */       source = new ArabicLetterTokenizer(this.matchVersion, reader);
/*     */     }
/* 126 */     TokenStream result = new LowerCaseFilter(this.matchVersion, source);
/* 127 */     result = new ArabicNormalizationFilter(result);
/*     */ 
/* 129 */     result = new PersianNormalizationFilter(result);
/*     */ 
/* 134 */     return new Analyzer.TokenStreamComponents(source, new StopFilter(this.matchVersion, result, this.stopwords));
/*     */   }
/*     */ 
/*     */   protected Reader initReader(String fieldName, Reader reader)
/*     */   {
/* 142 */     return this.matchVersion.onOrAfter(Version.LUCENE_31) ? new PersianCharFilter(reader) : reader;
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  78 */         DEFAULT_STOP_SET = PersianAnalyzer.loadStopwordSet(false, PersianAnalyzer.class, "stopwords.txt", "#");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  82 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.fa.PersianAnalyzer
 * JD-Core Version:    0.6.2
 */