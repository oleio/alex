/*    */ package org.apache.lucene.analysis.fa;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.CharFilter;
/*    */ import org.apache.lucene.analysis.util.AbstractAnalysisFactory;
/*    */ import org.apache.lucene.analysis.util.CharFilterFactory;
/*    */ import org.apache.lucene.analysis.util.MultiTermAwareComponent;
/*    */ 
/*    */ public class PersianCharFilterFactory extends CharFilterFactory
/*    */   implements MultiTermAwareComponent
/*    */ {
/*    */   public PersianCharFilterFactory(Map<String, String> args)
/*    */   {
/* 43 */     super(args);
/* 44 */     if (!args.isEmpty())
/* 45 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public CharFilter create(Reader input)
/*    */   {
/* 51 */     return new PersianCharFilter(input);
/*    */   }
/*    */ 
/*    */   public AbstractAnalysisFactory getMultiTermComponent()
/*    */   {
/* 56 */     return this;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.fa.PersianCharFilterFactory
 * JD-Core Version:    0.6.2
 */