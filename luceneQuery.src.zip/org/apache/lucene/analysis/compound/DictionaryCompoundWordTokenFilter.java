/*    */ package org.apache.lucene.analysis.compound;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.util.CharArraySet;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public class DictionaryCompoundWordTokenFilter extends CompoundWordTokenFilterBase
/*    */ {
/*    */   public DictionaryCompoundWordTokenFilter(Version matchVersion, TokenStream input, CharArraySet dictionary)
/*    */   {
/* 59 */     super(matchVersion, input, dictionary);
/* 60 */     if (dictionary == null)
/* 61 */       throw new IllegalArgumentException("dictionary cannot be null");
/*    */   }
/*    */ 
/*    */   public DictionaryCompoundWordTokenFilter(Version matchVersion, TokenStream input, CharArraySet dictionary, int minWordSize, int minSubwordSize, int maxSubwordSize, boolean onlyLongestMatch)
/*    */   {
/* 88 */     super(matchVersion, input, dictionary, minWordSize, minSubwordSize, maxSubwordSize, onlyLongestMatch);
/* 89 */     if (dictionary == null)
/* 90 */       throw new IllegalArgumentException("dictionary cannot be null");
/*    */   }
/*    */ 
/*    */   protected void decompose()
/*    */   {
/* 96 */     int len = this.termAtt.length();
/* 97 */     for (int i = 0; i <= len - this.minSubwordSize; i++) {
/* 98 */       CompoundWordTokenFilterBase.CompoundToken longestMatchToken = null;
/* 99 */       for (int j = this.minSubwordSize; (j <= this.maxSubwordSize) && 
/* 100 */         (i + j <= len); j++)
/*    */       {
/* 103 */         if (this.dictionary.contains(this.termAtt.buffer(), i, j)) {
/* 104 */           if (this.onlyLongestMatch) {
/* 105 */             if (longestMatchToken != null) {
/* 106 */               if (longestMatchToken.txt.length() < j)
/* 107 */                 longestMatchToken = new CompoundWordTokenFilterBase.CompoundToken(this, i, j);
/*    */             }
/*    */             else
/* 110 */               longestMatchToken = new CompoundWordTokenFilterBase.CompoundToken(this, i, j);
/*    */           }
/*    */           else {
/* 113 */             this.tokens.add(new CompoundWordTokenFilterBase.CompoundToken(this, i, j));
/*    */           }
/*    */         }
/*    */       }
/* 117 */       if ((this.onlyLongestMatch) && (longestMatchToken != null))
/* 118 */         this.tokens.add(longestMatchToken);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.compound.DictionaryCompoundWordTokenFilter
 * JD-Core Version:    0.6.2
 */