/*     */ package org.apache.lucene.analysis.compound;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.compound.hyphenation.HyphenationTree;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.ResourceLoader;
/*     */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*     */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ public class HyphenationCompoundWordTokenFilterFactory extends TokenFilterFactory
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   private CharArraySet dictionary;
/*     */   private HyphenationTree hyphenator;
/*     */   private final String dictFile;
/*     */   private final String hypFile;
/*     */   private final String encoding;
/*     */   private final int minWordSize;
/*     */   private final int minSubwordSize;
/*     */   private final int maxSubwordSize;
/*     */   private final boolean onlyLongestMatch;
/*     */ 
/*     */   public HyphenationCompoundWordTokenFilterFactory(Map<String, String> args)
/*     */   {
/*  73 */     super(args);
/*  74 */     assureMatchVersion();
/*  75 */     this.dictFile = get(args, "dictionary");
/*  76 */     this.encoding = get(args, "encoding");
/*  77 */     this.hypFile = require(args, "hyphenator");
/*  78 */     this.minWordSize = getInt(args, "minWordSize", 5);
/*  79 */     this.minSubwordSize = getInt(args, "minSubwordSize", 2);
/*  80 */     this.maxSubwordSize = getInt(args, "maxSubwordSize", 15);
/*  81 */     this.onlyLongestMatch = getBoolean(args, "onlyLongestMatch", false);
/*  82 */     if (!args.isEmpty())
/*  83 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*     */   }
/*     */ 
/*     */   public void inform(ResourceLoader loader)
/*     */     throws IOException
/*     */   {
/*  89 */     InputStream stream = null;
/*     */     try {
/*  91 */       if (this.dictFile != null) {
/*  92 */         this.dictionary = getWordSet(loader, this.dictFile, false);
/*     */       }
/*     */ 
/*  95 */       stream = loader.openResource(this.hypFile);
/*  96 */       InputSource is = new InputSource(stream);
/*  97 */       is.setEncoding(this.encoding);
/*  98 */       is.setSystemId(this.hypFile);
/*  99 */       this.hyphenator = HyphenationCompoundWordTokenFilter.getHyphenationTree(is);
/*     */     } finally {
/* 101 */       IOUtils.closeWhileHandlingException(new Closeable[] { stream });
/*     */     }
/*     */   }
/*     */ 
/*     */   public HyphenationCompoundWordTokenFilter create(TokenStream input)
/*     */   {
/* 107 */     return new HyphenationCompoundWordTokenFilter(this.luceneMatchVersion, input, this.hyphenator, this.dictionary, this.minWordSize, this.minSubwordSize, this.maxSubwordSize, this.onlyLongestMatch);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.compound.HyphenationCompoundWordTokenFilterFactory
 * JD-Core Version:    0.6.2
 */