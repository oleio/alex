/*     */ package org.apache.lucene.analysis.compound;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.LinkedList;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.compound.hyphenation.Hyphenation;
/*     */ import org.apache.lucene.analysis.compound.hyphenation.HyphenationTree;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ public class HyphenationCompoundWordTokenFilter extends CompoundWordTokenFilterBase
/*     */ {
/*     */   private HyphenationTree hyphenator;
/*     */ 
/*     */   public HyphenationCompoundWordTokenFilter(Version matchVersion, TokenStream input, HyphenationTree hyphenator, CharArraySet dictionary)
/*     */   {
/*  67 */     this(matchVersion, input, hyphenator, dictionary, 5, 2, 15, false);
/*     */   }
/*     */ 
/*     */   public HyphenationCompoundWordTokenFilter(Version matchVersion, TokenStream input, HyphenationTree hyphenator, CharArraySet dictionary, int minWordSize, int minSubwordSize, int maxSubwordSize, boolean onlyLongestMatch)
/*     */   {
/*  97 */     super(matchVersion, input, dictionary, minWordSize, minSubwordSize, maxSubwordSize, onlyLongestMatch);
/*     */ 
/* 100 */     this.hyphenator = hyphenator;
/*     */   }
/*     */ 
/*     */   public HyphenationCompoundWordTokenFilter(Version matchVersion, TokenStream input, HyphenationTree hyphenator, int minWordSize, int minSubwordSize, int maxSubwordSize)
/*     */   {
/* 113 */     this(matchVersion, input, hyphenator, null, minWordSize, minSubwordSize, maxSubwordSize, false);
/*     */   }
/*     */ 
/*     */   public HyphenationCompoundWordTokenFilter(Version matchVersion, TokenStream input, HyphenationTree hyphenator)
/*     */   {
/* 126 */     this(matchVersion, input, hyphenator, 5, 2, 15);
/*     */   }
/*     */ 
/*     */   public static HyphenationTree getHyphenationTree(String hyphenationFilename)
/*     */     throws IOException
/*     */   {
/* 139 */     return getHyphenationTree(new InputSource(hyphenationFilename));
/*     */   }
/*     */ 
/*     */   public static HyphenationTree getHyphenationTree(File hyphenationFile)
/*     */     throws IOException
/*     */   {
/* 151 */     return getHyphenationTree(new InputSource(hyphenationFile.toURI().toASCIIString()));
/*     */   }
/*     */ 
/*     */   public static HyphenationTree getHyphenationTree(InputSource hyphenationSource)
/*     */     throws IOException
/*     */   {
/* 163 */     HyphenationTree tree = new HyphenationTree();
/* 164 */     tree.loadPatterns(hyphenationSource);
/* 165 */     return tree;
/*     */   }
/*     */ 
/*     */   protected void decompose()
/*     */   {
/* 171 */     Hyphenation hyphens = this.hyphenator.hyphenate(this.termAtt.buffer(), 0, this.termAtt.length(), 1, 1);
/*     */ 
/* 173 */     if (hyphens == null) {
/* 174 */       return;
/*     */     }
/*     */ 
/* 177 */     int[] hyp = hyphens.getHyphenationPoints();
/*     */ 
/* 179 */     for (int i = 0; i < hyp.length; i++) {
/* 180 */       int remaining = hyp.length - i;
/* 181 */       int start = hyp[i];
/* 182 */       CompoundWordTokenFilterBase.CompoundToken longestMatchToken = null;
/* 183 */       for (int j = 1; j < remaining; j++) {
/* 184 */         int partLength = hyp[(i + j)] - start;
/*     */ 
/* 188 */         if (partLength > this.maxSubwordSize)
/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/* 194 */         if (partLength >= this.minSubwordSize)
/*     */         {
/* 201 */           if ((this.dictionary == null) || (this.dictionary.contains(this.termAtt.buffer(), start, partLength))) {
/* 202 */             if (this.onlyLongestMatch) {
/* 203 */               if (longestMatchToken != null) {
/* 204 */                 if (longestMatchToken.txt.length() < partLength)
/* 205 */                   longestMatchToken = new CompoundWordTokenFilterBase.CompoundToken(this, start, partLength);
/*     */               }
/*     */               else
/* 208 */                 longestMatchToken = new CompoundWordTokenFilterBase.CompoundToken(this, start, partLength);
/*     */             }
/*     */             else
/* 211 */               this.tokens.add(new CompoundWordTokenFilterBase.CompoundToken(this, start, partLength));
/*     */           }
/* 213 */           else if (this.dictionary.contains(this.termAtt.buffer(), start, partLength - 1))
/*     */           {
/* 218 */             if (this.onlyLongestMatch) {
/* 219 */               if (longestMatchToken != null) {
/* 220 */                 if (longestMatchToken.txt.length() < partLength - 1)
/* 221 */                   longestMatchToken = new CompoundWordTokenFilterBase.CompoundToken(this, start, partLength - 1);
/*     */               }
/*     */               else
/* 224 */                 longestMatchToken = new CompoundWordTokenFilterBase.CompoundToken(this, start, partLength - 1);
/*     */             }
/*     */             else
/* 227 */               this.tokens.add(new CompoundWordTokenFilterBase.CompoundToken(this, start, partLength - 1));
/*     */           }
/*     */         }
/*     */       }
/* 231 */       if ((this.onlyLongestMatch) && (longestMatchToken != null))
/* 232 */         this.tokens.add(longestMatchToken);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.compound.HyphenationCompoundWordTokenFilter
 * JD-Core Version:    0.6.2
 */