/*     */ package org.apache.lucene.analysis.compound.hyphenation;
/*     */ 
/*     */ public class CharVector
/*     */   implements Cloneable
/*     */ {
/*     */   private static final int DEFAULT_BLOCK_SIZE = 2048;
/*     */   private int blockSize;
/*     */   private char[] array;
/*     */   private int n;
/*     */ 
/*     */   public CharVector()
/*     */   {
/*  46 */     this(2048);
/*     */   }
/*     */ 
/*     */   public CharVector(int capacity) {
/*  50 */     if (capacity > 0)
/*  51 */       this.blockSize = capacity;
/*     */     else {
/*  53 */       this.blockSize = 2048;
/*     */     }
/*  55 */     this.array = new char[this.blockSize];
/*  56 */     this.n = 0;
/*     */   }
/*     */ 
/*     */   public CharVector(char[] a) {
/*  60 */     this.blockSize = 2048;
/*  61 */     this.array = a;
/*  62 */     this.n = a.length;
/*     */   }
/*     */ 
/*     */   public CharVector(char[] a, int capacity) {
/*  66 */     if (capacity > 0)
/*  67 */       this.blockSize = capacity;
/*     */     else {
/*  69 */       this.blockSize = 2048;
/*     */     }
/*  71 */     this.array = a;
/*  72 */     this.n = a.length;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  79 */     this.n = 0;
/*     */   }
/*     */ 
/*     */   public CharVector clone()
/*     */   {
/*  84 */     CharVector cv = new CharVector((char[])this.array.clone(), this.blockSize);
/*  85 */     cv.n = this.n;
/*  86 */     return cv;
/*     */   }
/*     */ 
/*     */   public char[] getArray() {
/*  90 */     return this.array;
/*     */   }
/*     */ 
/*     */   public int length()
/*     */   {
/*  97 */     return this.n;
/*     */   }
/*     */ 
/*     */   public int capacity()
/*     */   {
/* 104 */     return this.array.length;
/*     */   }
/*     */ 
/*     */   public void put(int index, char val) {
/* 108 */     this.array[index] = val;
/*     */   }
/*     */ 
/*     */   public char get(int index) {
/* 112 */     return this.array[index];
/*     */   }
/*     */ 
/*     */   public int alloc(int size) {
/* 116 */     int index = this.n;
/* 117 */     int len = this.array.length;
/* 118 */     if (this.n + size >= len) {
/* 119 */       char[] aux = new char[len + this.blockSize];
/* 120 */       System.arraycopy(this.array, 0, aux, 0, len);
/* 121 */       this.array = aux;
/*     */     }
/* 123 */     this.n += size;
/* 124 */     return index;
/*     */   }
/*     */ 
/*     */   public void trimToSize() {
/* 128 */     if (this.n < this.array.length) {
/* 129 */       char[] aux = new char[this.n];
/* 130 */       System.arraycopy(this.array, 0, aux, 0, this.n);
/* 131 */       this.array = aux;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.compound.hyphenation.CharVector
 * JD-Core Version:    0.6.2
 */