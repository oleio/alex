/*     */ package org.apache.lucene.analysis.compound.hyphenation;
/*     */ 
/*     */ public class ByteVector
/*     */ {
/*     */   private static final int DEFAULT_BLOCK_SIZE = 2048;
/*     */   private int blockSize;
/*     */   private byte[] array;
/*     */   private int n;
/*     */ 
/*     */   public ByteVector()
/*     */   {
/*  46 */     this(2048);
/*     */   }
/*     */ 
/*     */   public ByteVector(int capacity) {
/*  50 */     if (capacity > 0)
/*  51 */       this.blockSize = capacity;
/*     */     else {
/*  53 */       this.blockSize = 2048;
/*     */     }
/*  55 */     this.array = new byte[this.blockSize];
/*  56 */     this.n = 0;
/*     */   }
/*     */ 
/*     */   public ByteVector(byte[] a) {
/*  60 */     this.blockSize = 2048;
/*  61 */     this.array = a;
/*  62 */     this.n = 0;
/*     */   }
/*     */ 
/*     */   public ByteVector(byte[] a, int capacity) {
/*  66 */     if (capacity > 0)
/*  67 */       this.blockSize = capacity;
/*     */     else {
/*  69 */       this.blockSize = 2048;
/*     */     }
/*  71 */     this.array = a;
/*  72 */     this.n = 0;
/*     */   }
/*     */ 
/*     */   public byte[] getArray() {
/*  76 */     return this.array;
/*     */   }
/*     */ 
/*     */   public int length()
/*     */   {
/*  83 */     return this.n;
/*     */   }
/*     */ 
/*     */   public int capacity()
/*     */   {
/*  90 */     return this.array.length;
/*     */   }
/*     */ 
/*     */   public void put(int index, byte val) {
/*  94 */     this.array[index] = val;
/*     */   }
/*     */ 
/*     */   public byte get(int index) {
/*  98 */     return this.array[index];
/*     */   }
/*     */ 
/*     */   public int alloc(int size)
/*     */   {
/* 105 */     int index = this.n;
/* 106 */     int len = this.array.length;
/* 107 */     if (this.n + size >= len) {
/* 108 */       byte[] aux = new byte[len + this.blockSize];
/* 109 */       System.arraycopy(this.array, 0, aux, 0, len);
/* 110 */       this.array = aux;
/*     */     }
/* 112 */     this.n += size;
/* 113 */     return index;
/*     */   }
/*     */ 
/*     */   public void trimToSize() {
/* 117 */     if (this.n < this.array.length) {
/* 118 */       byte[] aux = new byte[this.n];
/* 119 */       System.arraycopy(this.array, 0, aux, 0, this.n);
/* 120 */       this.array = aux;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.compound.hyphenation.ByteVector
 * JD-Core Version:    0.6.2
 */