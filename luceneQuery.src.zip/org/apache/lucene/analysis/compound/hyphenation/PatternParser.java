/*     */ package org.apache.lucene.analysis.compound.hyphenation;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ public class PatternParser extends DefaultHandler
/*     */ {
/*     */   XMLReader parser;
/*     */   int currElement;
/*     */   PatternConsumer consumer;
/*     */   StringBuilder token;
/*     */   ArrayList<Object> exception;
/*     */   char hyphenChar;
/*     */   String errMsg;
/*     */   static final int ELEM_CLASSES = 1;
/*     */   static final int ELEM_EXCEPTIONS = 2;
/*     */   static final int ELEM_PATTERNS = 3;
/*     */   static final int ELEM_HYPHEN = 4;
/*     */ 
/*     */   public PatternParser()
/*     */   {
/*  66 */     this.token = new StringBuilder();
/*  67 */     this.parser = createParser();
/*  68 */     this.parser.setContentHandler(this);
/*  69 */     this.parser.setErrorHandler(this);
/*  70 */     this.parser.setEntityResolver(this);
/*  71 */     this.hyphenChar = '-';
/*     */   }
/*     */ 
/*     */   public PatternParser(PatternConsumer consumer)
/*     */   {
/*  76 */     this();
/*  77 */     this.consumer = consumer;
/*     */   }
/*     */ 
/*     */   public void setConsumer(PatternConsumer consumer) {
/*  81 */     this.consumer = consumer;
/*     */   }
/*     */ 
/*     */   public void parse(String filename)
/*     */     throws IOException
/*     */   {
/*  91 */     parse(new InputSource(filename));
/*     */   }
/*     */ 
/*     */   public void parse(File file)
/*     */     throws IOException
/*     */   {
/* 101 */     InputSource src = new InputSource(file.toURI().toASCIIString());
/* 102 */     parse(src);
/*     */   }
/*     */ 
/*     */   public void parse(InputSource source)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 113 */       this.parser.parse(source);
/*     */     } catch (SAXException e) {
/* 115 */       throw new IOException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   static XMLReader createParser()
/*     */   {
/*     */     try
/*     */     {
/* 126 */       SAXParserFactory factory = SAXParserFactory.newInstance();
/* 127 */       factory.setNamespaceAware(true);
/* 128 */       return factory.newSAXParser().getXMLReader();
/*     */     } catch (Exception e) {
/* 130 */       throw new RuntimeException(new StringBuilder().append("Couldn't create XMLReader: ").append(e.getMessage()).toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String readToken(StringBuilder chars)
/*     */   {
/* 136 */     boolean space = false;
/*     */ 
/* 138 */     for (int i = 0; (i < chars.length()) && 
/* 139 */       (Character.isWhitespace(chars.charAt(i))); i++)
/*     */     {
/* 140 */       space = true;
/*     */     }
/*     */ 
/* 145 */     if (space)
/*     */     {
/* 147 */       for (int countr = i; countr < chars.length(); countr++) {
/* 148 */         chars.setCharAt(countr - i, chars.charAt(countr));
/*     */       }
/* 150 */       chars.setLength(chars.length() - i);
/* 151 */       if (this.token.length() > 0) {
/* 152 */         String word = this.token.toString();
/* 153 */         this.token.setLength(0);
/* 154 */         return word;
/*     */       }
/*     */     }
/* 157 */     space = false;
/* 158 */     for (i = 0; i < chars.length(); i++) {
/* 159 */       if (Character.isWhitespace(chars.charAt(i))) {
/* 160 */         space = true;
/* 161 */         break;
/*     */       }
/*     */     }
/* 164 */     this.token.append(chars.toString().substring(0, i));
/*     */ 
/* 166 */     for (int countr = i; countr < chars.length(); countr++) {
/* 167 */       chars.setCharAt(countr - i, chars.charAt(countr));
/*     */     }
/* 169 */     chars.setLength(chars.length() - i);
/* 170 */     if (space) {
/* 171 */       String word = this.token.toString();
/* 172 */       this.token.setLength(0);
/* 173 */       return word;
/*     */     }
/* 175 */     this.token.append(chars);
/* 176 */     return null;
/*     */   }
/*     */ 
/*     */   protected static String getPattern(String word) {
/* 180 */     StringBuilder pat = new StringBuilder();
/* 181 */     int len = word.length();
/* 182 */     for (int i = 0; i < len; i++) {
/* 183 */       if (!Character.isDigit(word.charAt(i))) {
/* 184 */         pat.append(word.charAt(i));
/*     */       }
/*     */     }
/* 187 */     return pat.toString();
/*     */   }
/*     */ 
/*     */   protected ArrayList<Object> normalizeException(ArrayList<?> ex) {
/* 191 */     ArrayList res = new ArrayList();
/* 192 */     for (int i = 0; i < ex.size(); i++) {
/* 193 */       Object item = ex.get(i);
/* 194 */       if ((item instanceof String)) {
/* 195 */         String str = (String)item;
/* 196 */         StringBuilder buf = new StringBuilder();
/* 197 */         for (int j = 0; j < str.length(); j++) {
/* 198 */           char c = str.charAt(j);
/* 199 */           if (c != this.hyphenChar) {
/* 200 */             buf.append(c);
/*     */           } else {
/* 202 */             res.add(buf.toString());
/* 203 */             buf.setLength(0);
/* 204 */             char[] h = new char[1];
/* 205 */             h[0] = this.hyphenChar;
/*     */ 
/* 208 */             res.add(new Hyphen(new String(h), null, null));
/*     */           }
/*     */         }
/* 211 */         if (buf.length() > 0)
/* 212 */           res.add(buf.toString());
/*     */       }
/*     */       else {
/* 215 */         res.add(item);
/*     */       }
/*     */     }
/* 218 */     return res;
/*     */   }
/*     */ 
/*     */   protected String getExceptionWord(ArrayList<?> ex) {
/* 222 */     StringBuilder res = new StringBuilder();
/* 223 */     for (int i = 0; i < ex.size(); i++) {
/* 224 */       Object item = ex.get(i);
/* 225 */       if ((item instanceof String)) {
/* 226 */         res.append((String)item);
/*     */       }
/* 228 */       else if (((Hyphen)item).noBreak != null) {
/* 229 */         res.append(((Hyphen)item).noBreak);
/*     */       }
/*     */     }
/*     */ 
/* 233 */     return res.toString();
/*     */   }
/*     */ 
/*     */   protected static String getInterletterValues(String pat) {
/* 237 */     StringBuilder il = new StringBuilder();
/* 238 */     String word = new StringBuilder().append(pat).append("a").toString();
/* 239 */     int len = word.length();
/* 240 */     for (int i = 0; i < len; i++) {
/* 241 */       char c = word.charAt(i);
/* 242 */       if (Character.isDigit(c)) {
/* 243 */         il.append(c);
/* 244 */         i++;
/*     */       } else {
/* 246 */         il.append('0');
/*     */       }
/*     */     }
/* 249 */     return il.toString();
/*     */   }
/*     */ 
/*     */   public InputSource resolveEntity(String publicId, String systemId)
/*     */   {
/* 258 */     if (((systemId != null) && (systemId.matches("(?i).*\\bhyphenation.dtd\\b.*"))) || ("hyphenation-info".equals(publicId)))
/*     */     {
/* 263 */       return new InputSource(getClass().getResource("hyphenation.dtd").toExternalForm());
/*     */     }
/* 265 */     return null;
/*     */   }
/*     */ 
/*     */   public void startElement(String uri, String local, String raw, Attributes attrs)
/*     */   {
/* 279 */     if (local.equals("hyphen-char")) {
/* 280 */       String h = attrs.getValue("value");
/* 281 */       if ((h != null) && (h.length() == 1))
/* 282 */         this.hyphenChar = h.charAt(0);
/*     */     }
/* 284 */     else if (local.equals("classes")) {
/* 285 */       this.currElement = 1;
/* 286 */     } else if (local.equals("patterns")) {
/* 287 */       this.currElement = 3;
/* 288 */     } else if (local.equals("exceptions")) {
/* 289 */       this.currElement = 2;
/* 290 */       this.exception = new ArrayList();
/* 291 */     } else if (local.equals("hyphen")) {
/* 292 */       if (this.token.length() > 0) {
/* 293 */         this.exception.add(this.token.toString());
/*     */       }
/* 295 */       this.exception.add(new Hyphen(attrs.getValue("pre"), attrs.getValue("no"), attrs.getValue("post")));
/*     */ 
/* 297 */       this.currElement = 4;
/*     */     }
/* 299 */     this.token.setLength(0);
/*     */   }
/*     */ 
/*     */   public void endElement(String uri, String local, String raw)
/*     */   {
/* 310 */     if (this.token.length() > 0) {
/* 311 */       String word = this.token.toString();
/* 312 */       switch (this.currElement) {
/*     */       case 1:
/* 314 */         this.consumer.addClass(word);
/* 315 */         break;
/*     */       case 2:
/* 317 */         this.exception.add(word);
/* 318 */         this.exception = normalizeException(this.exception);
/* 319 */         this.consumer.addException(getExceptionWord(this.exception), (ArrayList)this.exception.clone());
/*     */ 
/* 321 */         break;
/*     */       case 3:
/* 323 */         this.consumer.addPattern(getPattern(word), getInterletterValues(word));
/* 324 */         break;
/*     */       case 4:
/*     */       }
/*     */ 
/* 329 */       if (this.currElement != 4) {
/* 330 */         this.token.setLength(0);
/*     */       }
/*     */     }
/* 333 */     if (this.currElement == 4)
/* 334 */       this.currElement = 2;
/*     */     else
/* 336 */       this.currElement = 0;
/*     */   }
/*     */ 
/*     */   public void characters(char[] ch, int start, int length)
/*     */   {
/* 347 */     StringBuilder chars = new StringBuilder(length);
/* 348 */     chars.append(ch, start, length);
/* 349 */     String word = readToken(chars);
/* 350 */     while (word != null)
/*     */     {
/* 352 */       switch (this.currElement) {
/*     */       case 1:
/* 354 */         this.consumer.addClass(word);
/* 355 */         break;
/*     */       case 2:
/* 357 */         this.exception.add(word);
/* 358 */         this.exception = normalizeException(this.exception);
/* 359 */         this.consumer.addException(getExceptionWord(this.exception), (ArrayList)this.exception.clone());
/*     */ 
/* 361 */         this.exception.clear();
/* 362 */         break;
/*     */       case 3:
/* 364 */         this.consumer.addPattern(getPattern(word), getInterletterValues(word));
/*     */       }
/*     */ 
/* 367 */       word = readToken(chars);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getLocationString(SAXParseException ex)
/*     */   {
/* 376 */     StringBuilder str = new StringBuilder();
/*     */ 
/* 378 */     String systemId = ex.getSystemId();
/* 379 */     if (systemId != null) {
/* 380 */       int index = systemId.lastIndexOf(47);
/* 381 */       if (index != -1) {
/* 382 */         systemId = systemId.substring(index + 1);
/*     */       }
/* 384 */       str.append(systemId);
/*     */     }
/* 386 */     str.append(':');
/* 387 */     str.append(ex.getLineNumber());
/* 388 */     str.append(':');
/* 389 */     str.append(ex.getColumnNumber());
/*     */ 
/* 391 */     return str.toString();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.compound.hyphenation.PatternParser
 * JD-Core Version:    0.6.2
 */