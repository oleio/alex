/*    */ package org.apache.lucene.analysis.compound.hyphenation;
/*    */ 
/*    */ public class Hyphen
/*    */ {
/*    */   public String preBreak;
/*    */   public String noBreak;
/*    */   public String postBreak;
/*    */ 
/*    */   Hyphen(String pre, String no, String post)
/*    */   {
/* 41 */     this.preBreak = pre;
/* 42 */     this.noBreak = no;
/* 43 */     this.postBreak = post;
/*    */   }
/*    */ 
/*    */   Hyphen(String pre) {
/* 47 */     this.preBreak = pre;
/* 48 */     this.noBreak = null;
/* 49 */     this.postBreak = null;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 54 */     if ((this.noBreak == null) && (this.postBreak == null) && (this.preBreak != null) && (this.preBreak.equals("-")))
/*    */     {
/* 56 */       return "-";
/*    */     }
/* 58 */     StringBuilder res = new StringBuilder("{");
/* 59 */     res.append(this.preBreak);
/* 60 */     res.append("}{");
/* 61 */     res.append(this.postBreak);
/* 62 */     res.append("}{");
/* 63 */     res.append(this.noBreak);
/* 64 */     res.append('}');
/* 65 */     return res.toString();
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.compound.hyphenation.Hyphen
 * JD-Core Version:    0.6.2
 */