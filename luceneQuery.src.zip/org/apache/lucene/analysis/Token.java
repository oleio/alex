/*     */ package org.apache.lucene.analysis;
/*     */ 
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttributeImpl;
/*     */ import org.apache.lucene.analysis.tokenattributes.FlagsAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PayloadAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionLengthAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.Attribute;
/*     */ import org.apache.lucene.util.AttributeImpl;
/*     */ import org.apache.lucene.util.AttributeReflector;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ import org.apache.lucene.util.BytesRef;
/*     */ 
/*     */ public class Token extends CharTermAttributeImpl
/*     */   implements TypeAttribute, PositionIncrementAttribute, FlagsAttribute, OffsetAttribute, PayloadAttribute, PositionLengthAttribute
/*     */ {
/*     */   private int startOffset;
/*     */   private int endOffset;
/* 127 */   private String type = "word";
/*     */   private int flags;
/*     */   private BytesRef payload;
/* 130 */   private int positionIncrement = 1;
/* 131 */   private int positionLength = 1;
/*     */ 
/* 623 */   public static final AttributeSource.AttributeFactory TOKEN_ATTRIBUTE_FACTORY = new TokenAttributeFactory(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY);
/*     */ 
/*     */   public Token()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Token(int start, int end)
/*     */   {
/* 142 */     checkOffsets(start, end);
/* 143 */     this.startOffset = start;
/* 144 */     this.endOffset = end;
/*     */   }
/*     */ 
/*     */   public Token(int start, int end, String typ)
/*     */   {
/* 153 */     checkOffsets(start, end);
/* 154 */     this.startOffset = start;
/* 155 */     this.endOffset = end;
/* 156 */     this.type = typ;
/*     */   }
/*     */ 
/*     */   public Token(int start, int end, int flags)
/*     */   {
/* 167 */     checkOffsets(start, end);
/* 168 */     this.startOffset = start;
/* 169 */     this.endOffset = end;
/* 170 */     this.flags = flags;
/*     */   }
/*     */ 
/*     */   public Token(String text, int start, int end)
/*     */   {
/* 183 */     checkOffsets(start, end);
/* 184 */     append(text);
/* 185 */     this.startOffset = start;
/* 186 */     this.endOffset = end;
/*     */   }
/*     */ 
/*     */   public Token(String text, int start, int end, String typ)
/*     */   {
/* 199 */     checkOffsets(start, end);
/* 200 */     append(text);
/* 201 */     this.startOffset = start;
/* 202 */     this.endOffset = end;
/* 203 */     this.type = typ;
/*     */   }
/*     */ 
/*     */   public Token(String text, int start, int end, int flags)
/*     */   {
/* 217 */     checkOffsets(start, end);
/* 218 */     append(text);
/* 219 */     this.startOffset = start;
/* 220 */     this.endOffset = end;
/* 221 */     this.flags = flags;
/*     */   }
/*     */ 
/*     */   public Token(char[] startTermBuffer, int termBufferOffset, int termBufferLength, int start, int end)
/*     */   {
/* 235 */     checkOffsets(start, end);
/* 236 */     copyBuffer(startTermBuffer, termBufferOffset, termBufferLength);
/* 237 */     this.startOffset = start;
/* 238 */     this.endOffset = end;
/*     */   }
/*     */ 
/*     */   public void setPositionIncrement(int positionIncrement)
/*     */   {
/* 247 */     if (positionIncrement < 0) {
/* 248 */       throw new IllegalArgumentException("Increment must be zero or greater: " + positionIncrement);
/*     */     }
/* 250 */     this.positionIncrement = positionIncrement;
/*     */   }
/*     */ 
/*     */   public int getPositionIncrement()
/*     */   {
/* 259 */     return this.positionIncrement;
/*     */   }
/*     */ 
/*     */   public void setPositionLength(int positionLength)
/*     */   {
/* 268 */     this.positionLength = positionLength;
/*     */   }
/*     */ 
/*     */   public int getPositionLength()
/*     */   {
/* 277 */     return this.positionLength;
/*     */   }
/*     */ 
/*     */   public final int startOffset()
/*     */   {
/* 286 */     return this.startOffset;
/*     */   }
/*     */ 
/*     */   public final int endOffset()
/*     */   {
/* 295 */     return this.endOffset;
/*     */   }
/*     */ 
/*     */   public void setOffset(int startOffset, int endOffset)
/*     */   {
/* 304 */     checkOffsets(startOffset, endOffset);
/* 305 */     this.startOffset = startOffset;
/* 306 */     this.endOffset = endOffset;
/*     */   }
/*     */ 
/*     */   public final String type()
/*     */   {
/* 315 */     return this.type;
/*     */   }
/*     */ 
/*     */   public final void setType(String type)
/*     */   {
/* 324 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public int getFlags()
/*     */   {
/* 333 */     return this.flags;
/*     */   }
/*     */ 
/*     */   public void setFlags(int flags)
/*     */   {
/* 342 */     this.flags = flags;
/*     */   }
/*     */ 
/*     */   public BytesRef getPayload()
/*     */   {
/* 351 */     return this.payload;
/*     */   }
/*     */ 
/*     */   public void setPayload(BytesRef payload)
/*     */   {
/* 360 */     this.payload = payload;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 368 */     super.clear();
/* 369 */     this.payload = null;
/* 370 */     this.positionIncrement = 1;
/* 371 */     this.flags = 0;
/* 372 */     this.startOffset = (this.endOffset = 0);
/* 373 */     this.type = "word";
/*     */   }
/*     */ 
/*     */   public Token clone()
/*     */   {
/* 378 */     Token t = (Token)super.clone();
/*     */ 
/* 380 */     if (this.payload != null) {
/* 381 */       t.payload = this.payload.clone();
/*     */     }
/* 383 */     return t;
/*     */   }
/*     */ 
/*     */   public Token clone(char[] newTermBuffer, int newTermOffset, int newTermLength, int newStartOffset, int newEndOffset)
/*     */   {
/* 392 */     Token t = new Token(newTermBuffer, newTermOffset, newTermLength, newStartOffset, newEndOffset);
/* 393 */     t.positionIncrement = this.positionIncrement;
/* 394 */     t.flags = this.flags;
/* 395 */     t.type = this.type;
/* 396 */     if (this.payload != null)
/* 397 */       t.payload = this.payload.clone();
/* 398 */     return t;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 403 */     if (obj == this) {
/* 404 */       return true;
/*     */     }
/* 406 */     if ((obj instanceof Token)) {
/* 407 */       Token other = (Token)obj;
/* 408 */       return (this.startOffset == other.startOffset) && (this.endOffset == other.endOffset) && (this.flags == other.flags) && (this.positionIncrement == other.positionIncrement) && (this.type == null ? other.type == null : this.type.equals(other.type)) && (this.payload == null ? other.payload == null : this.payload.equals(other.payload)) && (super.equals(obj));
/*     */     }
/*     */ 
/* 417 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 422 */     int code = super.hashCode();
/* 423 */     code = code * 31 + this.startOffset;
/* 424 */     code = code * 31 + this.endOffset;
/* 425 */     code = code * 31 + this.flags;
/* 426 */     code = code * 31 + this.positionIncrement;
/* 427 */     if (this.type != null)
/* 428 */       code = code * 31 + this.type.hashCode();
/* 429 */     if (this.payload != null)
/* 430 */       code = code * 31 + this.payload.hashCode();
/* 431 */     return code;
/*     */   }
/*     */ 
/*     */   private void clearNoTermBuffer()
/*     */   {
/* 436 */     this.payload = null;
/* 437 */     this.positionIncrement = 1;
/* 438 */     this.flags = 0;
/* 439 */     this.startOffset = (this.endOffset = 0);
/* 440 */     this.type = "word";
/*     */   }
/*     */ 
/*     */   public Token reinit(char[] newTermBuffer, int newTermOffset, int newTermLength, int newStartOffset, int newEndOffset, String newType)
/*     */   {
/* 449 */     checkOffsets(newStartOffset, newEndOffset);
/* 450 */     clearNoTermBuffer();
/* 451 */     copyBuffer(newTermBuffer, newTermOffset, newTermLength);
/* 452 */     this.payload = null;
/* 453 */     this.positionIncrement = 1;
/* 454 */     this.startOffset = newStartOffset;
/* 455 */     this.endOffset = newEndOffset;
/* 456 */     this.type = newType;
/* 457 */     return this;
/*     */   }
/*     */ 
/*     */   public Token reinit(char[] newTermBuffer, int newTermOffset, int newTermLength, int newStartOffset, int newEndOffset)
/*     */   {
/* 466 */     checkOffsets(newStartOffset, newEndOffset);
/* 467 */     clearNoTermBuffer();
/* 468 */     copyBuffer(newTermBuffer, newTermOffset, newTermLength);
/* 469 */     this.startOffset = newStartOffset;
/* 470 */     this.endOffset = newEndOffset;
/* 471 */     this.type = "word";
/* 472 */     return this;
/*     */   }
/*     */ 
/*     */   public Token reinit(String newTerm, int newStartOffset, int newEndOffset, String newType)
/*     */   {
/* 481 */     checkOffsets(newStartOffset, newEndOffset);
/* 482 */     clear();
/* 483 */     append(newTerm);
/* 484 */     this.startOffset = newStartOffset;
/* 485 */     this.endOffset = newEndOffset;
/* 486 */     this.type = newType;
/* 487 */     return this;
/*     */   }
/*     */ 
/*     */   public Token reinit(String newTerm, int newTermOffset, int newTermLength, int newStartOffset, int newEndOffset, String newType)
/*     */   {
/* 496 */     checkOffsets(newStartOffset, newEndOffset);
/* 497 */     clear();
/* 498 */     append(newTerm, newTermOffset, newTermOffset + newTermLength);
/* 499 */     this.startOffset = newStartOffset;
/* 500 */     this.endOffset = newEndOffset;
/* 501 */     this.type = newType;
/* 502 */     return this;
/*     */   }
/*     */ 
/*     */   public Token reinit(String newTerm, int newStartOffset, int newEndOffset)
/*     */   {
/* 511 */     checkOffsets(newStartOffset, newEndOffset);
/* 512 */     clear();
/* 513 */     append(newTerm);
/* 514 */     this.startOffset = newStartOffset;
/* 515 */     this.endOffset = newEndOffset;
/* 516 */     this.type = "word";
/* 517 */     return this;
/*     */   }
/*     */ 
/*     */   public Token reinit(String newTerm, int newTermOffset, int newTermLength, int newStartOffset, int newEndOffset)
/*     */   {
/* 526 */     checkOffsets(newStartOffset, newEndOffset);
/* 527 */     clear();
/* 528 */     append(newTerm, newTermOffset, newTermOffset + newTermLength);
/* 529 */     this.startOffset = newStartOffset;
/* 530 */     this.endOffset = newEndOffset;
/* 531 */     this.type = "word";
/* 532 */     return this;
/*     */   }
/*     */ 
/*     */   public void reinit(Token prototype)
/*     */   {
/* 540 */     copyBuffer(prototype.buffer(), 0, prototype.length());
/* 541 */     this.positionIncrement = prototype.positionIncrement;
/* 542 */     this.flags = prototype.flags;
/* 543 */     this.startOffset = prototype.startOffset;
/* 544 */     this.endOffset = prototype.endOffset;
/* 545 */     this.type = prototype.type;
/* 546 */     this.payload = prototype.payload;
/*     */   }
/*     */ 
/*     */   public void reinit(Token prototype, String newTerm)
/*     */   {
/* 555 */     setEmpty().append(newTerm);
/* 556 */     this.positionIncrement = prototype.positionIncrement;
/* 557 */     this.flags = prototype.flags;
/* 558 */     this.startOffset = prototype.startOffset;
/* 559 */     this.endOffset = prototype.endOffset;
/* 560 */     this.type = prototype.type;
/* 561 */     this.payload = prototype.payload;
/*     */   }
/*     */ 
/*     */   public void reinit(Token prototype, char[] newTermBuffer, int offset, int length)
/*     */   {
/* 572 */     copyBuffer(newTermBuffer, offset, length);
/* 573 */     this.positionIncrement = prototype.positionIncrement;
/* 574 */     this.flags = prototype.flags;
/* 575 */     this.startOffset = prototype.startOffset;
/* 576 */     this.endOffset = prototype.endOffset;
/* 577 */     this.type = prototype.type;
/* 578 */     this.payload = prototype.payload;
/*     */   }
/*     */ 
/*     */   public void copyTo(AttributeImpl target)
/*     */   {
/* 583 */     if ((target instanceof Token)) {
/* 584 */       Token to = (Token)target;
/* 585 */       to.reinit(this);
/*     */ 
/* 587 */       if (this.payload != null)
/* 588 */         to.payload = this.payload.clone();
/*     */     }
/*     */     else {
/* 591 */       super.copyTo(target);
/* 592 */       ((OffsetAttribute)target).setOffset(this.startOffset, this.endOffset);
/* 593 */       ((PositionIncrementAttribute)target).setPositionIncrement(this.positionIncrement);
/* 594 */       ((PayloadAttribute)target).setPayload(this.payload == null ? null : this.payload.clone());
/* 595 */       ((FlagsAttribute)target).setFlags(this.flags);
/* 596 */       ((PositionLengthAttribute)target).setType(this.type);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void reflectWith(AttributeReflector reflector)
/*     */   {
/* 602 */     super.reflectWith(reflector);
/* 603 */     reflector.reflect(OffsetAttribute.class, "startOffset", Integer.valueOf(this.startOffset));
/* 604 */     reflector.reflect(OffsetAttribute.class, "endOffset", Integer.valueOf(this.endOffset));
/* 605 */     reflector.reflect(PositionIncrementAttribute.class, "positionIncrement", Integer.valueOf(this.positionIncrement));
/* 606 */     reflector.reflect(PayloadAttribute.class, "payload", this.payload);
/* 607 */     reflector.reflect(FlagsAttribute.class, "flags", Integer.valueOf(this.flags));
/* 608 */     reflector.reflect(PositionLengthAttribute.class, "type", this.type);
/*     */   }
/*     */ 
/*     */   private void checkOffsets(int startOffset, int endOffset) {
/* 612 */     if ((startOffset < 0) || (endOffset < startOffset))
/* 613 */       throw new IllegalArgumentException("startOffset must be non-negative, and endOffset must be >= startOffset, startOffset=" + startOffset + ",endOffset=" + endOffset);
/*     */   }
/*     */ 
/*     */   public static final class TokenAttributeFactory extends AttributeSource.AttributeFactory
/*     */   {
/*     */     private final AttributeSource.AttributeFactory delegate;
/*     */ 
/*     */     public TokenAttributeFactory(AttributeSource.AttributeFactory delegate)
/*     */     {
/* 637 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     public AttributeImpl createAttributeInstance(Class<? extends Attribute> attClass)
/*     */     {
/* 642 */       return attClass.isAssignableFrom(Token.class) ? new Token() : this.delegate.createAttributeInstance(attClass);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 648 */       if (this == other) return true;
/* 649 */       if ((other instanceof TokenAttributeFactory)) {
/* 650 */         TokenAttributeFactory af = (TokenAttributeFactory)other;
/* 651 */         return this.delegate.equals(af.delegate);
/*     */       }
/* 653 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 658 */       return this.delegate.hashCode() ^ 0xA45AA31;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.Token
 * JD-Core Version:    0.6.2
 */