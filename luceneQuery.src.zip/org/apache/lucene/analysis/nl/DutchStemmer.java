/*     */ package org.apache.lucene.analysis.nl;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ @Deprecated
/*     */ public class DutchStemmer
/*     */ {
/*  35 */   private static final Locale locale = new Locale("nl", "NL");
/*     */ 
/*  40 */   private StringBuilder sb = new StringBuilder();
/*     */   private boolean _removedE;
/*     */   private Map _stemDict;
/*     */   private int _R1;
/*     */   private int _R2;
/*     */ 
/*     */   public String stem(String term)
/*     */   {
/*  55 */     term = term.toLowerCase(locale);
/*  56 */     if (!isStemmable(term))
/*  57 */       return term;
/*  58 */     if ((this._stemDict != null) && (this._stemDict.containsKey(term))) {
/*  59 */       if ((this._stemDict.get(term) instanceof String)) {
/*  60 */         return (String)this._stemDict.get(term);
/*     */       }
/*  62 */       return null;
/*     */     }
/*     */ 
/*  65 */     this.sb.delete(0, this.sb.length());
/*  66 */     this.sb.insert(0, term);
/*     */ 
/*  68 */     substitute(this.sb);
/*  69 */     storeYandI(this.sb);
/*  70 */     this._R1 = getRIndex(this.sb, 0);
/*  71 */     this._R1 = Math.max(3, this._R1);
/*  72 */     step1(this.sb);
/*  73 */     step2(this.sb);
/*  74 */     this._R2 = getRIndex(this.sb, this._R1);
/*  75 */     step3a(this.sb);
/*  76 */     step3b(this.sb);
/*  77 */     step4(this.sb);
/*  78 */     reStoreYandI(this.sb);
/*  79 */     return this.sb.toString();
/*     */   }
/*     */ 
/*     */   private boolean enEnding(StringBuilder sb) {
/*  83 */     String[] enend = { "ene", "en" };
/*  84 */     for (int i = 0; i < enend.length; i++) {
/*  85 */       String end = enend[i];
/*  86 */       String s = sb.toString();
/*  87 */       int index = s.length() - end.length();
/*  88 */       if ((s.endsWith(end)) && (index >= this._R1) && (isValidEnEnding(sb, index - 1)))
/*     */       {
/*  92 */         sb.delete(index, index + end.length());
/*  93 */         unDouble(sb, index);
/*  94 */         return true;
/*     */       }
/*     */     }
/*  97 */     return false;
/*     */   }
/*     */ 
/*     */   private void step1(StringBuilder sb)
/*     */   {
/* 102 */     if (this._R1 >= sb.length()) {
/* 103 */       return;
/*     */     }
/* 105 */     String s = sb.toString();
/* 106 */     int lengthR1 = sb.length() - this._R1;
/*     */ 
/* 109 */     if (s.endsWith("heden")) {
/* 110 */       sb.replace(this._R1, lengthR1 + this._R1, sb.substring(this._R1, lengthR1 + this._R1).replaceAll("heden", "heid"));
/* 111 */       return;
/*     */     }
/*     */ 
/* 114 */     if (enEnding(sb))
/*     */       return;
/*     */     int index;
/* 117 */     if ((s.endsWith("se")) && ((index = s.length() - 2) >= this._R1) && (isValidSEnding(sb, index - 1)))
/*     */     {
/* 121 */       sb.delete(index, index + 2);
/*     */       return;
/*     */     }
/*     */     int index;
/* 124 */     if ((s.endsWith("s")) && ((index = s.length() - 1) >= this._R1) && (isValidSEnding(sb, index - 1)))
/*     */     {
/* 127 */       sb.delete(index, index + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void step2(StringBuilder sb)
/*     */   {
/* 138 */     this._removedE = false;
/* 139 */     if (this._R1 >= sb.length())
/* 140 */       return;
/* 141 */     String s = sb.toString();
/* 142 */     int index = s.length() - 1;
/* 143 */     if ((index >= this._R1) && (s.endsWith("e")) && (!isVowel(sb.charAt(index - 1))))
/*     */     {
/* 146 */       sb.delete(index, index + 1);
/* 147 */       unDouble(sb);
/* 148 */       this._removedE = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void step3a(StringBuilder sb)
/*     */   {
/* 158 */     if (this._R2 >= sb.length())
/* 159 */       return;
/* 160 */     String s = sb.toString();
/* 161 */     int index = s.length() - 4;
/* 162 */     if ((s.endsWith("heid")) && (index >= this._R2) && (sb.charAt(index - 1) != 'c')) {
/* 163 */       sb.delete(index, index + 4);
/* 164 */       enEnding(sb);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void step3b(StringBuilder sb)
/*     */   {
/* 183 */     if (this._R2 >= sb.length())
/* 184 */       return;
/* 185 */     String s = sb.toString();
/* 186 */     int index = 0;
/*     */ 
/* 188 */     if (((s.endsWith("end")) || (s.endsWith("ing"))) && ((index = s.length() - 3) >= this._R2))
/*     */     {
/* 190 */       sb.delete(index, index + 3);
/* 191 */       if ((sb.charAt(index - 2) == 'i') && (sb.charAt(index - 1) == 'g'))
/*     */       {
/* 193 */         if (((sb.charAt(index - 3) != 'e' ? 1 : 0) & (index - 2 >= this._R2 ? 1 : 0)) != 0) {
/* 194 */           index -= 2;
/* 195 */           sb.delete(index, index + 2);
/*     */         }
/*     */       }
/* 198 */       else unDouble(sb, index);
/*     */ 
/* 200 */       return;
/*     */     }
/* 202 */     if ((s.endsWith("ig")) && ((index = s.length() - 2) >= this._R2))
/*     */     {
/* 205 */       if (sb.charAt(index - 1) != 'e')
/* 206 */         sb.delete(index, index + 2);
/* 207 */       return;
/*     */     }
/* 209 */     if ((s.endsWith("lijk")) && ((index = s.length() - 4) >= this._R2))
/*     */     {
/* 212 */       sb.delete(index, index + 4);
/* 213 */       step2(sb);
/* 214 */       return;
/*     */     }
/* 216 */     if ((s.endsWith("baar")) && ((index = s.length() - 4) >= this._R2))
/*     */     {
/* 219 */       sb.delete(index, index + 4);
/* 220 */       return;
/*     */     }
/* 222 */     if ((s.endsWith("bar")) && ((index = s.length() - 3) >= this._R2))
/*     */     {
/* 225 */       if (this._removedE)
/* 226 */         sb.delete(index, index + 3);
/* 227 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void step4(StringBuilder sb)
/*     */   {
/* 238 */     if (sb.length() < 4)
/* 239 */       return;
/* 240 */     String end = sb.substring(sb.length() - 4, sb.length());
/* 241 */     char c = end.charAt(0);
/* 242 */     char v1 = end.charAt(1);
/* 243 */     char v2 = end.charAt(2);
/* 244 */     char d = end.charAt(3);
/* 245 */     if ((v1 == v2) && (d != 'I') && (v1 != 'i') && (isVowel(v1)) && (!isVowel(d)) && (!isVowel(c)))
/*     */     {
/* 251 */       sb.delete(sb.length() - 2, sb.length() - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isStemmable(String term)
/*     */   {
/* 261 */     for (int c = 0; c < term.length(); c++) {
/* 262 */       if (!Character.isLetter(term.charAt(c))) return false;
/*     */     }
/* 264 */     return true;
/*     */   }
/*     */ 
/*     */   private void substitute(StringBuilder buffer)
/*     */   {
/* 271 */     for (int i = 0; i < buffer.length(); i++)
/* 272 */       switch (buffer.charAt(i))
/*     */       {
/*     */       case 'á':
/*     */       case 'ä':
/* 276 */         buffer.setCharAt(i, 'a');
/* 277 */         break;
/*     */       case 'é':
/*     */       case 'ë':
/* 282 */         buffer.setCharAt(i, 'e');
/* 283 */         break;
/*     */       case 'ú':
/*     */       case 'ü':
/* 288 */         buffer.setCharAt(i, 'u');
/* 289 */         break;
/*     */       case 'i':
/*     */       case 'ï':
/* 294 */         buffer.setCharAt(i, 'i');
/* 295 */         break;
/*     */       case 'ó':
/*     */       case 'ö':
/* 300 */         buffer.setCharAt(i, 'o');
/*     */       }
/*     */   }
/*     */ 
/*     */   private boolean isValidSEnding(StringBuilder sb, int index)
/*     */   {
/* 312 */     char c = sb.charAt(index);
/* 313 */     if ((isVowel(c)) || (c == 'j'))
/* 314 */       return false;
/* 315 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean isValidEnEnding(StringBuilder sb, int index)
/*     */   {
/* 323 */     char c = sb.charAt(index);
/* 324 */     if (isVowel(c))
/* 325 */       return false;
/* 326 */     if (c < '\003') {
/* 327 */       return false;
/*     */     }
/* 329 */     if ((c == 'm') && (sb.charAt(index - 2) == 'g') && (sb.charAt(index - 1) == 'e'))
/* 330 */       return false;
/* 331 */     return true;
/*     */   }
/*     */ 
/*     */   private void unDouble(StringBuilder sb) {
/* 335 */     unDouble(sb, sb.length());
/*     */   }
/*     */ 
/*     */   private void unDouble(StringBuilder sb, int endIndex) {
/* 339 */     String s = sb.substring(0, endIndex);
/* 340 */     if ((s.endsWith("kk")) || (s.endsWith("tt")) || (s.endsWith("dd")) || (s.endsWith("nn")) || (s.endsWith("mm")) || (s.endsWith("ff")))
/* 341 */       sb.delete(endIndex - 1, endIndex);
/*     */   }
/*     */ 
/*     */   private int getRIndex(StringBuilder sb, int start)
/*     */   {
/* 346 */     if (start == 0)
/* 347 */       start = 1;
/* 348 */     for (int i = start; 
/* 349 */       i < sb.length(); i++)
/*     */     {
/* 351 */       if ((!isVowel(sb.charAt(i))) && (isVowel(sb.charAt(i - 1)))) {
/* 352 */         return i + 1;
/*     */       }
/*     */     }
/* 355 */     return i + 1;
/*     */   }
/*     */ 
/*     */   private void storeYandI(StringBuilder sb) {
/* 359 */     if (sb.charAt(0) == 'y') {
/* 360 */       sb.setCharAt(0, 'Y');
/*     */     }
/* 362 */     int last = sb.length() - 1;
/*     */ 
/* 364 */     for (int i = 1; i < last; i++) {
/* 365 */       switch (sb.charAt(i))
/*     */       {
/*     */       case 'i':
/* 368 */         if ((isVowel(sb.charAt(i - 1))) && (isVowel(sb.charAt(i + 1))))
/*     */         {
/* 371 */           sb.setCharAt(i, 'I'); } break;
/*     */       case 'y':
/* 376 */         if (isVowel(sb.charAt(i - 1))) {
/* 377 */           sb.setCharAt(i, 'Y');
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/* 382 */     if ((last > 0) && (sb.charAt(last) == 'y') && (isVowel(sb.charAt(last - 1))))
/* 383 */       sb.setCharAt(last, 'Y');
/*     */   }
/*     */ 
/*     */   private void reStoreYandI(StringBuilder sb) {
/* 387 */     String tmp = sb.toString();
/* 388 */     sb.delete(0, sb.length());
/* 389 */     sb.insert(0, tmp.replaceAll("I", "i").replaceAll("Y", "y"));
/*     */   }
/*     */ 
/*     */   private boolean isVowel(char c) {
/* 393 */     switch (c)
/*     */     {
/*     */     case 'a':
/*     */     case 'e':
/*     */     case 'i':
/*     */     case 'o':
/*     */     case 'u':
/*     */     case 'y':
/*     */     case 'è':
/* 402 */       return true;
/*     */     }
/*     */ 
/* 405 */     return false;
/*     */   }
/*     */ 
/*     */   void setStemDictionary(Map dict) {
/* 409 */     this._stemDict = dict;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.nl.DutchStemmer
 * JD-Core Version:    0.6.2
 */