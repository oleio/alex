/*     */ package org.apache.lucene.analysis.nl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*     */ 
/*     */ @Deprecated
/*     */ public final class DutchStemFilter extends TokenFilter
/*     */ {
/*  53 */   private DutchStemmer stemmer = new DutchStemmer();
/*     */ 
/*  55 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  56 */   private final KeywordAttribute keywordAttr = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/*     */ 
/*     */   public DutchStemFilter(TokenStream _in) {
/*  59 */     super(_in);
/*     */   }
/*     */ 
/*     */   public DutchStemFilter(TokenStream _in, Map<?, ?> stemdictionary)
/*     */   {
/*  66 */     this(_in);
/*  67 */     this.stemmer.setStemDictionary(stemdictionary);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*  75 */     if (this.input.incrementToken()) {
/*  76 */       String term = this.termAtt.toString();
/*     */ 
/*  79 */       if (!this.keywordAttr.isKeyword()) {
/*  80 */         String s = this.stemmer.stem(term);
/*     */ 
/*  82 */         if ((s != null) && (!s.equals(term)))
/*  83 */           this.termAtt.setEmpty().append(s);
/*     */       }
/*  85 */       return true;
/*     */     }
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */   public void setStemmer(DutchStemmer stemmer)
/*     */   {
/*  95 */     if (stemmer != null)
/*  96 */       this.stemmer = stemmer;
/*     */   }
/*     */ 
/*     */   public void setStemDictionary(HashMap<?, ?> dict)
/*     */   {
/* 105 */     if (this.stemmer != null)
/* 106 */       this.stemmer.setStemDictionary(dict);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.nl.DutchStemFilter
 * JD-Core Version:    0.6.2
 */