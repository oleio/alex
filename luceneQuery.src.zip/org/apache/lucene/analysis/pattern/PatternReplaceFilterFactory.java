/*    */ package org.apache.lucene.analysis.pattern;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Map;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class PatternReplaceFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   final Pattern pattern;
/*    */   final String replacement;
/*    */   final boolean replaceAll;
/*    */ 
/*    */   public PatternReplaceFilterFactory(Map<String, String> args)
/*    */   {
/* 47 */     super(args);
/* 48 */     this.pattern = getPattern(args, "pattern");
/* 49 */     this.replacement = get(args, "replacement");
/* 50 */     this.replaceAll = "all".equals(get(args, "replace", Arrays.asList(new String[] { "all", "first" }), "all"));
/* 51 */     if (!args.isEmpty())
/* 52 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public PatternReplaceFilter create(TokenStream input)
/*    */   {
/* 58 */     return new PatternReplaceFilter(input, this.pattern, this.replacement, this.replaceAll);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.pattern.PatternReplaceFilterFactory
 * JD-Core Version:    0.6.2
 */