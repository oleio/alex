/*    */ package org.apache.lucene.analysis.reverse;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class ReverseStringFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public ReverseStringFilterFactory(Map<String, String> args)
/*    */   {
/* 42 */     super(args);
/* 43 */     assureMatchVersion();
/* 44 */     if (!args.isEmpty())
/* 45 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ReverseStringFilter create(TokenStream in)
/*    */   {
/* 51 */     return new ReverseStringFilter(this.luceneMatchVersion, in);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.reverse.ReverseStringFilterFactory
 * JD-Core Version:    0.6.2
 */