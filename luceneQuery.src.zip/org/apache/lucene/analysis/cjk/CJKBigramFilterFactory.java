/*    */ package org.apache.lucene.analysis.cjk;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class CJKBigramFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   final int flags;
/*    */   final boolean outputUnigrams;
/*    */ 
/*    */   public CJKBigramFilterFactory(Map<String, String> args)
/*    */   {
/* 46 */     super(args);
/* 47 */     int flags = 0;
/* 48 */     if (getBoolean(args, "han", true)) {
/* 49 */       flags |= 1;
/*    */     }
/* 51 */     if (getBoolean(args, "hiragana", true)) {
/* 52 */       flags |= 2;
/*    */     }
/* 54 */     if (getBoolean(args, "katakana", true)) {
/* 55 */       flags |= 4;
/*    */     }
/* 57 */     if (getBoolean(args, "hangul", true)) {
/* 58 */       flags |= 8;
/*    */     }
/* 60 */     this.flags = flags;
/* 61 */     this.outputUnigrams = getBoolean(args, "outputUnigrams", false);
/* 62 */     if (!args.isEmpty())
/* 63 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 69 */     return new CJKBigramFilter(input, this.flags, this.outputUnigrams);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cjk.CJKBigramFilterFactory
 * JD-Core Version:    0.6.2
 */