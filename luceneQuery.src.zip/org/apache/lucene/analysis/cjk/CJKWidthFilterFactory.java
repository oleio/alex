/*    */ package org.apache.lucene.analysis.cjk;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.AbstractAnalysisFactory;
/*    */ import org.apache.lucene.analysis.util.MultiTermAwareComponent;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class CJKWidthFilterFactory extends TokenFilterFactory
/*    */   implements MultiTermAwareComponent
/*    */ {
/*    */   public CJKWidthFilterFactory(Map<String, String> args)
/*    */   {
/* 44 */     super(args);
/* 45 */     if (!args.isEmpty())
/* 46 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 52 */     return new CJKWidthFilter(input);
/*    */   }
/*    */ 
/*    */   public AbstractAnalysisFactory getMultiTermComponent()
/*    */   {
/* 57 */     return this;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cjk.CJKWidthFilterFactory
 * JD-Core Version:    0.6.2
 */