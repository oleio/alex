/*    */ package org.apache.lucene.analysis.cjk;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ @Deprecated
/*    */ public class CJKTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   public CJKTokenizerFactory(Map<String, String> args)
/*    */   {
/* 41 */     super(args);
/* 42 */     if (!args.isEmpty())
/* 43 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public CJKTokenizer create(AttributeSource.AttributeFactory factory, Reader in)
/*    */   {
/* 49 */     return new CJKTokenizer(factory, in);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cjk.CJKTokenizerFactory
 * JD-Core Version:    0.6.2
 */