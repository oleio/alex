/*     */ package org.apache.lucene.analysis.cjk;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ @Deprecated
/*     */ public final class CJKTokenizer extends Tokenizer
/*     */ {
/*     */   static final int WORD_TYPE = 0;
/*     */   static final int SINGLE_TOKEN_TYPE = 1;
/*     */   static final int DOUBLE_TOKEN_TYPE = 2;
/*  61 */   static final String[] TOKEN_TYPE_NAMES = { "word", "single", "double" };
/*     */   private static final int MAX_WORD_LEN = 255;
/*     */   private static final int IO_BUFFER_SIZE = 256;
/*  72 */   private int offset = 0;
/*     */ 
/*  75 */   private int bufferIndex = 0;
/*     */ 
/*  78 */   private int dataLen = 0;
/*     */ 
/*  84 */   private final char[] buffer = new char['ÿ'];
/*     */ 
/*  90 */   private final char[] ioBuffer = new char[256];
/*     */ 
/*  93 */   private int tokenType = 0;
/*     */ 
/* 100 */   private boolean preIsTokened = false;
/*     */ 
/* 102 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 103 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 104 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/*     */ 
/*     */   public CJKTokenizer(Reader in)
/*     */   {
/* 114 */     super(in);
/*     */   }
/*     */ 
/*     */   public CJKTokenizer(AttributeSource.AttributeFactory factory, Reader in) {
/* 118 */     super(factory, in);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 136 */     clearAttributes();
/*     */     while (true)
/*     */     {
/* 141 */       int length = 0;
/*     */ 
/* 144 */       int start = this.offset;
/*     */       while (true)
/*     */       {
/* 153 */         this.offset += 1;
/*     */ 
/* 155 */         if (this.bufferIndex >= this.dataLen) {
/* 156 */           this.dataLen = this.input.read(this.ioBuffer);
/* 157 */           this.bufferIndex = 0;
/*     */         }
/*     */ 
/* 160 */         if (this.dataLen == -1) {
/* 161 */           if (length > 0) {
/* 162 */             if (this.preIsTokened == true) {
/* 163 */               length = 0;
/* 164 */               this.preIsTokened = false; break;
/*     */             }
/*     */ 
/* 167 */             this.offset -= 1;
/*     */ 
/* 170 */             break;
/*     */           }
/* 172 */           this.offset -= 1;
/* 173 */           return false;
/*     */         }
/*     */ 
/* 177 */         char c = this.ioBuffer[(this.bufferIndex++)];
/*     */ 
/* 180 */         Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
/*     */ 
/* 184 */         if ((ub == Character.UnicodeBlock.BASIC_LATIN) || (ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS))
/*     */         {
/* 187 */           if (ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS) {
/* 188 */             int i = c;
/* 189 */             if ((i >= 65281) && (i <= 65374))
/*     */             {
/* 191 */               i -= 65248;
/* 192 */               c = (char)i;
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 197 */           if ((Character.isLetterOrDigit(c)) || (c == '_') || (c == '+') || (c == '#'))
/*     */           {
/* 200 */             if (length == 0)
/*     */             {
/* 204 */               start = this.offset - 1;
/* 205 */             } else if (this.tokenType == 2)
/*     */             {
/* 209 */               this.offset -= 1;
/* 210 */               this.bufferIndex -= 1;
/*     */ 
/* 212 */               if (this.preIsTokened != true)
/*     */                 break;
/* 214 */               length = 0;
/* 215 */               this.preIsTokened = false;
/* 216 */               break;
/*     */             }
/*     */ 
/* 223 */             this.buffer[(length++)] = Character.toLowerCase(c);
/* 224 */             this.tokenType = 1;
/*     */ 
/* 227 */             if (length == 255)
/* 228 */               break;
/*     */           }
/* 230 */           else if (length > 0) {
/* 231 */             if (this.preIsTokened != true) break;
/* 232 */             length = 0;
/* 233 */             this.preIsTokened = false;
/*     */           }
/*     */ 
/*     */         }
/* 240 */         else if (Character.isLetter(c)) {
/* 241 */           if (length == 0) {
/* 242 */             start = this.offset - 1;
/* 243 */             this.buffer[(length++)] = c;
/* 244 */             this.tokenType = 2;
/*     */           } else {
/* 246 */             if (this.tokenType == 1) {
/* 247 */               this.offset -= 1;
/* 248 */               this.bufferIndex -= 1;
/*     */ 
/* 251 */               break;
/*     */             }
/* 253 */             this.buffer[(length++)] = c;
/* 254 */             this.tokenType = 2;
/*     */ 
/* 256 */             if (length == 2) {
/* 257 */               this.offset -= 1;
/* 258 */               this.bufferIndex -= 1;
/* 259 */               this.preIsTokened = true;
/*     */ 
/* 261 */               break;
/*     */             }
/*     */           }
/*     */         }
/* 265 */         else if (length > 0) {
/* 266 */           if (this.preIsTokened != true)
/*     */             break;
/* 268 */           length = 0;
/* 269 */           this.preIsTokened = false;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 277 */       if (length > 0) {
/* 278 */         this.termAtt.copyBuffer(this.buffer, 0, length);
/* 279 */         this.offsetAtt.setOffset(correctOffset(start), correctOffset(start + length));
/* 280 */         this.typeAtt.setType(TOKEN_TYPE_NAMES[this.tokenType]);
/* 281 */         return true;
/* 282 */       }if (this.dataLen == -1) {
/* 283 */         this.offset -= 1;
/* 284 */         return false;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void end()
/*     */     throws IOException
/*     */   {
/* 294 */     super.end();
/*     */ 
/* 296 */     int finalOffset = correctOffset(this.offset);
/* 297 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 302 */     super.reset();
/* 303 */     this.offset = (this.bufferIndex = this.dataLen = 0);
/* 304 */     this.preIsTokened = false;
/* 305 */     this.tokenType = 0;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cjk.CJKTokenizer
 * JD-Core Version:    0.6.2
 */