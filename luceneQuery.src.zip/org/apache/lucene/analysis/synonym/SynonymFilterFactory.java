/*     */ package org.apache.lucene.analysis.synonym;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.util.ResourceLoader;
/*     */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*     */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public class SynonymFilterFactory extends TokenFilterFactory
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   private final TokenFilterFactory delegator;
/*     */ 
/*     */   public SynonymFilterFactory(Map<String, String> args)
/*     */   {
/*  69 */     super(args);
/*  70 */     assureMatchVersion();
/*  71 */     if (this.luceneMatchVersion.onOrAfter(Version.LUCENE_34)) {
/*  72 */       this.delegator = new FSTSynonymFilterFactory(new HashMap(getOriginalArgs()));
/*     */     }
/*     */     else
/*     */     {
/*  76 */       if ((args.containsKey("format")) && (!((String)args.get("format")).equals("solr"))) {
/*  77 */         throw new IllegalArgumentException("You must specify luceneMatchVersion >= 3.4 to use alternate synonyms formats");
/*     */       }
/*  79 */       this.delegator = new SlowSynonymFilterFactory(new HashMap(getOriginalArgs()));
/*     */     }
/*     */   }
/*     */ 
/*     */   public TokenStream create(TokenStream input)
/*     */   {
/*  85 */     return this.delegator.create(input);
/*     */   }
/*     */ 
/*     */   public void inform(ResourceLoader loader) throws IOException
/*     */   {
/*  90 */     ((ResourceLoaderAware)this.delegator).inform(loader);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   TokenFilterFactory getDelegator()
/*     */   {
/* 101 */     return this.delegator;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.synonym.SynonymFilterFactory
 * JD-Core Version:    0.6.2
 */