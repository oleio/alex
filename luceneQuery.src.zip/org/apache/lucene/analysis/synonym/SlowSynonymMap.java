/*     */ package org.apache.lucene.analysis.synonym;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.lucene.analysis.Token;
/*     */ import org.apache.lucene.analysis.util.CharArrayMap;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ @Deprecated
/*     */ class SlowSynonymMap
/*     */ {
/*     */   public CharArrayMap<SlowSynonymMap> submap;
/*     */   public Token[] synonyms;
/*     */   int flags;
/*     */   static final int INCLUDE_ORIG = 1;
/*     */   static final int IGNORE_CASE = 2;
/*     */ 
/*     */   public SlowSynonymMap()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SlowSynonymMap(boolean ignoreCase)
/*     */   {
/*  42 */     if (ignoreCase) this.flags |= 2; 
/*     */   }
/*     */ 
/*  45 */   public boolean includeOrig() { return (this.flags & 0x1) != 0; } 
/*  46 */   public boolean ignoreCase() { return (this.flags & 0x2) != 0; }
/*     */ 
/*     */ 
/*     */   public void add(List<String> singleMatch, List<Token> replacement, boolean includeOrig, boolean mergeExisting)
/*     */   {
/*  55 */     SlowSynonymMap currMap = this;
/*  56 */     for (String str : singleMatch) {
/*  57 */       if (currMap.submap == null)
/*     */       {
/*  60 */         currMap.submap = new CharArrayMap(Version.LUCENE_CURRENT, 1, ignoreCase());
/*     */       }
/*     */ 
/*  63 */       SlowSynonymMap map = (SlowSynonymMap)currMap.submap.get(str);
/*  64 */       if (map == null) {
/*  65 */         map = new SlowSynonymMap();
/*  66 */         map.flags |= this.flags & 0x2;
/*  67 */         currMap.submap.put(str, map);
/*     */       }
/*     */ 
/*  70 */       currMap = map;
/*     */     }
/*     */ 
/*  73 */     if ((currMap.synonyms != null) && (!mergeExisting)) {
/*  74 */       throw new IllegalArgumentException(new StringBuilder().append("SynonymFilter: there is already a mapping for ").append(singleMatch).toString());
/*     */     }
/*  76 */     List superset = currMap.synonyms == null ? replacement : mergeTokens(Arrays.asList(currMap.synonyms), replacement);
/*     */ 
/*  78 */     currMap.synonyms = ((Token[])superset.toArray(new Token[superset.size()]));
/*  79 */     if (includeOrig) currMap.flags |= 1;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  85 */     StringBuilder sb = new StringBuilder("<");
/*  86 */     if (this.synonyms != null) {
/*  87 */       sb.append("[");
/*  88 */       for (int i = 0; i < this.synonyms.length; i++) {
/*  89 */         if (i != 0) sb.append(',');
/*  90 */         sb.append(this.synonyms[i]);
/*     */       }
/*  92 */       if ((this.flags & 0x1) != 0) {
/*  93 */         sb.append(",ORIG");
/*     */       }
/*  95 */       sb.append("],");
/*     */     }
/*  97 */     sb.append(this.submap);
/*  98 */     sb.append(">");
/*  99 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static List<Token> makeTokens(List<String> strings)
/*     */   {
/* 106 */     List ret = new ArrayList(strings.size());
/* 107 */     for (String str : strings)
/*     */     {
/* 109 */       Token newTok = new Token(str, 0, 0, "SYNONYM");
/* 110 */       ret.add(newTok);
/*     */     }
/* 112 */     return ret;
/*     */   }
/*     */ 
/*     */   public static List<Token> mergeTokens(List<Token> lst1, List<Token> lst2)
/*     */   {
/* 125 */     ArrayList result = new ArrayList();
/* 126 */     if ((lst1 == null) || (lst2 == null)) {
/* 127 */       if (lst2 != null) result.addAll(lst2);
/* 128 */       if (lst1 != null) result.addAll(lst1);
/* 129 */       return result;
/*     */     }
/*     */ 
/* 132 */     int pos = 0;
/* 133 */     Iterator iter1 = lst1.iterator();
/* 134 */     Iterator iter2 = lst2.iterator();
/* 135 */     Token tok1 = iter1.hasNext() ? (Token)iter1.next() : null;
/* 136 */     Token tok2 = iter2.hasNext() ? (Token)iter2.next() : null;
/* 137 */     int pos1 = tok1 != null ? tok1.getPositionIncrement() : 0;
/* 138 */     int pos2 = tok2 != null ? tok2.getPositionIncrement() : 0;
/* 139 */     while ((tok1 != null) || (tok2 != null)) {
/* 140 */       while ((tok1 != null) && ((pos1 <= pos2) || (tok2 == null))) {
/* 141 */         Token tok = new Token(tok1.startOffset(), tok1.endOffset(), tok1.type());
/* 142 */         tok.copyBuffer(tok1.buffer(), 0, tok1.length());
/* 143 */         tok.setPositionIncrement(pos1 - pos);
/* 144 */         result.add(tok);
/* 145 */         pos = pos1;
/* 146 */         tok1 = iter1.hasNext() ? (Token)iter1.next() : null;
/* 147 */         pos1 += (tok1 != null ? tok1.getPositionIncrement() : 0);
/*     */       }
/* 149 */       while ((tok2 != null) && ((pos2 <= pos1) || (tok1 == null))) {
/* 150 */         Token tok = new Token(tok2.startOffset(), tok2.endOffset(), tok2.type());
/* 151 */         tok.copyBuffer(tok2.buffer(), 0, tok2.length());
/* 152 */         tok.setPositionIncrement(pos2 - pos);
/* 153 */         result.add(tok);
/* 154 */         pos = pos2;
/* 155 */         tok2 = iter2.hasNext() ? (Token)iter2.next() : null;
/* 156 */         pos2 += (tok2 != null ? tok2.getPositionIncrement() : 0);
/*     */       }
/*     */     }
/* 159 */     return result;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.synonym.SlowSynonymMap
 * JD-Core Version:    0.6.2
 */