/*     */ package org.apache.lucene.analysis.synonym;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.LineNumberReader;
/*     */ import java.io.Reader;
/*     */ import java.text.ParseException;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.util.CharsRef;
/*     */ 
/*     */ public class SolrSynonymParser extends SynonymMap.Parser
/*     */ {
/*     */   private final boolean expand;
/*     */ 
/*     */   public SolrSynonymParser(boolean dedup, boolean expand, Analyzer analyzer)
/*     */   {
/*  61 */     super(dedup, analyzer);
/*  62 */     this.expand = expand;
/*     */   }
/*     */ 
/*     */   public void parse(Reader in) throws IOException, ParseException
/*     */   {
/*  67 */     LineNumberReader br = new LineNumberReader(in);
/*     */     try {
/*  69 */       addInternal(br);
/*     */     } catch (IllegalArgumentException e) {
/*  71 */       ParseException ex = new ParseException(new StringBuilder().append("Invalid synonym rule at line ").append(br.getLineNumber()).toString(), 0);
/*  72 */       ex.initCause(e);
/*  73 */       throw ex;
/*     */     } finally {
/*  75 */       br.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void addInternal(BufferedReader in) throws IOException {
/*  80 */     String line = null;
/*  81 */     while ((line = in.readLine()) != null)
/*  82 */       if ((line.length() != 0) && (line.charAt(0) != '#'))
/*     */       {
/*  90 */         String[] sides = split(line, "=>");
/*     */         CharsRef[] inputs;
/*     */         CharsRef[] outputs;
/*  91 */         if (sides.length > 1) {
/*  92 */           if (sides.length != 2) {
/*  93 */             throw new IllegalArgumentException("more than one explicit mapping specified on the same line");
/*     */           }
/*  95 */           String[] inputStrings = split(sides[0], ",");
/*  96 */           CharsRef[] inputs = new CharsRef[inputStrings.length];
/*  97 */           for (int i = 0; i < inputs.length; i++) {
/*  98 */             inputs[i] = analyze(unescape(inputStrings[i]).trim(), new CharsRef());
/*     */           }
/*     */ 
/* 101 */           String[] outputStrings = split(sides[1], ",");
/* 102 */           CharsRef[] outputs = new CharsRef[outputStrings.length];
/* 103 */           for (int i = 0; i < outputs.length; i++)
/* 104 */             outputs[i] = analyze(unescape(outputStrings[i]).trim(), new CharsRef());
/*     */         }
/*     */         else {
/* 107 */           String[] inputStrings = split(line, ",");
/* 108 */           inputs = new CharsRef[inputStrings.length];
/* 109 */           for (int i = 0; i < inputs.length; i++)
/* 110 */             inputs[i] = analyze(unescape(inputStrings[i]).trim(), new CharsRef());
/*     */           CharsRef[] outputs;
/* 112 */           if (this.expand) {
/* 113 */             outputs = inputs;
/*     */           } else {
/* 115 */             outputs = new CharsRef[1];
/* 116 */             outputs[0] = inputs[0];
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 124 */         for (int i = 0; i < inputs.length; i++)
/* 125 */           for (int j = 0; j < outputs.length; j++)
/* 126 */             add(inputs[i], outputs[j], false);
/*     */       }
/*     */   }
/*     */ 
/*     */   private static String[] split(String s, String separator)
/*     */   {
/* 133 */     ArrayList list = new ArrayList(2);
/* 134 */     StringBuilder sb = new StringBuilder();
/* 135 */     int pos = 0; int end = s.length();
/* 136 */     while (pos < end) {
/* 137 */       if (s.startsWith(separator, pos)) {
/* 138 */         if (sb.length() > 0) {
/* 139 */           list.add(sb.toString());
/* 140 */           sb = new StringBuilder();
/*     */         }
/* 142 */         pos += separator.length();
/*     */       }
/*     */       else
/*     */       {
/* 146 */         char ch = s.charAt(pos++);
/* 147 */         if (ch == '\\') {
/* 148 */           sb.append(ch);
/* 149 */           if (pos >= end) break;
/* 150 */           ch = s.charAt(pos++);
/*     */         }
/*     */ 
/* 153 */         sb.append(ch);
/*     */       }
/*     */     }
/* 156 */     if (sb.length() > 0) {
/* 157 */       list.add(sb.toString());
/*     */     }
/*     */ 
/* 160 */     return (String[])list.toArray(new String[list.size()]);
/*     */   }
/*     */ 
/*     */   private String unescape(String s) {
/* 164 */     if (s.indexOf("\\") >= 0) {
/* 165 */       StringBuilder sb = new StringBuilder();
/* 166 */       for (int i = 0; i < s.length(); i++) {
/* 167 */         char ch = s.charAt(i);
/* 168 */         if ((ch == '\\') && (i < s.length() - 1))
/* 169 */           sb.append(s.charAt(++i));
/*     */         else {
/* 171 */           sb.append(ch);
/*     */         }
/*     */       }
/* 174 */       return sb.toString();
/*     */     }
/* 176 */     return s;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.synonym.SolrSynonymParser
 * JD-Core Version:    0.6.2
 */