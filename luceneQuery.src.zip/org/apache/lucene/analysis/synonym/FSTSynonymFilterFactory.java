/*     */ package org.apache.lucene.analysis.synonym;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.text.ParseException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.WhitespaceTokenizer;
/*     */ import org.apache.lucene.analysis.util.ResourceLoader;
/*     */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*     */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*     */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ @Deprecated
/*     */ final class FSTSynonymFilterFactory extends TokenFilterFactory
/*     */   implements ResourceLoaderAware
/*     */ {
/*  64 */   private final boolean ignoreCase = getBoolean(args, "ignoreCase", false);
/*     */ 
/*  69 */   private final String tokenizerFactory = get(args, "tokenizerFactory");
/*     */ 
/*  65 */   private final String synonyms = require(args, "synonyms");
/*  66 */   private final String format = get(args, "format");
/*  67 */   private final boolean expand = getBoolean(args, "expand", true);
/*     */ 
/*  58 */   private final Map<String, String> tokArgs = new HashMap();
/*     */   private SynonymMap map;
/*     */ 
/*     */   public FSTSynonymFilterFactory(Map<String, String> args)
/*     */   {
/*  63 */     super(args);
/*     */     Iterator itr;
/*  70 */     if (this.tokenizerFactory != null) {
/*  71 */       assureMatchVersion();
/*  72 */       this.tokArgs.put("luceneMatchVersion", getLuceneMatchVersion().toString());
/*  73 */       for (itr = args.keySet().iterator(); itr.hasNext(); ) {
/*  74 */         String key = (String)itr.next();
/*  75 */         this.tokArgs.put(key.replaceAll("^tokenizerFactory\\.", ""), args.get(key));
/*  76 */         itr.remove();
/*     */       }
/*     */     }
/*  79 */     if (!args.isEmpty())
/*  80 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*     */   }
/*     */ 
/*     */   public TokenStream create(TokenStream input)
/*     */   {
/*  88 */     return this.map.fst == null ? input : new SynonymFilter(input, this.map, this.ignoreCase);
/*     */   }
/*     */ 
/*     */   public void inform(ResourceLoader loader) throws IOException
/*     */   {
/*  93 */     final TokenizerFactory factory = this.tokenizerFactory == null ? null : loadTokenizerFactory(loader, this.tokenizerFactory);
/*     */ 
/*  95 */     Analyzer analyzer = new Analyzer()
/*     */     {
/*     */       protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader) {
/*  98 */         Tokenizer tokenizer = factory == null ? new WhitespaceTokenizer(Version.LUCENE_CURRENT, reader) : factory.create(reader);
/*  99 */         TokenStream stream = FSTSynonymFilterFactory.this.ignoreCase ? new LowerCaseFilter(Version.LUCENE_CURRENT, tokenizer) : tokenizer;
/* 100 */         return new Analyzer.TokenStreamComponents(tokenizer, stream);
/*     */       }
/*     */     };
/*     */     try
/*     */     {
/* 105 */       String formatClass = this.format;
/* 106 */       if ((this.format == null) || (this.format.equals("solr")))
/* 107 */         formatClass = SolrSynonymParser.class.getName();
/* 108 */       else if (this.format.equals("wordnet")) {
/* 109 */         formatClass = WordnetSynonymParser.class.getName();
/*     */       }
/*     */ 
/* 112 */       this.map = loadSynonyms(loader, formatClass, true, analyzer);
/*     */     } catch (ParseException e) {
/* 114 */       throw new IOException("Error parsing synonyms file:", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private SynonymMap loadSynonyms(ResourceLoader loader, String cname, boolean dedup, Analyzer analyzer)
/*     */     throws IOException, ParseException
/*     */   {
/* 122 */     CharsetDecoder decoder = Charset.forName("UTF-8").newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
/*     */ 
/* 127 */     Class clazz = loader.findClass(cname, SynonymMap.Parser.class);
/*     */     SynonymMap.Parser parser;
/*     */     try
/*     */     {
/* 129 */       parser = (SynonymMap.Parser)clazz.getConstructor(new Class[] { Boolean.TYPE, Boolean.TYPE, Analyzer.class }).newInstance(new Object[] { Boolean.valueOf(dedup), Boolean.valueOf(this.expand), analyzer });
/*     */     } catch (Exception e) {
/* 131 */       throw new RuntimeException(e);
/*     */     }
/*     */ 
/* 134 */     File synonymFile = new File(this.synonyms);
/* 135 */     if (synonymFile.exists()) {
/* 136 */       decoder.reset();
/* 137 */       parser.parse(new InputStreamReader(loader.openResource(this.synonyms), decoder));
/*     */     } else {
/* 139 */       List files = splitFileNames(this.synonyms);
/* 140 */       for (String file : files) {
/* 141 */         decoder.reset();
/* 142 */         parser.parse(new InputStreamReader(loader.openResource(file), decoder));
/*     */       }
/*     */     }
/* 145 */     return parser.build();
/*     */   }
/*     */ 
/*     */   private TokenizerFactory loadTokenizerFactory(ResourceLoader loader, String cname) throws IOException
/*     */   {
/* 150 */     Class clazz = loader.findClass(cname, TokenizerFactory.class);
/*     */     try {
/* 152 */       TokenizerFactory tokFactory = (TokenizerFactory)clazz.getConstructor(new Class[] { Map.class }).newInstance(new Object[] { this.tokArgs });
/* 153 */       if ((tokFactory instanceof ResourceLoaderAware)) {
/* 154 */         ((ResourceLoaderAware)tokFactory).inform(loader);
/*     */       }
/* 156 */       return tokFactory;
/*     */     } catch (Exception e) {
/* 158 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.synonym.FSTSynonymFilterFactory
 * JD-Core Version:    0.6.2
 */