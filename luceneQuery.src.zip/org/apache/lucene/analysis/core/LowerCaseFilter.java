/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.util.CharacterUtils;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class LowerCaseFilter extends TokenFilter
/*    */ {
/*    */   private final CharacterUtils charUtils;
/* 39 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */ 
/*    */   public LowerCaseFilter(Version matchVersion, TokenStream in)
/*    */   {
/* 48 */     super(in);
/* 49 */     this.charUtils = CharacterUtils.getInstance(matchVersion);
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken() throws IOException
/*    */   {
/* 54 */     if (this.input.incrementToken()) {
/* 55 */       this.charUtils.toLowerCase(this.termAtt.buffer(), 0, this.termAtt.length());
/* 56 */       return true;
/*    */     }
/* 58 */     return false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.LowerCaseFilter
 * JD-Core Version:    0.6.2
 */