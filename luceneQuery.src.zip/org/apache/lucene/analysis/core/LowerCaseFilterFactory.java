/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.AbstractAnalysisFactory;
/*    */ import org.apache.lucene.analysis.util.MultiTermAwareComponent;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class LowerCaseFilterFactory extends TokenFilterFactory
/*    */   implements MultiTermAwareComponent
/*    */ {
/*    */   public LowerCaseFilterFactory(Map<String, String> args)
/*    */   {
/* 42 */     super(args);
/* 43 */     assureMatchVersion();
/* 44 */     if (!args.isEmpty())
/* 45 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public LowerCaseFilter create(TokenStream input)
/*    */   {
/* 51 */     return new LowerCaseFilter(this.luceneMatchVersion, input);
/*    */   }
/*    */ 
/*    */   public AbstractAnalysisFactory getMultiTermComponent()
/*    */   {
/* 56 */     return this;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.LowerCaseFilterFactory
 * JD-Core Version:    0.6.2
 */