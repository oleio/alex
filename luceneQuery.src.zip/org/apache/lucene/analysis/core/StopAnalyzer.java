/*     */ package org.apache.lucene.analysis.core;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class StopAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*  60 */   public static final CharArraySet ENGLISH_STOP_WORDS_SET = CharArraySet.unmodifiableSet(stopSet);
/*     */ 
/*     */   public StopAnalyzer(Version matchVersion)
/*     */   {
/*  68 */     this(matchVersion, ENGLISH_STOP_WORDS_SET);
/*     */   }
/*     */ 
/*     */   public StopAnalyzer(Version matchVersion, CharArraySet stopWords)
/*     */   {
/*  75 */     super(matchVersion, stopWords);
/*     */   }
/*     */ 
/*     */   public StopAnalyzer(Version matchVersion, File stopwordsFile)
/*     */     throws IOException
/*     */   {
/*  83 */     this(matchVersion, loadStopwordSet(stopwordsFile, matchVersion));
/*     */   }
/*     */ 
/*     */   public StopAnalyzer(Version matchVersion, Reader stopwords)
/*     */     throws IOException
/*     */   {
/*  91 */     this(matchVersion, loadStopwordSet(stopwords, matchVersion));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 106 */     Tokenizer source = new LowerCaseTokenizer(this.matchVersion, reader);
/* 107 */     return new Analyzer.TokenStreamComponents(source, new StopFilter(this.matchVersion, source, this.stopwords));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  51 */     List stopWords = Arrays.asList(new String[] { "a", "an", "and", "are", "as", "at", "be", "but", "by", "for", "if", "in", "into", "is", "it", "no", "not", "of", "on", "or", "such", "that", "the", "their", "then", "there", "these", "they", "this", "to", "was", "will", "with" });
/*     */ 
/*  58 */     CharArraySet stopSet = new CharArraySet(Version.LUCENE_CURRENT, stopWords, false);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.StopAnalyzer
 * JD-Core Version:    0.6.2
 */