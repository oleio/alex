/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.Analyzer;
/*    */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class WhitespaceAnalyzer extends Analyzer
/*    */ {
/*    */   private final Version matchVersion;
/*    */ 
/*    */   public WhitespaceAnalyzer(Version matchVersion)
/*    */   {
/* 47 */     this.matchVersion = matchVersion;
/*    */   }
/*    */ 
/*    */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*    */   {
/* 53 */     return new Analyzer.TokenStreamComponents(new WhitespaceTokenizer(this.matchVersion, reader));
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.WhitespaceAnalyzer
 * JD-Core Version:    0.6.2
 */