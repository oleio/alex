/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.util.CharacterUtils;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class UpperCaseFilter extends TokenFilter
/*    */ {
/*    */   private final CharacterUtils charUtils;
/* 41 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */ 
/*    */   public UpperCaseFilter(Version matchVersion, TokenStream in)
/*    */   {
/* 50 */     super(in);
/* 51 */     this.charUtils = CharacterUtils.getInstance(matchVersion);
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken() throws IOException
/*    */   {
/* 56 */     if (this.input.incrementToken()) {
/* 57 */       this.charUtils.toUpperCase(this.termAtt.buffer(), 0, this.termAtt.length());
/* 58 */       return true;
/*    */     }
/* 60 */     return false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.UpperCaseFilter
 * JD-Core Version:    0.6.2
 */