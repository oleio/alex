/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class LowerCaseTokenizer extends LetterTokenizer
/*    */ {
/*    */   public LowerCaseTokenizer(Version matchVersion, Reader in)
/*    */   {
/* 59 */     super(matchVersion, in);
/*    */   }
/*    */ 
/*    */   public LowerCaseTokenizer(Version matchVersion, AttributeSource.AttributeFactory factory, Reader in)
/*    */   {
/* 74 */     super(matchVersion, factory, in);
/*    */   }
/*    */ 
/*    */   protected int normalize(int c)
/*    */   {
/* 81 */     return Character.toLowerCase(c);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.LowerCaseTokenizer
 * JD-Core Version:    0.6.2
 */