/*     */ package org.apache.lucene.analysis.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.ResourceLoader;
/*     */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*     */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*     */ 
/*     */ public class StopFilterFactory extends TokenFilterFactory
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   public static final String FORMAT_WORDSET = "wordset";
/*     */   public static final String FORMAT_SNOWBALL = "snowball";
/*     */   private CharArraySet stopWords;
/*     */   private final String stopWordFiles;
/*     */   private final String format;
/*     */   private final boolean ignoreCase;
/*     */   private final boolean enablePositionIncrements;
/*     */ 
/*     */   public StopFilterFactory(Map<String, String> args)
/*     */   {
/*  84 */     super(args);
/*  85 */     assureMatchVersion();
/*  86 */     this.stopWordFiles = get(args, "words");
/*  87 */     this.format = get(args, "format", null == this.stopWordFiles ? null : "wordset");
/*  88 */     this.ignoreCase = getBoolean(args, "ignoreCase", false);
/*  89 */     this.enablePositionIncrements = getBoolean(args, "enablePositionIncrements", true);
/*  90 */     if (!args.isEmpty())
/*  91 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*     */   }
/*     */ 
/*     */   public void inform(ResourceLoader loader)
/*     */     throws IOException
/*     */   {
/*  97 */     if (this.stopWordFiles != null) {
/*  98 */       if ("wordset".equalsIgnoreCase(this.format))
/*  99 */         this.stopWords = getWordSet(loader, this.stopWordFiles, this.ignoreCase);
/* 100 */       else if ("snowball".equalsIgnoreCase(this.format))
/* 101 */         this.stopWords = getSnowballWordSet(loader, this.stopWordFiles, this.ignoreCase);
/*     */       else
/* 103 */         throw new IllegalArgumentException("Unknown 'format' specified for 'words' file: " + this.format);
/*     */     }
/*     */     else {
/* 106 */       if (null != this.format) {
/* 107 */         throw new IllegalArgumentException("'format' can not be specified w/o an explicit 'words' file: " + this.format);
/*     */       }
/* 109 */       this.stopWords = new CharArraySet(this.luceneMatchVersion, StopAnalyzer.ENGLISH_STOP_WORDS_SET, this.ignoreCase);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isEnablePositionIncrements() {
/* 114 */     return this.enablePositionIncrements;
/*     */   }
/*     */ 
/*     */   public boolean isIgnoreCase() {
/* 118 */     return this.ignoreCase;
/*     */   }
/*     */ 
/*     */   public CharArraySet getStopWords() {
/* 122 */     return this.stopWords;
/*     */   }
/*     */ 
/*     */   public TokenStream create(TokenStream input)
/*     */   {
/* 127 */     StopFilter stopFilter = new StopFilter(this.luceneMatchVersion, input, this.stopWords);
/* 128 */     stopFilter.setEnablePositionIncrements(this.enablePositionIncrements);
/* 129 */     return stopFilter;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.StopFilterFactory
 * JD-Core Version:    0.6.2
 */