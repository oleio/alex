/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.Analyzer;
/*    */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*    */ 
/*    */ public final class KeywordAnalyzer extends Analyzer
/*    */ {
/*    */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*    */   {
/* 34 */     return new Analyzer.TokenStreamComponents(new KeywordTokenizer(reader));
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.KeywordAnalyzer
 * JD-Core Version:    0.6.2
 */