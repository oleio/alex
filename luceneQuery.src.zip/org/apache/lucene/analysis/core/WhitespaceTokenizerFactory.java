/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public class WhitespaceTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   public WhitespaceTokenizerFactory(Map<String, String> args)
/*    */   {
/* 39 */     super(args);
/* 40 */     assureMatchVersion();
/* 41 */     if (!args.isEmpty())
/* 42 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public WhitespaceTokenizer create(AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 48 */     return new WhitespaceTokenizer(this.luceneMatchVersion, factory, input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.WhitespaceTokenizerFactory
 * JD-Core Version:    0.6.2
 */