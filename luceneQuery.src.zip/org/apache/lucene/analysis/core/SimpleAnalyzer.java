/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.Analyzer;
/*    */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class SimpleAnalyzer extends Analyzer
/*    */ {
/*    */   private final Version matchVersion;
/*    */ 
/*    */   public SimpleAnalyzer(Version matchVersion)
/*    */   {
/* 47 */     this.matchVersion = matchVersion;
/*    */   }
/*    */ 
/*    */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*    */   {
/* 53 */     return new Analyzer.TokenStreamComponents(new LowerCaseTokenizer(this.matchVersion, reader));
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.SimpleAnalyzer
 * JD-Core Version:    0.6.2
 */