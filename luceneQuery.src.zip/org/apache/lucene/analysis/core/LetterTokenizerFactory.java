/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public class LetterTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   public LetterTokenizerFactory(Map<String, String> args)
/*    */   {
/* 39 */     super(args);
/* 40 */     assureMatchVersion();
/* 41 */     if (!args.isEmpty())
/* 42 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public LetterTokenizer create(AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 48 */     return new LetterTokenizer(this.luceneMatchVersion, factory, input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.core.LetterTokenizerFactory
 * JD-Core Version:    0.6.2
 */