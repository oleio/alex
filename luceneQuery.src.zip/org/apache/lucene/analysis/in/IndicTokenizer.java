/*    */ package org.apache.lucene.analysis.in;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.util.CharTokenizer;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ @Deprecated
/*    */ public final class IndicTokenizer extends CharTokenizer
/*    */ {
/*    */   public IndicTokenizer(Version matchVersion, AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 34 */     super(matchVersion, factory, input);
/*    */   }
/*    */ 
/*    */   public IndicTokenizer(Version matchVersion, Reader input) {
/* 38 */     super(matchVersion, input);
/*    */   }
/*    */ 
/*    */   protected boolean isTokenChar(int c)
/*    */   {
/* 43 */     return (Character.isLetter(c)) || (Character.getType(c) == 6) || (Character.getType(c) == 16) || (Character.getType(c) == 8);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.in.IndicTokenizer
 * JD-Core Version:    0.6.2
 */