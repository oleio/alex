/*     */ package org.apache.lucene.analysis;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.util.AttributeSource;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ public abstract class TokenStream extends AttributeSource
/*     */   implements Closeable
/*     */ {
/*     */   protected TokenStream()
/*     */   {
/*  93 */     assert (assertFinal());
/*     */   }
/*     */ 
/*     */   protected TokenStream(AttributeSource input)
/*     */   {
/* 100 */     super(input);
/* 101 */     assert (assertFinal());
/*     */   }
/*     */ 
/*     */   protected TokenStream(AttributeSource.AttributeFactory factory)
/*     */   {
/* 108 */     super(factory);
/* 109 */     assert (assertFinal());
/*     */   }
/*     */ 
/*     */   private boolean assertFinal() {
/*     */     try {
/* 114 */       Class clazz = getClass();
/* 115 */       if (!clazz.desiredAssertionStatus()) {
/* 116 */         return true;
/*     */       }
/*     */ 
/* 120 */       assert ((clazz.isAnonymousClass()) || ((clazz.getModifiers() & 0x12) != 0) || (Modifier.isFinal(clazz.getMethod("incrementToken", new Class[0]).getModifiers()))) : "TokenStream implementation classes or at least their incrementToken() implementation must be final";
/* 121 */       return true; } catch (NoSuchMethodException nsme) {
/*     */     }
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */   public abstract boolean incrementToken()
/*     */     throws IOException;
/*     */ 
/*     */   public void end()
/*     */     throws IOException
/*     */   {
/* 173 */     clearAttributes();
/* 174 */     if (hasAttribute(PositionIncrementAttribute.class))
/* 175 */       ((PositionIncrementAttribute)getAttribute(PositionIncrementAttribute.class)).setPositionIncrement(0);
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.TokenStream
 * JD-Core Version:    0.6.2
 */