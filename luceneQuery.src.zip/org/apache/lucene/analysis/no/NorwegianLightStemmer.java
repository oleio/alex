/*     */ package org.apache.lucene.analysis.no;
/*     */ 
/*     */ import org.apache.lucene.analysis.util.StemmerUtil;
/*     */ 
/*     */ public class NorwegianLightStemmer
/*     */ {
/*     */   public static final int BOKMAAL = 1;
/*     */   public static final int NYNORSK = 2;
/*     */   final boolean useBokmaal;
/*     */   final boolean useNynorsk;
/*     */ 
/*     */   public NorwegianLightStemmer(int flags)
/*     */   {
/*  78 */     if ((flags <= 0) || (flags > 3)) {
/*  79 */       throw new IllegalArgumentException("invalid flags");
/*     */     }
/*  81 */     this.useBokmaal = ((flags & 0x1) != 0);
/*  82 */     this.useNynorsk = ((flags & 0x2) != 0);
/*     */   }
/*     */ 
/*     */   public int stem(char[] s, int len)
/*     */   {
/*  87 */     if ((len > 4) && (s[(len - 1)] == 's')) {
/*  88 */       len--;
/*     */     }
/*     */ 
/*  91 */     if ((len > 7) && (((StemmerUtil.endsWith(s, len, "heter")) && (this.useBokmaal)) || ((StemmerUtil.endsWith(s, len, "heten")) && (this.useBokmaal)) || ((StemmerUtil.endsWith(s, len, "heita")) && (this.useNynorsk))))
/*     */     {
/*  98 */       return len - 5;
/*     */     }
/*     */ 
/* 101 */     if ((len > 8) && (this.useNynorsk) && ((StemmerUtil.endsWith(s, len, "heiter")) || (StemmerUtil.endsWith(s, len, "leiken")) || (StemmerUtil.endsWith(s, len, "leikar"))))
/*     */     {
/* 105 */       return len - 6;
/*     */     }
/* 107 */     if ((len > 5) && ((StemmerUtil.endsWith(s, len, "dom")) || ((StemmerUtil.endsWith(s, len, "het")) && (this.useBokmaal))))
/*     */     {
/* 111 */       return len - 3;
/*     */     }
/* 113 */     if ((len > 6) && (this.useNynorsk) && ((StemmerUtil.endsWith(s, len, "heit")) || (StemmerUtil.endsWith(s, len, "semd")) || (StemmerUtil.endsWith(s, len, "leik"))))
/*     */     {
/* 117 */       return len - 4;
/*     */     }
/* 119 */     if ((len > 7) && ((StemmerUtil.endsWith(s, len, "elser")) || (StemmerUtil.endsWith(s, len, "elsen"))))
/*     */     {
/* 122 */       return len - 5;
/*     */     }
/* 124 */     if ((len > 6) && (((StemmerUtil.endsWith(s, len, "ende")) && (this.useBokmaal)) || ((StemmerUtil.endsWith(s, len, "ande")) && (this.useNynorsk)) || (StemmerUtil.endsWith(s, len, "else")) || ((StemmerUtil.endsWith(s, len, "este")) && (this.useBokmaal)) || ((StemmerUtil.endsWith(s, len, "aste")) && (this.useNynorsk)) || ((StemmerUtil.endsWith(s, len, "eren")) && (this.useBokmaal)) || ((StemmerUtil.endsWith(s, len, "aren")) && (this.useNynorsk))))
/*     */     {
/* 138 */       return len - 4;
/*     */     }
/* 140 */     if ((len > 5) && (((StemmerUtil.endsWith(s, len, "ere")) && (this.useBokmaal)) || ((StemmerUtil.endsWith(s, len, "are")) && (this.useNynorsk)) || ((StemmerUtil.endsWith(s, len, "est")) && (this.useBokmaal)) || ((StemmerUtil.endsWith(s, len, "ast")) && (this.useNynorsk)) || (StemmerUtil.endsWith(s, len, "ene")) || ((StemmerUtil.endsWith(s, len, "ane")) && (this.useNynorsk))))
/*     */     {
/* 152 */       return len - 3;
/*     */     }
/* 154 */     if ((len > 4) && ((StemmerUtil.endsWith(s, len, "er")) || (StemmerUtil.endsWith(s, len, "en")) || (StemmerUtil.endsWith(s, len, "et")) || ((StemmerUtil.endsWith(s, len, "ar")) && (this.useNynorsk)) || ((StemmerUtil.endsWith(s, len, "st")) && (this.useBokmaal)) || (StemmerUtil.endsWith(s, len, "te"))))
/*     */     {
/* 163 */       return len - 2;
/*     */     }
/* 165 */     if (len > 3) {
/* 166 */       switch (s[(len - 1)]) {
/*     */       case 'a':
/*     */       case 'e':
/*     */       case 'n':
/* 170 */         return len - 1;
/*     */       }
/*     */     }
/* 173 */     return len;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.no.NorwegianLightStemmer
 * JD-Core Version:    0.6.2
 */