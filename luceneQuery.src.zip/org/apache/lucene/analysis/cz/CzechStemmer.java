/*     */ package org.apache.lucene.analysis.cz;
/*     */ 
/*     */ import org.apache.lucene.analysis.util.StemmerUtil;
/*     */ 
/*     */ public class CzechStemmer
/*     */ {
/*     */   public int stem(char[] s, int len)
/*     */   {
/*  45 */     len = removeCase(s, len);
/*  46 */     len = removePossessives(s, len);
/*  47 */     if (len > 0) {
/*  48 */       len = normalize(s, len);
/*     */     }
/*  50 */     return len;
/*     */   }
/*     */ 
/*     */   private int removeCase(char[] s, int len) {
/*  54 */     if ((len > 7) && (StemmerUtil.endsWith(s, len, "atech"))) {
/*  55 */       return len - 5;
/*     */     }
/*  57 */     if ((len > 6) && ((StemmerUtil.endsWith(s, len, "ětem")) || (StemmerUtil.endsWith(s, len, "etem")) || (StemmerUtil.endsWith(s, len, "atům"))))
/*     */     {
/*  61 */       return len - 4;
/*     */     }
/*  63 */     if ((len > 5) && ((StemmerUtil.endsWith(s, len, "ech")) || (StemmerUtil.endsWith(s, len, "ich")) || (StemmerUtil.endsWith(s, len, "ích")) || (StemmerUtil.endsWith(s, len, "ého")) || (StemmerUtil.endsWith(s, len, "ěmi")) || (StemmerUtil.endsWith(s, len, "emi")) || (StemmerUtil.endsWith(s, len, "ému")) || (StemmerUtil.endsWith(s, len, "ěte")) || (StemmerUtil.endsWith(s, len, "ete")) || (StemmerUtil.endsWith(s, len, "ěti")) || (StemmerUtil.endsWith(s, len, "eti")) || (StemmerUtil.endsWith(s, len, "ího")) || (StemmerUtil.endsWith(s, len, "iho")) || (StemmerUtil.endsWith(s, len, "ími")) || (StemmerUtil.endsWith(s, len, "ímu")) || (StemmerUtil.endsWith(s, len, "imu")) || (StemmerUtil.endsWith(s, len, "ách")) || (StemmerUtil.endsWith(s, len, "ata")) || (StemmerUtil.endsWith(s, len, "aty")) || (StemmerUtil.endsWith(s, len, "ých")) || (StemmerUtil.endsWith(s, len, "ama")) || (StemmerUtil.endsWith(s, len, "ami")) || (StemmerUtil.endsWith(s, len, "ové")) || (StemmerUtil.endsWith(s, len, "ovi")) || (StemmerUtil.endsWith(s, len, "ými"))))
/*     */     {
/*  89 */       return len - 3;
/*     */     }
/*  91 */     if ((len > 4) && ((StemmerUtil.endsWith(s, len, "em")) || (StemmerUtil.endsWith(s, len, "es")) || (StemmerUtil.endsWith(s, len, "ém")) || (StemmerUtil.endsWith(s, len, "ím")) || (StemmerUtil.endsWith(s, len, "ům")) || (StemmerUtil.endsWith(s, len, "at")) || (StemmerUtil.endsWith(s, len, "ám")) || (StemmerUtil.endsWith(s, len, "os")) || (StemmerUtil.endsWith(s, len, "us")) || (StemmerUtil.endsWith(s, len, "ým")) || (StemmerUtil.endsWith(s, len, "mi")) || (StemmerUtil.endsWith(s, len, "ou"))))
/*     */     {
/* 104 */       return len - 2;
/*     */     }
/* 106 */     if (len > 3) {
/* 107 */       switch (s[(len - 1)]) {
/*     */       case 'a':
/*     */       case 'e':
/*     */       case 'i':
/*     */       case 'o':
/*     */       case 'u':
/*     */       case 'y':
/*     */       case 'á':
/*     */       case 'é':
/*     */       case 'í':
/*     */       case 'ý':
/*     */       case 'ě':
/*     */       case 'ů':
/* 120 */         return len - 1;
/*     */       }
/*     */     }
/*     */ 
/* 124 */     return len;
/*     */   }
/*     */ 
/*     */   private int removePossessives(char[] s, int len) {
/* 128 */     if ((len > 5) && ((StemmerUtil.endsWith(s, len, "ov")) || (StemmerUtil.endsWith(s, len, "in")) || (StemmerUtil.endsWith(s, len, "ův"))))
/*     */     {
/* 132 */       return len - 2;
/*     */     }
/* 134 */     return len;
/*     */   }
/*     */ 
/*     */   private int normalize(char[] s, int len) {
/* 138 */     if (StemmerUtil.endsWith(s, len, "čt")) {
/* 139 */       s[(len - 2)] = 'c';
/* 140 */       s[(len - 1)] = 'k';
/* 141 */       return len;
/*     */     }
/*     */ 
/* 144 */     if (StemmerUtil.endsWith(s, len, "št")) {
/* 145 */       s[(len - 2)] = 's';
/* 146 */       s[(len - 1)] = 'k';
/* 147 */       return len;
/*     */     }
/*     */ 
/* 150 */     switch (s[(len - 1)]) {
/*     */     case 'c':
/*     */     case 'č':
/* 153 */       s[(len - 1)] = 'k';
/* 154 */       return len;
/*     */     case 'z':
/*     */     case 'ž':
/* 157 */       s[(len - 1)] = 'h';
/* 158 */       return len;
/*     */     }
/*     */ 
/* 161 */     if ((len > 1) && (s[(len - 2)] == 'e')) {
/* 162 */       s[(len - 2)] = s[(len - 1)];
/* 163 */       return len - 1;
/*     */     }
/*     */ 
/* 166 */     if ((len > 2) && (s[(len - 2)] == 'ů')) {
/* 167 */       s[(len - 2)] = 'o';
/* 168 */       return len;
/*     */     }
/*     */ 
/* 171 */     return len;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.cz.CzechStemmer
 * JD-Core Version:    0.6.2
 */