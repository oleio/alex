/*     */ package org.apache.lucene.analysis.hunspell;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ import org.apache.lucene.util.CharsRef;
/*     */ 
/*     */ public final class HunspellStemFilter extends TokenFilter
/*     */ {
/*  50 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  51 */   private final PositionIncrementAttribute posIncAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*  52 */   private final KeywordAttribute keywordAtt = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/*     */   private final Stemmer stemmer;
/*     */   private List<CharsRef> buffer;
/*     */   private AttributeSource.State savedState;
/*     */   private final boolean dedup;
/*     */   private final boolean longestOnly;
/* 136 */   static final Comparator<CharsRef> lengthComparator = new Comparator()
/*     */   {
/*     */     public int compare(CharsRef o1, CharsRef o2) {
/* 139 */       if (o2.length == o1.length)
/*     */       {
/* 141 */         return o2.compareTo(o1);
/*     */       }
/* 143 */       return o2.length < o1.length ? -1 : 1;
/*     */     }
/* 136 */   };
/*     */ 
/*     */   public HunspellStemFilter(TokenStream input, Dictionary dictionary)
/*     */   {
/*  64 */     this(input, dictionary, true);
/*     */   }
/*     */ 
/*     */   public HunspellStemFilter(TokenStream input, Dictionary dictionary, boolean dedup)
/*     */   {
/*  70 */     this(input, dictionary, dedup, false);
/*     */   }
/*     */ 
/*     */   public HunspellStemFilter(TokenStream input, Dictionary dictionary, boolean dedup, boolean longestOnly)
/*     */   {
/*  82 */     super(input);
/*  83 */     this.dedup = ((dedup) && (!longestOnly));
/*  84 */     this.stemmer = new Stemmer(dictionary);
/*  85 */     this.longestOnly = longestOnly;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  90 */     if ((this.buffer != null) && (!this.buffer.isEmpty())) {
/*  91 */       CharsRef nextStem = (CharsRef)this.buffer.remove(0);
/*  92 */       restoreState(this.savedState);
/*  93 */       this.posIncAtt.setPositionIncrement(0);
/*  94 */       this.termAtt.setEmpty().append(nextStem);
/*  95 */       return true;
/*     */     }
/*     */ 
/*  98 */     if (!this.input.incrementToken()) {
/*  99 */       return false;
/*     */     }
/*     */ 
/* 102 */     if (this.keywordAtt.isKeyword()) {
/* 103 */       return true;
/*     */     }
/*     */ 
/* 106 */     this.buffer = (this.dedup ? this.stemmer.uniqueStems(this.termAtt.buffer(), this.termAtt.length()) : this.stemmer.stem(this.termAtt.buffer(), this.termAtt.length()));
/*     */ 
/* 108 */     if (this.buffer.isEmpty()) {
/* 109 */       return true;
/*     */     }
/*     */ 
/* 112 */     if ((this.longestOnly) && (this.buffer.size() > 1)) {
/* 113 */       Collections.sort(this.buffer, lengthComparator);
/*     */     }
/*     */ 
/* 116 */     CharsRef stem = (CharsRef)this.buffer.remove(0);
/* 117 */     this.termAtt.setEmpty().append(stem);
/*     */ 
/* 119 */     if (this.longestOnly) {
/* 120 */       this.buffer.clear();
/*     */     }
/* 122 */     else if (!this.buffer.isEmpty()) {
/* 123 */       this.savedState = captureState();
/*     */     }
/*     */ 
/* 127 */     return true;
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 132 */     super.reset();
/* 133 */     this.buffer = null;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.hunspell.HunspellStemFilter
 * JD-Core Version:    0.6.2
 */