/*      */ package org.apache.lucene.analysis.hunspell;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.Closeable;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.LineNumberReader;
/*      */ import java.io.OutputStream;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetDecoder;
/*      */ import java.nio.charset.CodingErrorAction;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.text.ParseException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.TreeMap;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.lucene.store.ByteArrayDataOutput;
/*      */ import org.apache.lucene.util.ArrayUtil;
/*      */ import org.apache.lucene.util.BytesRef;
/*      */ import org.apache.lucene.util.BytesRefHash;
/*      */ import org.apache.lucene.util.CharsRef;
/*      */ import org.apache.lucene.util.IOUtils;
/*      */ import org.apache.lucene.util.IntsRef;
/*      */ import org.apache.lucene.util.OfflineSorter;
/*      */ import org.apache.lucene.util.OfflineSorter.ByteSequencesReader;
/*      */ import org.apache.lucene.util.OfflineSorter.ByteSequencesWriter;
/*      */ import org.apache.lucene.util.automaton.CharacterRunAutomaton;
/*      */ import org.apache.lucene.util.automaton.RegExp;
/*      */ import org.apache.lucene.util.fst.Builder;
/*      */ import org.apache.lucene.util.fst.CharSequenceOutputs;
/*      */ import org.apache.lucene.util.fst.FST;
/*      */ import org.apache.lucene.util.fst.FST.Arc;
/*      */ import org.apache.lucene.util.fst.FST.BytesReader;
/*      */ import org.apache.lucene.util.fst.FST.INPUT_TYPE;
/*      */ import org.apache.lucene.util.fst.IntSequenceOutputs;
/*      */ import org.apache.lucene.util.fst.Outputs;
/*      */ import org.apache.lucene.util.fst.Util;
/*      */ 
/*      */ public class Dictionary
/*      */ {
/*      */   static final char[] NOFLAGS;
/*      */   private static final String ALIAS_KEY = "AF";
/*      */   private static final String PREFIX_KEY = "PFX";
/*      */   private static final String SUFFIX_KEY = "SFX";
/*      */   private static final String FLAG_KEY = "FLAG";
/*      */   private static final String COMPLEXPREFIXES_KEY = "COMPLEXPREFIXES";
/*      */   private static final String CIRCUMFIX_KEY = "CIRCUMFIX";
/*      */   private static final String IGNORE_KEY = "IGNORE";
/*      */   private static final String ICONV_KEY = "ICONV";
/*      */   private static final String OCONV_KEY = "OCONV";
/*      */   private static final String NUM_FLAG_TYPE = "num";
/*      */   private static final String UTF8_FLAG_TYPE = "UTF-8";
/*      */   private static final String LONG_FLAG_TYPE = "long";
/*      */   private static final String PREFIX_CONDITION_REGEX_PATTERN = "%s.*";
/*      */   private static final String SUFFIX_CONDITION_REGEX_PATTERN = ".*%s";
/*      */   FST<IntsRef> prefixes;
/*      */   FST<IntsRef> suffixes;
/*   99 */   ArrayList<CharacterRunAutomaton> patterns = new ArrayList();
/*      */   FST<IntsRef> words;
/*  106 */   BytesRefHash flagLookup = new BytesRefHash();
/*      */   char[] stripData;
/*      */   int[] stripOffsets;
/*  113 */   byte[] affixData = new byte[64];
/*  114 */   private int currentAffix = 0;
/*      */ 
/*  116 */   private FlagParsingStrategy flagParsingStrategy = new SimpleFlagParsingStrategy(null);
/*      */   private String[] aliases;
/*  119 */   private int aliasCount = 0;
/*      */ 
/*  121 */   private final File tempDir = OfflineSorter.defaultTempDir();
/*      */   boolean ignoreCase;
/*      */   boolean complexPrefixes;
/*      */   boolean twoStageAffix;
/*  127 */   int circumfix = -1;
/*      */   private char[] ignore;
/*      */   FST<CharsRef> iconv;
/*      */   FST<CharsRef> oconv;
/*      */   boolean needsInputCleaning;
/*      */   boolean needsOutputCleaning;
/*      */   static final Pattern ENCODING_PATTERN;
/*  587 */   static final Map<String, String> CHARSET_ALIASES = Collections.unmodifiableMap(m);
/*      */ 
/*  633 */   final char FLAG_SEPARATOR = '\037';
/*      */ 
/*      */   public Dictionary(InputStream affix, InputStream dictionary)
/*      */     throws IOException, ParseException
/*      */   {
/*  150 */     this(affix, Collections.singletonList(dictionary), false);
/*      */   }
/*      */ 
/*      */   public Dictionary(InputStream affix, List<InputStream> dictionaries, boolean ignoreCase)
/*      */     throws IOException, ParseException
/*      */   {
/*  164 */     this.ignoreCase = ignoreCase;
/*  165 */     this.needsInputCleaning = ignoreCase;
/*  166 */     this.needsOutputCleaning = false;
/*  167 */     this.flagLookup.add(new BytesRef());
/*      */ 
/*  169 */     File aff = File.createTempFile("affix", "aff", this.tempDir);
/*  170 */     OutputStream out = new BufferedOutputStream(new FileOutputStream(aff));
/*  171 */     InputStream aff1 = null;
/*  172 */     InputStream aff2 = null;
/*      */     try
/*      */     {
/*  175 */       byte[] buffer = new byte[8192];
/*      */       int len;
/*  177 */       while ((len = affix.read(buffer)) > 0) {
/*  178 */         out.write(buffer, 0, len);
/*      */       }
/*  180 */       out.close();
/*      */ 
/*  183 */       aff1 = new BufferedInputStream(new FileInputStream(aff));
/*  184 */       String encoding = getDictionaryEncoding(aff1);
/*      */ 
/*  187 */       CharsetDecoder decoder = getJavaEncoding(encoding);
/*  188 */       aff2 = new BufferedInputStream(new FileInputStream(aff));
/*  189 */       readAffixFile(aff2, decoder);
/*      */ 
/*  192 */       IntSequenceOutputs o = IntSequenceOutputs.getSingleton();
/*  193 */       Builder b = new Builder(FST.INPUT_TYPE.BYTE4, o);
/*  194 */       readDictionaryFiles(dictionaries, decoder, b);
/*  195 */       this.words = b.finish();
/*  196 */       this.aliases = null;
/*      */     } finally {
/*  198 */       IOUtils.closeWhileHandlingException(new Closeable[] { out, aff1, aff2 });
/*  199 */       aff.delete();
/*      */     }
/*      */   }
/*      */ 
/*      */   IntsRef lookupWord(char[] word, int offset, int length)
/*      */   {
/*  207 */     return lookup(this.words, word, offset, length);
/*      */   }
/*      */ 
/*      */   IntsRef lookupPrefix(char[] word, int offset, int length)
/*      */   {
/*  219 */     return lookup(this.prefixes, word, offset, length);
/*      */   }
/*      */ 
/*      */   IntsRef lookupSuffix(char[] word, int offset, int length)
/*      */   {
/*  231 */     return lookup(this.suffixes, word, offset, length);
/*      */   }
/*      */ 
/*      */   IntsRef lookup(FST<IntsRef> fst, char[] word, int offset, int length)
/*      */   {
/*  237 */     if (fst == null) {
/*  238 */       return null;
/*      */     }
/*  240 */     FST.BytesReader bytesReader = fst.getBytesReader();
/*  241 */     FST.Arc arc = fst.getFirstArc(new FST.Arc());
/*      */ 
/*  243 */     IntsRef NO_OUTPUT = (IntsRef)fst.outputs.getNoOutput();
/*  244 */     IntsRef output = NO_OUTPUT;
/*      */ 
/*  246 */     int l = offset + length;
/*      */     try {
/*  248 */       int i = offset; for (int cp = 0; i < l; i += Character.charCount(cp)) {
/*  249 */         cp = Character.codePointAt(word, i, l);
/*  250 */         if (fst.findTargetArc(cp, arc, arc, bytesReader) == null)
/*  251 */           return null;
/*  252 */         if (arc.output != NO_OUTPUT) {
/*  253 */           output = (IntsRef)fst.outputs.add(output, arc.output);
/*      */         }
/*      */       }
/*  256 */       if (fst.findTargetArc(-1, arc, arc, bytesReader) == null)
/*  257 */         return null;
/*  258 */       if (arc.output != NO_OUTPUT) {
/*  259 */         return (IntsRef)fst.outputs.add(output, arc.output);
/*      */       }
/*  261 */       return output;
/*      */     }
/*      */     catch (IOException bogus) {
/*  264 */       throw new RuntimeException(bogus);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void readAffixFile(InputStream affixStream, CharsetDecoder decoder)
/*      */     throws IOException, ParseException
/*      */   {
/*  276 */     TreeMap prefixes = new TreeMap();
/*  277 */     TreeMap suffixes = new TreeMap();
/*  278 */     Map seenPatterns = new HashMap();
/*      */ 
/*  281 */     seenPatterns.put(".*", Integer.valueOf(0));
/*  282 */     this.patterns.add(null);
/*      */ 
/*  285 */     Map seenStrips = new LinkedHashMap();
/*  286 */     seenStrips.put("", Integer.valueOf(0));
/*      */ 
/*  288 */     LineNumberReader reader = new LineNumberReader(new InputStreamReader(affixStream, decoder));
/*  289 */     String line = null;
/*  290 */     while ((line = reader.readLine()) != null)
/*      */     {
/*  292 */       if ((reader.getLineNumber() == 1) && (line.startsWith("﻿"))) {
/*  293 */         line = line.substring(1);
/*      */       }
/*  295 */       if (line.startsWith("AF")) {
/*  296 */         parseAlias(line);
/*  297 */       } else if (line.startsWith("PFX")) {
/*  298 */         parseAffix(prefixes, line, reader, "%s.*", seenPatterns, seenStrips);
/*  299 */       } else if (line.startsWith("SFX")) {
/*  300 */         parseAffix(suffixes, line, reader, ".*%s", seenPatterns, seenStrips);
/*  301 */       } else if (line.startsWith("FLAG"))
/*      */       {
/*  304 */         this.flagParsingStrategy = getFlagParsingStrategy(line);
/*  305 */       } else if (line.equals("COMPLEXPREFIXES")) {
/*  306 */         this.complexPrefixes = true;
/*  307 */       } else if (line.startsWith("CIRCUMFIX")) {
/*  308 */         String[] parts = line.split("\\s+");
/*  309 */         if (parts.length != 2) {
/*  310 */           throw new ParseException("Illegal CIRCUMFIX declaration", reader.getLineNumber());
/*      */         }
/*  312 */         this.circumfix = this.flagParsingStrategy.parseFlag(parts[1]);
/*  313 */       } else if (line.startsWith("IGNORE")) {
/*  314 */         String[] parts = line.split("\\s+");
/*  315 */         if (parts.length != 2) {
/*  316 */           throw new ParseException("Illegal IGNORE declaration", reader.getLineNumber());
/*      */         }
/*  318 */         this.ignore = parts[1].toCharArray();
/*  319 */         Arrays.sort(this.ignore);
/*  320 */         this.needsInputCleaning = true;
/*  321 */       } else if ((line.startsWith("ICONV")) || (line.startsWith("OCONV"))) {
/*  322 */         String[] parts = line.split("\\s+");
/*  323 */         String type = parts[0];
/*  324 */         if (parts.length != 2) {
/*  325 */           throw new ParseException(new StringBuilder().append("Illegal ").append(type).append(" declaration").toString(), reader.getLineNumber());
/*      */         }
/*  327 */         int num = Integer.parseInt(parts[1]);
/*  328 */         FST res = parseConversions(reader, num);
/*  329 */         if (type.equals("ICONV")) {
/*  330 */           this.iconv = res;
/*  331 */           this.needsInputCleaning |= this.iconv != null;
/*      */         } else {
/*  333 */           this.oconv = res;
/*  334 */           this.needsOutputCleaning |= this.oconv != null;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  339 */     this.prefixes = affixFST(prefixes);
/*  340 */     this.suffixes = affixFST(suffixes);
/*      */ 
/*  342 */     int totalChars = 0;
/*  343 */     for (String strip : seenStrips.keySet()) {
/*  344 */       totalChars += strip.length();
/*      */     }
/*  346 */     this.stripData = new char[totalChars];
/*  347 */     this.stripOffsets = new int[seenStrips.size() + 1];
/*  348 */     int currentOffset = 0;
/*  349 */     int currentIndex = 0;
/*  350 */     for (String strip : seenStrips.keySet()) {
/*  351 */       this.stripOffsets[(currentIndex++)] = currentOffset;
/*  352 */       strip.getChars(0, strip.length(), this.stripData, currentOffset);
/*  353 */       currentOffset += strip.length();
/*      */     }
/*  355 */     assert (currentIndex == seenStrips.size());
/*  356 */     this.stripOffsets[currentIndex] = currentOffset; } 
/*      */   private FST<IntsRef> affixFST(TreeMap<String, List<Character>> affixes) throws IOException { // Byte code:
/*      */     //   0: invokestatic 43	org/apache/lucene/util/fst/IntSequenceOutputs:getSingleton	()Lorg/apache/lucene/util/fst/IntSequenceOutputs;
/*      */     //   3: astore_2
/*      */     //   4: new 44	org/apache/lucene/util/fst/Builder
/*      */     //   7: dup
/*      */     //   8: getstatic 45	org/apache/lucene/util/fst/FST$INPUT_TYPE:BYTE4	Lorg/apache/lucene/util/fst/FST$INPUT_TYPE;
/*      */     //   11: aload_2
/*      */     //   12: invokespecial 46	org/apache/lucene/util/fst/Builder:<init>	(Lorg/apache/lucene/util/fst/FST$INPUT_TYPE;Lorg/apache/lucene/util/fst/Outputs;)V
/*      */     //   15: astore_3
/*      */     //   16: new 63	org/apache/lucene/util/IntsRef
/*      */     //   19: dup
/*      */     //   20: invokespecial 142	org/apache/lucene/util/IntsRef:<init>	()V
/*      */     //   23: astore 4
/*      */     //   25: aload_1
/*      */     //   26: invokevirtual 143	java/util/TreeMap:entrySet	()Ljava/util/Set;
/*      */     //   29: invokeinterface 130 1 0
/*      */     //   34: astore 5
/*      */     //   36: aload 5
/*      */     //   38: invokeinterface 131 1 0
/*      */     //   43: ifeq +127 -> 170
/*      */     //   46: aload 5
/*      */     //   48: invokeinterface 132 1 0
/*      */     //   53: checkcast 144	java/util/Map$Entry
/*      */     //   56: astore 6
/*      */     //   58: aload 6
/*      */     //   60: invokeinterface 145 1 0
/*      */     //   65: checkcast 146	java/lang/CharSequence
/*      */     //   68: aload 4
/*      */     //   70: invokestatic 147	org/apache/lucene/util/fst/Util:toUTF32	(Ljava/lang/CharSequence;Lorg/apache/lucene/util/IntsRef;)Lorg/apache/lucene/util/IntsRef;
/*      */     //   73: pop
/*      */     //   74: aload 6
/*      */     //   76: invokeinterface 148 1 0
/*      */     //   81: checkcast 149	java/util/List
/*      */     //   84: astore 7
/*      */     //   86: new 63	org/apache/lucene/util/IntsRef
/*      */     //   89: dup
/*      */     //   90: aload 7
/*      */     //   92: invokeinterface 150 1 0
/*      */     //   97: invokespecial 151	org/apache/lucene/util/IntsRef:<init>	(I)V
/*      */     //   100: astore 8
/*      */     //   102: aload 7
/*      */     //   104: invokeinterface 152 1 0
/*      */     //   109: astore 9
/*      */     //   111: aload 9
/*      */     //   113: invokeinterface 131 1 0
/*      */     //   118: ifeq +41 -> 159
/*      */     //   121: aload 9
/*      */     //   123: invokeinterface 132 1 0
/*      */     //   128: checkcast 153	java/lang/Character
/*      */     //   131: astore 10
/*      */     //   133: aload 8
/*      */     //   135: getfield 154	org/apache/lucene/util/IntsRef:ints	[I
/*      */     //   138: aload 8
/*      */     //   140: dup
/*      */     //   141: getfield 155	org/apache/lucene/util/IntsRef:length	I
/*      */     //   144: dup_x1
/*      */     //   145: iconst_1
/*      */     //   146: iadd
/*      */     //   147: putfield 155	org/apache/lucene/util/IntsRef:length	I
/*      */     //   150: aload 10
/*      */     //   152: invokevirtual 156	java/lang/Character:charValue	()C
/*      */     //   155: iastore
/*      */     //   156: goto -45 -> 111
/*      */     //   159: aload_3
/*      */     //   160: aload 4
/*      */     //   162: aload 8
/*      */     //   164: invokevirtual 157	org/apache/lucene/util/fst/Builder:add	(Lorg/apache/lucene/util/IntsRef;Ljava/lang/Object;)V
/*      */     //   167: goto -131 -> 36
/*      */     //   170: aload_3
/*      */     //   171: invokevirtual 48	org/apache/lucene/util/fst/Builder:finish	()Lorg/apache/lucene/util/fst/FST;
/*      */     //   174: areturn } 
/*  394 */   private void parseAffix(TreeMap<String, List<Character>> affixes, String header, LineNumberReader reader, String conditionPattern, Map<String, Integer> seenPatterns, Map<String, Integer> seenStrips) throws IOException, ParseException { BytesRef scratch = new BytesRef();
/*  395 */     StringBuilder sb = new StringBuilder();
/*  396 */     String[] args = header.split("\\s+");
/*      */ 
/*  398 */     boolean crossProduct = args[2].equals("Y");
/*      */ 
/*  400 */     int numLines = Integer.parseInt(args[3]);
/*  401 */     this.affixData = ArrayUtil.grow(this.affixData, (this.currentAffix << 3) + (numLines << 3));
/*  402 */     ByteArrayDataOutput affixWriter = new ByteArrayDataOutput(this.affixData, this.currentAffix << 3, numLines << 3);
/*      */ 
/*  404 */     for (int i = 0; i < numLines; i++) {
/*  405 */       assert (affixWriter.getPosition() == this.currentAffix << 3);
/*  406 */       String line = reader.readLine();
/*  407 */       String[] ruleArgs = line.split("\\s+");
/*      */ 
/*  411 */       if (ruleArgs.length < 4) {
/*  412 */         throw new ParseException(new StringBuilder().append("The affix file contains a rule with less than four elements: ").append(line).toString(), reader.getLineNumber());
/*      */       }
/*      */ 
/*  415 */       char flag = this.flagParsingStrategy.parseFlag(ruleArgs[1]);
/*  416 */       String strip = ruleArgs[2].equals("0") ? "" : ruleArgs[2];
/*  417 */       String affixArg = ruleArgs[3];
/*  418 */       char[] appendFlags = null;
/*      */ 
/*  420 */       int flagSep = affixArg.lastIndexOf(47);
/*  421 */       if (flagSep != -1) {
/*  422 */         String flagPart = affixArg.substring(flagSep + 1);
/*  423 */         affixArg = affixArg.substring(0, flagSep);
/*      */ 
/*  425 */         if (this.aliasCount > 0) {
/*  426 */           flagPart = getAliasValue(Integer.parseInt(flagPart));
/*      */         }
/*      */ 
/*  429 */         appendFlags = this.flagParsingStrategy.parseFlags(flagPart);
/*  430 */         Arrays.sort(appendFlags);
/*  431 */         this.twoStageAffix = true;
/*      */       }
/*      */ 
/*  436 */       String condition = ruleArgs.length > 4 ? ruleArgs[4] : ".";
/*      */ 
/*  438 */       if ((condition.startsWith("[")) && (!condition.endsWith("]"))) {
/*  439 */         condition = new StringBuilder().append(condition).append("]").toString();
/*      */       }
/*      */ 
/*  442 */       if (condition.indexOf(45) >= 0)
/*  443 */         condition = condition.replace("-", "\\-");
/*      */       String regex;
/*      */       String regex;
/*  447 */       if (".".equals(condition)) {
/*  448 */         regex = ".*";
/*      */       }
/*      */       else
/*      */       {
/*      */         String regex;
/*  449 */         if (condition.equals(strip)) {
/*  450 */           regex = ".*";
/*      */         }
/*      */         else
/*      */         {
/*  454 */           regex = String.format(Locale.ROOT, conditionPattern, new Object[] { condition });
/*      */         }
/*      */       }
/*      */ 
/*  458 */       Integer patternIndex = (Integer)seenPatterns.get(regex);
/*  459 */       if (patternIndex == null) {
/*  460 */         patternIndex = Integer.valueOf(this.patterns.size());
/*  461 */         if (patternIndex.intValue() > 32767) {
/*  462 */           throw new UnsupportedOperationException("Too many patterns, please report this to dev@lucene.apache.org");
/*      */         }
/*  464 */         seenPatterns.put(regex, patternIndex);
/*  465 */         CharacterRunAutomaton pattern = new CharacterRunAutomaton(new RegExp(regex, 0).toAutomaton());
/*  466 */         this.patterns.add(pattern);
/*      */       }
/*      */ 
/*  469 */       Integer stripOrd = (Integer)seenStrips.get(strip);
/*  470 */       if (stripOrd == null) {
/*  471 */         stripOrd = Integer.valueOf(seenStrips.size());
/*  472 */         seenStrips.put(strip, stripOrd);
/*  473 */         if (stripOrd.intValue() > 65535) {
/*  474 */           throw new UnsupportedOperationException("Too many unique strips, please report this to dev@lucene.apache.org");
/*      */         }
/*      */       }
/*      */ 
/*  478 */       if (appendFlags == null) {
/*  479 */         appendFlags = NOFLAGS;
/*      */       }
/*      */ 
/*  482 */       encodeFlags(scratch, appendFlags);
/*  483 */       int appendFlagsOrd = this.flagLookup.add(scratch);
/*  484 */       if (appendFlagsOrd < 0)
/*      */       {
/*  486 */         appendFlagsOrd = -appendFlagsOrd - 1;
/*  487 */       } else if (appendFlagsOrd > 32767)
/*      */       {
/*  489 */         throw new UnsupportedOperationException("Too many unique append flags, please report this to dev@lucene.apache.org");
/*      */       }
/*      */ 
/*  492 */       affixWriter.writeShort((short)flag);
/*  493 */       affixWriter.writeShort((short)stripOrd.intValue());
/*      */ 
/*  495 */       int patternOrd = patternIndex.intValue() << 1 | (crossProduct ? 1 : 0);
/*  496 */       affixWriter.writeShort((short)patternOrd);
/*  497 */       affixWriter.writeShort((short)appendFlagsOrd);
/*      */ 
/*  499 */       if (this.needsInputCleaning) {
/*  500 */         CharSequence cleaned = cleanInput(affixArg, sb);
/*  501 */         affixArg = cleaned.toString();
/*      */       }
/*      */ 
/*  504 */       List list = (List)affixes.get(affixArg);
/*  505 */       if (list == null) {
/*  506 */         list = new ArrayList();
/*  507 */         affixes.put(affixArg, list);
/*      */       }
/*      */ 
/*  510 */       list.add(Character.valueOf((char)this.currentAffix));
/*  511 */       this.currentAffix += 1;
/*      */     } }
/*      */ 
/*      */   private FST<CharsRef> parseConversions(LineNumberReader reader, int num) throws IOException, ParseException
/*      */   {
/*  516 */     Map mappings = new TreeMap();
/*      */ 
/*  518 */     for (int i = 0; i < num; i++) {
/*  519 */       String line = reader.readLine();
/*  520 */       String[] parts = line.split("\\s+");
/*  521 */       if (parts.length != 3) {
/*  522 */         throw new ParseException(new StringBuilder().append("invalid syntax: ").append(line).toString(), reader.getLineNumber());
/*      */       }
/*  524 */       if (mappings.put(parts[1], parts[2]) != null) {
/*  525 */         throw new IllegalStateException(new StringBuilder().append("duplicate mapping specified for: ").append(parts[1]).toString());
/*      */       }
/*      */     }
/*      */ 
/*  529 */     Outputs outputs = CharSequenceOutputs.getSingleton();
/*  530 */     Builder builder = new Builder(FST.INPUT_TYPE.BYTE2, outputs);
/*  531 */     IntsRef scratchInts = new IntsRef();
/*  532 */     for (Map.Entry entry : mappings.entrySet()) {
/*  533 */       Util.toUTF16((CharSequence)entry.getKey(), scratchInts);
/*  534 */       builder.add(scratchInts, new CharsRef((String)entry.getValue()));
/*      */     }
/*      */ 
/*  537 */     return builder.finish();
/*      */   }
/*      */ 
/*      */   static String getDictionaryEncoding(InputStream affix)
/*      */     throws IOException, ParseException
/*      */   {
/*  552 */     StringBuilder encoding = new StringBuilder();
/*      */     while (true) {
/*  554 */       encoding.setLength(0);
/*      */       int ch;
/*  556 */       while (((ch = affix.read()) >= 0) && 
/*  557 */         (ch != 10))
/*      */       {
/*  560 */         if (ch != 13) {
/*  561 */           encoding.append((char)ch);
/*      */         }
/*      */       }
/*  564 */       if ((encoding.length() == 0) || (encoding.charAt(0) == '#') || (encoding.toString().trim().length() == 0))
/*      */       {
/*  569 */         if (ch < 0)
/*  570 */           throw new ParseException("Unexpected end of affix file.", 0);
/*      */       }
/*      */       else
/*      */       {
/*  574 */         Matcher matcher = ENCODING_PATTERN.matcher(encoding);
/*  575 */         if (matcher.find()) {
/*  576 */           int last = matcher.end();
/*  577 */           return encoding.substring(last).trim();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private CharsetDecoder getJavaEncoding(String encoding)
/*      */   {
/*  598 */     if ("ISO8859-14".equals(encoding)) {
/*  599 */       return new ISO8859_14Decoder();
/*      */     }
/*  601 */     String canon = (String)CHARSET_ALIASES.get(encoding);
/*  602 */     if (canon != null) {
/*  603 */       encoding = canon;
/*      */     }
/*  605 */     Charset charset = Charset.forName(encoding);
/*  606 */     return charset.newDecoder().onMalformedInput(CodingErrorAction.REPLACE);
/*      */   }
/*      */ 
/*      */   static FlagParsingStrategy getFlagParsingStrategy(String flagLine)
/*      */   {
/*  616 */     String[] parts = flagLine.split("\\s+");
/*  617 */     if (parts.length != 2) {
/*  618 */       throw new IllegalArgumentException(new StringBuilder().append("Illegal FLAG specification: ").append(flagLine).toString());
/*      */     }
/*  620 */     String flagType = parts[1];
/*      */ 
/*  622 */     if ("num".equals(flagType))
/*  623 */       return new NumFlagParsingStrategy(null);
/*  624 */     if ("UTF-8".equals(flagType))
/*  625 */       return new SimpleFlagParsingStrategy(null);
/*  626 */     if ("long".equals(flagType)) {
/*  627 */       return new DoubleASCIIFlagParsingStrategy(null);
/*      */     }
/*      */ 
/*  630 */     throw new IllegalArgumentException(new StringBuilder().append("Unknown flag type: ").append(flagType).toString());
/*      */   }
/*      */ 
/*      */   String unescapeEntry(String entry)
/*      */   {
/*  636 */     StringBuilder sb = new StringBuilder();
/*  637 */     for (int i = 0; i < entry.length(); i++) {
/*  638 */       char ch = entry.charAt(i);
/*  639 */       if ((ch == '\\') && (i + 1 < entry.length())) {
/*  640 */         sb.append(entry.charAt(i + 1));
/*  641 */         i++;
/*  642 */       } else if (ch == '/') {
/*  643 */         sb.append('\037');
/*      */       } else {
/*  645 */         sb.append(ch);
/*      */       }
/*      */     }
/*  648 */     return sb.toString(); } 
/*      */   private void readDictionaryFiles(List<InputStream> dictionaries, CharsetDecoder decoder, Builder<IntsRef> words) throws IOException { // Byte code:
/*      */     //   0: new 23	org/apache/lucene/util/BytesRef
/*      */     //   3: dup
/*      */     //   4: invokespecial 24	org/apache/lucene/util/BytesRef:<init>	()V
/*      */     //   7: astore 4
/*      */     //   9: new 63	org/apache/lucene/util/IntsRef
/*      */     //   12: dup
/*      */     //   13: invokespecial 142	org/apache/lucene/util/IntsRef:<init>	()V
/*      */     //   16: astore 5
/*      */     //   18: new 118	java/lang/StringBuilder
/*      */     //   21: dup
/*      */     //   22: invokespecial 119	java/lang/StringBuilder:<init>	()V
/*      */     //   25: astore 6
/*      */     //   27: ldc 247
/*      */     //   29: ldc 248
/*      */     //   31: aload_0
/*      */     //   32: getfield 17	org/apache/lucene/analysis/hunspell/Dictionary:tempDir	Ljava/io/File;
/*      */     //   35: invokestatic 28	java/io/File:createTempFile	(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;
/*      */     //   38: astore 7
/*      */     //   40: new 249	org/apache/lucene/util/OfflineSorter$ByteSequencesWriter
/*      */     //   43: dup
/*      */     //   44: aload 7
/*      */     //   46: invokespecial 250	org/apache/lucene/util/OfflineSorter$ByteSequencesWriter:<init>	(Ljava/io/File;)V
/*      */     //   49: astore 8
/*      */     //   51: iconst_0
/*      */     //   52: istore 9
/*      */     //   54: aload_1
/*      */     //   55: invokeinterface 152 1 0
/*      */     //   60: astore 10
/*      */     //   62: aload 10
/*      */     //   64: invokeinterface 131 1 0
/*      */     //   69: ifeq +205 -> 274
/*      */     //   72: aload 10
/*      */     //   74: invokeinterface 132 1 0
/*      */     //   79: checkcast 251	java/io/InputStream
/*      */     //   82: astore 11
/*      */     //   84: new 252	java/io/BufferedReader
/*      */     //   87: dup
/*      */     //   88: new 84	java/io/InputStreamReader
/*      */     //   91: dup
/*      */     //   92: aload 11
/*      */     //   94: aload_2
/*      */     //   95: invokespecial 85	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/nio/charset/CharsetDecoder;)V
/*      */     //   98: invokespecial 253	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
/*      */     //   101: astore 12
/*      */     //   103: aload 12
/*      */     //   105: invokevirtual 254	java/io/BufferedReader:readLine	()Ljava/lang/String;
/*      */     //   108: astore 13
/*      */     //   110: aload 12
/*      */     //   112: invokevirtual 254	java/io/BufferedReader:readLine	()Ljava/lang/String;
/*      */     //   115: dup
/*      */     //   116: astore 13
/*      */     //   118: ifnull +153 -> 271
/*      */     //   121: aload_0
/*      */     //   122: aload 13
/*      */     //   124: invokevirtual 255	org/apache/lucene/analysis/hunspell/Dictionary:unescapeEntry	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   127: astore 13
/*      */     //   129: aload_0
/*      */     //   130: getfield 21	org/apache/lucene/analysis/hunspell/Dictionary:needsInputCleaning	Z
/*      */     //   133: ifeq +122 -> 255
/*      */     //   136: aload 13
/*      */     //   138: bipush 31
/*      */     //   140: invokevirtual 165	java/lang/String:lastIndexOf	(I)I
/*      */     //   143: istore 14
/*      */     //   145: iload 14
/*      */     //   147: iconst_m1
/*      */     //   148: if_icmpne +34 -> 182
/*      */     //   151: aload_0
/*      */     //   152: aload 13
/*      */     //   154: aload 6
/*      */     //   156: invokevirtual 199	org/apache/lucene/analysis/hunspell/Dictionary:cleanInput	(Ljava/lang/CharSequence;Ljava/lang/StringBuilder;)Ljava/lang/CharSequence;
/*      */     //   159: astore 15
/*      */     //   161: aload 8
/*      */     //   163: aload 15
/*      */     //   165: invokeinterface 200 1 0
/*      */     //   170: getstatic 256	java/nio/charset/StandardCharsets:UTF_8	Ljava/nio/charset/Charset;
/*      */     //   173: invokevirtual 257	java/lang/String:getBytes	(Ljava/nio/charset/Charset;)[B
/*      */     //   176: invokevirtual 258	org/apache/lucene/util/OfflineSorter$ByteSequencesWriter:write	([B)V
/*      */     //   179: goto +73 -> 252
/*      */     //   182: aload 13
/*      */     //   184: iconst_0
/*      */     //   185: iload 14
/*      */     //   187: invokevirtual 166	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   190: astore 15
/*      */     //   192: aload_0
/*      */     //   193: aload 15
/*      */     //   195: aload 6
/*      */     //   197: invokevirtual 199	org/apache/lucene/analysis/hunspell/Dictionary:cleanInput	(Ljava/lang/CharSequence;Ljava/lang/StringBuilder;)Ljava/lang/CharSequence;
/*      */     //   200: astore 16
/*      */     //   202: aload 16
/*      */     //   204: aload 6
/*      */     //   206: if_acmpeq +17 -> 223
/*      */     //   209: aload 6
/*      */     //   211: iconst_0
/*      */     //   212: invokevirtual 215	java/lang/StringBuilder:setLength	(I)V
/*      */     //   215: aload 6
/*      */     //   217: aload 16
/*      */     //   219: invokevirtual 259	java/lang/StringBuilder:append	(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;
/*      */     //   222: pop
/*      */     //   223: aload 6
/*      */     //   225: aload 13
/*      */     //   227: iload 14
/*      */     //   229: invokevirtual 91	java/lang/String:substring	(I)Ljava/lang/String;
/*      */     //   232: invokevirtual 121	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   235: pop
/*      */     //   236: aload 8
/*      */     //   238: aload 6
/*      */     //   240: invokevirtual 123	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   243: getstatic 256	java/nio/charset/StandardCharsets:UTF_8	Ljava/nio/charset/Charset;
/*      */     //   246: invokevirtual 257	java/lang/String:getBytes	(Ljava/nio/charset/Charset;)[B
/*      */     //   249: invokevirtual 258	org/apache/lucene/util/OfflineSorter$ByteSequencesWriter:write	([B)V
/*      */     //   252: goto -142 -> 110
/*      */     //   255: aload 8
/*      */     //   257: aload 13
/*      */     //   259: getstatic 256	java/nio/charset/StandardCharsets:UTF_8	Ljava/nio/charset/Charset;
/*      */     //   262: invokevirtual 257	java/lang/String:getBytes	(Ljava/nio/charset/Charset;)[B
/*      */     //   265: invokevirtual 258	org/apache/lucene/util/OfflineSorter$ByteSequencesWriter:write	([B)V
/*      */     //   268: goto -158 -> 110
/*      */     //   271: goto -209 -> 62
/*      */     //   274: iconst_1
/*      */     //   275: istore 9
/*      */     //   277: iload 9
/*      */     //   279: ifeq +18 -> 297
/*      */     //   282: iconst_1
/*      */     //   283: anewarray 51	java/io/Closeable
/*      */     //   286: dup
/*      */     //   287: iconst_0
/*      */     //   288: aload 8
/*      */     //   290: aastore
/*      */     //   291: invokestatic 260	org/apache/lucene/util/IOUtils:close	([Ljava/io/Closeable;)V
/*      */     //   294: goto +55 -> 349
/*      */     //   297: iconst_1
/*      */     //   298: anewarray 51	java/io/Closeable
/*      */     //   301: dup
/*      */     //   302: iconst_0
/*      */     //   303: aload 8
/*      */     //   305: aastore
/*      */     //   306: invokestatic 52	org/apache/lucene/util/IOUtils:closeWhileHandlingException	([Ljava/io/Closeable;)V
/*      */     //   309: goto +40 -> 349
/*      */     //   312: astore 17
/*      */     //   314: iload 9
/*      */     //   316: ifeq +18 -> 334
/*      */     //   319: iconst_1
/*      */     //   320: anewarray 51	java/io/Closeable
/*      */     //   323: dup
/*      */     //   324: iconst_0
/*      */     //   325: aload 8
/*      */     //   327: aastore
/*      */     //   328: invokestatic 260	org/apache/lucene/util/IOUtils:close	([Ljava/io/Closeable;)V
/*      */     //   331: goto +15 -> 346
/*      */     //   334: iconst_1
/*      */     //   335: anewarray 51	java/io/Closeable
/*      */     //   338: dup
/*      */     //   339: iconst_0
/*      */     //   340: aload 8
/*      */     //   342: aastore
/*      */     //   343: invokestatic 52	org/apache/lucene/util/IOUtils:closeWhileHandlingException	([Ljava/io/Closeable;)V
/*      */     //   346: aload 17
/*      */     //   348: athrow
/*      */     //   349: ldc_w 261
/*      */     //   352: ldc 248
/*      */     //   354: aload_0
/*      */     //   355: getfield 17	org/apache/lucene/analysis/hunspell/Dictionary:tempDir	Ljava/io/File;
/*      */     //   358: invokestatic 28	java/io/File:createTempFile	(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;
/*      */     //   361: astore 10
/*      */     //   363: new 262	org/apache/lucene/util/OfflineSorter
/*      */     //   366: dup
/*      */     //   367: new 263	org/apache/lucene/analysis/hunspell/Dictionary$1
/*      */     //   370: dup
/*      */     //   371: aload_0
/*      */     //   372: invokespecial 264	org/apache/lucene/analysis/hunspell/Dictionary$1:<init>	(Lorg/apache/lucene/analysis/hunspell/Dictionary;)V
/*      */     //   375: invokespecial 265	org/apache/lucene/util/OfflineSorter:<init>	(Ljava/util/Comparator;)V
/*      */     //   378: astore 11
/*      */     //   380: aload 11
/*      */     //   382: aload 7
/*      */     //   384: aload 10
/*      */     //   386: invokevirtual 266	org/apache/lucene/util/OfflineSorter:sort	(Ljava/io/File;Ljava/io/File;)Lorg/apache/lucene/util/OfflineSorter$SortInfo;
/*      */     //   389: pop
/*      */     //   390: aload 7
/*      */     //   392: invokevirtual 53	java/io/File:delete	()Z
/*      */     //   395: pop
/*      */     //   396: new 267	org/apache/lucene/util/OfflineSorter$ByteSequencesReader
/*      */     //   399: dup
/*      */     //   400: aload 10
/*      */     //   402: invokespecial 268	org/apache/lucene/util/OfflineSorter$ByteSequencesReader:<init>	(Ljava/io/File;)V
/*      */     //   405: astore 12
/*      */     //   407: new 23	org/apache/lucene/util/BytesRef
/*      */     //   410: dup
/*      */     //   411: invokespecial 24	org/apache/lucene/util/BytesRef:<init>	()V
/*      */     //   414: astore 13
/*      */     //   416: aconst_null
/*      */     //   417: astore 14
/*      */     //   419: new 63	org/apache/lucene/util/IntsRef
/*      */     //   422: dup
/*      */     //   423: invokespecial 142	org/apache/lucene/util/IntsRef:<init>	()V
/*      */     //   426: astore 15
/*      */     //   428: aload 12
/*      */     //   430: aload 13
/*      */     //   432: invokevirtual 269	org/apache/lucene/util/OfflineSorter$ByteSequencesReader:read	(Lorg/apache/lucene/util/BytesRef;)Z
/*      */     //   435: ifeq +328 -> 763
/*      */     //   438: aload 13
/*      */     //   440: invokevirtual 270	org/apache/lucene/util/BytesRef:utf8ToString	()Ljava/lang/String;
/*      */     //   443: astore 16
/*      */     //   445: aload 16
/*      */     //   447: bipush 31
/*      */     //   449: invokevirtual 165	java/lang/String:lastIndexOf	(I)I
/*      */     //   452: istore 19
/*      */     //   454: iload 19
/*      */     //   456: iconst_m1
/*      */     //   457: if_icmpne +15 -> 472
/*      */     //   460: getstatic 195	org/apache/lucene/analysis/hunspell/Dictionary:NOFLAGS	[C
/*      */     //   463: astore 18
/*      */     //   465: aload 16
/*      */     //   467: astore 17
/*      */     //   469: goto +117 -> 586
/*      */     //   472: aload 16
/*      */     //   474: bipush 9
/*      */     //   476: iload 19
/*      */     //   478: invokevirtual 271	java/lang/String:indexOf	(II)I
/*      */     //   481: istore 20
/*      */     //   483: iload 20
/*      */     //   485: iconst_m1
/*      */     //   486: if_icmpne +10 -> 496
/*      */     //   489: aload 16
/*      */     //   491: invokevirtual 134	java/lang/String:length	()I
/*      */     //   494: istore 20
/*      */     //   496: aload 16
/*      */     //   498: bipush 32
/*      */     //   500: iload 19
/*      */     //   502: invokevirtual 271	java/lang/String:indexOf	(II)I
/*      */     //   505: istore 21
/*      */     //   507: iload 21
/*      */     //   509: iconst_m1
/*      */     //   510: if_icmpne +10 -> 520
/*      */     //   513: aload 16
/*      */     //   515: invokevirtual 134	java/lang/String:length	()I
/*      */     //   518: istore 21
/*      */     //   520: iload 20
/*      */     //   522: iload 21
/*      */     //   524: invokestatic 272	java/lang/Math:min	(II)I
/*      */     //   527: istore 20
/*      */     //   529: aload 16
/*      */     //   531: iload 19
/*      */     //   533: iconst_1
/*      */     //   534: iadd
/*      */     //   535: iload 20
/*      */     //   537: invokevirtual 166	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   540: astore 22
/*      */     //   542: aload_0
/*      */     //   543: getfield 15	org/apache/lucene/analysis/hunspell/Dictionary:aliasCount	I
/*      */     //   546: ifle +14 -> 560
/*      */     //   549: aload_0
/*      */     //   550: aload 22
/*      */     //   552: invokestatic 124	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   555: invokespecial 167	org/apache/lucene/analysis/hunspell/Dictionary:getAliasValue	(I)Ljava/lang/String;
/*      */     //   558: astore 22
/*      */     //   560: aload_0
/*      */     //   561: getfield 14	org/apache/lucene/analysis/hunspell/Dictionary:flagParsingStrategy	Lorg/apache/lucene/analysis/hunspell/Dictionary$FlagParsingStrategy;
/*      */     //   564: aload 22
/*      */     //   566: invokevirtual 168	org/apache/lucene/analysis/hunspell/Dictionary$FlagParsingStrategy:parseFlags	(Ljava/lang/String;)[C
/*      */     //   569: astore 18
/*      */     //   571: aload 18
/*      */     //   573: invokestatic 115	java/util/Arrays:sort	([C)V
/*      */     //   576: aload 16
/*      */     //   578: iconst_0
/*      */     //   579: iload 19
/*      */     //   581: invokevirtual 166	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   584: astore 17
/*      */     //   586: aload 14
/*      */     //   588: ifnonnull +7 -> 595
/*      */     //   591: iconst_1
/*      */     //   592: goto +10 -> 602
/*      */     //   595: aload 17
/*      */     //   597: aload 14
/*      */     //   599: invokevirtual 273	java/lang/String:compareTo	(Ljava/lang/String;)I
/*      */     //   602: istore 20
/*      */     //   604: iload 20
/*      */     //   606: ifge +43 -> 649
/*      */     //   609: new 235	java/lang/IllegalArgumentException
/*      */     //   612: dup
/*      */     //   613: new 118	java/lang/StringBuilder
/*      */     //   616: dup
/*      */     //   617: invokespecial 119	java/lang/StringBuilder:<init>	()V
/*      */     //   620: ldc_w 274
/*      */     //   623: invokevirtual 121	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   626: aload 17
/*      */     //   628: invokevirtual 121	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   631: ldc_w 275
/*      */     //   634: invokevirtual 121	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   637: aload 14
/*      */     //   639: invokevirtual 121	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   642: invokevirtual 123	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   645: invokespecial 237	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*      */     //   648: athrow
/*      */     //   649: aload 4
/*      */     //   651: aload 18
/*      */     //   653: invokestatic 196	org/apache/lucene/analysis/hunspell/Dictionary:encodeFlags	(Lorg/apache/lucene/util/BytesRef;[C)V
/*      */     //   656: aload_0
/*      */     //   657: getfield 9	org/apache/lucene/analysis/hunspell/Dictionary:flagLookup	Lorg/apache/lucene/util/BytesRefHash;
/*      */     //   660: aload 4
/*      */     //   662: invokevirtual 25	org/apache/lucene/util/BytesRefHash:add	(Lorg/apache/lucene/util/BytesRef;)I
/*      */     //   665: istore 21
/*      */     //   667: iload 21
/*      */     //   669: ifge +10 -> 679
/*      */     //   672: iload 21
/*      */     //   674: ineg
/*      */     //   675: iconst_1
/*      */     //   676: isub
/*      */     //   677: istore 21
/*      */     //   679: iload 20
/*      */     //   681: ifle +24 -> 705
/*      */     //   684: aload 14
/*      */     //   686: ifnull +19 -> 705
/*      */     //   689: aload 14
/*      */     //   691: aload 5
/*      */     //   693: invokestatic 147	org/apache/lucene/util/fst/Util:toUTF32	(Ljava/lang/CharSequence;Lorg/apache/lucene/util/IntsRef;)Lorg/apache/lucene/util/IntsRef;
/*      */     //   696: pop
/*      */     //   697: aload_3
/*      */     //   698: aload 5
/*      */     //   700: aload 15
/*      */     //   702: invokevirtual 157	org/apache/lucene/util/fst/Builder:add	(Lorg/apache/lucene/util/IntsRef;Ljava/lang/Object;)V
/*      */     //   705: iload 20
/*      */     //   707: ifgt +8 -> 715
/*      */     //   710: aload 14
/*      */     //   712: ifnonnull +16 -> 728
/*      */     //   715: aload 17
/*      */     //   717: astore 14
/*      */     //   719: new 63	org/apache/lucene/util/IntsRef
/*      */     //   722: dup
/*      */     //   723: invokespecial 142	org/apache/lucene/util/IntsRef:<init>	()V
/*      */     //   726: astore 15
/*      */     //   728: aload 15
/*      */     //   730: aload 15
/*      */     //   732: getfield 155	org/apache/lucene/util/IntsRef:length	I
/*      */     //   735: iconst_1
/*      */     //   736: iadd
/*      */     //   737: invokevirtual 276	org/apache/lucene/util/IntsRef:grow	(I)V
/*      */     //   740: aload 15
/*      */     //   742: getfield 154	org/apache/lucene/util/IntsRef:ints	[I
/*      */     //   745: aload 15
/*      */     //   747: dup
/*      */     //   748: getfield 155	org/apache/lucene/util/IntsRef:length	I
/*      */     //   751: dup_x1
/*      */     //   752: iconst_1
/*      */     //   753: iadd
/*      */     //   754: putfield 155	org/apache/lucene/util/IntsRef:length	I
/*      */     //   757: iload 21
/*      */     //   759: iastore
/*      */     //   760: goto -332 -> 428
/*      */     //   763: aload 14
/*      */     //   765: aload 5
/*      */     //   767: invokestatic 147	org/apache/lucene/util/fst/Util:toUTF32	(Ljava/lang/CharSequence;Lorg/apache/lucene/util/IntsRef;)Lorg/apache/lucene/util/IntsRef;
/*      */     //   770: pop
/*      */     //   771: aload_3
/*      */     //   772: aload 5
/*      */     //   774: aload 15
/*      */     //   776: invokevirtual 157	org/apache/lucene/util/fst/Builder:add	(Lorg/apache/lucene/util/IntsRef;Ljava/lang/Object;)V
/*      */     //   779: aload 12
/*      */     //   781: invokevirtual 277	org/apache/lucene/util/OfflineSorter$ByteSequencesReader:close	()V
/*      */     //   784: aload 10
/*      */     //   786: invokevirtual 53	java/io/File:delete	()Z
/*      */     //   789: pop
/*      */     //   790: return
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   54	277	312	finally
/*      */     //   312	314	312	finally } 
/*  818 */   static char[] decodeFlags(BytesRef b) { if (b.length == 0) {
/*  819 */       return CharsRef.EMPTY_CHARS;
/*      */     }
/*  821 */     int len = b.length >>> 1;
/*  822 */     char[] flags = new char[len];
/*  823 */     int upto = 0;
/*  824 */     int end = b.offset + b.length;
/*  825 */     for (int i = b.offset; i < end; i += 2) {
/*  826 */       flags[(upto++)] = ((char)(b.bytes[i] << 8 | b.bytes[(i + 1)] & 0xFF));
/*      */     }
/*  828 */     return flags; }
/*      */ 
/*      */   static void encodeFlags(BytesRef b, char[] flags)
/*      */   {
/*  832 */     int len = flags.length << 1;
/*  833 */     b.grow(len);
/*  834 */     b.length = len;
/*  835 */     int upto = b.offset;
/*  836 */     for (int i = 0; i < flags.length; i++) {
/*  837 */       int flag = flags[i];
/*  838 */       b.bytes[(upto++)] = ((byte)(flag >> 8 & 0xFF));
/*  839 */       b.bytes[(upto++)] = ((byte)(flag & 0xFF));
/*      */     }
/*      */   }
/*      */ 
/*      */   private void parseAlias(String line) {
/*  844 */     String[] ruleArgs = line.split("\\s+");
/*  845 */     if (this.aliases == null)
/*      */     {
/*  847 */       int count = Integer.parseInt(ruleArgs[1]);
/*  848 */       this.aliases = new String[count];
/*      */     }
/*      */     else {
/*  851 */       String aliasValue = ruleArgs.length == 1 ? "" : ruleArgs[1];
/*  852 */       this.aliases[(this.aliasCount++)] = aliasValue;
/*      */     }
/*      */   }
/*      */ 
/*      */   private String getAliasValue(int id) {
/*      */     try {
/*  858 */       return this.aliases[(id - 1)];
/*      */     } catch (IndexOutOfBoundsException ex) {
/*  860 */       throw new IllegalArgumentException(new StringBuilder().append("Bad flag alias number:").append(id).toString(), ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   static boolean hasFlag(char[] flags, char flag)
/*      */   {
/*  961 */     return Arrays.binarySearch(flags, flag) >= 0;
/*      */   }
/*      */ 
/*      */   CharSequence cleanInput(CharSequence input, StringBuilder reuse) {
/*  965 */     reuse.setLength(0);
/*      */ 
/*  967 */     for (int i = 0; i < input.length(); i++) {
/*  968 */       char ch = input.charAt(i);
/*      */ 
/*  970 */       if ((this.ignore == null) || (Arrays.binarySearch(this.ignore, ch) < 0))
/*      */       {
/*  974 */         if ((this.ignoreCase) && (this.iconv == null))
/*      */         {
/*  976 */           ch = Character.toLowerCase(ch);
/*      */         }
/*      */ 
/*  979 */         reuse.append(ch);
/*      */       }
/*      */     }
/*  982 */     if (this.iconv != null) {
/*      */       try {
/*  984 */         applyMappings(this.iconv, reuse);
/*      */       } catch (IOException bogus) {
/*  986 */         throw new RuntimeException(bogus);
/*      */       }
/*  988 */       if (this.ignoreCase) {
/*  989 */         for (int i = 0; i < reuse.length(); i++) {
/*  990 */           reuse.setCharAt(i, Character.toLowerCase(reuse.charAt(i)));
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  995 */     return reuse;
/*      */   }
/*      */ 
/*      */   static void applyMappings(FST<CharsRef> fst, StringBuilder sb) throws IOException
/*      */   {
/* 1000 */     FST.BytesReader bytesReader = fst.getBytesReader();
/* 1001 */     FST.Arc firstArc = fst.getFirstArc(new FST.Arc());
/* 1002 */     CharsRef NO_OUTPUT = (CharsRef)fst.outputs.getNoOutput();
/*      */ 
/* 1005 */     FST.Arc arc = new FST.Arc();
/*      */ 
/* 1009 */     for (int i = 0; i < sb.length(); i++) {
/* 1010 */       arc.copyFrom(firstArc);
/* 1011 */       CharsRef output = NO_OUTPUT;
/* 1012 */       int longestMatch = -1;
/* 1013 */       CharsRef longestOutput = null;
/*      */ 
/* 1015 */       for (int j = i; j < sb.length(); j++) {
/* 1016 */         char ch = sb.charAt(j);
/* 1017 */         if (fst.findTargetArc(ch, arc, arc, bytesReader) == null) {
/*      */           break;
/*      */         }
/* 1020 */         output = (CharsRef)fst.outputs.add(output, arc.output);
/*      */ 
/* 1022 */         if (arc.isFinal()) {
/* 1023 */           longestOutput = (CharsRef)fst.outputs.add(output, arc.nextFinalOutput);
/* 1024 */           longestMatch = j;
/*      */         }
/*      */       }
/*      */ 
/* 1028 */       if (longestMatch >= 0) {
/* 1029 */         sb.delete(i, longestMatch + 1);
/* 1030 */         sb.insert(i, longestOutput);
/* 1031 */         i += longestOutput.length - 1;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   74 */     NOFLAGS = new char[0];
/*      */ 
/*  541 */     ENCODING_PATTERN = Pattern.compile("^(ï»¿)?SET\\s+");
/*      */ 
/*  584 */     Map m = new HashMap();
/*  585 */     m.put("microsoft-cp1251", "windows-1251");
/*  586 */     m.put("TIS620-2533", "TIS-620");
/*      */   }
/*      */ 
/*      */   private static class DoubleASCIIFlagParsingStrategy extends Dictionary.FlagParsingStrategy
/*      */   {
/*      */     public char[] parseFlags(String rawFlags)
/*      */     {
/*  941 */       if (rawFlags.length() == 0) {
/*  942 */         return new char[0];
/*      */       }
/*      */ 
/*  945 */       StringBuilder builder = new StringBuilder();
/*  946 */       if (rawFlags.length() % 2 == 1) {
/*  947 */         throw new IllegalArgumentException(new StringBuilder().append("Invalid flags (should be even number of characters): ").append(rawFlags).toString());
/*      */       }
/*  949 */       for (int i = 0; i < rawFlags.length(); i += 2) {
/*  950 */         char cookedFlag = (char)(rawFlags.charAt(i) + rawFlags.charAt(i + 1));
/*  951 */         builder.append(cookedFlag);
/*      */       }
/*      */ 
/*  954 */       char[] flags = new char[builder.length()];
/*  955 */       builder.getChars(0, builder.length(), flags, 0);
/*  956 */       return flags;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class NumFlagParsingStrategy extends Dictionary.FlagParsingStrategy
/*      */   {
/*      */     public char[] parseFlags(String rawFlags)
/*      */     {
/*  910 */       String[] rawFlagParts = rawFlags.trim().split(",");
/*  911 */       char[] flags = new char[rawFlagParts.length];
/*  912 */       int upto = 0;
/*      */ 
/*  914 */       for (int i = 0; i < rawFlagParts.length; i++)
/*      */       {
/*  916 */         String replacement = rawFlagParts[i].replaceAll("[^0-9]", "");
/*      */ 
/*  918 */         if (!replacement.isEmpty())
/*      */         {
/*  921 */           flags[(upto++)] = ((char)Integer.parseInt(replacement));
/*      */         }
/*      */       }
/*  924 */       if (upto < flags.length) {
/*  925 */         flags = Arrays.copyOf(flags, upto);
/*      */       }
/*  927 */       return flags;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SimpleFlagParsingStrategy extends Dictionary.FlagParsingStrategy
/*      */   {
/*      */     public char[] parseFlags(String rawFlags)
/*      */     {
/*  899 */       return rawFlags.toCharArray();
/*      */     }
/*      */   }
/*      */ 
/*      */   static abstract class FlagParsingStrategy
/*      */   {
/*      */     char parseFlag(String rawFlag)
/*      */     {
/*  876 */       char[] flags = parseFlags(rawFlag);
/*  877 */       if (flags.length != 1) {
/*  878 */         throw new IllegalArgumentException("expected only one flag, got: " + rawFlag);
/*      */       }
/*  880 */       return flags[0];
/*      */     }
/*      */ 
/*      */     abstract char[] parseFlags(String paramString);
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.hunspell.Dictionary
 * JD-Core Version:    0.6.2
 */