/*    */ package org.apache.lucene.analysis.hunspell;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.CharBuffer;
/*    */ import java.nio.charset.CharsetDecoder;
/*    */ import java.nio.charset.CoderResult;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ 
/*    */ final class ISO8859_14Decoder extends CharsetDecoder
/*    */ {
/* 29 */   static final char[] TABLE = { ' ', 'Ḃ', 'ḃ', '£', 'Ċ', 'ċ', 'Ḋ', '§', 'Ẁ', '©', 'Ẃ', 'ḋ', 'Ỳ', '­', '®', 'Ÿ', 'Ḟ', 'ḟ', 'Ġ', 'ġ', 'Ṁ', 'ṁ', '¶', 'Ṗ', 'ẁ', 'ṗ', 'ẃ', 'Ṡ', 'ỳ', 'Ẅ', 'ẅ', 'ṡ', 'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ŵ', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ṫ', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'Ŷ', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ŵ', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ṫ', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ŷ', 'ÿ' };
/*    */ 
/*    */   ISO8859_14Decoder()
/*    */   {
/* 45 */     super(StandardCharsets.ISO_8859_1, 1.0F, 1.0F);
/*    */   }
/*    */ 
/*    */   protected CoderResult decodeLoop(ByteBuffer in, CharBuffer out)
/*    */   {
/* 50 */     while ((in.hasRemaining()) && (out.hasRemaining())) {
/* 51 */       char ch = (char)(in.get() & 0xFF);
/* 52 */       if (ch >= ' ') {
/* 53 */         ch = TABLE[(ch - ' ')];
/*    */       }
/* 55 */       out.put(ch);
/*    */     }
/* 57 */     return in.hasRemaining() ? CoderResult.OVERFLOW : CoderResult.UNDERFLOW;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.hunspell.ISO8859_14Decoder
 * JD-Core Version:    0.6.2
 */