/*     */ package org.apache.lucene.analysis.it;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.snowball.SnowballFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.ElisionFilter;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.analysis.util.WordlistLoader;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.tartarus.snowball.ext.ItalianStemmer;
/*     */ 
/*     */ public final class ItalianAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   private final CharArraySet stemExclusionSet;
/*     */   public static final String DEFAULT_STOPWORD_FILE = "italian_stop.txt";
/*  60 */   private static final CharArraySet DEFAULT_ARTICLES = CharArraySet.unmodifiableSet(new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "c", "l", "all", "dall", "dell", "nell", "sull", "coll", "pell", "gl", "agl", "dagl", "degl", "negl", "sugl", "un", "m", "t", "s", "v", "d" }), true));
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  72 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public ItalianAnalyzer(Version matchVersion)
/*     */   {
/*  98 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   public ItalianAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/* 108 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public ItalianAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/* 121 */     super(matchVersion, stopwords);
/* 122 */     this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 141 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 142 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/* 143 */     if (this.matchVersion.onOrAfter(Version.LUCENE_32)) {
/* 144 */       result = new ElisionFilter(result, DEFAULT_ARTICLES);
/*     */     }
/* 146 */     result = new LowerCaseFilter(this.matchVersion, result);
/* 147 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 148 */     if (!this.stemExclusionSet.isEmpty())
/* 149 */       result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
/* 150 */     if (this.matchVersion.onOrAfter(Version.LUCENE_36))
/* 151 */       result = new ItalianLightStemFilter(result);
/*     */     else {
/* 153 */       result = new SnowballFilter(result, new ItalianStemmer());
/*     */     }
/* 155 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  84 */         DEFAULT_STOP_SET = WordlistLoader.getSnowballWordSet(IOUtils.getDecodingReader(SnowballFilter.class, "italian_stop.txt", StandardCharsets.UTF_8), Version.LUCENE_CURRENT);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  89 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.it.ItalianAnalyzer
 * JD-Core Version:    0.6.2
 */