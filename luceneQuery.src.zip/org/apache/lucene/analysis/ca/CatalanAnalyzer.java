/*     */ package org.apache.lucene.analysis.ca;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.Arrays;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.snowball.SnowballFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.ElisionFilter;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.tartarus.snowball.ext.CatalanStemmer;
/*     */ 
/*     */ public final class CatalanAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   private final CharArraySet stemExclusionSet;
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*  56 */   private static final CharArraySet DEFAULT_ARTICLES = CharArraySet.unmodifiableSet(new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "d", "l", "m", "n", "s", "t" }), true));
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  67 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public CatalanAnalyzer(Version matchVersion)
/*     */   {
/*  93 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   public CatalanAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/* 103 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public CatalanAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/* 116 */     super(matchVersion, stopwords);
/* 117 */     this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 136 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 137 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/* 138 */     if (this.matchVersion.onOrAfter(Version.LUCENE_36)) {
/* 139 */       result = new ElisionFilter(result, DEFAULT_ARTICLES);
/*     */     }
/* 141 */     result = new LowerCaseFilter(this.matchVersion, result);
/* 142 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 143 */     if (!this.stemExclusionSet.isEmpty())
/* 144 */       result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
/* 145 */     result = new SnowballFilter(result, new CatalanStemmer());
/* 146 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  79 */         DEFAULT_STOP_SET = CatalanAnalyzer.loadStopwordSet(false, CatalanAnalyzer.class, "stopwords.txt", "#");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  84 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ca.CatalanAnalyzer
 * JD-Core Version:    0.6.2
 */