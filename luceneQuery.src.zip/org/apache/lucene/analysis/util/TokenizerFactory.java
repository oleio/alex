/*    */ package org.apache.lucene.analysis.util;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.apache.lucene.analysis.Tokenizer;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public abstract class TokenizerFactory extends AbstractAnalysisFactory
/*    */ {
/* 33 */   private static final AnalysisSPILoader<TokenizerFactory> loader = new AnalysisSPILoader(TokenizerFactory.class);
/*    */ 
/*    */   public static TokenizerFactory forName(String name, Map<String, String> args)
/*    */   {
/* 38 */     return (TokenizerFactory)loader.newInstance(name, args);
/*    */   }
/*    */ 
/*    */   public static Class<? extends TokenizerFactory> lookupClass(String name)
/*    */   {
/* 43 */     return loader.lookupClass(name);
/*    */   }
/*    */ 
/*    */   public static Set<String> availableTokenizers()
/*    */   {
/* 48 */     return loader.availableServices();
/*    */   }
/*    */ 
/*    */   public static void reloadTokenizers(ClassLoader classloader)
/*    */   {
/* 63 */     loader.reload(classloader);
/*    */   }
/*    */ 
/*    */   protected TokenizerFactory(Map<String, String> args)
/*    */   {
/* 70 */     super(args);
/*    */   }
/*    */ 
/*    */   public final Tokenizer create(Reader input)
/*    */   {
/* 75 */     return create(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY, input);
/*    */   }
/*    */ 
/*    */   public abstract Tokenizer create(AttributeSource.AttributeFactory paramAttributeFactory, Reader paramReader);
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.TokenizerFactory
 * JD-Core Version:    0.6.2
 */