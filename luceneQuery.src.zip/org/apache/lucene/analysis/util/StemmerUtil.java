/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ public class StemmerUtil
/*     */ {
/*     */   public static boolean startsWith(char[] s, int len, String prefix)
/*     */   {
/*  38 */     int prefixLen = prefix.length();
/*  39 */     if (prefixLen > len)
/*  40 */       return false;
/*  41 */     for (int i = 0; i < prefixLen; i++)
/*  42 */       if (s[i] != prefix.charAt(i))
/*  43 */         return false;
/*  44 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean endsWith(char[] s, int len, String suffix)
/*     */   {
/*  56 */     int suffixLen = suffix.length();
/*  57 */     if (suffixLen > len)
/*  58 */       return false;
/*  59 */     for (int i = suffixLen - 1; i >= 0; i--) {
/*  60 */       if (s[(len - (suffixLen - i))] != suffix.charAt(i))
/*  61 */         return false;
/*     */     }
/*  63 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean endsWith(char[] s, int len, char[] suffix)
/*     */   {
/*  75 */     int suffixLen = suffix.length;
/*  76 */     if (suffixLen > len)
/*  77 */       return false;
/*  78 */     for (int i = suffixLen - 1; i >= 0; i--) {
/*  79 */       if (s[(len - (suffixLen - i))] != suffix[i])
/*  80 */         return false;
/*     */     }
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */   public static int delete(char[] s, int pos, int len)
/*     */   {
/*  94 */     assert (pos < len);
/*  95 */     if (pos < len - 1) {
/*  96 */       System.arraycopy(s, pos + 1, s, pos, len - pos - 1);
/*     */     }
/*  98 */     return len - 1;
/*     */   }
/*     */ 
/*     */   public static int deleteN(char[] s, int pos, int len, int nChars)
/*     */   {
/* 111 */     assert (pos + nChars <= len);
/* 112 */     if (pos + nChars < len) {
/* 113 */       System.arraycopy(s, pos + nChars, s, pos, len - pos - nChars);
/*     */     }
/* 115 */     return len - nChars;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.StemmerUtil
 * JD-Core Version:    0.6.2
 */