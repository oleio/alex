package org.apache.lucene.analysis.util;

public abstract interface MultiTermAwareComponent
{
  public abstract AbstractAnalysisFactory getMultiTermComponent();
}

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.MultiTermAwareComponent
 * JD-Core Version:    0.6.2
 */