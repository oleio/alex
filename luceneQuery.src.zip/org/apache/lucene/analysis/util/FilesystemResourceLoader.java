/*    */ package org.apache.lucene.analysis.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public final class FilesystemResourceLoader
/*    */   implements ResourceLoader
/*    */ {
/*    */   private final File baseDirectory;
/*    */   private final ResourceLoader delegate;
/*    */ 
/*    */   public FilesystemResourceLoader()
/*    */   {
/* 49 */     this((File)null);
/*    */   }
/*    */ 
/*    */   public FilesystemResourceLoader(File baseDirectory)
/*    */   {
/* 59 */     this(baseDirectory, new ClasspathResourceLoader());
/*    */   }
/*    */ 
/*    */   public FilesystemResourceLoader(File baseDirectory, ResourceLoader delegate)
/*    */   {
/* 69 */     if ((baseDirectory != null) && (!baseDirectory.isDirectory()))
/* 70 */       throw new IllegalArgumentException("baseDirectory is not a directory or null");
/* 71 */     if (delegate == null)
/* 72 */       throw new IllegalArgumentException("delegate ResourceLoader may not be null");
/* 73 */     this.baseDirectory = baseDirectory;
/* 74 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   public InputStream openResource(String resource) throws IOException
/*    */   {
/*    */     try {
/* 80 */       File file = new File(resource);
/* 81 */       if ((this.baseDirectory != null) && (!file.isAbsolute())) {
/* 82 */         file = new File(this.baseDirectory, resource);
/*    */       }
/* 84 */       return new FileInputStream(file); } catch (FileNotFoundException fnfe) {
/*    */     }
/* 86 */     return this.delegate.openResource(resource);
/*    */   }
/*    */ 
/*    */   public <T> T newInstance(String cname, Class<T> expectedType)
/*    */   {
/* 92 */     return this.delegate.newInstance(cname, expectedType);
/*    */   }
/*    */ 
/*    */   public <T> Class<? extends T> findClass(String cname, Class<T> expectedType)
/*    */   {
/* 97 */     return this.delegate.findClass(cname, expectedType);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.FilesystemResourceLoader
 * JD-Core Version:    0.6.2
 */