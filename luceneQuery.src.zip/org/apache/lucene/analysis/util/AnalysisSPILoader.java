/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ServiceConfigurationError;
/*     */ import java.util.Set;
/*     */ import org.apache.lucene.util.SPIClassIterator;
/*     */ 
/*     */ final class AnalysisSPILoader<S extends AbstractAnalysisFactory>
/*     */ {
/*  36 */   private volatile Map<String, Class<? extends S>> services = Collections.emptyMap();
/*     */   private final Class<S> clazz;
/*     */   private final String[] suffixes;
/*     */ 
/*     */   public AnalysisSPILoader(Class<S> clazz)
/*     */   {
/*  41 */     this(clazz, new String[] { clazz.getSimpleName() });
/*     */   }
/*     */ 
/*     */   public AnalysisSPILoader(Class<S> clazz, ClassLoader loader) {
/*  45 */     this(clazz, new String[] { clazz.getSimpleName() }, loader);
/*     */   }
/*     */ 
/*     */   public AnalysisSPILoader(Class<S> clazz, String[] suffixes) {
/*  49 */     this(clazz, suffixes, Thread.currentThread().getContextClassLoader());
/*     */   }
/*     */ 
/*     */   public AnalysisSPILoader(Class<S> clazz, String[] suffixes, ClassLoader classloader) {
/*  53 */     this.clazz = clazz;
/*  54 */     this.suffixes = suffixes;
/*     */ 
/*  56 */     ClassLoader clazzClassloader = clazz.getClassLoader();
/*  57 */     if ((clazzClassloader != null) && (!SPIClassIterator.isParentClassLoader(clazzClassloader, classloader))) {
/*  58 */       reload(clazzClassloader);
/*     */     }
/*  60 */     reload(classloader);
/*     */   }
/*     */ 
/*     */   public synchronized void reload(ClassLoader classloader)
/*     */   {
/*  75 */     LinkedHashMap services = new LinkedHashMap(this.services);
/*     */ 
/*  77 */     SPIClassIterator loader = SPIClassIterator.get(this.clazz, classloader);
/*  78 */     while (loader.hasNext()) {
/*  79 */       Class service = loader.next();
/*  80 */       String clazzName = service.getSimpleName();
/*  81 */       String name = null;
/*  82 */       for (String suffix : this.suffixes) {
/*  83 */         if (clazzName.endsWith(suffix)) {
/*  84 */           name = clazzName.substring(0, clazzName.length() - suffix.length()).toLowerCase(Locale.ROOT);
/*  85 */           break;
/*     */         }
/*     */       }
/*  88 */       if (name == null) {
/*  89 */         throw new ServiceConfigurationError("The class name " + service.getName() + " has wrong suffix, allowed are: " + Arrays.toString(this.suffixes));
/*     */       }
/*     */ 
/* 100 */       if (!services.containsKey(name)) {
/* 101 */         services.put(name, service);
/*     */       }
/*     */     }
/* 104 */     this.services = Collections.unmodifiableMap(services);
/*     */   }
/*     */ 
/*     */   public S newInstance(String name, Map<String, String> args) {
/* 108 */     Class service = lookupClass(name);
/*     */     try {
/* 110 */       return (AbstractAnalysisFactory)service.getConstructor(new Class[] { Map.class }).newInstance(new Object[] { args });
/*     */     } catch (Exception e) {
/* 112 */       throw new IllegalArgumentException("SPI class of type " + this.clazz.getName() + " with name '" + name + "' cannot be instantiated. " + "This is likely due to a misconfiguration of the java class '" + service.getName() + "': ", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class<? extends S> lookupClass(String name)
/*     */   {
/* 118 */     Class service = (Class)this.services.get(name.toLowerCase(Locale.ROOT));
/* 119 */     if (service != null) {
/* 120 */       return service;
/*     */     }
/* 122 */     throw new IllegalArgumentException("A SPI class of type " + this.clazz.getName() + " with name '" + name + "' does not exist. " + "You need to add the corresponding JAR file supporting this SPI to your classpath. " + "The current classpath supports the following names: " + availableServices());
/*     */   }
/*     */ 
/*     */   public Set<String> availableServices()
/*     */   {
/* 129 */     return this.services.keySet();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.AnalysisSPILoader
 * JD-Core Version:    0.6.2
 */