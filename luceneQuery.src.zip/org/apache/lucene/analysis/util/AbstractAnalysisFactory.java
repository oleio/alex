/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public abstract class AbstractAnalysisFactory
/*     */ {
/*     */   public static final String LUCENE_MATCH_VERSION_PARAM = "luceneMatchVersion";
/*     */   private final Map<String, String> originalArgs;
/*     */   protected final Version luceneMatchVersion;
/*  63 */   private boolean isExplicitLuceneMatchVersion = false;
/*     */ 
/* 195 */   private static final Pattern ITEM_PATTERN = Pattern.compile("[^,\\s]+");
/*     */   private static final String CLASS_NAME = "class";
/*     */ 
/*     */   protected AbstractAnalysisFactory(Map<String, String> args)
/*     */   {
/*  69 */     this.originalArgs = Collections.unmodifiableMap(new HashMap(args));
/*  70 */     String version = get(args, "luceneMatchVersion");
/*  71 */     this.luceneMatchVersion = (version == null ? null : Version.parseLeniently(version));
/*  72 */     args.remove("class");
/*     */   }
/*     */ 
/*     */   public final Map<String, String> getOriginalArgs() {
/*  76 */     return this.originalArgs;
/*     */   }
/*     */ 
/*     */   protected final void assureMatchVersion()
/*     */   {
/*  83 */     if (this.luceneMatchVersion == null)
/*  84 */       throw new IllegalArgumentException("Configuration Error: Factory '" + getClass().getName() + "' needs a 'luceneMatchVersion' parameter");
/*     */   }
/*     */ 
/*     */   public final Version getLuceneMatchVersion()
/*     */   {
/*  90 */     return this.luceneMatchVersion;
/*     */   }
/*     */ 
/*     */   public String require(Map<String, String> args, String name) {
/*  94 */     String s = (String)args.remove(name);
/*  95 */     if (s == null) {
/*  96 */       throw new IllegalArgumentException("Configuration Error: missing parameter '" + name + "'");
/*     */     }
/*  98 */     return s;
/*     */   }
/*     */   public String require(Map<String, String> args, String name, Collection<String> allowedValues) {
/* 101 */     return require(args, name, allowedValues, true);
/*     */   }
/*     */   public String require(Map<String, String> args, String name, Collection<String> allowedValues, boolean caseSensitive) {
/* 104 */     String s = (String)args.remove(name);
/* 105 */     if (s == null) {
/* 106 */       throw new IllegalArgumentException("Configuration Error: missing parameter '" + name + "'");
/*     */     }
/* 108 */     for (String allowedValue : allowedValues) {
/* 109 */       if (caseSensitive) {
/* 110 */         if (s.equals(allowedValue)) {
/* 111 */           return s;
/*     */         }
/*     */       }
/* 114 */       else if (s.equalsIgnoreCase(allowedValue)) {
/* 115 */         return s;
/*     */       }
/*     */     }
/*     */ 
/* 119 */     throw new IllegalArgumentException("Configuration Error: '" + name + "' value must be one of " + allowedValues);
/*     */   }
/*     */ 
/*     */   public String get(Map<String, String> args, String name) {
/* 123 */     return (String)args.remove(name);
/*     */   }
/*     */   public String get(Map<String, String> args, String name, String defaultVal) {
/* 126 */     String s = (String)args.remove(name);
/* 127 */     return s == null ? defaultVal : s;
/*     */   }
/*     */   public String get(Map<String, String> args, String name, Collection<String> allowedValues) {
/* 130 */     return get(args, name, allowedValues, null);
/*     */   }
/*     */   public String get(Map<String, String> args, String name, Collection<String> allowedValues, String defaultVal) {
/* 133 */     return get(args, name, allowedValues, defaultVal, true);
/*     */   }
/*     */   public String get(Map<String, String> args, String name, Collection<String> allowedValues, String defaultVal, boolean caseSensitive) {
/* 136 */     String s = (String)args.remove(name);
/* 137 */     if (s == null) {
/* 138 */       return defaultVal;
/*     */     }
/* 140 */     for (String allowedValue : allowedValues) {
/* 141 */       if (caseSensitive) {
/* 142 */         if (s.equals(allowedValue)) {
/* 143 */           return s;
/*     */         }
/*     */       }
/* 146 */       else if (s.equalsIgnoreCase(allowedValue)) {
/* 147 */         return s;
/*     */       }
/*     */     }
/*     */ 
/* 151 */     throw new IllegalArgumentException("Configuration Error: '" + name + "' value must be one of " + allowedValues);
/*     */   }
/*     */ 
/*     */   protected final int requireInt(Map<String, String> args, String name)
/*     */   {
/* 156 */     return Integer.parseInt(require(args, name));
/*     */   }
/*     */   protected final int getInt(Map<String, String> args, String name, int defaultVal) {
/* 159 */     String s = (String)args.remove(name);
/* 160 */     return s == null ? defaultVal : Integer.parseInt(s);
/*     */   }
/*     */ 
/*     */   protected final boolean requireBoolean(Map<String, String> args, String name) {
/* 164 */     return Boolean.parseBoolean(require(args, name));
/*     */   }
/*     */   protected final boolean getBoolean(Map<String, String> args, String name, boolean defaultVal) {
/* 167 */     String s = (String)args.remove(name);
/* 168 */     return s == null ? defaultVal : Boolean.parseBoolean(s);
/*     */   }
/*     */ 
/*     */   protected final float requireFloat(Map<String, String> args, String name) {
/* 172 */     return Float.parseFloat(require(args, name));
/*     */   }
/*     */   protected final float getFloat(Map<String, String> args, String name, float defaultVal) {
/* 175 */     String s = (String)args.remove(name);
/* 176 */     return s == null ? defaultVal : Float.parseFloat(s);
/*     */   }
/*     */ 
/*     */   public char requireChar(Map<String, String> args, String name) {
/* 180 */     return require(args, name).charAt(0);
/*     */   }
/*     */   public char getChar(Map<String, String> args, String name, char defaultValue) {
/* 183 */     String s = (String)args.remove(name);
/* 184 */     if (s == null) {
/* 185 */       return defaultValue;
/*     */     }
/* 187 */     if (s.length() != 1) {
/* 188 */       throw new IllegalArgumentException(name + " should be a char. \"" + s + "\" is invalid");
/*     */     }
/* 190 */     return s.charAt(0);
/*     */   }
/*     */ 
/*     */   public Set<String> getSet(Map<String, String> args, String name)
/*     */   {
/* 199 */     String s = (String)args.remove(name);
/* 200 */     if (s == null) {
/* 201 */       return null;
/*     */     }
/* 203 */     Set set = null;
/* 204 */     Matcher matcher = ITEM_PATTERN.matcher(s);
/* 205 */     if (matcher.find()) {
/* 206 */       set = new HashSet();
/* 207 */       set.add(matcher.group(0));
/* 208 */       while (matcher.find()) {
/* 209 */         set.add(matcher.group(0));
/*     */       }
/*     */     }
/* 212 */     return set;
/*     */   }
/*     */ 
/*     */   protected final Pattern getPattern(Map<String, String> args, String name)
/*     */   {
/*     */     try
/*     */     {
/* 221 */       return Pattern.compile(require(args, name));
/*     */     } catch (PatternSyntaxException e) {
/* 223 */       throw new IllegalArgumentException("Configuration Error: '" + name + "' can not be parsed in " + getClass().getSimpleName(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final CharArraySet getWordSet(ResourceLoader loader, String wordFiles, boolean ignoreCase)
/*     */     throws IOException
/*     */   {
/* 235 */     assureMatchVersion();
/* 236 */     List files = splitFileNames(wordFiles);
/* 237 */     CharArraySet words = null;
/* 238 */     if (files.size() > 0)
/*     */     {
/* 241 */       words = new CharArraySet(this.luceneMatchVersion, files.size() * 10, ignoreCase);
/*     */ 
/* 243 */       for (String file : files) {
/* 244 */         List wlist = getLines(loader, file.trim());
/* 245 */         words.addAll(StopFilter.makeStopSet(this.luceneMatchVersion, wlist, ignoreCase));
/*     */       }
/*     */     }
/*     */ 
/* 249 */     return words;
/*     */   }
/*     */ 
/*     */   protected final List<String> getLines(ResourceLoader loader, String resource)
/*     */     throws IOException
/*     */   {
/* 256 */     return WordlistLoader.getLines(loader.openResource(resource), StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */   protected final CharArraySet getSnowballWordSet(ResourceLoader loader, String wordFiles, boolean ignoreCase)
/*     */     throws IOException
/*     */   {
/* 263 */     assureMatchVersion();
/* 264 */     List files = splitFileNames(wordFiles);
/* 265 */     CharArraySet words = null;
/* 266 */     if (files.size() > 0)
/*     */     {
/* 269 */       words = new CharArraySet(this.luceneMatchVersion, files.size() * 10, ignoreCase);
/*     */ 
/* 271 */       for (String file : files) {
/* 272 */         InputStream stream = null;
/* 273 */         Reader reader = null;
/*     */         try {
/* 275 */           stream = loader.openResource(file.trim());
/* 276 */           CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
/*     */ 
/* 279 */           reader = new InputStreamReader(stream, decoder);
/* 280 */           WordlistLoader.getSnowballWordSet(reader, words);
/*     */         } finally {
/* 282 */           IOUtils.closeWhileHandlingException(new Closeable[] { reader, stream });
/*     */         }
/*     */       }
/*     */     }
/* 286 */     return words;
/*     */   }
/*     */ 
/*     */   protected final List<String> splitFileNames(String fileNames)
/*     */   {
/* 297 */     if (fileNames == null) {
/* 298 */       return Collections.emptyList();
/*     */     }
/* 300 */     List result = new ArrayList();
/* 301 */     for (String file : fileNames.split("(?<!\\\\),")) {
/* 302 */       result.add(file.replaceAll("\\\\(?=,)", ""));
/*     */     }
/*     */ 
/* 305 */     return result;
/*     */   }
/*     */ 
/*     */   public String getClassArg()
/*     */   {
/* 315 */     if (null != this.originalArgs) {
/* 316 */       String className = (String)this.originalArgs.get("class");
/* 317 */       if (null != className) {
/* 318 */         return className;
/*     */       }
/*     */     }
/* 321 */     return getClass().getName();
/*     */   }
/*     */ 
/*     */   public boolean isExplicitLuceneMatchVersion() {
/* 325 */     return this.isExplicitLuceneMatchVersion;
/*     */   }
/*     */ 
/*     */   public void setExplicitLuceneMatchVersion(boolean isExplicitLuceneMatchVersion) {
/* 329 */     this.isExplicitLuceneMatchVersion = isExplicitLuceneMatchVersion;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.AbstractAnalysisFactory
 * JD-Core Version:    0.6.2
 */