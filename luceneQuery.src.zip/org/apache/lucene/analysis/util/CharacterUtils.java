/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public abstract class CharacterUtils
/*     */ {
/*  33 */   private static final Java4CharacterUtils JAVA_4 = new Java4CharacterUtils();
/*  34 */   private static final Java5CharacterUtils JAVA_5 = new Java5CharacterUtils();
/*     */ 
/*     */   public static CharacterUtils getInstance(Version matchVersion)
/*     */   {
/*  46 */     return matchVersion.onOrAfter(Version.LUCENE_31) ? JAVA_5 : JAVA_4;
/*     */   }
/*     */ 
/*     */   public static CharacterUtils getJava4Instance()
/*     */   {
/*  51 */     return JAVA_4;
/*     */   }
/*     */ 
/*     */   public abstract int codePointAt(CharSequence paramCharSequence, int paramInt);
/*     */ 
/*     */   public abstract int codePointAt(char[] paramArrayOfChar, int paramInt1, int paramInt2);
/*     */ 
/*     */   public abstract int codePointCount(CharSequence paramCharSequence);
/*     */ 
/*     */   public static CharacterBuffer newCharacterBuffer(int bufferSize)
/*     */   {
/* 111 */     if (bufferSize < 2) {
/* 112 */       throw new IllegalArgumentException("buffersize must be >= 2");
/*     */     }
/* 114 */     return new CharacterBuffer(new char[bufferSize], 0, 0);
/*     */   }
/*     */ 
/*     */   public final void toLowerCase(char[] buffer, int offset, int limit)
/*     */   {
/* 126 */     assert (buffer.length >= limit);
/* 127 */     assert ((offset <= 0) && (offset <= buffer.length));
/* 128 */     for (int i = offset; i < limit; )
/* 129 */       i += Character.toChars(Character.toLowerCase(codePointAt(buffer, i, limit)), buffer, i);
/*     */   }
/*     */ 
/*     */   public final void toUpperCase(char[] buffer, int offset, int limit)
/*     */   {
/* 143 */     assert (buffer.length >= limit);
/* 144 */     assert ((offset <= 0) && (offset <= buffer.length));
/* 145 */     for (int i = offset; i < limit; )
/* 146 */       i += Character.toChars(Character.toUpperCase(codePointAt(buffer, i, limit)), buffer, i);
/*     */   }
/*     */ 
/*     */   public final int toCodePoints(char[] src, int srcOff, int srcLen, int[] dest, int destOff)
/*     */   {
/* 155 */     if (srcLen < 0) {
/* 156 */       throw new IllegalArgumentException("srcLen must be >= 0");
/*     */     }
/* 158 */     int codePointCount = 0;
/* 159 */     for (int i = 0; i < srcLen; ) {
/* 160 */       int cp = codePointAt(src, srcOff + i, srcOff + srcLen);
/* 161 */       int charCount = Character.charCount(cp);
/* 162 */       dest[(destOff + codePointCount++)] = cp;
/* 163 */       i += charCount;
/*     */     }
/* 165 */     return codePointCount;
/*     */   }
/*     */ 
/*     */   public final int toChars(int[] src, int srcOff, int srcLen, char[] dest, int destOff)
/*     */   {
/* 171 */     if (srcLen < 0) {
/* 172 */       throw new IllegalArgumentException("srcLen must be >= 0");
/*     */     }
/* 174 */     int written = 0;
/* 175 */     for (int i = 0; i < srcLen; i++) {
/* 176 */       written += Character.toChars(src[(srcOff + i)], dest, destOff + written);
/*     */     }
/* 178 */     return written;
/*     */   }
/*     */ 
/*     */   public abstract boolean fill(CharacterBuffer paramCharacterBuffer, Reader paramReader, int paramInt)
/*     */     throws IOException;
/*     */ 
/*     */   public final boolean fill(CharacterBuffer buffer, Reader reader)
/*     */     throws IOException
/*     */   {
/* 220 */     return fill(buffer, reader, buffer.buffer.length);
/*     */   }
/*     */ 
/*     */   public abstract int offsetByCodePoints(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */ 
/*     */   static int readFully(Reader reader, char[] dest, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 228 */     int read = 0;
/* 229 */     while (read < len) {
/* 230 */       int r = reader.read(dest, offset + read, len - read);
/* 231 */       if (r == -1) {
/*     */         break;
/*     */       }
/* 234 */       read += r;
/*     */     }
/* 236 */     return read;
/*     */   }
/*     */ 
/*     */   public static final class CharacterBuffer
/*     */   {
/*     */     private final char[] buffer;
/*     */     private int offset;
/*     */     private int length;
/*     */     char lastTrailingHighSurrogate;
/*     */ 
/*     */     CharacterBuffer(char[] buffer, int offset, int length)
/*     */     {
/* 359 */       this.buffer = buffer;
/* 360 */       this.offset = offset;
/* 361 */       this.length = length;
/*     */     }
/*     */ 
/*     */     public char[] getBuffer()
/*     */     {
/* 370 */       return this.buffer;
/*     */     }
/*     */ 
/*     */     public int getOffset()
/*     */     {
/* 379 */       return this.offset;
/*     */     }
/*     */ 
/*     */     public int getLength()
/*     */     {
/* 389 */       return this.length;
/*     */     }
/*     */ 
/*     */     public void reset()
/*     */     {
/* 397 */       this.offset = 0;
/* 398 */       this.length = 0;
/* 399 */       this.lastTrailingHighSurrogate = '\000';
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class Java4CharacterUtils extends CharacterUtils
/*     */   {
/*     */     public int codePointAt(CharSequence seq, int offset)
/*     */     {
/* 305 */       return seq.charAt(offset);
/*     */     }
/*     */ 
/*     */     public int codePointAt(char[] chars, int offset, int limit)
/*     */     {
/* 310 */       if (offset >= limit)
/* 311 */         throw new IndexOutOfBoundsException("offset must be less than limit");
/* 312 */       return chars[offset];
/*     */     }
/*     */ 
/*     */     public boolean fill(CharacterUtils.CharacterBuffer buffer, Reader reader, int numChars)
/*     */       throws IOException
/*     */     {
/* 318 */       assert (buffer.buffer.length >= 1);
/* 319 */       if ((numChars < 1) || (numChars > buffer.buffer.length)) {
/* 320 */         throw new IllegalArgumentException("numChars must be >= 1 and <= the buffer size");
/*     */       }
/* 322 */       buffer.offset = 0;
/* 323 */       int read = readFully(reader, buffer.buffer, 0, numChars);
/* 324 */       buffer.length = read;
/* 325 */       buffer.lastTrailingHighSurrogate = '\000';
/* 326 */       return read == numChars;
/*     */     }
/*     */ 
/*     */     public int codePointCount(CharSequence seq)
/*     */     {
/* 331 */       return seq.length();
/*     */     }
/*     */ 
/*     */     public int offsetByCodePoints(char[] buf, int start, int count, int index, int offset)
/*     */     {
/* 336 */       int result = index + offset;
/* 337 */       if ((result < 0) || (result > count)) {
/* 338 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 340 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class Java5CharacterUtils extends CharacterUtils
/*     */   {
/*     */     public int codePointAt(CharSequence seq, int offset)
/*     */     {
/* 245 */       return Character.codePointAt(seq, offset);
/*     */     }
/*     */ 
/*     */     public int codePointAt(char[] chars, int offset, int limit)
/*     */     {
/* 250 */       return Character.codePointAt(chars, offset, limit);
/*     */     }
/*     */ 
/*     */     public boolean fill(CharacterUtils.CharacterBuffer buffer, Reader reader, int numChars) throws IOException
/*     */     {
/* 255 */       assert (buffer.buffer.length >= 2);
/* 256 */       if ((numChars < 2) || (numChars > buffer.buffer.length)) {
/* 257 */         throw new IllegalArgumentException("numChars must be >= 2 and <= the buffer size");
/*     */       }
/* 259 */       char[] charBuffer = buffer.buffer;
/* 260 */       buffer.offset = 0;
/*     */       int offset;
/*     */       int offset;
/* 264 */       if (buffer.lastTrailingHighSurrogate != 0) {
/* 265 */         charBuffer[0] = buffer.lastTrailingHighSurrogate;
/* 266 */         buffer.lastTrailingHighSurrogate = '\000';
/* 267 */         offset = 1;
/*     */       } else {
/* 269 */         offset = 0;
/*     */       }
/*     */ 
/* 272 */       int read = readFully(reader, charBuffer, offset, numChars - offset);
/*     */ 
/* 274 */       buffer.length = (offset + read);
/* 275 */       boolean result = buffer.length == numChars;
/* 276 */       if (buffer.length < numChars)
/*     */       {
/* 279 */         return result;
/*     */       }
/*     */ 
/* 282 */       if (Character.isHighSurrogate(charBuffer[(buffer.length - 1)])) {
/* 283 */         buffer.lastTrailingHighSurrogate = charBuffer[CharacterUtils.CharacterBuffer.access$206(buffer)];
/*     */       }
/* 285 */       return result;
/*     */     }
/*     */ 
/*     */     public int codePointCount(CharSequence seq)
/*     */     {
/* 290 */       return Character.codePointCount(seq, 0, seq.length());
/*     */     }
/*     */ 
/*     */     public int offsetByCodePoints(char[] buf, int start, int count, int index, int offset)
/*     */     {
/* 295 */       return Character.offsetByCodePoints(buf, start, count, index, offset);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.CharacterUtils
 * JD-Core Version:    0.6.2
 */