/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public class CharArrayMap<V> extends AbstractMap<Object, V>
/*     */ {
/*  55 */   private static final CharArrayMap<?> EMPTY_MAP = new EmptyCharArrayMap();
/*     */   private static final int INIT_SIZE = 8;
/*     */   private final CharacterUtils charUtils;
/*     */   private boolean ignoreCase;
/*     */   private int count;
/*     */   final Version matchVersion;
/*     */   char[][] keys;
/*     */   V[] values;
/* 356 */   private CharArrayMap<V>.EntrySet entrySet = null;
/* 357 */   private CharArraySet keySet = null;
/*     */ 
/*     */   public CharArrayMap(Version matchVersion, int startSize, boolean ignoreCase)
/*     */   {
/*  79 */     this.ignoreCase = ignoreCase;
/*  80 */     int size = 8;
/*  81 */     while (startSize + (startSize >> 2) > size)
/*  82 */       size <<= 1;
/*  83 */     this.keys = new char[size][];
/*  84 */     this.values = ((Object[])new Object[size]);
/*  85 */     this.charUtils = CharacterUtils.getInstance(matchVersion);
/*  86 */     this.matchVersion = matchVersion;
/*     */   }
/*     */ 
/*     */   public CharArrayMap(Version matchVersion, Map<?, ? extends V> c, boolean ignoreCase)
/*     */   {
/* 102 */     this(matchVersion, c.size(), ignoreCase);
/* 103 */     putAll(c);
/*     */   }
/*     */ 
/*     */   private CharArrayMap(CharArrayMap<V> toCopy)
/*     */   {
/* 108 */     this.keys = toCopy.keys;
/* 109 */     this.values = toCopy.values;
/* 110 */     this.ignoreCase = toCopy.ignoreCase;
/* 111 */     this.count = toCopy.count;
/* 112 */     this.charUtils = toCopy.charUtils;
/* 113 */     this.matchVersion = toCopy.matchVersion;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 119 */     this.count = 0;
/* 120 */     Arrays.fill(this.keys, null);
/* 121 */     Arrays.fill(this.values, null);
/*     */   }
/*     */ 
/*     */   public boolean containsKey(char[] text, int off, int len)
/*     */   {
/* 127 */     return this.keys[getSlot(text, off, len)] != null;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(CharSequence cs)
/*     */   {
/* 132 */     return this.keys[getSlot(cs)] != null;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object o)
/*     */   {
/* 137 */     if ((o instanceof char[])) {
/* 138 */       char[] text = (char[])o;
/* 139 */       return containsKey(text, 0, text.length);
/*     */     }
/* 141 */     return containsKey(o.toString());
/*     */   }
/*     */ 
/*     */   public V get(char[] text, int off, int len)
/*     */   {
/* 147 */     return this.values[getSlot(text, off, len)];
/*     */   }
/*     */ 
/*     */   public V get(CharSequence cs)
/*     */   {
/* 152 */     return this.values[getSlot(cs)];
/*     */   }
/*     */ 
/*     */   public V get(Object o)
/*     */   {
/* 157 */     if ((o instanceof char[])) {
/* 158 */       char[] text = (char[])o;
/* 159 */       return get(text, 0, text.length);
/*     */     }
/* 161 */     return get(o.toString());
/*     */   }
/*     */ 
/*     */   private int getSlot(char[] text, int off, int len) {
/* 165 */     int code = getHashCode(text, off, len);
/* 166 */     int pos = code & this.keys.length - 1;
/* 167 */     char[] text2 = this.keys[pos];
/* 168 */     if ((text2 != null) && (!equals(text, off, len, text2))) {
/* 169 */       int inc = (code >> 8) + code | 0x1;
/*     */       do {
/* 171 */         code += inc;
/* 172 */         pos = code & this.keys.length - 1;
/* 173 */         text2 = this.keys[pos];
/* 174 */       }while ((text2 != null) && (!equals(text, off, len, text2)));
/*     */     }
/* 176 */     return pos;
/*     */   }
/*     */ 
/*     */   private int getSlot(CharSequence text)
/*     */   {
/* 181 */     int code = getHashCode(text);
/* 182 */     int pos = code & this.keys.length - 1;
/* 183 */     char[] text2 = this.keys[pos];
/* 184 */     if ((text2 != null) && (!equals(text, text2))) {
/* 185 */       int inc = (code >> 8) + code | 0x1;
/*     */       do {
/* 187 */         code += inc;
/* 188 */         pos = code & this.keys.length - 1;
/* 189 */         text2 = this.keys[pos];
/* 190 */       }while ((text2 != null) && (!equals(text, text2)));
/*     */     }
/* 192 */     return pos;
/*     */   }
/*     */ 
/*     */   public V put(CharSequence text, V value)
/*     */   {
/* 197 */     return put(text.toString(), value);
/*     */   }
/*     */ 
/*     */   public V put(Object o, V value)
/*     */   {
/* 202 */     if ((o instanceof char[])) {
/* 203 */       return put((char[])o, value);
/*     */     }
/* 205 */     return put(o.toString(), value);
/*     */   }
/*     */ 
/*     */   public V put(String text, V value)
/*     */   {
/* 210 */     return put(text.toCharArray(), value);
/*     */   }
/*     */ 
/*     */   public V put(char[] text, V value)
/*     */   {
/* 218 */     if (this.ignoreCase) {
/* 219 */       this.charUtils.toLowerCase(text, 0, text.length);
/*     */     }
/* 221 */     int slot = getSlot(text, 0, text.length);
/* 222 */     if (this.keys[slot] != null) {
/* 223 */       Object oldValue = this.values[slot];
/* 224 */       this.values[slot] = value;
/* 225 */       return oldValue;
/*     */     }
/* 227 */     this.keys[slot] = text;
/* 228 */     this.values[slot] = value;
/* 229 */     this.count += 1;
/*     */ 
/* 231 */     if (this.count + (this.count >> 2) > this.keys.length) {
/* 232 */       rehash();
/*     */     }
/*     */ 
/* 235 */     return null;
/*     */   }
/*     */ 
/*     */   private void rehash()
/*     */   {
/* 240 */     assert (this.keys.length == this.values.length);
/* 241 */     int newSize = 2 * this.keys.length;
/* 242 */     char[][] oldkeys = this.keys;
/* 243 */     Object[] oldvalues = this.values;
/* 244 */     this.keys = new char[newSize][];
/* 245 */     this.values = ((Object[])new Object[newSize]);
/*     */ 
/* 247 */     for (int i = 0; i < oldkeys.length; i++) {
/* 248 */       char[] text = oldkeys[i];
/* 249 */       if (text != null)
/*     */       {
/* 251 */         int slot = getSlot(text, 0, text.length);
/* 252 */         this.keys[slot] = text;
/* 253 */         this.values[slot] = oldvalues[i];
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean equals(char[] text1, int off, int len, char[] text2) {
/* 259 */     if (len != text2.length)
/* 260 */       return false;
/* 261 */     int limit = off + len;
/*     */     int i;
/* 262 */     if (this.ignoreCase)
/* 263 */       for (i = 0; i < len; ) {
/* 264 */         int codePointAt = this.charUtils.codePointAt(text1, off + i, limit);
/* 265 */         if (Character.toLowerCase(codePointAt) != this.charUtils.codePointAt(text2, i, text2.length))
/* 266 */           return false;
/* 267 */         i += Character.charCount(codePointAt);
/*     */       }
/*     */     else {
/* 270 */       for (int i = 0; i < len; i++) {
/* 271 */         if (text1[(off + i)] != text2[i])
/* 272 */           return false;
/*     */       }
/*     */     }
/* 275 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean equals(CharSequence text1, char[] text2) {
/* 279 */     int len = text1.length();
/* 280 */     if (len != text2.length)
/* 281 */       return false;
/*     */     int i;
/* 282 */     if (this.ignoreCase)
/* 283 */       for (i = 0; i < len; ) {
/* 284 */         int codePointAt = this.charUtils.codePointAt(text1, i);
/* 285 */         if (Character.toLowerCase(codePointAt) != this.charUtils.codePointAt(text2, i, text2.length))
/* 286 */           return false;
/* 287 */         i += Character.charCount(codePointAt);
/*     */       }
/*     */     else {
/* 290 */       for (int i = 0; i < len; i++) {
/* 291 */         if (text1.charAt(i) != text2[i])
/* 292 */           return false;
/*     */       }
/*     */     }
/* 295 */     return true;
/*     */   }
/*     */ 
/*     */   private int getHashCode(char[] text, int offset, int len) {
/* 299 */     if (text == null)
/* 300 */       throw new NullPointerException();
/* 301 */     int code = 0;
/* 302 */     int stop = offset + len;
/*     */     int i;
/* 303 */     if (this.ignoreCase)
/* 304 */       for (i = offset; i < stop; ) {
/* 305 */         int codePointAt = this.charUtils.codePointAt(text, i, stop);
/* 306 */         code = code * 31 + Character.toLowerCase(codePointAt);
/* 307 */         i += Character.charCount(codePointAt);
/*     */       }
/*     */     else {
/* 310 */       for (int i = offset; i < stop; i++) {
/* 311 */         code = code * 31 + text[i];
/*     */       }
/*     */     }
/* 314 */     return code;
/*     */   }
/*     */ 
/*     */   private int getHashCode(CharSequence text) {
/* 318 */     if (text == null)
/* 319 */       throw new NullPointerException();
/* 320 */     int code = 0;
/* 321 */     int len = text.length();
/*     */     int i;
/* 322 */     if (this.ignoreCase)
/* 323 */       for (i = 0; i < len; ) {
/* 324 */         int codePointAt = this.charUtils.codePointAt(text, i);
/* 325 */         code = code * 31 + Character.toLowerCase(codePointAt);
/* 326 */         i += Character.charCount(codePointAt);
/*     */       }
/*     */     else {
/* 329 */       for (int i = 0; i < len; i++) {
/* 330 */         code = code * 31 + text.charAt(i);
/*     */       }
/*     */     }
/* 333 */     return code;
/*     */   }
/*     */ 
/*     */   public V remove(Object key)
/*     */   {
/* 338 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 343 */     return this.count;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 348 */     StringBuilder sb = new StringBuilder("{");
/* 349 */     for (Map.Entry entry : entrySet()) {
/* 350 */       if (sb.length() > 1) sb.append(", ");
/* 351 */       sb.append(entry);
/*     */     }
/* 353 */     return sb.append('}').toString();
/*     */   }
/*     */ 
/*     */   CharArrayMap<V>.EntrySet createEntrySet()
/*     */   {
/* 360 */     return new EntrySet(true, null);
/*     */   }
/*     */ 
/*     */   public final CharArrayMap<V>.EntrySet entrySet()
/*     */   {
/* 365 */     if (this.entrySet == null) {
/* 366 */       this.entrySet = createEntrySet();
/*     */     }
/* 368 */     return this.entrySet;
/*     */   }
/*     */ 
/*     */   final Set<Object> originalKeySet()
/*     */   {
/* 373 */     return super.keySet();
/*     */   }
/*     */ 
/*     */   public final CharArraySet keySet()
/*     */   {
/* 380 */     if (this.keySet == null)
/*     */     {
/* 382 */       this.keySet = new CharArraySet(this)
/*     */       {
/*     */         public boolean add(Object o) {
/* 385 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         public boolean add(CharSequence text) {
/* 389 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         public boolean add(String text) {
/* 393 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         public boolean add(char[] text) {
/* 397 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */     }
/* 401 */     return this.keySet;
/*     */   }
/*     */ 
/*     */   public static <V> CharArrayMap<V> unmodifiableMap(CharArrayMap<V> map)
/*     */   {
/* 556 */     if (map == null)
/* 557 */       throw new NullPointerException("Given map is null");
/* 558 */     if ((map == emptyMap()) || (map.isEmpty()))
/* 559 */       return emptyMap();
/* 560 */     if ((map instanceof UnmodifiableCharArrayMap))
/* 561 */       return map;
/* 562 */     return new UnmodifiableCharArrayMap(map);
/*     */   }
/*     */ 
/*     */   public static <V> CharArrayMap<V> copy(Version matchVersion, Map<?, ? extends V> map)
/*     */   {
/* 588 */     if (map == EMPTY_MAP)
/* 589 */       return emptyMap();
/* 590 */     if ((map instanceof CharArrayMap)) {
/* 591 */       CharArrayMap m = (CharArrayMap)map;
/*     */ 
/* 594 */       char[][] keys = new char[m.keys.length][];
/* 595 */       System.arraycopy(m.keys, 0, keys, 0, keys.length);
/* 596 */       Object[] values = (Object[])new Object[m.values.length];
/* 597 */       System.arraycopy(m.values, 0, values, 0, values.length);
/* 598 */       m = new CharArrayMap(m);
/* 599 */       m.keys = keys;
/* 600 */       m.values = values;
/* 601 */       return m;
/*     */     }
/* 603 */     return new CharArrayMap(matchVersion, map, false);
/*     */   }
/*     */ 
/*     */   public static <V> CharArrayMap<V> emptyMap()
/*     */   {
/* 609 */     return EMPTY_MAP;
/*     */   }
/*     */ 
/*     */   private static final class EmptyCharArrayMap<V> extends CharArrayMap.UnmodifiableCharArrayMap<V>
/*     */   {
/*     */     EmptyCharArrayMap()
/*     */     {
/* 662 */       super();
/*     */     }
/*     */ 
/*     */     public boolean containsKey(char[] text, int off, int len)
/*     */     {
/* 667 */       if (text == null)
/* 668 */         throw new NullPointerException();
/* 669 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean containsKey(CharSequence cs)
/*     */     {
/* 674 */       if (cs == null)
/* 675 */         throw new NullPointerException();
/* 676 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean containsKey(Object o)
/*     */     {
/* 681 */       if (o == null)
/* 682 */         throw new NullPointerException();
/* 683 */       return false;
/*     */     }
/*     */ 
/*     */     public V get(char[] text, int off, int len)
/*     */     {
/* 688 */       if (text == null)
/* 689 */         throw new NullPointerException();
/* 690 */       return null;
/*     */     }
/*     */ 
/*     */     public V get(CharSequence cs)
/*     */     {
/* 695 */       if (cs == null)
/* 696 */         throw new NullPointerException();
/* 697 */       return null;
/*     */     }
/*     */ 
/*     */     public V get(Object o)
/*     */     {
/* 702 */       if (o == null)
/* 703 */         throw new NullPointerException();
/* 704 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class UnmodifiableCharArrayMap<V> extends CharArrayMap<V>
/*     */   {
/*     */     UnmodifiableCharArrayMap(CharArrayMap<V> map)
/*     */     {
/* 616 */       super(null);
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 621 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public V put(Object o, V val)
/*     */     {
/* 626 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public V put(char[] text, V val)
/*     */     {
/* 631 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public V put(CharSequence text, V val)
/*     */     {
/* 636 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public V put(String text, V val)
/*     */     {
/* 641 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public V remove(Object key)
/*     */     {
/* 646 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     CharArrayMap<V>.EntrySet createEntrySet()
/*     */     {
/* 651 */       return new CharArrayMap.EntrySet(this, false, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public final class EntrySet extends AbstractSet<Map.Entry<Object, V>>
/*     */   {
/*     */     private final boolean allowModify;
/*     */ 
/*     */     private EntrySet(boolean allowModify)
/*     */     {
/* 507 */       this.allowModify = allowModify;
/*     */     }
/*     */ 
/*     */     public CharArrayMap<V>.EntryIterator iterator()
/*     */     {
/* 512 */       return new CharArrayMap.EntryIterator(CharArrayMap.this, this.allowModify, null);
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o)
/*     */     {
/* 518 */       if (!(o instanceof Map.Entry))
/* 519 */         return false;
/* 520 */       Map.Entry e = (Map.Entry)o;
/* 521 */       Object key = e.getKey();
/* 522 */       Object val = e.getValue();
/* 523 */       Object v = CharArrayMap.this.get(key);
/* 524 */       return v == null ? false : val == null ? true : v.equals(val);
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o)
/*     */     {
/* 529 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 534 */       return CharArrayMap.this.count;
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 539 */       if (!this.allowModify)
/* 540 */         throw new UnsupportedOperationException();
/* 541 */       CharArrayMap.this.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class MapEntry
/*     */     implements Map.Entry<Object, V>
/*     */   {
/*     */     private final int pos;
/*     */     private final boolean allowModify;
/*     */ 
/*     */     private MapEntry(int pos, boolean allowModify)
/*     */     {
/* 469 */       this.pos = pos;
/* 470 */       this.allowModify = allowModify;
/*     */     }
/*     */ 
/*     */     public Object getKey()
/*     */     {
/* 477 */       return CharArrayMap.this.keys[this.pos].clone();
/*     */     }
/*     */ 
/*     */     public V getValue()
/*     */     {
/* 482 */       return CharArrayMap.this.values[this.pos];
/*     */     }
/*     */ 
/*     */     public V setValue(V value)
/*     */     {
/* 487 */       if (!this.allowModify)
/* 488 */         throw new UnsupportedOperationException();
/* 489 */       Object old = CharArrayMap.this.values[this.pos];
/* 490 */       CharArrayMap.this.values[this.pos] = value;
/* 491 */       return old;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 496 */       return new StringBuilder().append(CharArrayMap.this.keys[this.pos]).append('=').append(CharArrayMap.this.values[this.pos] == CharArrayMap.this ? "(this Map)" : CharArrayMap.this.values[this.pos]).toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   public class EntryIterator
/*     */     implements Iterator<Map.Entry<Object, V>>
/*     */   {
/* 406 */     private int pos = -1;
/*     */     private int lastPos;
/*     */     private final boolean allowModify;
/*     */ 
/*     */     private EntryIterator(boolean allowModify)
/*     */     {
/* 411 */       this.allowModify = allowModify;
/* 412 */       goNext();
/*     */     }
/*     */ 
/*     */     private void goNext() {
/* 416 */       this.lastPos = this.pos;
/* 417 */       this.pos += 1;
/* 418 */       while ((this.pos < CharArrayMap.this.keys.length) && (CharArrayMap.this.keys[this.pos] == null)) this.pos += 1;
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/* 423 */       return this.pos < CharArrayMap.this.keys.length;
/*     */     }
/*     */ 
/*     */     public char[] nextKey()
/*     */     {
/* 428 */       goNext();
/* 429 */       return CharArrayMap.this.keys[this.lastPos];
/*     */     }
/*     */ 
/*     */     public String nextKeyString()
/*     */     {
/* 434 */       return new String(nextKey());
/*     */     }
/*     */ 
/*     */     public V currentValue()
/*     */     {
/* 439 */       return CharArrayMap.this.values[this.lastPos];
/*     */     }
/*     */ 
/*     */     public V setValue(V value)
/*     */     {
/* 444 */       if (!this.allowModify)
/* 445 */         throw new UnsupportedOperationException();
/* 446 */       Object old = CharArrayMap.this.values[this.lastPos];
/* 447 */       CharArrayMap.this.values[this.lastPos] = value;
/* 448 */       return old;
/*     */     }
/*     */ 
/*     */     public Map.Entry<Object, V> next()
/*     */     {
/* 454 */       goNext();
/* 455 */       return new CharArrayMap.MapEntry(CharArrayMap.this, this.lastPos, this.allowModify, null);
/*     */     }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 460 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.CharArrayMap
 * JD-Core Version:    0.6.2
 */