/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public abstract class StopwordAnalyzerBase extends Analyzer
/*     */ {
/*     */   protected final CharArraySet stopwords;
/*     */   protected final Version matchVersion;
/*     */ 
/*     */   public CharArraySet getStopwordSet()
/*     */   {
/*  50 */     return this.stopwords;
/*     */   }
/*     */ 
/*     */   protected StopwordAnalyzerBase(Version version, CharArraySet stopwords)
/*     */   {
/*  62 */     this.matchVersion = version;
/*     */ 
/*  64 */     this.stopwords = (stopwords == null ? CharArraySet.EMPTY_SET : CharArraySet.unmodifiableSet(CharArraySet.copy(version, stopwords)));
/*     */   }
/*     */ 
/*     */   protected StopwordAnalyzerBase(Version version)
/*     */   {
/*  75 */     this(version, null);
/*     */   }
/*     */ 
/*     */   protected static CharArraySet loadStopwordSet(boolean ignoreCase, Class<? extends Analyzer> aClass, String resource, String comment)
/*     */     throws IOException
/*     */   {
/*  99 */     Reader reader = null;
/*     */     try {
/* 101 */       reader = IOUtils.getDecodingReader(aClass.getResourceAsStream(resource), StandardCharsets.UTF_8);
/* 102 */       return WordlistLoader.getWordSet(reader, comment, new CharArraySet(Version.LUCENE_CURRENT, 16, ignoreCase));
/*     */     } finally {
/* 104 */       IOUtils.close(new Closeable[] { reader });
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static CharArraySet loadStopwordSet(File stopwords, Version matchVersion)
/*     */     throws IOException
/*     */   {
/* 124 */     Reader reader = null;
/*     */     try {
/* 126 */       reader = IOUtils.getDecodingReader(stopwords, StandardCharsets.UTF_8);
/* 127 */       return WordlistLoader.getWordSet(reader, matchVersion);
/*     */     } finally {
/* 129 */       IOUtils.close(new Closeable[] { reader });
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static CharArraySet loadStopwordSet(Reader stopwords, Version matchVersion)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 149 */       return WordlistLoader.getWordSet(stopwords, matchVersion);
/*     */     } finally {
/* 151 */       IOUtils.close(new Closeable[] { stopwords });
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.StopwordAnalyzerBase
 * JD-Core Version:    0.6.2
 */