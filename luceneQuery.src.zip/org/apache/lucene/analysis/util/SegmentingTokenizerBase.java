/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.text.BreakIterator;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ public abstract class SegmentingTokenizerBase extends Tokenizer
/*     */ {
/*     */   protected static final int BUFFERMAX = 1024;
/*  43 */   protected final char[] buffer = new char[1024];
/*     */ 
/*  45 */   private int length = 0;
/*     */ 
/*  47 */   private int usableLength = 0;
/*     */ 
/*  49 */   protected int offset = 0;
/*     */   private final BreakIterator iterator;
/*  52 */   private final CharArrayIterator wrapper = CharArrayIterator.newSentenceInstance();
/*     */ 
/*  54 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */ 
/*     */   public SegmentingTokenizerBase(Reader reader, BreakIterator iterator)
/*     */   {
/*  65 */     this(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY, reader, iterator);
/*     */   }
/*     */ 
/*     */   public SegmentingTokenizerBase(AttributeSource.AttributeFactory factory, Reader reader, BreakIterator iterator)
/*     */   {
/*  72 */     super(factory, reader);
/*  73 */     this.iterator = iterator;
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken() throws IOException
/*     */   {
/*  78 */     if ((this.length == 0) || (!incrementWord())) {
/*  79 */       while (!incrementSentence()) {
/*  80 */         refill();
/*  81 */         if (this.length <= 0) {
/*  82 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/*  91 */     super.reset();
/*  92 */     this.wrapper.setText(this.buffer, 0, 0);
/*  93 */     this.iterator.setText(this.wrapper);
/*  94 */     this.length = (this.usableLength = this.offset = 0);
/*     */   }
/*     */ 
/*     */   public final void end() throws IOException
/*     */   {
/*  99 */     super.end();
/* 100 */     int finalOffset = correctOffset(this.length < 0 ? this.offset : this.offset + this.length);
/* 101 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */   }
/*     */ 
/*     */   private int findSafeEnd()
/*     */   {
/* 106 */     for (int i = this.length - 1; i >= 0; i--)
/* 107 */       if (isSafeEnd(this.buffer[i]))
/* 108 */         return i + 1;
/* 109 */     return -1;
/*     */   }
/*     */ 
/*     */   protected boolean isSafeEnd(char ch)
/*     */   {
/* 114 */     switch (ch) {
/*     */     case '\n':
/*     */     case '\r':
/*     */     case '':
/*     */     case ' ':
/*     */     case ' ':
/* 120 */       return true;
/*     */     }
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */   private void refill()
/*     */     throws IOException
/*     */   {
/* 131 */     this.offset += this.usableLength;
/* 132 */     int leftover = this.length - this.usableLength;
/* 133 */     System.arraycopy(this.buffer, this.usableLength, this.buffer, 0, leftover);
/* 134 */     int requested = this.buffer.length - leftover;
/* 135 */     int returned = read(this.input, this.buffer, leftover, requested);
/* 136 */     this.length = (returned < 0 ? leftover : returned + leftover);
/* 137 */     if (returned < requested) {
/* 138 */       this.usableLength = this.length;
/*     */     } else {
/* 140 */       this.usableLength = findSafeEnd();
/* 141 */       if (this.usableLength < 0) {
/* 142 */         this.usableLength = this.length;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 148 */     this.wrapper.setText(this.buffer, 0, Math.max(0, this.usableLength));
/* 149 */     this.iterator.setText(this.wrapper);
/*     */   }
/*     */ 
/*     */   private static int read(Reader input, char[] buffer, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 156 */     assert (length >= 0) : ("length must not be negative: " + length);
/*     */ 
/* 158 */     int remaining = length;
/* 159 */     while (remaining > 0) {
/* 160 */       int location = length - remaining;
/* 161 */       int count = input.read(buffer, offset + location, remaining);
/* 162 */       if (-1 == count) {
/*     */         break;
/*     */       }
/* 165 */       remaining -= count;
/*     */     }
/* 167 */     return length - remaining;
/*     */   }
/*     */ 
/*     */   private boolean incrementSentence()
/*     */     throws IOException
/*     */   {
/* 175 */     if (this.length == 0)
/* 176 */       return false;
/*     */     while (true)
/*     */     {
/* 179 */       int start = this.iterator.current();
/*     */ 
/* 181 */       if (start == -1) {
/* 182 */         return false;
/*     */       }
/*     */ 
/* 185 */       int end = this.iterator.next();
/*     */ 
/* 187 */       if (end == -1) {
/* 188 */         return false;
/*     */       }
/* 190 */       setNextSentence(start, end);
/* 191 */       if (incrementWord())
/* 192 */         return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void setNextSentence(int paramInt1, int paramInt2);
/*     */ 
/*     */   protected abstract boolean incrementWord();
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.SegmentingTokenizerBase
 * JD-Core Version:    0.6.2
 */