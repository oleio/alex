/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public abstract class FilteringTokenFilter extends TokenFilter
/*     */ {
/*     */   protected final Version version;
/*  45 */   private final PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*     */   private boolean enablePositionIncrements;
/*  47 */   private boolean first = true;
/*     */   private int skippedPositions;
/*     */ 
/*     */   private static void checkPositionIncrement(Version version, boolean enablePositionIncrements)
/*     */   {
/*  39 */     if ((!enablePositionIncrements) && (version.onOrAfter(Version.LUCENE_44)))
/*  40 */       throw new IllegalArgumentException("enablePositionIncrements=false is not supported anymore as of Lucene 4.4 as it can create broken token streams");
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public FilteringTokenFilter(Version version, boolean enablePositionIncrements, TokenStream input)
/*     */   {
/*  59 */     this(version, input);
/*  60 */     checkPositionIncrement(version, enablePositionIncrements);
/*  61 */     this.enablePositionIncrements = enablePositionIncrements;
/*     */   }
/*     */ 
/*     */   public FilteringTokenFilter(Version version, TokenStream in)
/*     */   {
/*  70 */     super(in);
/*  71 */     this.version = version;
/*  72 */     this.enablePositionIncrements = true;
/*     */   }
/*     */ 
/*     */   protected abstract boolean accept()
/*     */     throws IOException;
/*     */ 
/*     */   public final boolean incrementToken() throws IOException
/*     */   {
/*  80 */     if (this.enablePositionIncrements) {
/*  81 */       this.skippedPositions = 0;
/*  82 */       while (this.input.incrementToken()) {
/*  83 */         if (accept()) {
/*  84 */           if (this.skippedPositions != 0) {
/*  85 */             this.posIncrAtt.setPositionIncrement(this.posIncrAtt.getPositionIncrement() + this.skippedPositions);
/*     */           }
/*  87 */           return true;
/*     */         }
/*  89 */         this.skippedPositions += this.posIncrAtt.getPositionIncrement();
/*     */       }
/*     */     }
/*  92 */     while (this.input.incrementToken()) {
/*  93 */       if (accept()) {
/*  94 */         if (this.first)
/*     */         {
/*  96 */           if (this.posIncrAtt.getPositionIncrement() == 0) {
/*  97 */             this.posIncrAtt.setPositionIncrement(1);
/*     */           }
/*  99 */           this.first = false;
/*     */         }
/* 101 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 111 */     super.reset();
/* 112 */     this.first = true;
/* 113 */     this.skippedPositions = 0;
/*     */   }
/*     */ 
/*     */   public boolean getEnablePositionIncrements()
/*     */   {
/* 120 */     return this.enablePositionIncrements;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setEnablePositionIncrements(boolean enable)
/*     */   {
/* 142 */     checkPositionIncrement(this.version, enable);
/* 143 */     this.enablePositionIncrements = enable;
/*     */   }
/*     */ 
/*     */   public void end() throws IOException
/*     */   {
/* 148 */     super.end();
/* 149 */     if (this.enablePositionIncrements)
/* 150 */       this.posIncrAtt.setPositionIncrement(this.posIncrAtt.getPositionIncrement() + this.skippedPositions);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.FilteringTokenFilter
 * JD-Core Version:    0.6.2
 */