/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public abstract class CharTokenizer extends Tokenizer
/*     */ {
/*  97 */   private int offset = 0; private int bufferIndex = 0; private int dataLen = 0; private int finalOffset = 0;
/*     */   private static final int MAX_WORD_LEN = 255;
/*     */   private static final int IO_BUFFER_SIZE = 4096;
/* 101 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 102 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */   private final CharacterUtils charUtils;
/* 105 */   private final CharacterUtils.CharacterBuffer ioBuffer = CharacterUtils.newCharacterBuffer(4096);
/*     */ 
/*     */   public CharTokenizer(Version matchVersion, Reader input)
/*     */   {
/*  77 */     super(input);
/*  78 */     this.charUtils = CharacterUtils.getInstance(matchVersion);
/*     */   }
/*     */ 
/*     */   public CharTokenizer(Version matchVersion, AttributeSource.AttributeFactory factory, Reader input)
/*     */   {
/*  93 */     super(factory, input);
/*  94 */     this.charUtils = CharacterUtils.getInstance(matchVersion);
/*     */   }
/*     */ 
/*     */   protected abstract boolean isTokenChar(int paramInt);
/*     */ 
/*     */   protected int normalize(int c)
/*     */   {
/* 121 */     return c;
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken() throws IOException
/*     */   {
/* 126 */     clearAttributes();
/* 127 */     int length = 0;
/* 128 */     int start = -1;
/* 129 */     int end = -1;
/* 130 */     char[] buffer = this.termAtt.buffer();
/*     */     while (true)
/* 132 */       if (this.bufferIndex >= this.dataLen) {
/* 133 */         this.offset += this.dataLen;
/* 134 */         this.charUtils.fill(this.ioBuffer, this.input);
/* 135 */         if (this.ioBuffer.getLength() == 0) {
/* 136 */           this.dataLen = 0;
/* 137 */           if (length <= 0)
/*     */           {
/* 140 */             this.finalOffset = correctOffset(this.offset);
/* 141 */             return false;
/*     */           }
/*     */         } else {
/* 144 */           this.dataLen = this.ioBuffer.getLength();
/* 145 */           this.bufferIndex = 0;
/*     */         }
/*     */       } else {
/* 148 */         int c = this.charUtils.codePointAt(this.ioBuffer.getBuffer(), this.bufferIndex, this.ioBuffer.getLength());
/* 149 */         int charCount = Character.charCount(c);
/* 150 */         this.bufferIndex += charCount;
/*     */ 
/* 152 */         if (isTokenChar(c)) {
/* 153 */           if (length == 0) {
/* 154 */             assert (start == -1);
/* 155 */             start = this.offset + this.bufferIndex - charCount;
/* 156 */             end = start;
/* 157 */           } else if (length >= buffer.length - 1) {
/* 158 */             buffer = this.termAtt.resizeBuffer(2 + length);
/*     */           }
/* 160 */           end += charCount;
/* 161 */           length += Character.toChars(normalize(c), buffer, length);
/* 162 */           if (length >= 255)
/* 163 */             break; 
/*     */         } else { if (length > 0)
/*     */             break;
/*     */         }
/*     */       }
/* 168 */     this.termAtt.setLength(length);
/* 169 */     assert (start != -1);
/* 170 */     this.offsetAtt.setOffset(correctOffset(start), this.finalOffset = correctOffset(end));
/* 171 */     return true;
/*     */   }
/*     */ 
/*     */   public final void end()
/*     */     throws IOException
/*     */   {
/* 177 */     super.end();
/*     */ 
/* 179 */     this.offsetAtt.setOffset(this.finalOffset, this.finalOffset);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 184 */     super.reset();
/* 185 */     this.bufferIndex = 0;
/* 186 */     this.offset = 0;
/* 187 */     this.dataLen = 0;
/* 188 */     this.finalOffset = 0;
/* 189 */     this.ioBuffer.reset();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.CharTokenizer
 * JD-Core Version:    0.6.2
 */