/*    */ package org.apache.lucene.analysis.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.fr.FrenchAnalyzer;
/*    */ 
/*    */ public class ElisionFilterFactory extends TokenFilterFactory
/*    */   implements ResourceLoaderAware, MultiTermAwareComponent
/*    */ {
/*    */   private final String articlesFile;
/*    */   private final boolean ignoreCase;
/*    */   private CharArraySet articles;
/*    */ 
/*    */   public ElisionFilterFactory(Map<String, String> args)
/*    */   {
/* 45 */     super(args);
/* 46 */     this.articlesFile = get(args, "articles");
/* 47 */     this.ignoreCase = getBoolean(args, "ignoreCase", false);
/* 48 */     if (!args.isEmpty())
/* 49 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public void inform(ResourceLoader loader)
/*    */     throws IOException
/*    */   {
/* 55 */     if (this.articlesFile == null)
/* 56 */       this.articles = FrenchAnalyzer.DEFAULT_ARTICLES;
/*    */     else
/* 58 */       this.articles = getWordSet(loader, this.articlesFile, this.ignoreCase);
/*    */   }
/*    */ 
/*    */   public ElisionFilter create(TokenStream input)
/*    */   {
/* 64 */     return new ElisionFilter(input, this.articles);
/*    */   }
/*    */ 
/*    */   public AbstractAnalysisFactory getMultiTermComponent()
/*    */   {
/* 69 */     return this;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.ElisionFilterFactory
 * JD-Core Version:    0.6.2
 */