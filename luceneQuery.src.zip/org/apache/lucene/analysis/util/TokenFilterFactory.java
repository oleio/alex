/*    */ package org.apache.lucene.analysis.util;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ 
/*    */ public abstract class TokenFilterFactory extends AbstractAnalysisFactory
/*    */ {
/* 31 */   private static final AnalysisSPILoader<TokenFilterFactory> loader = new AnalysisSPILoader(TokenFilterFactory.class, new String[] { "TokenFilterFactory", "FilterFactory" });
/*    */ 
/*    */   public static TokenFilterFactory forName(String name, Map<String, String> args)
/*    */   {
/* 37 */     return (TokenFilterFactory)loader.newInstance(name, args);
/*    */   }
/*    */ 
/*    */   public static Class<? extends TokenFilterFactory> lookupClass(String name)
/*    */   {
/* 42 */     return loader.lookupClass(name);
/*    */   }
/*    */ 
/*    */   public static Set<String> availableTokenFilters()
/*    */   {
/* 47 */     return loader.availableServices();
/*    */   }
/*    */ 
/*    */   public static void reloadTokenFilters(ClassLoader classloader)
/*    */   {
/* 62 */     loader.reload(classloader);
/*    */   }
/*    */ 
/*    */   protected TokenFilterFactory(Map<String, String> args)
/*    */   {
/* 69 */     super(args);
/*    */   }
/*    */ 
/*    */   public abstract TokenStream create(TokenStream paramTokenStream);
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.TokenFilterFactory
 * JD-Core Version:    0.6.2
 */