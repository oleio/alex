/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public class WordlistLoader
/*     */ {
/*     */   private static final int INITIAL_CAPACITY = 16;
/*     */ 
/*     */   public static CharArraySet getWordSet(Reader reader, CharArraySet result)
/*     */     throws IOException
/*     */   {
/*  55 */     BufferedReader br = null;
/*     */     try {
/*  57 */       br = getBufferedReader(reader);
/*  58 */       String word = null;
/*  59 */       while ((word = br.readLine()) != null)
/*  60 */         result.add(word.trim());
/*     */     }
/*     */     finally
/*     */     {
/*  64 */       IOUtils.close(new Closeable[] { br });
/*     */     }
/*  66 */     return result;
/*     */   }
/*     */ 
/*     */   public static CharArraySet getWordSet(Reader reader, Version matchVersion)
/*     */     throws IOException
/*     */   {
/*  80 */     return getWordSet(reader, new CharArraySet(matchVersion, 16, false));
/*     */   }
/*     */ 
/*     */   public static CharArraySet getWordSet(Reader reader, String comment, Version matchVersion)
/*     */     throws IOException
/*     */   {
/*  95 */     return getWordSet(reader, comment, new CharArraySet(matchVersion, 16, false));
/*     */   }
/*     */ 
/*     */   public static CharArraySet getWordSet(Reader reader, String comment, CharArraySet result)
/*     */     throws IOException
/*     */   {
/* 110 */     BufferedReader br = null;
/*     */     try {
/* 112 */       br = getBufferedReader(reader);
/* 113 */       String word = null;
/* 114 */       while ((word = br.readLine()) != null) {
/* 115 */         if (!word.startsWith(comment))
/* 116 */           result.add(word.trim());
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 121 */       IOUtils.close(new Closeable[] { br });
/*     */     }
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */   public static CharArraySet getSnowballWordSet(Reader reader, CharArraySet result)
/*     */     throws IOException
/*     */   {
/* 144 */     BufferedReader br = null;
/*     */     try {
/* 146 */       br = getBufferedReader(reader);
/* 147 */       String line = null;
/* 148 */       while ((line = br.readLine()) != null) {
/* 149 */         int comment = line.indexOf('|');
/* 150 */         if (comment >= 0) line = line.substring(0, comment);
/* 151 */         String[] words = line.split("\\s+");
/* 152 */         for (int i = 0; i < words.length; i++)
/* 153 */           if (words[i].length() > 0) result.add(words[i]); 
/*     */       }
/*     */     }
/* 156 */     finally { IOUtils.close(new Closeable[] { br }); }
/*     */ 
/* 158 */     return result;
/*     */   }
/*     */ 
/*     */   public static CharArraySet getSnowballWordSet(Reader reader, Version matchVersion)
/*     */     throws IOException
/*     */   {
/* 177 */     return getSnowballWordSet(reader, new CharArraySet(matchVersion, 16, false));
/*     */   }
/*     */ 
/*     */   public static CharArrayMap<String> getStemDict(Reader reader, CharArrayMap<String> result)
/*     */     throws IOException
/*     */   {
/* 190 */     BufferedReader br = null;
/*     */     try {
/* 192 */       br = getBufferedReader(reader);
/*     */       String line;
/* 194 */       while ((line = br.readLine()) != null) {
/* 195 */         String[] wordstem = line.split("\t", 2);
/* 196 */         result.put(wordstem[0], wordstem[1]);
/*     */       }
/*     */     } finally {
/* 199 */       IOUtils.close(new Closeable[] { br });
/*     */     }
/* 201 */     return result;
/*     */   }
/*     */ 
/*     */   public static List<String> getLines(InputStream stream, Charset charset)
/*     */     throws IOException
/*     */   {
/* 216 */     BufferedReader input = null;
/*     */ 
/* 218 */     boolean success = false;
/*     */     try {
/* 220 */       input = getBufferedReader(IOUtils.getDecodingReader(stream, charset));
/*     */ 
/* 222 */       ArrayList lines = new ArrayList();
/* 223 */       for (String word = null; (word = input.readLine()) != null; )
/*     */       {
/* 225 */         if ((lines.isEmpty()) && (word.length() > 0) && (word.charAt(0) == 65279)) {
/* 226 */           word = word.substring(1);
/*     */         }
/* 228 */         if (!word.startsWith("#")) {
/* 229 */           word = word.trim();
/*     */ 
/* 231 */           if (word.length() != 0)
/* 232 */             lines.add(word); 
/*     */         }
/*     */       }
/* 234 */       success = true;
/* 235 */       return lines;
/*     */     } finally {
/* 237 */       if (success)
/* 238 */         IOUtils.close(new Closeable[] { input });
/*     */       else
/* 240 */         IOUtils.closeWhileHandlingException(new Closeable[] { input });
/*     */     }
/*     */   }
/*     */ 
/*     */   private static BufferedReader getBufferedReader(Reader reader)
/*     */   {
/* 246 */     return (reader instanceof BufferedReader) ? (BufferedReader)reader : new BufferedReader(reader);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.util.WordlistLoader
 * JD-Core Version:    0.6.2
 */