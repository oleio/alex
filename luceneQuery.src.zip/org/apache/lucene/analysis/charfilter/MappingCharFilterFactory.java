/*     */ package org.apache.lucene.analysis.charfilter;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.lucene.analysis.util.AbstractAnalysisFactory;
/*     */ import org.apache.lucene.analysis.util.CharFilterFactory;
/*     */ import org.apache.lucene.analysis.util.MultiTermAwareComponent;
/*     */ import org.apache.lucene.analysis.util.ResourceLoader;
/*     */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*     */ 
/*     */ public class MappingCharFilterFactory extends CharFilterFactory
/*     */   implements ResourceLoaderAware, MultiTermAwareComponent
/*     */ {
/*     */   protected NormalizeCharMap normMap;
/*     */   private final String mapping;
/*  97 */   static Pattern p = Pattern.compile("\"(.*)\"\\s*=>\\s*\"(.*)\"\\s*$");
/*     */ 
/* 108 */   char[] out = new char[256];
/*     */ 
/*     */   public MappingCharFilterFactory(Map<String, String> args)
/*     */   {
/*  55 */     super(args);
/*  56 */     this.mapping = get(args, "mapping");
/*  57 */     if (!args.isEmpty())
/*  58 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*     */   }
/*     */ 
/*     */   public void inform(ResourceLoader loader)
/*     */     throws IOException
/*     */   {
/*  65 */     if (this.mapping != null) {
/*  66 */       List wlist = null;
/*  67 */       File mappingFile = new File(this.mapping);
/*  68 */       if (mappingFile.exists()) {
/*  69 */         wlist = getLines(loader, this.mapping);
/*     */       } else {
/*  71 */         List files = splitFileNames(this.mapping);
/*  72 */         wlist = new ArrayList();
/*  73 */         for (String file : files) {
/*  74 */           List lines = getLines(loader, file.trim());
/*  75 */           wlist.addAll(lines);
/*     */         }
/*     */       }
/*  78 */       NormalizeCharMap.Builder builder = new NormalizeCharMap.Builder();
/*  79 */       parseRules(wlist, builder);
/*  80 */       this.normMap = builder.build();
/*  81 */       if (this.normMap.map == null)
/*     */       {
/*  84 */         this.normMap = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Reader create(Reader input)
/*     */   {
/*  93 */     return this.normMap == null ? input : new MappingCharFilter(this.normMap, input);
/*     */   }
/*     */ 
/*     */   protected void parseRules(List<String> rules, NormalizeCharMap.Builder builder)
/*     */   {
/* 100 */     for (String rule : rules) {
/* 101 */       Matcher m = p.matcher(rule);
/* 102 */       if (!m.find())
/* 103 */         throw new IllegalArgumentException("Invalid Mapping Rule : [" + rule + "], file = " + this.mapping);
/* 104 */       builder.add(parseString(m.group(1)), parseString(m.group(2)));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String parseString(String s)
/*     */   {
/* 111 */     int readPos = 0;
/* 112 */     int len = s.length();
/* 113 */     int writePos = 0;
/* 114 */     while (readPos < len) {
/* 115 */       char c = s.charAt(readPos++);
/* 116 */       if (c == '\\') {
/* 117 */         if (readPos >= len)
/* 118 */           throw new IllegalArgumentException("Invalid escaped char in [" + s + "]");
/* 119 */         c = s.charAt(readPos++);
/* 120 */         switch (c) { case '\\':
/* 121 */           c = '\\'; break;
/*     */         case '"':
/* 122 */           c = '"'; break;
/*     */         case 'n':
/* 123 */           c = '\n'; break;
/*     */         case 't':
/* 124 */           c = '\t'; break;
/*     */         case 'r':
/* 125 */           c = '\r'; break;
/*     */         case 'b':
/* 126 */           c = '\b'; break;
/*     */         case 'f':
/* 127 */           c = '\f'; break;
/*     */         case 'u':
/* 129 */           if (readPos + 3 >= len)
/* 130 */             throw new IllegalArgumentException("Invalid escaped char in [" + s + "]");
/* 131 */           c = (char)Integer.parseInt(s.substring(readPos, readPos + 4), 16);
/* 132 */           readPos += 4;
/*     */         }
/*     */       }
/*     */ 
/* 136 */       this.out[(writePos++)] = c;
/*     */     }
/* 138 */     return new String(this.out, 0, writePos);
/*     */   }
/*     */ 
/*     */   public AbstractAnalysisFactory getMultiTermComponent()
/*     */   {
/* 143 */     return this;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.charfilter.MappingCharFilterFactory
 * JD-Core Version:    0.6.2
 */