/*     */ package org.apache.lucene.analysis.charfilter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.lucene.util.CharsRef;
/*     */ import org.apache.lucene.util.IntsRef;
/*     */ import org.apache.lucene.util.fst.Builder;
/*     */ import org.apache.lucene.util.fst.CharSequenceOutputs;
/*     */ import org.apache.lucene.util.fst.FST;
/*     */ import org.apache.lucene.util.fst.FST.Arc;
/*     */ import org.apache.lucene.util.fst.FST.BytesReader;
/*     */ import org.apache.lucene.util.fst.FST.INPUT_TYPE;
/*     */ import org.apache.lucene.util.fst.Outputs;
/*     */ import org.apache.lucene.util.fst.Util;
/*     */ 
/*     */ public class NormalizeCharMap
/*     */ {
/*     */   final FST<CharsRef> map;
/*  43 */   final Map<Character, FST.Arc<CharsRef>> cachedRootArcs = new HashMap();
/*     */ 
/*     */   private NormalizeCharMap(FST<CharsRef> map)
/*     */   {
/*  47 */     this.map = map;
/*  48 */     if (map != null)
/*     */       try
/*     */       {
/*  51 */         FST.Arc scratchArc = new FST.Arc();
/*  52 */         FST.BytesReader fstReader = map.getBytesReader();
/*  53 */         map.getFirstArc(scratchArc);
/*  54 */         if (FST.targetHasArcs(scratchArc)) {
/*  55 */           map.readFirstRealTargetArc(scratchArc.target, scratchArc, fstReader);
/*     */           while (true) {
/*  57 */             assert (scratchArc.label != -1);
/*  58 */             this.cachedRootArcs.put(Character.valueOf((char)scratchArc.label), new FST.Arc().copyFrom(scratchArc));
/*  59 */             if (scratchArc.isLast()) {
/*     */               break;
/*     */             }
/*  62 */             map.readNextRealArc(scratchArc, fstReader);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IOException ioe)
/*     */       {
/*  68 */         throw new RuntimeException(ioe);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static class Builder
/*     */   {
/*  81 */     private final Map<String, String> pendingPairs = new TreeMap();
/*     */ 
/*     */     public void add(String match, String replacement)
/*     */     {
/*  95 */       if (match.length() == 0) {
/*  96 */         throw new IllegalArgumentException("cannot match the empty string");
/*     */       }
/*  98 */       if (this.pendingPairs.containsKey(match)) {
/*  99 */         throw new IllegalArgumentException("match \"" + match + "\" was already added");
/*     */       }
/* 101 */       this.pendingPairs.put(match, replacement);
/*     */     }
/*     */ 
/*     */     public NormalizeCharMap build()
/*     */     {
/*     */       FST map;
/*     */       try
/*     */       {
/* 110 */         Outputs outputs = CharSequenceOutputs.getSingleton();
/* 111 */         Builder builder = new Builder(FST.INPUT_TYPE.BYTE2, outputs);
/* 112 */         IntsRef scratch = new IntsRef();
/* 113 */         for (Map.Entry ent : this.pendingPairs.entrySet()) {
/* 114 */           builder.add(Util.toUTF16((CharSequence)ent.getKey(), scratch), new CharsRef((String)ent.getValue()));
/*     */         }
/*     */ 
/* 117 */         map = builder.finish();
/* 118 */         this.pendingPairs.clear();
/*     */       }
/*     */       catch (IOException ioe) {
/* 121 */         throw new RuntimeException(ioe);
/*     */       }
/*     */ 
/* 124 */       return new NormalizeCharMap(map, null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.charfilter.NormalizeCharMap
 * JD-Core Version:    0.6.2
 */