/*    */ package org.apache.lucene.analysis.ru;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ @Deprecated
/*    */ public class RussianLetterTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   public RussianLetterTokenizerFactory(Map<String, String> args)
/*    */   {
/* 34 */     super(args);
/* 35 */     assureMatchVersion();
/* 36 */     if (!args.isEmpty())
/* 37 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public RussianLetterTokenizer create(AttributeSource.AttributeFactory factory, Reader in)
/*    */   {
/* 43 */     return new RussianLetterTokenizer(this.luceneMatchVersion, factory, in);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.ru.RussianLetterTokenizerFactory
 * JD-Core Version:    0.6.2
 */