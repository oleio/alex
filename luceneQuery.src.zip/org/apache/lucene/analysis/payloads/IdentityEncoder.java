/*    */ package org.apache.lucene.analysis.payloads;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.CharBuffer;
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import org.apache.lucene.util.BytesRef;
/*    */ 
/*    */ public class IdentityEncoder extends AbstractEncoder
/*    */   implements PayloadEncoder
/*    */ {
/* 32 */   protected Charset charset = StandardCharsets.UTF_8;
/*    */ 
/*    */   public IdentityEncoder() {
/*    */   }
/*    */ 
/*    */   public IdentityEncoder(Charset charset) {
/* 38 */     this.charset = charset;
/*    */   }
/*    */ 
/*    */   public BytesRef encode(char[] buffer, int offset, int length)
/*    */   {
/* 43 */     ByteBuffer bb = this.charset.encode(CharBuffer.wrap(buffer, offset, length));
/* 44 */     if (bb.hasArray()) {
/* 45 */       return new BytesRef(bb.array(), bb.arrayOffset() + bb.position(), bb.remaining());
/*    */     }
/*    */ 
/* 48 */     byte[] b = new byte[bb.remaining()];
/* 49 */     bb.get(b);
/* 50 */     return new BytesRef(b);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.payloads.IdentityEncoder
 * JD-Core Version:    0.6.2
 */