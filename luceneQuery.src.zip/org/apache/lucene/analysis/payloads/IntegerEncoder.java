/*    */ package org.apache.lucene.analysis.payloads;
/*    */ 
/*    */ import org.apache.lucene.util.ArrayUtil;
/*    */ import org.apache.lucene.util.BytesRef;
/*    */ 
/*    */ public class IntegerEncoder extends AbstractEncoder
/*    */   implements PayloadEncoder
/*    */ {
/*    */   public BytesRef encode(char[] buffer, int offset, int length)
/*    */   {
/* 33 */     int payload = ArrayUtil.parseInt(buffer, offset, length);
/* 34 */     byte[] bytes = PayloadHelper.encodeInt(payload);
/* 35 */     BytesRef result = new BytesRef(bytes);
/* 36 */     return result;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.payloads.IntegerEncoder
 * JD-Core Version:    0.6.2
 */