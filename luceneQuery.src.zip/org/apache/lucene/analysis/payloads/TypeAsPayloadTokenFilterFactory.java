/*    */ package org.apache.lucene.analysis.payloads;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class TypeAsPayloadTokenFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public TypeAsPayloadTokenFilterFactory(Map<String, String> args)
/*    */   {
/* 40 */     super(args);
/* 41 */     if (!args.isEmpty())
/* 42 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TypeAsPayloadTokenFilter create(TokenStream input)
/*    */   {
/* 48 */     return new TypeAsPayloadTokenFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.payloads.TypeAsPayloadTokenFilterFactory
 * JD-Core Version:    0.6.2
 */