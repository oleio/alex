/*    */ package org.apache.lucene.analysis.payloads;
/*    */ 
/*    */ import org.apache.lucene.util.BytesRef;
/*    */ 
/*    */ public class FloatEncoder extends AbstractEncoder
/*    */   implements PayloadEncoder
/*    */ {
/*    */   public BytesRef encode(char[] buffer, int offset, int length)
/*    */   {
/* 32 */     float payload = Float.parseFloat(new String(buffer, offset, length));
/* 33 */     byte[] bytes = PayloadHelper.encodeFloat(payload);
/* 34 */     BytesRef result = new BytesRef(bytes);
/* 35 */     return result;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.payloads.FloatEncoder
 * JD-Core Version:    0.6.2
 */