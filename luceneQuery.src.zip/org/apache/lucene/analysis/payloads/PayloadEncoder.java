package org.apache.lucene.analysis.payloads;

import org.apache.lucene.util.BytesRef;

public abstract interface PayloadEncoder
{
  public abstract BytesRef encode(char[] paramArrayOfChar);

  public abstract BytesRef encode(char[] paramArrayOfChar, int paramInt1, int paramInt2);
}

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.payloads.PayloadEncoder
 * JD-Core Version:    0.6.2
 */