/*     */ package org.apache.lucene.analysis.th;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopAnalyzer;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class ThaiAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*     */   private static final String STOPWORDS_COMMENT = "#";
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  59 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public ThaiAnalyzer(Version matchVersion)
/*     */   {
/*  87 */     this(matchVersion, matchVersion.onOrAfter(Version.LUCENE_36) ? DefaultSetHolder.DEFAULT_STOP_SET : StopAnalyzer.ENGLISH_STOP_WORDS_SET);
/*     */   }
/*     */ 
/*     */   public ThaiAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/*  97 */     super(matchVersion, stopwords);
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 113 */     if (this.matchVersion.onOrAfter(Version.LUCENE_48)) {
/* 114 */       Tokenizer source = new ThaiTokenizer(reader);
/* 115 */       TokenStream result = new LowerCaseFilter(this.matchVersion, source);
/* 116 */       result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 117 */       return new Analyzer.TokenStreamComponents(source, result);
/*     */     }
/* 119 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 120 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/* 121 */     if (this.matchVersion.onOrAfter(Version.LUCENE_31))
/* 122 */       result = new LowerCaseFilter(this.matchVersion, result);
/* 123 */     result = new ThaiWordFilter(this.matchVersion, result);
/* 124 */     return new Analyzer.TokenStreamComponents(source, new StopFilter(this.matchVersion, result, this.stopwords));
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  71 */         DEFAULT_STOP_SET = ThaiAnalyzer.loadStopwordSet(false, ThaiAnalyzer.class, "stopwords.txt", "#");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  76 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.th.ThaiAnalyzer
 * JD-Core Version:    0.6.2
 */