/*     */ package org.apache.lucene.analysis.el;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public class GreekStemmer
/*     */ {
/* 208 */   private static final CharArraySet exc4 = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "θ", "δ", "ελ", "γαλ", "ν", "π", "ιδ", "παρ" }), false);
/*     */ 
/* 234 */   private static final CharArraySet exc6 = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "αλ", "αδ", "ενδ", "αμαν", "αμμοχαλ", "ηθ", "ανηθ", "αντιδ", "φυσ", "βρωμ", "γερ", "εξωδ", "καλπ", "καλλιν", "καταδ", "μουλ", "μπαν", "μπαγιατ", "μπολ", "μποσ", "νιτ", "ξικ", "συνομηλ", "πετσ", "πιτσ", "πικαντ", "πλιατσ", "ποστελν", "πρωτοδ", "σερτ", "συναδ", "τσαμ", "υποδ", "φιλον", "φυλοδ", "χασ" }), false);
/*     */ 
/* 259 */   private static final CharArraySet exc7 = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "αναπ", "αποθ", "αποκ", "αποστ", "βουβ", "ξεθ", "ουλ", "πεθ", "πικρ", "ποτ", "σιχ", "χ" }), false);
/*     */ 
/* 286 */   private static final CharArraySet exc8a = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "τρ", "τσ" }), false);
/*     */ 
/* 290 */   private static final CharArraySet exc8b = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "βετερ", "βουλκ", "βραχμ", "γ", "δραδουμ", "θ", "καλπουζ", "καστελ", "κορμορ", "λαοπλ", "μωαμεθ", "μ", "μουσουλμ", "ν", "ουλ", "π", "πελεκ", "πλ", "πολισ", "πορτολ", "σαρακατσ", "σουλτ", "τσαρλατ", "ορφ", "τσιγγ", "τσοπ", "φωτοστεφ", "χ", "ψυχοπλ", "αγ", "ορφ", "γαλ", "γερ", "δεκ", "διπλ", "αμερικαν", "ουρ", "πιθ", "πουριτ", "σ", "ζωντ", "ικ", "καστ", "κοπ", "λιχ", "λουθηρ", "μαιντ", "μελ", "σιγ", "σπ", "στεγ", "τραγ", "τσαγ", "φ", "ερ", "αδαπ", "αθιγγ", "αμηχ", "ανικ", "ανοργ", "απηγ", "απιθ", "ατσιγγ", "βασ", "βασκ", "βαθυγαλ", "βιομηχ", "βραχυκ", "διατ", "διαφ", "ενοργ", "θυσ", "καπνοβιομηχ", "καταγαλ", "κλιβ", "κοιλαρφ", "λιβ", "μεγλοβιομηχ", "μικροβιομηχ", "νταβ", "ξηροκλιβ", "ολιγοδαμ", "ολογαλ", "πενταρφ", "περηφ", "περιτρ", "πλατ", "πολυδαπ", "πολυμηχ", "στεφ", "ταβ", "τετ", "υπερηφ", "υποκοπ", "χαμηλοδαπ", "ψηλοταβ" }), false);
/*     */ 
/* 349 */   private static final CharArraySet exc9 = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "αβαρ", "βεν", "εναρ", "αβρ", "αδ", "αθ", "αν", "απλ", "βαρον", "ντρ", "σκ", "κοπ", "μπορ", "νιφ", "παγ", "παρακαλ", "σερπ", "σκελ", "συρφ", "τοκ", "υ", "δ", "εμ", "θαρρ", "θ" }), false);
/*     */ 
/* 437 */   private static final CharArraySet exc12a = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "π", "απ", "συμπ", "ασυμπ", "ακαταπ", "αμεταμφ" }), false);
/*     */ 
/* 441 */   private static final CharArraySet exc12b = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "αλ", "αρ", "εκτελ", "ζ", "μ", "ξ", "παρακαλ", "αρ", "προ", "νισ" }), false);
/*     */ 
/* 461 */   private static final CharArraySet exc13 = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "διαθ", "θ", "παρακαταθ", "προσθ", "συνθ" }), false);
/*     */ 
/* 495 */   private static final CharArraySet exc14 = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "φαρμακ", "χαδ", "αγκ", "αναρρ", "βρομ", "εκλιπ", "λαμπιδ", "λεχ", "μ", "πατ", "ρ", "λ", "μεδ", "μεσαζ", "υποτειν", "αμ", "αιθ", "ανηκ", "δεσποζ", "ενδιαφερ", "δε", "δευτερευ", "καθαρευ", "πλε", "τσα" }), false);
/*     */ 
/* 533 */   private static final CharArraySet exc15a = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "αβαστ", "πολυφ", "αδηφ", "παμφ", "ρ", "ασπ", "αφ", "αμαλ", "αμαλλι", "ανυστ", "απερ", "ασπαρ", "αχαρ", "δερβεν", "δροσοπ", "ξεφ", "νεοπ", "νομοτ", "ολοπ", "ομοτ", "προστ", "προσωποπ", "συμπ", "συντ", "τ", "υποτ", "χαρ", "αειπ", "αιμοστ", "ανυπ", "αποτ", "αρτιπ", "διατ", "εν", "επιτ", "κροκαλοπ", "σιδηροπ", "λ", "ναυ", "ουλαμ", "ουρ", "π", "τρ", "μ" }), false);
/*     */ 
/* 542 */   private static final CharArraySet exc15b = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "ψοφ", "ναυλοχ" }), false);
/*     */ 
/* 579 */   private static final CharArraySet exc16 = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "ν", "χερσον", "δωδεκαν", "ερημον", "μεγαλον", "επταν" }), false);
/*     */ 
/* 599 */   private static final CharArraySet exc17 = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "ασβ", "σβ", "αχρ", "χρ", "απλ", "αειμν", "δυσχρ", "ευχρ", "κοινοχρ", "παλιμψ" }), false);
/*     */ 
/* 613 */   private static final CharArraySet exc18 = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "ν", "ρ", "σπι", "στραβομουτσ", "κακομουτσ", "εξων" }), false);
/*     */ 
/* 637 */   private static final CharArraySet exc19 = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "παρασουσ", "φ", "χ", "ωριοπλ", "αζ", "αλλοσουσ", "ασουσ" }), false);
/*     */ 
/*     */   public int stem(char[] s, int len)
/*     */   {
/*  45 */     if (len < 4) {
/*  46 */       return len;
/*     */     }
/*  48 */     int origLen = len;
/*     */ 
/*  50 */     len = rule0(s, len);
/*  51 */     len = rule1(s, len);
/*  52 */     len = rule2(s, len);
/*  53 */     len = rule3(s, len);
/*  54 */     len = rule4(s, len);
/*  55 */     len = rule5(s, len);
/*  56 */     len = rule6(s, len);
/*  57 */     len = rule7(s, len);
/*  58 */     len = rule8(s, len);
/*  59 */     len = rule9(s, len);
/*  60 */     len = rule10(s, len);
/*  61 */     len = rule11(s, len);
/*  62 */     len = rule12(s, len);
/*  63 */     len = rule13(s, len);
/*  64 */     len = rule14(s, len);
/*  65 */     len = rule15(s, len);
/*  66 */     len = rule16(s, len);
/*  67 */     len = rule17(s, len);
/*  68 */     len = rule18(s, len);
/*  69 */     len = rule19(s, len);
/*  70 */     len = rule20(s, len);
/*     */ 
/*  72 */     if (len == origLen) {
/*  73 */       len = rule21(s, len);
/*     */     }
/*  75 */     return rule22(s, len);
/*     */   }
/*     */ 
/*     */   private int rule0(char[] s, int len) {
/*  79 */     if ((len > 9) && ((endsWith(s, len, "καθεστωτοσ")) || (endsWith(s, len, "καθεστωτων"))))
/*     */     {
/*  81 */       return len - 4;
/*     */     }
/*  83 */     if ((len > 8) && ((endsWith(s, len, "γεγονοτοσ")) || (endsWith(s, len, "γεγονοτων"))))
/*     */     {
/*  85 */       return len - 4;
/*     */     }
/*  87 */     if ((len > 8) && (endsWith(s, len, "καθεστωτα"))) {
/*  88 */       return len - 3;
/*     */     }
/*  90 */     if ((len > 7) && ((endsWith(s, len, "τατογιου")) || (endsWith(s, len, "τατογιων"))))
/*     */     {
/*  92 */       return len - 4;
/*     */     }
/*  94 */     if ((len > 7) && (endsWith(s, len, "γεγονοτα"))) {
/*  95 */       return len - 3;
/*     */     }
/*  97 */     if ((len > 7) && (endsWith(s, len, "καθεστωσ"))) {
/*  98 */       return len - 2;
/*     */     }
/* 100 */     if (((len > 6) && (endsWith(s, len, "σκαγιου"))) || (endsWith(s, len, "σκαγιων")) || (endsWith(s, len, "ολογιου")) || (endsWith(s, len, "ολογιων")) || (endsWith(s, len, "κρεατοσ")) || (endsWith(s, len, "κρεατων")) || (endsWith(s, len, "περατοσ")) || (endsWith(s, len, "περατων")) || (endsWith(s, len, "τερατοσ")) || (endsWith(s, len, "τερατων")))
/*     */     {
/* 110 */       return len - 4;
/*     */     }
/* 112 */     if ((len > 6) && (endsWith(s, len, "τατογια"))) {
/* 113 */       return len - 3;
/*     */     }
/* 115 */     if ((len > 6) && (endsWith(s, len, "γεγονοσ"))) {
/* 116 */       return len - 2;
/*     */     }
/* 118 */     if ((len > 5) && ((endsWith(s, len, "φαγιου")) || (endsWith(s, len, "φαγιων")) || (endsWith(s, len, "σογιου")) || (endsWith(s, len, "σογιων"))))
/*     */     {
/* 122 */       return len - 4;
/*     */     }
/* 124 */     if ((len > 5) && ((endsWith(s, len, "σκαγια")) || (endsWith(s, len, "ολογια")) || (endsWith(s, len, "κρεατα")) || (endsWith(s, len, "περατα")) || (endsWith(s, len, "τερατα"))))
/*     */     {
/* 129 */       return len - 3;
/*     */     }
/* 131 */     if ((len > 4) && ((endsWith(s, len, "φαγια")) || (endsWith(s, len, "σογια")) || (endsWith(s, len, "φωτοσ")) || (endsWith(s, len, "φωτων"))))
/*     */     {
/* 135 */       return len - 3;
/*     */     }
/* 137 */     if ((len > 4) && ((endsWith(s, len, "κρεασ")) || (endsWith(s, len, "περασ")) || (endsWith(s, len, "τερασ"))))
/*     */     {
/* 140 */       return len - 2;
/*     */     }
/* 142 */     if ((len > 3) && (endsWith(s, len, "φωτα"))) {
/* 143 */       return len - 2;
/*     */     }
/* 145 */     if ((len > 2) && (endsWith(s, len, "φωσ"))) {
/* 146 */       return len - 1;
/*     */     }
/* 148 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule1(char[] s, int len) {
/* 152 */     if ((len > 4) && ((endsWith(s, len, "αδεσ")) || (endsWith(s, len, "αδων")))) {
/* 153 */       len -= 4;
/* 154 */       if ((!endsWith(s, len, "οκ")) && (!endsWith(s, len, "μαμ")) && (!endsWith(s, len, "μαν")) && (!endsWith(s, len, "μπαμπ")) && (!endsWith(s, len, "πατερ")) && (!endsWith(s, len, "γιαγι")) && (!endsWith(s, len, "νταντ")) && (!endsWith(s, len, "κυρ")) && (!endsWith(s, len, "θει")) && (!endsWith(s, len, "πεθερ")))
/*     */       {
/* 164 */         len += 2;
/*     */       }
/*     */     }
/* 166 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule2(char[] s, int len) {
/* 170 */     if ((len > 4) && ((endsWith(s, len, "εδεσ")) || (endsWith(s, len, "εδων")))) {
/* 171 */       len -= 4;
/* 172 */       if ((endsWith(s, len, "οπ")) || (endsWith(s, len, "ιπ")) || (endsWith(s, len, "εμπ")) || (endsWith(s, len, "υπ")) || (endsWith(s, len, "γηπ")) || (endsWith(s, len, "δαπ")) || (endsWith(s, len, "κρασπ")) || (endsWith(s, len, "μιλ")))
/*     */       {
/* 180 */         len += 2;
/*     */       }
/*     */     }
/* 182 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule3(char[] s, int len) {
/* 186 */     if ((len > 5) && ((endsWith(s, len, "ουδεσ")) || (endsWith(s, len, "ουδων")))) {
/* 187 */       len -= 5;
/* 188 */       if ((endsWith(s, len, "αρκ")) || (endsWith(s, len, "καλιακ")) || (endsWith(s, len, "πεταλ")) || (endsWith(s, len, "λιχ")) || (endsWith(s, len, "πλεξ")) || (endsWith(s, len, "σκ")) || (endsWith(s, len, "σ")) || (endsWith(s, len, "φλ")) || (endsWith(s, len, "φρ")) || (endsWith(s, len, "βελ")) || (endsWith(s, len, "λουλ")) || (endsWith(s, len, "χν")) || (endsWith(s, len, "σπ")) || (endsWith(s, len, "τραγ")) || (endsWith(s, len, "φε")))
/*     */       {
/* 203 */         len += 3;
/*     */       }
/*     */     }
/* 205 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule4(char[] s, int len)
/*     */   {
/* 213 */     if ((len > 3) && ((endsWith(s, len, "εωσ")) || (endsWith(s, len, "εων")))) {
/* 214 */       len -= 3;
/* 215 */       if (exc4.contains(s, 0, len))
/* 216 */         len++;
/*     */     }
/* 218 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule5(char[] s, int len) {
/* 222 */     if ((len > 2) && (endsWith(s, len, "ια"))) {
/* 223 */       len -= 2;
/* 224 */       if (endsWithVowel(s, len))
/* 225 */         len++;
/* 226 */     } else if ((len > 3) && ((endsWith(s, len, "ιου")) || (endsWith(s, len, "ιων")))) {
/* 227 */       len -= 3;
/* 228 */       if (endsWithVowel(s, len))
/* 229 */         len++;
/*     */     }
/* 231 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule6(char[] s, int len)
/*     */   {
/* 243 */     boolean removed = false;
/* 244 */     if ((len > 3) && ((endsWith(s, len, "ικα")) || (endsWith(s, len, "ικο")))) {
/* 245 */       len -= 3;
/* 246 */       removed = true;
/* 247 */     } else if ((len > 4) && ((endsWith(s, len, "ικου")) || (endsWith(s, len, "ικων")))) {
/* 248 */       len -= 4;
/* 249 */       removed = true;
/*     */     }
/*     */ 
/* 252 */     if ((removed) && (
/* 253 */       (endsWithVowel(s, len)) || (exc6.contains(s, 0, len)))) {
/* 254 */       len += 2;
/*     */     }
/* 256 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule7(char[] s, int len)
/*     */   {
/* 265 */     if ((len == 5) && (endsWith(s, len, "αγαμε"))) {
/* 266 */       return len - 1;
/*     */     }
/* 268 */     if ((len > 7) && (endsWith(s, len, "ηθηκαμε")))
/* 269 */       len -= 7;
/* 270 */     else if ((len > 6) && (endsWith(s, len, "ουσαμε")))
/* 271 */       len -= 6;
/* 272 */     else if ((len > 5) && ((endsWith(s, len, "αγαμε")) || (endsWith(s, len, "ησαμε")) || (endsWith(s, len, "ηκαμε"))))
/*     */     {
/* 275 */       len -= 5;
/*     */     }
/* 277 */     if ((len > 3) && (endsWith(s, len, "αμε"))) {
/* 278 */       len -= 3;
/* 279 */       if (exc7.contains(s, 0, len)) {
/* 280 */         len += 2;
/*     */       }
/*     */     }
/* 283 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule8(char[] s, int len)
/*     */   {
/* 307 */     boolean removed = false;
/*     */ 
/* 309 */     if ((len > 8) && (endsWith(s, len, "ιουντανε"))) {
/* 310 */       len -= 8;
/* 311 */       removed = true;
/* 312 */     } else if (((len > 7) && (endsWith(s, len, "ιοντανε"))) || (endsWith(s, len, "ουντανε")) || (endsWith(s, len, "ηθηκανε")))
/*     */     {
/* 315 */       len -= 7;
/* 316 */       removed = true;
/* 317 */     } else if (((len > 6) && (endsWith(s, len, "ιοτανε"))) || (endsWith(s, len, "οντανε")) || (endsWith(s, len, "ουσανε")))
/*     */     {
/* 320 */       len -= 6;
/* 321 */       removed = true;
/* 322 */     } else if (((len > 5) && (endsWith(s, len, "αγανε"))) || (endsWith(s, len, "ησανε")) || (endsWith(s, len, "οτανε")) || (endsWith(s, len, "ηκανε")))
/*     */     {
/* 326 */       len -= 5;
/* 327 */       removed = true;
/*     */     }
/*     */ 
/* 330 */     if ((removed) && (exc8a.contains(s, 0, len)))
/*     */     {
/* 332 */       len += 4;
/* 333 */       s[(len - 4)] = 'α';
/* 334 */       s[(len - 3)] = 'γ';
/* 335 */       s[(len - 2)] = 'α';
/* 336 */       s[(len - 1)] = 'ν';
/*     */     }
/*     */ 
/* 339 */     if ((len > 3) && (endsWith(s, len, "ανε"))) {
/* 340 */       len -= 3;
/* 341 */       if ((endsWithVowelNoY(s, len)) || (exc8b.contains(s, 0, len))) {
/* 342 */         len += 2;
/*     */       }
/*     */     }
/*     */ 
/* 346 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule9(char[] s, int len)
/*     */   {
/* 356 */     if ((len > 5) && (endsWith(s, len, "ησετε"))) {
/* 357 */       len -= 5;
/*     */     }
/* 359 */     if ((len > 3) && (endsWith(s, len, "ετε"))) {
/* 360 */       len -= 3;
/* 361 */       if ((exc9.contains(s, 0, len)) || (endsWithVowelNoY(s, len)) || (endsWith(s, len, "οδ")) || (endsWith(s, len, "αιρ")) || (endsWith(s, len, "φορ")) || (endsWith(s, len, "ταθ")) || (endsWith(s, len, "διαθ")) || (endsWith(s, len, "σχ")) || (endsWith(s, len, "ενδ")) || (endsWith(s, len, "ευρ")) || (endsWith(s, len, "τιθ")) || (endsWith(s, len, "υπερθ")) || (endsWith(s, len, "ραθ")) || (endsWith(s, len, "ενθ")) || (endsWith(s, len, "ροθ")) || (endsWith(s, len, "σθ")) || (endsWith(s, len, "πυρ")) || (endsWith(s, len, "αιν")) || (endsWith(s, len, "συνδ")) || (endsWith(s, len, "συν")) || (endsWith(s, len, "συνθ")) || (endsWith(s, len, "χωρ")) || (endsWith(s, len, "πον")) || (endsWith(s, len, "βρ")) || (endsWith(s, len, "καθ")) || (endsWith(s, len, "ευθ")) || (endsWith(s, len, "εκθ")) || (endsWith(s, len, "νετ")) || (endsWith(s, len, "ρον")) || (endsWith(s, len, "αρκ")) || (endsWith(s, len, "βαρ")) || (endsWith(s, len, "βολ")) || (endsWith(s, len, "ωφελ")))
/*     */       {
/* 394 */         len += 2;
/*     */       }
/*     */     }
/*     */ 
/* 398 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule10(char[] s, int len) {
/* 402 */     if ((len > 5) && ((endsWith(s, len, "οντασ")) || (endsWith(s, len, "ωντασ")))) {
/* 403 */       len -= 5;
/* 404 */       if ((len == 3) && (endsWith(s, len, "αρχ"))) {
/* 405 */         len += 3;
/* 406 */         s[(len - 3)] = 'ο';
/*     */       }
/* 408 */       if (endsWith(s, len, "κρε")) {
/* 409 */         len += 3;
/* 410 */         s[(len - 3)] = 'ω';
/*     */       }
/*     */     }
/*     */ 
/* 414 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule11(char[] s, int len) {
/* 418 */     if ((len > 6) && (endsWith(s, len, "ομαστε"))) {
/* 419 */       len -= 6;
/* 420 */       if ((len == 2) && (endsWith(s, len, "ον")))
/* 421 */         len += 5;
/*     */     }
/* 423 */     else if ((len > 7) && (endsWith(s, len, "ιομαστε"))) {
/* 424 */       len -= 7;
/* 425 */       if ((len == 2) && (endsWith(s, len, "ον"))) {
/* 426 */         len += 5;
/* 427 */         s[(len - 5)] = 'ο';
/* 428 */         s[(len - 4)] = 'μ';
/* 429 */         s[(len - 3)] = 'α';
/* 430 */         s[(len - 2)] = 'σ';
/* 431 */         s[(len - 1)] = 'τ';
/*     */       }
/*     */     }
/* 434 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule12(char[] s, int len)
/*     */   {
/* 446 */     if ((len > 5) && (endsWith(s, len, "ιεστε"))) {
/* 447 */       len -= 5;
/* 448 */       if (exc12a.contains(s, 0, len)) {
/* 449 */         len += 4;
/*     */       }
/*     */     }
/* 452 */     if ((len > 4) && (endsWith(s, len, "εστε"))) {
/* 453 */       len -= 4;
/* 454 */       if (exc12b.contains(s, 0, len)) {
/* 455 */         len += 3;
/*     */       }
/*     */     }
/* 458 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule13(char[] s, int len)
/*     */   {
/* 466 */     if ((len > 6) && (endsWith(s, len, "ηθηκεσ")))
/* 467 */       len -= 6;
/* 468 */     else if ((len > 5) && ((endsWith(s, len, "ηθηκα")) || (endsWith(s, len, "ηθηκε")))) {
/* 469 */       len -= 5;
/*     */     }
/*     */ 
/* 472 */     boolean removed = false;
/*     */ 
/* 474 */     if ((len > 4) && (endsWith(s, len, "ηκεσ"))) {
/* 475 */       len -= 4;
/* 476 */       removed = true;
/* 477 */     } else if ((len > 3) && ((endsWith(s, len, "ηκα")) || (endsWith(s, len, "ηκε")))) {
/* 478 */       len -= 3;
/* 479 */       removed = true;
/*     */     }
/*     */ 
/* 482 */     if ((removed) && ((exc13.contains(s, 0, len)) || (endsWith(s, len, "σκωλ")) || (endsWith(s, len, "σκουλ")) || (endsWith(s, len, "ναρθ")) || (endsWith(s, len, "σφ")) || (endsWith(s, len, "οθ")) || (endsWith(s, len, "πιθ"))))
/*     */     {
/* 489 */       len += 2;
/*     */     }
/*     */ 
/* 492 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule14(char[] s, int len)
/*     */   {
/* 503 */     boolean removed = false;
/*     */ 
/* 505 */     if ((len > 5) && (endsWith(s, len, "ουσεσ"))) {
/* 506 */       len -= 5;
/* 507 */       removed = true;
/* 508 */     } else if ((len > 4) && ((endsWith(s, len, "ουσα")) || (endsWith(s, len, "ουσε")))) {
/* 509 */       len -= 4;
/* 510 */       removed = true;
/*     */     }
/*     */ 
/* 513 */     if ((removed) && ((exc14.contains(s, 0, len)) || (endsWithVowel(s, len)) || (endsWith(s, len, "ποδαρ")) || (endsWith(s, len, "βλεπ")) || (endsWith(s, len, "πανταχ")) || (endsWith(s, len, "φρυδ")) || (endsWith(s, len, "μαντιλ")) || (endsWith(s, len, "μαλλ")) || (endsWith(s, len, "κυματ")) || (endsWith(s, len, "λαχ")) || (endsWith(s, len, "ληγ")) || (endsWith(s, len, "φαγ")) || (endsWith(s, len, "ομ")) || (endsWith(s, len, "πρωτ"))))
/*     */     {
/* 527 */       len += 3;
/*     */     }
/*     */ 
/* 530 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule15(char[] s, int len)
/*     */   {
/* 547 */     boolean removed = false;
/* 548 */     if ((len > 4) && (endsWith(s, len, "αγεσ"))) {
/* 549 */       len -= 4;
/* 550 */       removed = true;
/* 551 */     } else if ((len > 3) && ((endsWith(s, len, "αγα")) || (endsWith(s, len, "αγε")))) {
/* 552 */       len -= 3;
/* 553 */       removed = true;
/*     */     }
/*     */ 
/* 556 */     if (removed) {
/* 557 */       boolean cond1 = (exc15a.contains(s, 0, len)) || (endsWith(s, len, "οφ")) || (endsWith(s, len, "πελ")) || (endsWith(s, len, "χορτ")) || (endsWith(s, len, "λλ")) || (endsWith(s, len, "σφ")) || (endsWith(s, len, "ρπ")) || (endsWith(s, len, "φρ")) || (endsWith(s, len, "πρ")) || (endsWith(s, len, "λοχ")) || (endsWith(s, len, "σμην"));
/*     */ 
/* 569 */       boolean cond2 = (exc15b.contains(s, 0, len)) || (endsWith(s, len, "κολλ"));
/*     */ 
/* 572 */       if ((cond1) && (!cond2)) {
/* 573 */         len += 2;
/*     */       }
/*     */     }
/* 576 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule16(char[] s, int len)
/*     */   {
/* 584 */     boolean removed = false;
/* 585 */     if ((len > 4) && (endsWith(s, len, "ησου"))) {
/* 586 */       len -= 4;
/* 587 */       removed = true;
/* 588 */     } else if ((len > 3) && ((endsWith(s, len, "ησε")) || (endsWith(s, len, "ησα")))) {
/* 589 */       len -= 3;
/* 590 */       removed = true;
/*     */     }
/*     */ 
/* 593 */     if ((removed) && (exc16.contains(s, 0, len))) {
/* 594 */       len += 2;
/*     */     }
/* 596 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule17(char[] s, int len)
/*     */   {
/* 604 */     if ((len > 4) && (endsWith(s, len, "ηστε"))) {
/* 605 */       len -= 4;
/* 606 */       if (exc17.contains(s, 0, len)) {
/* 607 */         len += 3;
/*     */       }
/*     */     }
/* 610 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule18(char[] s, int len)
/*     */   {
/* 618 */     boolean removed = false;
/*     */ 
/* 620 */     if ((len > 6) && ((endsWith(s, len, "ησουνε")) || (endsWith(s, len, "ηθουνε")))) {
/* 621 */       len -= 6;
/* 622 */       removed = true;
/* 623 */     } else if ((len > 4) && (endsWith(s, len, "ουνε"))) {
/* 624 */       len -= 4;
/* 625 */       removed = true;
/*     */     }
/*     */ 
/* 628 */     if ((removed) && (exc18.contains(s, 0, len))) {
/* 629 */       len += 3;
/* 630 */       s[(len - 3)] = 'ο';
/* 631 */       s[(len - 2)] = 'υ';
/* 632 */       s[(len - 1)] = 'ν';
/*     */     }
/* 634 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule19(char[] s, int len)
/*     */   {
/* 642 */     boolean removed = false;
/*     */ 
/* 644 */     if ((len > 6) && ((endsWith(s, len, "ησουμε")) || (endsWith(s, len, "ηθουμε")))) {
/* 645 */       len -= 6;
/* 646 */       removed = true;
/* 647 */     } else if ((len > 4) && (endsWith(s, len, "ουμε"))) {
/* 648 */       len -= 4;
/* 649 */       removed = true;
/*     */     }
/*     */ 
/* 652 */     if ((removed) && (exc19.contains(s, 0, len))) {
/* 653 */       len += 3;
/* 654 */       s[(len - 3)] = 'ο';
/* 655 */       s[(len - 2)] = 'υ';
/* 656 */       s[(len - 1)] = 'μ';
/*     */     }
/* 658 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule20(char[] s, int len) {
/* 662 */     if ((len > 5) && ((endsWith(s, len, "ματων")) || (endsWith(s, len, "ματοσ"))))
/* 663 */       len -= 3;
/* 664 */     else if ((len > 4) && (endsWith(s, len, "ματα")))
/* 665 */       len -= 2;
/* 666 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule21(char[] s, int len) {
/* 670 */     if ((len > 9) && (endsWith(s, len, "ιοντουσαν"))) {
/* 671 */       return len - 9;
/*     */     }
/* 673 */     if ((len > 8) && ((endsWith(s, len, "ιομασταν")) || (endsWith(s, len, "ιοσασταν")) || (endsWith(s, len, "ιουμαστε")) || (endsWith(s, len, "οντουσαν"))))
/*     */     {
/* 677 */       return len - 8;
/*     */     }
/* 679 */     if ((len > 7) && ((endsWith(s, len, "ιεμαστε")) || (endsWith(s, len, "ιεσαστε")) || (endsWith(s, len, "ιομουνα")) || (endsWith(s, len, "ιοσαστε")) || (endsWith(s, len, "ιοσουνα")) || (endsWith(s, len, "ιουνται")) || (endsWith(s, len, "ιουνταν")) || (endsWith(s, len, "ηθηκατε")) || (endsWith(s, len, "ομασταν")) || (endsWith(s, len, "οσασταν")) || (endsWith(s, len, "ουμαστε"))))
/*     */     {
/* 690 */       return len - 7;
/*     */     }
/* 692 */     if ((len > 6) && ((endsWith(s, len, "ιομουν")) || (endsWith(s, len, "ιονταν")) || (endsWith(s, len, "ιοσουν")) || (endsWith(s, len, "ηθειτε")) || (endsWith(s, len, "ηθηκαν")) || (endsWith(s, len, "ομουνα")) || (endsWith(s, len, "οσαστε")) || (endsWith(s, len, "οσουνα")) || (endsWith(s, len, "ουνται")) || (endsWith(s, len, "ουνταν")) || (endsWith(s, len, "ουσατε"))))
/*     */     {
/* 703 */       return len - 6;
/*     */     }
/* 705 */     if ((len > 5) && ((endsWith(s, len, "αγατε")) || (endsWith(s, len, "ιεμαι")) || (endsWith(s, len, "ιεται")) || (endsWith(s, len, "ιεσαι")) || (endsWith(s, len, "ιοταν")) || (endsWith(s, len, "ιουμα")) || (endsWith(s, len, "ηθεισ")) || (endsWith(s, len, "ηθουν")) || (endsWith(s, len, "ηκατε")) || (endsWith(s, len, "ησατε")) || (endsWith(s, len, "ησουν")) || (endsWith(s, len, "ομουν")) || (endsWith(s, len, "ονται")) || (endsWith(s, len, "ονταν")) || (endsWith(s, len, "οσουν")) || (endsWith(s, len, "ουμαι")) || (endsWith(s, len, "ουσαν"))))
/*     */     {
/* 722 */       return len - 5;
/*     */     }
/* 724 */     if ((len > 4) && ((endsWith(s, len, "αγαν")) || (endsWith(s, len, "αμαι")) || (endsWith(s, len, "ασαι")) || (endsWith(s, len, "αται")) || (endsWith(s, len, "ειτε")) || (endsWith(s, len, "εσαι")) || (endsWith(s, len, "εται")) || (endsWith(s, len, "ηδεσ")) || (endsWith(s, len, "ηδων")) || (endsWith(s, len, "ηθει")) || (endsWith(s, len, "ηκαν")) || (endsWith(s, len, "ησαν")) || (endsWith(s, len, "ησει")) || (endsWith(s, len, "ησεσ")) || (endsWith(s, len, "ομαι")) || (endsWith(s, len, "οταν"))))
/*     */     {
/* 740 */       return len - 4;
/*     */     }
/* 742 */     if ((len > 3) && ((endsWith(s, len, "αει")) || (endsWith(s, len, "εισ")) || (endsWith(s, len, "ηθω")) || (endsWith(s, len, "ησω")) || (endsWith(s, len, "ουν")) || (endsWith(s, len, "ουσ"))))
/*     */     {
/* 748 */       return len - 3;
/*     */     }
/* 750 */     if ((len > 2) && ((endsWith(s, len, "αν")) || (endsWith(s, len, "ασ")) || (endsWith(s, len, "αω")) || (endsWith(s, len, "ει")) || (endsWith(s, len, "εσ")) || (endsWith(s, len, "ησ")) || (endsWith(s, len, "οι")) || (endsWith(s, len, "οσ")) || (endsWith(s, len, "ου")) || (endsWith(s, len, "υσ")) || (endsWith(s, len, "ων"))))
/*     */     {
/* 761 */       return len - 2;
/*     */     }
/* 763 */     if ((len > 1) && (endsWithVowel(s, len))) {
/* 764 */       return len - 1;
/*     */     }
/* 766 */     return len;
/*     */   }
/*     */ 
/*     */   private int rule22(char[] s, int len) {
/* 770 */     if ((endsWith(s, len, "εστερ")) || (endsWith(s, len, "εστατ")))
/*     */     {
/* 772 */       return len - 5;
/*     */     }
/* 774 */     if ((endsWith(s, len, "οτερ")) || (endsWith(s, len, "οτατ")) || (endsWith(s, len, "υτερ")) || (endsWith(s, len, "υτατ")) || (endsWith(s, len, "ωτερ")) || (endsWith(s, len, "ωτατ")))
/*     */     {
/* 780 */       return len - 4;
/*     */     }
/* 782 */     return len;
/*     */   }
/*     */ 
/*     */   private boolean endsWith(char[] s, int len, String suffix)
/*     */   {
/* 795 */     int suffixLen = suffix.length();
/* 796 */     if (suffixLen > len)
/* 797 */       return false;
/* 798 */     for (int i = suffixLen - 1; i >= 0; i--) {
/* 799 */       if (s[(len - (suffixLen - i))] != suffix.charAt(i))
/* 800 */         return false;
/*     */     }
/* 802 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean endsWithVowel(char[] s, int len)
/*     */   {
/* 815 */     if (len == 0)
/* 816 */       return false;
/* 817 */     switch (s[(len - 1)]) {
/*     */     case 'α':
/*     */     case 'ε':
/*     */     case 'η':
/*     */     case 'ι':
/*     */     case 'ο':
/*     */     case 'υ':
/*     */     case 'ω':
/* 825 */       return true;
/*     */     case 'β':
/*     */     case 'γ':
/*     */     case 'δ':
/*     */     case 'ζ':
/*     */     case 'θ':
/*     */     case 'κ':
/*     */     case 'λ':
/*     */     case 'μ':
/*     */     case 'ν':
/*     */     case 'ξ':
/*     */     case 'π':
/*     */     case 'ρ':
/*     */     case 'ς':
/*     */     case 'σ':
/*     */     case 'τ':
/*     */     case 'φ':
/*     */     case 'χ':
/* 827 */     case 'ψ': } return false;
/*     */   }
/*     */ 
/*     */   private boolean endsWithVowelNoY(char[] s, int len)
/*     */   {
/* 841 */     if (len == 0)
/* 842 */       return false;
/* 843 */     switch (s[(len - 1)]) {
/*     */     case 'α':
/*     */     case 'ε':
/*     */     case 'η':
/*     */     case 'ι':
/*     */     case 'ο':
/*     */     case 'ω':
/* 850 */       return true;
/*     */     }
/* 852 */     return false;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.el.GreekStemmer
 * JD-Core Version:    0.6.2
 */