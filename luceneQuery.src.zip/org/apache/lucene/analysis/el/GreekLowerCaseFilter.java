/*     */ package org.apache.lucene.analysis.el;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.util.CharacterUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class GreekLowerCaseFilter extends TokenFilter
/*     */ {
/*  38 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */   private final CharacterUtils charUtils;
/*     */ 
/*     */   public GreekLowerCaseFilter(Version matchVersion, TokenStream in)
/*     */   {
/*  49 */     super(in);
/*  50 */     this.charUtils = CharacterUtils.getInstance(matchVersion);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  55 */     if (this.input.incrementToken()) {
/*  56 */       char[] chArray = this.termAtt.buffer();
/*  57 */       int chLen = this.termAtt.length();
/*  58 */       for (int i = 0; i < chLen; ) {
/*  59 */         i += Character.toChars(lowerCase(this.charUtils.codePointAt(chArray, i, chLen)), chArray, i);
/*     */       }
/*     */ 
/*  62 */       return true;
/*     */     }
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */   private int lowerCase(int codepoint)
/*     */   {
/*  69 */     switch (codepoint)
/*     */     {
/*     */     case 962:
/*  77 */       return 963;
/*     */     case 902:
/*     */     case 940:
/*  85 */       return 945;
/*     */     case 904:
/*     */     case 941:
/*  89 */       return 949;
/*     */     case 905:
/*     */     case 942:
/*  93 */       return 951;
/*     */     case 906:
/*     */     case 912:
/*     */     case 938:
/*     */     case 943:
/*     */     case 970:
/* 100 */       return 953;
/*     */     case 910:
/*     */     case 939:
/*     */     case 944:
/*     */     case 971:
/*     */     case 973:
/* 107 */       return 965;
/*     */     case 908:
/*     */     case 972:
/* 111 */       return 959;
/*     */     case 911:
/*     */     case 974:
/* 115 */       return 969;
/*     */     case 930:
/* 122 */       return 962;
/*     */     case 903:
/*     */     case 907:
/*     */     case 909:
/*     */     case 913:
/*     */     case 914:
/*     */     case 915:
/*     */     case 916:
/*     */     case 917:
/*     */     case 918:
/*     */     case 919:
/*     */     case 920:
/*     */     case 921:
/*     */     case 922:
/*     */     case 923:
/*     */     case 924:
/*     */     case 925:
/*     */     case 926:
/*     */     case 927:
/*     */     case 928:
/*     */     case 929:
/*     */     case 931:
/*     */     case 932:
/*     */     case 933:
/*     */     case 934:
/*     */     case 935:
/*     */     case 936:
/*     */     case 937:
/*     */     case 945:
/*     */     case 946:
/*     */     case 947:
/*     */     case 948:
/*     */     case 949:
/*     */     case 950:
/*     */     case 951:
/*     */     case 952:
/*     */     case 953:
/*     */     case 954:
/*     */     case 955:
/*     */     case 956:
/*     */     case 957:
/*     */     case 958:
/*     */     case 959:
/*     */     case 960:
/*     */     case 961:
/*     */     case 963:
/*     */     case 964:
/*     */     case 965:
/*     */     case 966:
/*     */     case 967:
/*     */     case 968:
/* 125 */     case 969: } return Character.toLowerCase(codepoint);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.el.GreekLowerCaseFilter
 * JD-Core Version:    0.6.2
 */