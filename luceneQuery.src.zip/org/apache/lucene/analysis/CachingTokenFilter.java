/*    */ package org.apache.lucene.analysis;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import org.apache.lucene.util.AttributeSource.State;
/*    */ 
/*    */ public final class CachingTokenFilter extends TokenFilter
/*    */ {
/* 37 */   private List<AttributeSource.State> cache = null;
/* 38 */   private Iterator<AttributeSource.State> iterator = null;
/*    */   private AttributeSource.State finalState;
/*    */ 
/*    */   public CachingTokenFilter(TokenStream input)
/*    */   {
/* 47 */     super(input);
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken() throws IOException
/*    */   {
/* 52 */     if (this.cache == null)
/*    */     {
/* 54 */       this.cache = new LinkedList();
/* 55 */       fillCache();
/* 56 */       this.iterator = this.cache.iterator();
/*    */     }
/*    */ 
/* 59 */     if (!this.iterator.hasNext())
/*    */     {
/* 61 */       return false;
/*    */     }
/*    */ 
/* 64 */     restoreState((AttributeSource.State)this.iterator.next());
/* 65 */     return true;
/*    */   }
/*    */ 
/*    */   public final void end()
/*    */   {
/* 70 */     if (this.finalState != null)
/* 71 */       restoreState(this.finalState);
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */   {
/* 84 */     if (this.cache != null)
/* 85 */       this.iterator = this.cache.iterator();
/*    */   }
/*    */ 
/*    */   private void fillCache() throws IOException
/*    */   {
/* 90 */     while (this.input.incrementToken()) {
/* 91 */       this.cache.add(captureState());
/*    */     }
/*    */ 
/* 94 */     this.input.end();
/* 95 */     this.finalState = captureState();
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.CachingTokenFilter
 * JD-Core Version:    0.6.2
 */