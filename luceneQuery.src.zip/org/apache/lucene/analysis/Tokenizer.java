/*     */ package org.apache.lucene.analysis;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ public abstract class Tokenizer extends TokenStream
/*     */ {
/*  35 */   protected Reader input = ILLEGAL_STATE_READER;
/*     */ 
/*  38 */   private Reader inputPending = ILLEGAL_STATE_READER;
/*     */ 
/* 107 */   private static final Reader ILLEGAL_STATE_READER = new Reader()
/*     */   {
/*     */     public int read(char[] cbuf, int off, int len) {
/* 110 */       throw new IllegalStateException("TokenStream contract violation: reset()/close() call missing, reset() called multiple times, or subclass does not call super.reset(). Please see Javadocs of TokenStream class for more information about the correct consuming workflow.");
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/*     */     }
/* 107 */   };
/*     */ 
/*     */   protected Tokenizer(Reader input)
/*     */   {
/*  42 */     if (input == null) {
/*  43 */       throw new NullPointerException("input must not be null");
/*     */     }
/*  45 */     this.inputPending = input;
/*     */   }
/*     */ 
/*     */   protected Tokenizer(AttributeSource.AttributeFactory factory, Reader input)
/*     */   {
/*  50 */     super(factory);
/*  51 */     if (input == null) {
/*  52 */       throw new NullPointerException("input must not be null");
/*     */     }
/*  54 */     this.inputPending = input;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  66 */     this.input.close();
/*     */ 
/*  69 */     this.inputPending = (this.input = ILLEGAL_STATE_READER);
/*     */   }
/*     */ 
/*     */   protected final int correctOffset(int currentOff)
/*     */   {
/*  79 */     return (this.input instanceof CharFilter) ? ((CharFilter)this.input).correctOffset(currentOff) : currentOff;
/*     */   }
/*     */ 
/*     */   public final void setReader(Reader input)
/*     */     throws IOException
/*     */   {
/*  86 */     if (input == null)
/*  87 */       throw new NullPointerException("input must not be null");
/*  88 */     if (this.input != ILLEGAL_STATE_READER) {
/*  89 */       throw new IllegalStateException("TokenStream contract violation: close() call missing");
/*     */     }
/*  91 */     this.inputPending = input;
/*  92 */     assert (setReaderTestPoint());
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/*  97 */     super.reset();
/*  98 */     this.input = this.inputPending;
/*  99 */     this.inputPending = ILLEGAL_STATE_READER;
/*     */   }
/*     */ 
/*     */   boolean setReaderTestPoint()
/*     */   {
/* 104 */     return true;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.analysis.Tokenizer
 * JD-Core Version:    0.6.2
 */