/*    */ package org.apache.lucene;
/*    */ 
/*    */ public final class LucenePackage
/*    */ {
/*    */   public static Package get()
/*    */   {
/* 27 */     return LucenePackage.class.getPackage();
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneQuery.jar
 * Qualified Name:     org.apache.lucene.LucenePackage
 * JD-Core Version:    0.6.2
 */