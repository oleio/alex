/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public final class KeywordRepeatFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public KeywordRepeatFilterFactory(Map<String, String> args)
/*    */   {
/* 36 */     super(args);
/* 37 */     if (!args.isEmpty())
/* 38 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 44 */     return new KeywordRepeatFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.KeywordRepeatFilterFactory
 * JD-Core Version:    0.6.2
 */