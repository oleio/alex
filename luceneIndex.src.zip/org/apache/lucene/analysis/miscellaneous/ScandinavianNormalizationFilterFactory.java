/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class ScandinavianNormalizationFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public ScandinavianNormalizationFilterFactory(Map<String, String> args)
/*    */   {
/* 38 */     super(args);
/* 39 */     if (!args.isEmpty())
/* 40 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ScandinavianNormalizationFilter create(TokenStream input)
/*    */   {
/* 46 */     return new ScandinavianNormalizationFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.ScandinavianNormalizationFilterFactory
 * JD-Core Version:    0.6.2
 */