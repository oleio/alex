/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*    */ import org.apache.lucene.analysis.util.CharArraySet;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class RemoveDuplicatesTokenFilter extends TokenFilter
/*    */ {
/* 34 */   private final CharTermAttribute termAttribute = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 35 */   private final PositionIncrementAttribute posIncAttribute = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*    */ 
/* 38 */   private final CharArraySet previous = new CharArraySet(Version.LUCENE_31, 8, false);
/*    */ 
/*    */   public RemoveDuplicatesTokenFilter(TokenStream in)
/*    */   {
/* 46 */     super(in);
/*    */   }
/*    */ 
/*    */   public boolean incrementToken()
/*    */     throws IOException
/*    */   {
/* 54 */     while (this.input.incrementToken()) {
/* 55 */       char[] term = this.termAttribute.buffer();
/* 56 */       int length = this.termAttribute.length();
/* 57 */       int posIncrement = this.posIncAttribute.getPositionIncrement();
/*    */ 
/* 59 */       if (posIncrement > 0) {
/* 60 */         this.previous.clear();
/*    */       }
/*    */ 
/* 63 */       boolean duplicate = (posIncrement == 0) && (this.previous.contains(term, 0, length));
/*    */ 
/* 66 */       char[] saved = new char[length];
/* 67 */       System.arraycopy(term, 0, saved, 0, length);
/* 68 */       this.previous.add(saved);
/*    */ 
/* 70 */       if (!duplicate) {
/* 71 */         return true;
/*    */       }
/*    */     }
/* 74 */     return false;
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */     throws IOException
/*    */   {
/* 82 */     super.reset();
/* 83 */     this.previous.clear();
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.RemoveDuplicatesTokenFilter
 * JD-Core Version:    0.6.2
 */