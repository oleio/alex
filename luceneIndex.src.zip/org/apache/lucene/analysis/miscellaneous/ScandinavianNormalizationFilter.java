/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.util.StemmerUtil;
/*     */ 
/*     */ public final class ScandinavianNormalizationFilter extends TokenFilter
/*     */ {
/*  46 */   private final CharTermAttribute charTermAttribute = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */   private static final char AA = 'Å';
/*     */   private static final char aa = 'å';
/*     */   private static final char AE = 'Æ';
/*     */   private static final char ae = 'æ';
/*     */   private static final char AE_se = 'Ä';
/*     */   private static final char ae_se = 'ä';
/*     */   private static final char OE = 'Ø';
/*     */   private static final char oe = 'ø';
/*     */   private static final char OE_se = 'Ö';
/*     */   private static final char oe_se = 'ö';
/*     */ 
/*     */   public ScandinavianNormalizationFilter(TokenStream input)
/*     */   {
/*  43 */     super(input);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*  62 */     if (!this.input.incrementToken()) {
/*  63 */       return false;
/*     */     }
/*     */ 
/*  66 */     char[] buffer = this.charTermAttribute.buffer();
/*  67 */     int length = this.charTermAttribute.length();
/*     */ 
/*  71 */     for (int i = 0; i < length; i++)
/*     */     {
/*  73 */       if (buffer[i] == 'ä') {
/*  74 */         buffer[i] = 'æ';
/*     */       }
/*  76 */       else if (buffer[i] == 'Ä') {
/*  77 */         buffer[i] = 'Æ';
/*     */       }
/*  79 */       else if (buffer[i] == 'ö') {
/*  80 */         buffer[i] = 'ø';
/*     */       }
/*  82 */       else if (buffer[i] == 'Ö') {
/*  83 */         buffer[i] = 'Ø';
/*     */       }
/*  85 */       else if (length - 1 > i)
/*     */       {
/*  87 */         if ((buffer[i] == 'a') && ((buffer[(i + 1)] == 'a') || (buffer[(i + 1)] == 'o') || (buffer[(i + 1)] == 'A') || (buffer[(i + 1)] == 'O'))) {
/*  88 */           length = StemmerUtil.delete(buffer, i + 1, length);
/*  89 */           buffer[i] = 'å';
/*     */         }
/*  91 */         else if ((buffer[i] == 'A') && ((buffer[(i + 1)] == 'a') || (buffer[(i + 1)] == 'A') || (buffer[(i + 1)] == 'o') || (buffer[(i + 1)] == 'O'))) {
/*  92 */           length = StemmerUtil.delete(buffer, i + 1, length);
/*  93 */           buffer[i] = 'Å';
/*     */         }
/*  95 */         else if ((buffer[i] == 'a') && ((buffer[(i + 1)] == 'e') || (buffer[(i + 1)] == 'E'))) {
/*  96 */           length = StemmerUtil.delete(buffer, i + 1, length);
/*  97 */           buffer[i] = 'æ';
/*     */         }
/*  99 */         else if ((buffer[i] == 'A') && ((buffer[(i + 1)] == 'e') || (buffer[(i + 1)] == 'E'))) {
/* 100 */           length = StemmerUtil.delete(buffer, i + 1, length);
/* 101 */           buffer[i] = 'Æ';
/*     */         }
/* 103 */         else if ((buffer[i] == 'o') && ((buffer[(i + 1)] == 'e') || (buffer[(i + 1)] == 'E') || (buffer[(i + 1)] == 'o') || (buffer[(i + 1)] == 'O'))) {
/* 104 */           length = StemmerUtil.delete(buffer, i + 1, length);
/* 105 */           buffer[i] = 'ø';
/*     */         }
/* 107 */         else if ((buffer[i] == 'O') && ((buffer[(i + 1)] == 'e') || (buffer[(i + 1)] == 'E') || (buffer[(i + 1)] == 'o') || (buffer[(i + 1)] == 'O'))) {
/* 108 */           length = StemmerUtil.delete(buffer, i + 1, length);
/* 109 */           buffer[i] = 'Ø';
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 116 */     this.charTermAttribute.setLength(length);
/*     */ 
/* 119 */     return true;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.ScandinavianNormalizationFilter
 * JD-Core Version:    0.6.2
 */