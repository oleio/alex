/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.util.FilteringTokenFilter;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class LengthFilter extends FilteringTokenFilter
/*    */ {
/*    */   private final int min;
/*    */   private final int max;
/* 36 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */ 
/*    */   @Deprecated
/*    */   public LengthFilter(Version version, boolean enablePositionIncrements, TokenStream in, int min, int max)
/*    */   {
/* 41 */     super(version, enablePositionIncrements, in);
/* 42 */     if (min < 0) {
/* 43 */       throw new IllegalArgumentException("minimum length must be greater than or equal to zero");
/*    */     }
/* 45 */     if (min > max) {
/* 46 */       throw new IllegalArgumentException("maximum length must not be greater than minimum length");
/*    */     }
/* 48 */     this.min = min;
/* 49 */     this.max = max;
/*    */   }
/*    */ 
/*    */   public LengthFilter(Version version, TokenStream in, int min, int max)
/*    */   {
/* 62 */     super(version, in);
/* 63 */     if (min < 0) {
/* 64 */       throw new IllegalArgumentException("minimum length must be greater than or equal to zero");
/*    */     }
/* 66 */     if (min > max) {
/* 67 */       throw new IllegalArgumentException("maximum length must not be greater than minimum length");
/*    */     }
/* 69 */     this.min = min;
/* 70 */     this.max = max;
/*    */   }
/*    */ 
/*    */   public boolean accept()
/*    */   {
/* 75 */     int len = this.termAtt.length();
/* 76 */     return (len >= this.min) && (len <= this.max);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.LengthFilter
 * JD-Core Version:    0.6.2
 */