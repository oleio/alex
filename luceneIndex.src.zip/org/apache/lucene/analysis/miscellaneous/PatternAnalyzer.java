/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.StopAnalyzer;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ @Deprecated
/*     */ public final class PatternAnalyzer extends Analyzer
/*     */ {
/*  71 */   public static final Pattern NON_WORD_PATTERN = Pattern.compile("\\W+");
/*     */ 
/*  74 */   public static final Pattern WHITESPACE_PATTERN = Pattern.compile("\\s+");
/*     */ 
/*  76 */   private static final CharArraySet EXTENDED_ENGLISH_STOP_WORDS = CharArraySet.unmodifiableSet(new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(new String[] { "a", "about", "above", "across", "adj", "after", "afterwards", "again", "against", "albeit", "all", "almost", "alone", "along", "already", "also", "although", "always", "among", "amongst", "an", "and", "another", "any", "anyhow", "anyone", "anything", "anywhere", "are", "around", "as", "at", "be", "became", "because", "become", "becomes", "becoming", "been", "before", "beforehand", "behind", "being", "below", "beside", "besides", "between", "beyond", "both", "but", "by", "can", "cannot", "co", "could", "down", "during", "each", "eg", "either", "else", "elsewhere", "enough", "etc", "even", "ever", "every", "everyone", "everything", "everywhere", "except", "few", "first", "for", "former", "formerly", "from", "further", "had", "has", "have", "he", "hence", "her", "here", "hereafter", "hereby", "herein", "hereupon", "hers", "herself", "him", "himself", "his", "how", "however", "i", "ie", "if", "in", "inc", "indeed", "into", "is", "it", "its", "itself", "last", "latter", "latterly", "least", "less", "ltd", "many", "may", "me", "meanwhile", "might", "more", "moreover", "most", "mostly", "much", "must", "my", "myself", "namely", "neither", "never", "nevertheless", "next", "no", "nobody", "none", "noone", "nor", "not", "nothing", "now", "nowhere", "of", "off", "often", "on", "once one", "only", "onto", "or", "other", "others", "otherwise", "our", "ours", "ourselves", "out", "over", "own", "per", "perhaps", "rather", "s", "same", "seem", "seemed", "seeming", "seems", "several", "she", "should", "since", "so", "some", "somehow", "someone", "something", "sometime", "sometimes", "somewhere", "still", "such", "t", "than", "that", "the", "their", "them", "themselves", "then", "thence", "there", "thereafter", "thereby", "therefor", "therein", "thereupon", "these", "they", "this", "those", "though", "through", "throughout", "thru", "thus", "to", "together", "too", "toward", "towards", "under", "until", "up", "upon", "us", "very", "via", "was", "we", "well", "were", "what", "whatever", "whatsoever", "when", "whence", "whenever", "whensoever", "where", "whereafter", "whereas", "whereat", "whereby", "wherefrom", "wherein", "whereinto", "whereof", "whereon", "whereto", "whereunto", "whereupon", "wherever", "wherewith", "whether", "which", "whichever", "whichsoever", "while", "whilst", "whither", "who", "whoever", "whole", "whom", "whomever", "whomsoever", "whose", "whosoever", "why", "will", "with", "within", "without", "would", "xsubj", "xcal", "xauthor", "xother ", "xnote", "yet", "you", "your", "yours", "yourself", "yourselves" }), true));
/*     */ 
/* 126 */   public static final PatternAnalyzer DEFAULT_ANALYZER = new PatternAnalyzer(Version.LUCENE_CURRENT, NON_WORD_PATTERN, true, StopAnalyzer.ENGLISH_STOP_WORDS_SET);
/*     */ 
/* 136 */   public static final PatternAnalyzer EXTENDED_ANALYZER = new PatternAnalyzer(Version.LUCENE_CURRENT, NON_WORD_PATTERN, true, EXTENDED_ENGLISH_STOP_WORDS);
/*     */   private final Pattern pattern;
/*     */   private final boolean toLowerCase;
/*     */   private final CharArraySet stopWords;
/*     */   private final Version matchVersion;
/*     */ 
/*     */   public PatternAnalyzer(Version matchVersion, Pattern pattern, boolean toLowerCase, CharArraySet stopWords)
/*     */   {
/* 165 */     if (pattern == null) {
/* 166 */       throw new IllegalArgumentException("pattern must not be null");
/*     */     }
/* 168 */     if (eqPattern(NON_WORD_PATTERN, pattern)) pattern = NON_WORD_PATTERN;
/* 169 */     else if (eqPattern(WHITESPACE_PATTERN, pattern)) pattern = WHITESPACE_PATTERN;
/*     */ 
/* 171 */     if ((stopWords != null) && (stopWords.size() == 0)) stopWords = null;
/*     */ 
/* 173 */     this.pattern = pattern;
/* 174 */     this.toLowerCase = toLowerCase;
/* 175 */     this.stopWords = stopWords;
/* 176 */     this.matchVersion = matchVersion;
/*     */   }
/*     */ 
/*     */   public Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader, String text)
/*     */   {
/* 194 */     if (reader == null) {
/* 195 */       reader = new FastStringReader(text);
/*     */     }
/* 197 */     if (this.pattern == NON_WORD_PATTERN)
/* 198 */       return new Analyzer.TokenStreamComponents(new FastStringTokenizer(reader, true, this.toLowerCase, this.stopWords));
/* 199 */     if (this.pattern == WHITESPACE_PATTERN) {
/* 200 */       return new Analyzer.TokenStreamComponents(new FastStringTokenizer(reader, false, this.toLowerCase, this.stopWords));
/*     */     }
/*     */ 
/* 203 */     Tokenizer tokenizer = new PatternTokenizer(reader, this.pattern, this.toLowerCase);
/* 204 */     TokenStream result = this.stopWords != null ? new StopFilter(this.matchVersion, tokenizer, this.stopWords) : tokenizer;
/* 205 */     return new Analyzer.TokenStreamComponents(tokenizer, result);
/*     */   }
/*     */ 
/*     */   public Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 221 */     return createComponents(fieldName, reader, null);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 233 */     if (this == other) return true;
/* 234 */     if ((this == DEFAULT_ANALYZER) && (other == EXTENDED_ANALYZER)) return false;
/* 235 */     if ((other == DEFAULT_ANALYZER) && (this == EXTENDED_ANALYZER)) return false;
/*     */ 
/* 237 */     if ((other instanceof PatternAnalyzer)) {
/* 238 */       PatternAnalyzer p2 = (PatternAnalyzer)other;
/* 239 */       return (this.toLowerCase == p2.toLowerCase) && (eqPattern(this.pattern, p2.pattern)) && (eq(this.stopWords, p2.stopWords));
/*     */     }
/*     */ 
/* 244 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 254 */     if (this == DEFAULT_ANALYZER) return -1218418418;
/* 255 */     if (this == EXTENDED_ANALYZER) return 1303507063;
/*     */ 
/* 257 */     int h = 1;
/* 258 */     h = 31 * h + this.pattern.pattern().hashCode();
/* 259 */     h = 31 * h + this.pattern.flags();
/* 260 */     h = 31 * h + (this.toLowerCase ? 1231 : 1237);
/* 261 */     h = 31 * h + (this.stopWords != null ? this.stopWords.hashCode() : 0);
/* 262 */     return h;
/*     */   }
/*     */ 
/*     */   private static boolean eq(Object o1, Object o2)
/*     */   {
/* 267 */     return (o1 == o2) || ((o1 != null) && (o1.equals(o2)));
/*     */   }
/*     */ 
/*     */   private static boolean eqPattern(Pattern p1, Pattern p2)
/*     */   {
/* 272 */     return (p1 == p2) || ((p1.flags() == p2.flags()) && (p1.pattern().equals(p2.pattern())));
/*     */   }
/*     */ 
/*     */   private static String toString(Reader input)
/*     */     throws IOException
/*     */   {
/* 282 */     if ((input instanceof FastStringReader)) {
/* 283 */       return ((FastStringReader)input).getString();
/*     */     }
/*     */     try
/*     */     {
/* 287 */       int len = 256;
/* 288 */       char[] buffer = new char[len];
/* 289 */       char[] output = new char[len];
/*     */ 
/* 291 */       len = 0;
/*     */       int n;
/*     */       char[] tmp;
/* 293 */       while ((n = input.read(buffer)) >= 0) {
/* 294 */         if (len + n > output.length) {
/* 295 */           tmp = new char[Math.max(output.length << 1, len + n)];
/* 296 */           System.arraycopy(output, 0, tmp, 0, len);
/* 297 */           System.arraycopy(buffer, 0, tmp, len, n);
/* 298 */           buffer = output;
/* 299 */           output = tmp;
/*     */         } else {
/* 301 */           System.arraycopy(buffer, 0, output, len, n);
/*     */         }
/* 303 */         len += n;
/*     */       }
/*     */ 
/* 306 */       return new String(output, 0, len);
/*     */     } finally {
/* 308 */       input.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class FastStringReader extends StringReader
/*     */   {
/*     */     private final String s;
/*     */ 
/*     */     FastStringReader(String s)
/*     */     {
/* 514 */       super();
/* 515 */       this.s = s;
/*     */     }
/*     */ 
/*     */     String getString() {
/* 519 */       return this.s;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class FastStringTokenizer extends Tokenizer
/*     */   {
/*     */     private String str;
/*     */     private int pos;
/*     */     private final boolean isLetter;
/*     */     private final boolean toLowerCase;
/*     */     private final CharArraySet stopWords;
/* 408 */     private static final Locale locale = Locale.getDefault();
/* 409 */     private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 410 */     private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */ 
/*     */     public FastStringTokenizer(Reader input, boolean isLetter, boolean toLowerCase, CharArraySet stopWords) {
/* 413 */       super();
/* 414 */       this.isLetter = isLetter;
/* 415 */       this.toLowerCase = toLowerCase;
/* 416 */       this.stopWords = stopWords;
/*     */     }
/*     */ 
/*     */     public boolean incrementToken()
/*     */     {
/* 421 */       if (this.str == null) {
/* 422 */         throw new IllegalStateException("Consumer did not call reset()."); } clearAttributes();
/*     */ 
/* 426 */       String s = this.str;
/* 427 */       int len = s.length();
/* 428 */       int i = this.pos;
/* 429 */       boolean letter = this.isLetter;
/*     */ 
/* 431 */       int start = 0;
/*     */       String text;
/*     */       do { text = null;
/* 436 */         while ((i < len) && (!isTokenChar(s.charAt(i), letter))) {
/* 437 */           i++;
/*     */         }
/*     */ 
/* 440 */         if (i < len) {
/* 441 */           start = i;
/* 442 */           while ((i < len) && (isTokenChar(s.charAt(i), letter))) {
/* 443 */             i++;
/*     */           }
/*     */ 
/* 446 */           text = s.substring(start, i);
/* 447 */           if (this.toLowerCase) text = text.toLowerCase(locale);
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 459 */       while ((text != null) && (isStopWord(text)));
/*     */ 
/* 461 */       this.pos = i;
/* 462 */       if (text == null)
/*     */       {
/* 464 */         return false;
/*     */       }
/* 466 */       this.termAtt.setEmpty().append(text);
/* 467 */       this.offsetAtt.setOffset(correctOffset(start), correctOffset(i));
/* 468 */       return true;
/*     */     }
/*     */ 
/*     */     public final void end() throws IOException
/*     */     {
/* 473 */       super.end();
/*     */ 
/* 475 */       int finalOffset = this.str.length();
/* 476 */       this.offsetAtt.setOffset(correctOffset(finalOffset), correctOffset(finalOffset));
/*     */     }
/*     */ 
/*     */     private boolean isTokenChar(char c, boolean isLetter) {
/* 480 */       return !Character.isWhitespace(c) ? true : isLetter ? Character.isLetter(c) : false;
/*     */     }
/*     */ 
/*     */     private boolean isStopWord(String text) {
/* 484 */       return (this.stopWords != null) && (this.stopWords.contains(text));
/*     */     }
/*     */ 
/*     */     public void close() throws IOException
/*     */     {
/* 489 */       super.close();
/* 490 */       this.str = null;
/*     */     }
/*     */ 
/*     */     public void reset() throws IOException
/*     */     {
/* 495 */       super.reset();
/* 496 */       this.str = PatternAnalyzer.toString(this.input);
/* 497 */       this.pos = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class PatternTokenizer extends Tokenizer
/*     */   {
/*     */     private final Pattern pattern;
/*     */     private String str;
/*     */     private final boolean toLowerCase;
/*     */     private Matcher matcher;
/* 326 */     private int pos = 0;
/* 327 */     private boolean initialized = false;
/* 328 */     private static final Locale locale = Locale.getDefault();
/* 329 */     private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 330 */     private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */ 
/*     */     public PatternTokenizer(Reader input, Pattern pattern, boolean toLowerCase) {
/* 333 */       super();
/* 334 */       this.pattern = pattern;
/* 335 */       this.matcher = pattern.matcher("");
/* 336 */       this.toLowerCase = toLowerCase;
/*     */     }
/*     */ 
/*     */     public final boolean incrementToken()
/*     */     {
/* 341 */       if (!this.initialized) {
/* 342 */         throw new IllegalStateException("Consumer did not call reset().");
/*     */       }
/* 344 */       if (this.matcher == null) return false;
/* 345 */       clearAttributes();
/*     */       while (true) {
/* 347 */         int start = this.pos;
/*     */ 
/* 349 */         boolean isMatch = this.matcher.find();
/*     */         int end;
/* 350 */         if (isMatch) {
/* 351 */           int end = this.matcher.start();
/* 352 */           this.pos = this.matcher.end();
/*     */         } else {
/* 354 */           end = this.str.length();
/* 355 */           this.matcher = null;
/*     */         }
/*     */ 
/* 358 */         if (start != end) {
/* 359 */           String text = this.str.substring(start, end);
/* 360 */           if (this.toLowerCase) text = text.toLowerCase(locale);
/* 361 */           this.termAtt.setEmpty().append(text);
/* 362 */           this.offsetAtt.setOffset(correctOffset(start), correctOffset(end));
/* 363 */           return true;
/*     */         }
/* 365 */         if (!isMatch) return false; 
/*     */       }
/*     */     }
/*     */ 
/*     */     public final void end()
/*     */       throws IOException
/*     */     {
/* 371 */       super.end();
/*     */ 
/* 373 */       int finalOffset = correctOffset(this.str.length());
/* 374 */       this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */     }
/*     */ 
/*     */     public void close() throws IOException
/*     */     {
/* 379 */       super.close();
/* 380 */       this.initialized = false;
/*     */     }
/*     */ 
/*     */     public void reset() throws IOException
/*     */     {
/* 385 */       super.reset();
/* 386 */       this.str = PatternAnalyzer.toString(this.input);
/* 387 */       this.matcher = this.pattern.matcher(this.str);
/* 388 */       this.pos = 0;
/* 389 */       this.initialized = true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.PatternAnalyzer
 * JD-Core Version:    0.6.2
 */