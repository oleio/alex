/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.util.ArrayUtil;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ import org.apache.lucene.util.InPlaceMergeSorter;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class WordDelimiterFilter extends TokenFilter
/*     */ {
/*     */   public static final int LOWER = 1;
/*     */   public static final int UPPER = 2;
/*     */   public static final int DIGIT = 4;
/*     */   public static final int SUBWORD_DELIM = 8;
/*     */   public static final int ALPHA = 3;
/*     */   public static final int ALPHANUM = 7;
/*     */   public static final int GENERATE_WORD_PARTS = 1;
/*     */   public static final int GENERATE_NUMBER_PARTS = 2;
/*     */   public static final int CATENATE_WORDS = 4;
/*     */   public static final int CATENATE_NUMBERS = 8;
/*     */   public static final int CATENATE_ALL = 16;
/*     */   public static final int PRESERVE_ORIGINAL = 32;
/*     */   public static final int SPLIT_ON_CASE_CHANGE = 64;
/*     */   public static final int SPLIT_ON_NUMERICS = 128;
/*     */   public static final int STEM_ENGLISH_POSSESSIVE = 256;
/*     */   final CharArraySet protWords;
/*     */   private final int flags;
/* 167 */   private final CharTermAttribute termAttribute = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 168 */   private final OffsetAttribute offsetAttribute = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 169 */   private final PositionIncrementAttribute posIncAttribute = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/* 170 */   private final TypeAttribute typeAttribute = (TypeAttribute)addAttribute(TypeAttribute.class);
/*     */   private final WordDelimiterIterator iterator;
/* 176 */   private final WordDelimiterConcatenation concat = new WordDelimiterConcatenation();
/*     */ 
/* 178 */   private int lastConcatCount = 0;
/*     */ 
/* 181 */   private final WordDelimiterConcatenation concatAll = new WordDelimiterConcatenation();
/*     */ 
/* 184 */   private int accumPosInc = 0;
/*     */ 
/* 186 */   private char[] savedBuffer = new char[1024];
/*     */   private int savedStartOffset;
/*     */   private int savedEndOffset;
/*     */   private String savedType;
/* 190 */   private boolean hasSavedState = false;
/*     */ 
/* 193 */   private boolean hasIllegalOffsets = false;
/*     */ 
/* 196 */   private boolean hasOutputToken = false;
/*     */ 
/* 199 */   private boolean hasOutputFollowingOriginal = false;
/*     */ 
/* 377 */   private AttributeSource.State[] buffered = new AttributeSource.State[8];
/* 378 */   private int[] startOff = new int[8];
/* 379 */   private int[] posInc = new int[8];
/* 380 */   private int bufferedLen = 0;
/* 381 */   private int bufferedPos = 0;
/*     */   private boolean first;
/* 410 */   final OffsetSorter sorter = new OffsetSorter(null);
/*     */ 
/*     */   public WordDelimiterFilter(Version matchVersion, TokenStream in, byte[] charTypeTable, int configurationFlags, CharArraySet protWords)
/*     */   {
/* 210 */     super(in);
/* 211 */     if (!matchVersion.onOrAfter(Version.LUCENE_48)) {
/* 212 */       throw new IllegalArgumentException("This class only works with Lucene 4.8+. To emulate the old (broken) behavior of WordDelimiterFilter, use Lucene47WordDelimiterFilter");
/*     */     }
/* 214 */     this.flags = configurationFlags;
/* 215 */     this.protWords = protWords;
/* 216 */     this.iterator = new WordDelimiterIterator(charTypeTable, has(64), has(128), has(256));
/*     */   }
/*     */ 
/*     */   public WordDelimiterFilter(Version matchVersion, TokenStream in, int configurationFlags, CharArraySet protWords)
/*     */   {
/* 229 */     this(matchVersion, in, WordDelimiterIterator.DEFAULT_WORD_DELIM_TABLE, configurationFlags, protWords);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*     */     while (true)
/* 235 */       if (!this.hasSavedState)
/*     */       {
/* 237 */         if (!this.input.incrementToken()) {
/* 238 */           return false;
/*     */         }
/*     */ 
/* 241 */         int termLength = this.termAttribute.length();
/* 242 */         char[] termBuffer = this.termAttribute.buffer();
/*     */ 
/* 244 */         this.accumPosInc += this.posIncAttribute.getPositionIncrement();
/*     */ 
/* 246 */         this.iterator.setText(termBuffer, termLength);
/* 247 */         this.iterator.next();
/*     */ 
/* 250 */         if (((this.iterator.current == 0) && (this.iterator.end == termLength)) || ((this.protWords != null) && (this.protWords.contains(termBuffer, 0, termLength))))
/*     */         {
/* 252 */           this.posIncAttribute.setPositionIncrement(this.accumPosInc);
/* 253 */           this.accumPosInc = 0;
/* 254 */           this.first = false;
/* 255 */           return true;
/*     */         }
/*     */ 
/* 259 */         if ((this.iterator.end == -1) && (!has(32)))
/*     */         {
/* 262 */           if ((this.posIncAttribute.getPositionIncrement() == 1) && (!this.first)) {
/* 263 */             this.accumPosInc -= 1;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 268 */           saveState();
/*     */ 
/* 270 */           this.hasOutputToken = false;
/* 271 */           this.hasOutputFollowingOriginal = (!has(32));
/* 272 */           this.lastConcatCount = 0;
/*     */ 
/* 274 */           if (has(32)) {
/* 275 */             this.posIncAttribute.setPositionIncrement(this.accumPosInc);
/* 276 */             this.accumPosInc = 0;
/* 277 */             this.first = false;
/* 278 */             return true;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 283 */       else if (this.iterator.end == -1) {
/* 284 */         if ((!this.concat.isEmpty()) && 
/* 285 */           (flushConcatenation(this.concat))) {
/* 286 */           buffer();
/*     */         }
/* 291 */         else if (!this.concatAll.isEmpty())
/*     */         {
/* 293 */           if (this.concatAll.subwordCount > this.lastConcatCount) {
/* 294 */             this.concatAll.writeAndClear();
/* 295 */             buffer();
/*     */           }
/*     */           else {
/* 298 */             this.concatAll.clear();
/*     */           }
/*     */         } else {
/* 301 */           if (this.bufferedPos < this.bufferedLen) {
/* 302 */             if (this.bufferedPos == 0) {
/* 303 */               this.sorter.sort(0, this.bufferedLen);
/*     */             }
/* 305 */             clearAttributes();
/* 306 */             restoreState(this.buffered[(this.bufferedPos++)]);
/* 307 */             if ((this.first) && (this.posIncAttribute.getPositionIncrement() == 0))
/*     */             {
/* 309 */               this.posIncAttribute.setPositionIncrement(1);
/*     */             }
/* 311 */             this.first = false;
/* 312 */             return true;
/*     */           }
/*     */ 
/* 316 */           this.bufferedPos = (this.bufferedLen = 0);
/* 317 */           this.hasSavedState = false;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 322 */         if (this.iterator.isSingleWord()) {
/* 323 */           generatePart(true);
/* 324 */           this.iterator.next();
/* 325 */           this.first = false;
/* 326 */           return true;
/*     */         }
/*     */ 
/* 329 */         int wordType = this.iterator.type();
/*     */ 
/* 332 */         if ((!this.concat.isEmpty()) && ((this.concat.type & wordType) == 0)) {
/* 333 */           if (flushConcatenation(this.concat)) {
/* 334 */             this.hasOutputToken = false;
/* 335 */             buffer();
/*     */           }
/*     */           else {
/* 338 */             this.hasOutputToken = false;
/*     */           }
/*     */         }
/*     */         else {
/* 342 */           if (shouldConcatenate(wordType)) {
/* 343 */             if (this.concat.isEmpty()) {
/* 344 */               this.concat.type = wordType;
/*     */             }
/* 346 */             concatenate(this.concat);
/*     */           }
/*     */ 
/* 350 */           if (has(16)) {
/* 351 */             concatenate(this.concatAll);
/*     */           }
/*     */ 
/* 355 */           if (shouldGenerateParts(wordType)) {
/* 356 */             generatePart(false);
/* 357 */             buffer();
/*     */           }
/*     */ 
/* 360 */           this.iterator.next();
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException {
/* 366 */     super.reset();
/* 367 */     this.hasSavedState = false;
/* 368 */     this.concat.clear();
/* 369 */     this.concatAll.clear();
/* 370 */     this.accumPosInc = (this.bufferedPos = this.bufferedLen = 0);
/* 371 */     this.first = true;
/*     */   }
/*     */ 
/*     */   private void buffer()
/*     */   {
/* 413 */     if (this.bufferedLen == this.buffered.length) {
/* 414 */       int newSize = ArrayUtil.oversize(this.bufferedLen + 1, 8);
/* 415 */       this.buffered = ((AttributeSource.State[])Arrays.copyOf(this.buffered, newSize));
/* 416 */       this.startOff = Arrays.copyOf(this.startOff, newSize);
/* 417 */       this.posInc = Arrays.copyOf(this.posInc, newSize);
/*     */     }
/* 419 */     this.startOff[this.bufferedLen] = this.offsetAttribute.startOffset();
/* 420 */     this.posInc[this.bufferedLen] = this.posIncAttribute.getPositionIncrement();
/* 421 */     this.buffered[this.bufferedLen] = captureState();
/* 422 */     this.bufferedLen += 1;
/*     */   }
/*     */ 
/*     */   private void saveState()
/*     */   {
/* 430 */     this.savedStartOffset = this.offsetAttribute.startOffset();
/* 431 */     this.savedEndOffset = this.offsetAttribute.endOffset();
/*     */ 
/* 433 */     this.hasIllegalOffsets = (this.savedEndOffset - this.savedStartOffset != this.termAttribute.length());
/* 434 */     this.savedType = this.typeAttribute.type();
/*     */ 
/* 436 */     if (this.savedBuffer.length < this.termAttribute.length()) {
/* 437 */       this.savedBuffer = new char[ArrayUtil.oversize(this.termAttribute.length(), 2)];
/*     */     }
/*     */ 
/* 440 */     System.arraycopy(this.termAttribute.buffer(), 0, this.savedBuffer, 0, this.termAttribute.length());
/* 441 */     this.iterator.text = this.savedBuffer;
/*     */ 
/* 443 */     this.hasSavedState = true;
/*     */   }
/*     */ 
/*     */   private boolean flushConcatenation(WordDelimiterConcatenation concatenation)
/*     */   {
/* 453 */     this.lastConcatCount = concatenation.subwordCount;
/* 454 */     if ((concatenation.subwordCount != 1) || (!shouldGenerateParts(concatenation.type))) {
/* 455 */       concatenation.writeAndClear();
/* 456 */       return true;
/*     */     }
/* 458 */     concatenation.clear();
/* 459 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean shouldConcatenate(int wordType)
/*     */   {
/* 469 */     return ((has(4)) && (isAlpha(wordType))) || ((has(8)) && (isDigit(wordType)));
/*     */   }
/*     */ 
/*     */   private boolean shouldGenerateParts(int wordType)
/*     */   {
/* 479 */     return ((has(1)) && (isAlpha(wordType))) || ((has(2)) && (isDigit(wordType)));
/*     */   }
/*     */ 
/*     */   private void concatenate(WordDelimiterConcatenation concatenation)
/*     */   {
/* 488 */     if (concatenation.isEmpty()) {
/* 489 */       concatenation.startOffset = (this.savedStartOffset + this.iterator.current);
/*     */     }
/* 491 */     concatenation.append(this.savedBuffer, this.iterator.current, this.iterator.end - this.iterator.current);
/* 492 */     concatenation.endOffset = (this.savedStartOffset + this.iterator.end);
/*     */   }
/*     */ 
/*     */   private void generatePart(boolean isSingleWord)
/*     */   {
/* 501 */     clearAttributes();
/* 502 */     this.termAttribute.copyBuffer(this.savedBuffer, this.iterator.current, this.iterator.end - this.iterator.current);
/*     */ 
/* 504 */     int startOffset = this.savedStartOffset + this.iterator.current;
/* 505 */     int endOffset = this.savedStartOffset + this.iterator.end;
/*     */ 
/* 507 */     if (this.hasIllegalOffsets)
/*     */     {
/* 510 */       if ((isSingleWord) && (startOffset <= this.savedEndOffset))
/* 511 */         this.offsetAttribute.setOffset(startOffset, this.savedEndOffset);
/*     */       else
/* 513 */         this.offsetAttribute.setOffset(this.savedStartOffset, this.savedEndOffset);
/*     */     }
/*     */     else {
/* 516 */       this.offsetAttribute.setOffset(startOffset, endOffset);
/*     */     }
/* 518 */     this.posIncAttribute.setPositionIncrement(position(false));
/* 519 */     this.typeAttribute.setType(this.savedType);
/*     */   }
/*     */ 
/*     */   private int position(boolean inject)
/*     */   {
/* 529 */     int posInc = this.accumPosInc;
/*     */ 
/* 531 */     if (this.hasOutputToken) {
/* 532 */       this.accumPosInc = 0;
/* 533 */       return inject ? 0 : Math.max(1, posInc);
/*     */     }
/*     */ 
/* 536 */     this.hasOutputToken = true;
/*     */ 
/* 538 */     if (!this.hasOutputFollowingOriginal)
/*     */     {
/* 540 */       this.hasOutputFollowingOriginal = true;
/* 541 */       return 0;
/*     */     }
/*     */ 
/* 544 */     this.accumPosInc = 0;
/* 545 */     return Math.max(1, posInc);
/*     */   }
/*     */ 
/*     */   static boolean isAlpha(int type)
/*     */   {
/* 555 */     return (type & 0x3) != 0;
/*     */   }
/*     */ 
/*     */   static boolean isDigit(int type)
/*     */   {
/* 565 */     return (type & 0x4) != 0;
/*     */   }
/*     */ 
/*     */   static boolean isSubwordDelim(int type)
/*     */   {
/* 575 */     return (type & 0x8) != 0;
/*     */   }
/*     */ 
/*     */   static boolean isUpper(int type)
/*     */   {
/* 585 */     return (type & 0x2) != 0;
/*     */   }
/*     */ 
/*     */   private boolean has(int flag)
/*     */   {
/* 595 */     return (this.flags & flag) != 0;
/*     */   }
/*     */ 
/*     */   final class WordDelimiterConcatenation
/*     */   {
/* 604 */     final StringBuilder buffer = new StringBuilder();
/*     */     int startOffset;
/*     */     int endOffset;
/*     */     int type;
/*     */     int subwordCount;
/*     */ 
/*     */     WordDelimiterConcatenation()
/*     */     {
/*     */     }
/*     */ 
/*     */     void append(char[] text, int offset, int length)
/*     */     {
/* 618 */       this.buffer.append(text, offset, length);
/* 619 */       this.subwordCount += 1;
/*     */     }
/*     */ 
/*     */     void write()
/*     */     {
/* 626 */       WordDelimiterFilter.this.clearAttributes();
/* 627 */       if (WordDelimiterFilter.this.termAttribute.length() < this.buffer.length()) {
/* 628 */         WordDelimiterFilter.this.termAttribute.resizeBuffer(this.buffer.length());
/*     */       }
/* 630 */       char[] termbuffer = WordDelimiterFilter.this.termAttribute.buffer();
/*     */ 
/* 632 */       this.buffer.getChars(0, this.buffer.length(), termbuffer, 0);
/* 633 */       WordDelimiterFilter.this.termAttribute.setLength(this.buffer.length());
/*     */ 
/* 635 */       if (WordDelimiterFilter.this.hasIllegalOffsets) {
/* 636 */         WordDelimiterFilter.this.offsetAttribute.setOffset(WordDelimiterFilter.this.savedStartOffset, WordDelimiterFilter.this.savedEndOffset);
/*     */       }
/*     */       else {
/* 639 */         WordDelimiterFilter.this.offsetAttribute.setOffset(this.startOffset, this.endOffset);
/*     */       }
/* 641 */       WordDelimiterFilter.this.posIncAttribute.setPositionIncrement(WordDelimiterFilter.this.position(true));
/* 642 */       WordDelimiterFilter.this.typeAttribute.setType(WordDelimiterFilter.this.savedType);
/* 643 */       WordDelimiterFilter.this.accumPosInc = 0;
/*     */     }
/*     */ 
/*     */     boolean isEmpty()
/*     */     {
/* 652 */       return this.buffer.length() == 0;
/*     */     }
/*     */ 
/*     */     void clear()
/*     */     {
/* 659 */       this.buffer.setLength(0);
/* 660 */       this.startOffset = (this.endOffset = this.type = this.subwordCount = 0);
/*     */     }
/*     */ 
/*     */     void writeAndClear()
/*     */     {
/* 667 */       write();
/* 668 */       clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class OffsetSorter extends InPlaceMergeSorter
/*     */   {
/*     */     private OffsetSorter()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected int compare(int i, int j)
/*     */     {
/* 387 */       int cmp = Integer.compare(WordDelimiterFilter.this.startOff[i], WordDelimiterFilter.this.startOff[j]);
/* 388 */       if (cmp == 0) {
/* 389 */         cmp = Integer.compare(WordDelimiterFilter.this.posInc[j], WordDelimiterFilter.this.posInc[i]);
/*     */       }
/* 391 */       return cmp;
/*     */     }
/*     */ 
/*     */     protected void swap(int i, int j)
/*     */     {
/* 396 */       AttributeSource.State tmp = WordDelimiterFilter.this.buffered[i];
/* 397 */       WordDelimiterFilter.this.buffered[i] = WordDelimiterFilter.this.buffered[j];
/* 398 */       WordDelimiterFilter.this.buffered[j] = tmp;
/*     */ 
/* 400 */       int tmp2 = WordDelimiterFilter.this.startOff[i];
/* 401 */       WordDelimiterFilter.this.startOff[i] = WordDelimiterFilter.this.startOff[j];
/* 402 */       WordDelimiterFilter.this.startOff[j] = tmp2;
/*     */ 
/* 404 */       tmp2 = WordDelimiterFilter.this.posInc[i];
/* 405 */       WordDelimiterFilter.this.posInc[i] = WordDelimiterFilter.this.posInc[j];
/* 406 */       WordDelimiterFilter.this.posInc[j] = tmp2;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.WordDelimiterFilter
 * JD-Core Version:    0.6.2
 */