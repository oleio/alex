/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class ScandinavianFoldingFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public ScandinavianFoldingFilterFactory(Map<String, String> args)
/*    */   {
/* 38 */     super(args);
/* 39 */     if (!args.isEmpty())
/* 40 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ScandinavianFoldingFilter create(TokenStream input)
/*    */   {
/* 46 */     return new ScandinavianFoldingFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.ScandinavianFoldingFilterFactory
 * JD-Core Version:    0.6.2
 */