/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class HyphenatedWordsFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public HyphenatedWordsFilterFactory(Map<String, String> args)
/*    */   {
/* 40 */     super(args);
/* 41 */     if (!args.isEmpty())
/* 42 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public HyphenatedWordsFilter create(TokenStream input)
/*    */   {
/* 48 */     return new HyphenatedWordsFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.HyphenatedWordsFilterFactory
 * JD-Core Version:    0.6.2
 */