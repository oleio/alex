/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.util.CharArraySet;
/*    */ import org.apache.lucene.analysis.util.FilteringTokenFilter;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class KeepWordFilter extends FilteringTokenFilter
/*    */ {
/*    */   private final CharArraySet words;
/* 34 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */ 
/*    */   @Deprecated
/*    */   public KeepWordFilter(Version version, boolean enablePositionIncrements, TokenStream in, CharArraySet words)
/*    */   {
/* 39 */     super(version, enablePositionIncrements, in);
/* 40 */     this.words = words;
/*    */   }
/*    */ 
/*    */   public KeepWordFilter(Version version, TokenStream in, CharArraySet words)
/*    */   {
/* 52 */     super(version, in);
/* 53 */     this.words = words;
/*    */   }
/*    */ 
/*    */   public boolean accept()
/*    */   {
/* 58 */     return this.words.contains(this.termAtt.buffer(), 0, this.termAtt.length());
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.KeepWordFilter
 * JD-Core Version:    0.6.2
 */