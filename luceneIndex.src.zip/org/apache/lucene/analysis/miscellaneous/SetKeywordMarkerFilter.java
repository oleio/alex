/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.util.CharArraySet;
/*    */ 
/*    */ public final class SetKeywordMarkerFilter extends KeywordMarkerFilter
/*    */ {
/* 29 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */   private final CharArraySet keywordSet;
/*    */ 
/*    */   public SetKeywordMarkerFilter(TokenStream in, CharArraySet keywordSet)
/*    */   {
/* 43 */     super(in);
/* 44 */     this.keywordSet = keywordSet;
/*    */   }
/*    */ 
/*    */   protected boolean isKeyword()
/*    */   {
/* 49 */     return this.keywordSet.contains(this.termAtt.buffer(), 0, this.termAtt.length());
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter
 * JD-Core Version:    0.6.2
 */