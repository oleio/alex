/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class TruncateTokenFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public static final String PREFIX_LENGTH_KEY = "prefixLength";
/*    */   private final byte prefixLength;
/*    */ 
/*    */   public TruncateTokenFilterFactory(Map<String, String> args)
/*    */   {
/* 46 */     super(args);
/* 47 */     this.prefixLength = Byte.parseByte(get(args, "prefixLength", "5"));
/* 48 */     if (this.prefixLength < 1)
/* 49 */       throw new IllegalArgumentException("prefixLength parameter must be a positive number: " + this.prefixLength);
/* 50 */     if (!args.isEmpty())
/* 51 */       throw new IllegalArgumentException("Unknown parameter(s): " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 57 */     return new TruncateTokenFilter(input, this.prefixLength);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.TruncateTokenFilterFactory
 * JD-Core Version:    0.6.2
 */