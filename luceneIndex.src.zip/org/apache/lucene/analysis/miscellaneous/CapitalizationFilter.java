/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ 
/*     */ public final class CapitalizationFilter extends TokenFilter
/*     */ {
/*     */   public static final int DEFAULT_MAX_WORD_COUNT = 2147483647;
/*     */   public static final int DEFAULT_MAX_TOKEN_LENGTH = 2147483647;
/*     */   private final boolean onlyFirstWord;
/*     */   private final CharArraySet keep;
/*     */   private final boolean forceFirstLetter;
/*     */   private final Collection<char[]> okPrefix;
/*     */   private final int minWordLength;
/*     */   private final int maxWordCount;
/*     */   private final int maxTokenLength;
/*  48 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */ 
/*     */   public CapitalizationFilter(TokenStream in)
/*     */   {
/*  57 */     this(in, true, null, true, null, 0, 2147483647, 2147483647);
/*     */   }
/*     */ 
/*     */   public CapitalizationFilter(TokenStream in, boolean onlyFirstWord, CharArraySet keep, boolean forceFirstLetter, Collection<char[]> okPrefix, int minWordLength, int maxWordCount, int maxTokenLength)
/*     */   {
/*  76 */     super(in);
/*  77 */     this.onlyFirstWord = onlyFirstWord;
/*  78 */     this.keep = keep;
/*  79 */     this.forceFirstLetter = forceFirstLetter;
/*  80 */     this.okPrefix = okPrefix;
/*  81 */     this.minWordLength = minWordLength;
/*  82 */     this.maxWordCount = maxWordCount;
/*  83 */     this.maxTokenLength = maxTokenLength;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  88 */     if (!this.input.incrementToken()) return false;
/*     */ 
/*  90 */     char[] termBuffer = this.termAtt.buffer();
/*  91 */     int termBufferLength = this.termAtt.length();
/*  92 */     char[] backup = null;
/*     */ 
/*  94 */     if (this.maxWordCount < 2147483647)
/*     */     {
/*  96 */       backup = new char[termBufferLength];
/*  97 */       System.arraycopy(termBuffer, 0, backup, 0, termBufferLength);
/*     */     }
/*     */ 
/* 100 */     if (termBufferLength < this.maxTokenLength) {
/* 101 */       int wordCount = 0;
/*     */ 
/* 103 */       int lastWordStart = 0;
/* 104 */       for (int i = 0; i < termBufferLength; i++) {
/* 105 */         char c = termBuffer[i];
/* 106 */         if ((c <= ' ') || (c == '.')) {
/* 107 */           int len = i - lastWordStart;
/* 108 */           if (len > 0) {
/* 109 */             processWord(termBuffer, lastWordStart, len, wordCount++);
/* 110 */             lastWordStart = i + 1;
/* 111 */             i++;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 117 */       if (lastWordStart < termBufferLength) {
/* 118 */         processWord(termBuffer, lastWordStart, termBufferLength - lastWordStart, wordCount++);
/*     */       }
/*     */ 
/* 121 */       if (wordCount > this.maxWordCount) {
/* 122 */         this.termAtt.copyBuffer(backup, 0, termBufferLength);
/*     */       }
/*     */     }
/*     */ 
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */   private void processWord(char[] buffer, int offset, int length, int wordCount) {
/* 130 */     if (length < 1) {
/* 131 */       return;
/*     */     }
/*     */ 
/* 134 */     if ((this.onlyFirstWord) && (wordCount > 0)) {
/* 135 */       for (int i = 0; i < length; i++) {
/* 136 */         buffer[(offset + i)] = Character.toLowerCase(buffer[(offset + i)]);
/*     */       }
/*     */ 
/* 139 */       return;
/*     */     }
/*     */ 
/* 142 */     if ((this.keep != null) && (this.keep.contains(buffer, offset, length))) {
/* 143 */       if ((wordCount == 0) && (this.forceFirstLetter)) {
/* 144 */         buffer[offset] = Character.toUpperCase(buffer[offset]);
/*     */       }
/* 146 */       return;
/*     */     }
/*     */ 
/* 149 */     if (length < this.minWordLength) {
/* 150 */       return;
/*     */     }
/*     */ 
/* 153 */     if (this.okPrefix != null) {
/* 154 */       for (char[] prefix : this.okPrefix) {
/* 155 */         if (length >= prefix.length) {
/* 156 */           boolean match = true;
/* 157 */           for (int i = 0; i < prefix.length; i++) {
/* 158 */             if (prefix[i] != buffer[(offset + i)]) {
/* 159 */               match = false;
/* 160 */               break;
/*     */             }
/*     */           }
/* 163 */           if (match == true) {
/* 164 */             return;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 174 */     buffer[offset] = Character.toUpperCase(buffer[offset]);
/*     */ 
/* 176 */     for (int i = 1; i < length; i++)
/* 177 */       buffer[(offset + i)] = Character.toLowerCase(buffer[(offset + i)]);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.CapitalizationFilter
 * JD-Core Version:    0.6.2
 */