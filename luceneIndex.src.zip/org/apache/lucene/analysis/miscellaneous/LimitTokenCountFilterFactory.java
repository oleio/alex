/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class LimitTokenCountFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public static final String MAX_TOKEN_COUNT_KEY = "maxTokenCount";
/*    */   public static final String CONSUME_ALL_TOKENS_KEY = "consumeAllTokens";
/*    */   final int maxTokenCount;
/*    */   final boolean consumeAllTokens;
/*    */ 
/*    */   public LimitTokenCountFilterFactory(Map<String, String> args)
/*    */   {
/* 47 */     super(args);
/* 48 */     this.maxTokenCount = requireInt(args, "maxTokenCount");
/* 49 */     this.consumeAllTokens = getBoolean(args, "consumeAllTokens", false);
/* 50 */     if (!args.isEmpty())
/* 51 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 57 */     return new LimitTokenCountFilter(input, this.maxTokenCount, this.consumeAllTokens);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.LimitTokenCountFilterFactory
 * JD-Core Version:    0.6.2
 */