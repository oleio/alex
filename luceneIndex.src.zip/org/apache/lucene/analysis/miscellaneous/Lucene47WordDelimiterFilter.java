/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.util.ArrayUtil;
/*     */ 
/*     */ @Deprecated
/*     */ public final class Lucene47WordDelimiterFilter extends TokenFilter
/*     */ {
/*     */   public static final int LOWER = 1;
/*     */   public static final int UPPER = 2;
/*     */   public static final int DIGIT = 4;
/*     */   public static final int SUBWORD_DELIM = 8;
/*     */   public static final int ALPHA = 3;
/*     */   public static final int ALPHANUM = 7;
/*     */   public static final int GENERATE_WORD_PARTS = 1;
/*     */   public static final int GENERATE_NUMBER_PARTS = 2;
/*     */   public static final int CATENATE_WORDS = 4;
/*     */   public static final int CATENATE_NUMBERS = 8;
/*     */   public static final int CATENATE_ALL = 16;
/*     */   public static final int PRESERVE_ORIGINAL = 32;
/*     */   public static final int SPLIT_ON_CASE_CHANGE = 64;
/*     */   public static final int SPLIT_ON_NUMERICS = 128;
/*     */   public static final int STEM_ENGLISH_POSSESSIVE = 256;
/*     */   final CharArraySet protWords;
/*     */   private final int flags;
/* 118 */   private final CharTermAttribute termAttribute = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 119 */   private final OffsetAttribute offsetAttribute = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 120 */   private final PositionIncrementAttribute posIncAttribute = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/* 121 */   private final TypeAttribute typeAttribute = (TypeAttribute)addAttribute(TypeAttribute.class);
/*     */   private final WordDelimiterIterator iterator;
/* 127 */   private final WordDelimiterConcatenation concat = new WordDelimiterConcatenation();
/*     */ 
/* 129 */   private int lastConcatCount = 0;
/*     */ 
/* 132 */   private final WordDelimiterConcatenation concatAll = new WordDelimiterConcatenation();
/*     */ 
/* 135 */   private int accumPosInc = 0;
/*     */ 
/* 137 */   private char[] savedBuffer = new char[1024];
/*     */   private int savedStartOffset;
/*     */   private int savedEndOffset;
/*     */   private String savedType;
/* 141 */   private boolean hasSavedState = false;
/*     */ 
/* 144 */   private boolean hasIllegalOffsets = false;
/*     */ 
/* 147 */   private boolean hasOutputToken = false;
/*     */ 
/* 150 */   private boolean hasOutputFollowingOriginal = false;
/*     */ 
/*     */   public Lucene47WordDelimiterFilter(TokenStream in, byte[] charTypeTable, int configurationFlags, CharArraySet protWords)
/*     */   {
/* 161 */     super(in);
/* 162 */     this.flags = configurationFlags;
/* 163 */     this.protWords = protWords;
/* 164 */     this.iterator = new WordDelimiterIterator(charTypeTable, has(64), has(128), has(256));
/*     */   }
/*     */ 
/*     */   public Lucene47WordDelimiterFilter(TokenStream in, int configurationFlags, CharArraySet protWords)
/*     */   {
/* 177 */     this(in, WordDelimiterIterator.DEFAULT_WORD_DELIM_TABLE, configurationFlags, protWords);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*     */     while (true)
/* 183 */       if (!this.hasSavedState)
/*     */       {
/* 185 */         if (!this.input.incrementToken()) {
/* 186 */           return false;
/*     */         }
/*     */ 
/* 189 */         int termLength = this.termAttribute.length();
/* 190 */         char[] termBuffer = this.termAttribute.buffer();
/*     */ 
/* 192 */         this.accumPosInc += this.posIncAttribute.getPositionIncrement();
/*     */ 
/* 194 */         this.iterator.setText(termBuffer, termLength);
/* 195 */         this.iterator.next();
/*     */ 
/* 198 */         if (((this.iterator.current == 0) && (this.iterator.end == termLength)) || ((this.protWords != null) && (this.protWords.contains(termBuffer, 0, termLength))))
/*     */         {
/* 200 */           this.posIncAttribute.setPositionIncrement(this.accumPosInc);
/* 201 */           this.accumPosInc = 0;
/* 202 */           return true;
/*     */         }
/*     */ 
/* 206 */         if ((this.iterator.end == -1) && (!has(32)))
/*     */         {
/* 208 */           if (this.posIncAttribute.getPositionIncrement() == 1) {
/* 209 */             this.accumPosInc -= 1;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 214 */           saveState();
/*     */ 
/* 216 */           this.hasOutputToken = false;
/* 217 */           this.hasOutputFollowingOriginal = (!has(32));
/* 218 */           this.lastConcatCount = 0;
/*     */ 
/* 220 */           if (has(32)) {
/* 221 */             this.posIncAttribute.setPositionIncrement(this.accumPosInc);
/* 222 */             this.accumPosInc = 0;
/* 223 */             return true;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 228 */       else if (this.iterator.end == -1) {
/* 229 */         if ((!this.concat.isEmpty()) && 
/* 230 */           (flushConcatenation(this.concat))) {
/* 231 */           return true;
/*     */         }
/*     */ 
/* 235 */         if (!this.concatAll.isEmpty())
/*     */         {
/* 237 */           if (this.concatAll.subwordCount > this.lastConcatCount) {
/* 238 */             this.concatAll.writeAndClear();
/* 239 */             return true;
/*     */           }
/* 241 */           this.concatAll.clear();
/*     */         }
/*     */ 
/* 245 */         this.hasSavedState = false;
/*     */       }
/*     */       else
/*     */       {
/* 250 */         if (this.iterator.isSingleWord()) {
/* 251 */           generatePart(true);
/* 252 */           this.iterator.next();
/* 253 */           return true;
/*     */         }
/*     */ 
/* 256 */         int wordType = this.iterator.type();
/*     */ 
/* 259 */         if ((!this.concat.isEmpty()) && ((this.concat.type & wordType) == 0)) {
/* 260 */           if (flushConcatenation(this.concat)) {
/* 261 */             this.hasOutputToken = false;
/* 262 */             return true;
/*     */           }
/* 264 */           this.hasOutputToken = false;
/*     */         }
/*     */ 
/* 268 */         if (shouldConcatenate(wordType)) {
/* 269 */           if (this.concat.isEmpty()) {
/* 270 */             this.concat.type = wordType;
/*     */           }
/* 272 */           concatenate(this.concat);
/*     */         }
/*     */ 
/* 276 */         if (has(16)) {
/* 277 */           concatenate(this.concatAll);
/*     */         }
/*     */ 
/* 281 */         if (shouldGenerateParts(wordType)) {
/* 282 */           generatePart(false);
/* 283 */           this.iterator.next();
/* 284 */           return true;
/*     */         }
/*     */ 
/* 287 */         this.iterator.next();
/*     */       }
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 296 */     super.reset();
/* 297 */     this.hasSavedState = false;
/* 298 */     this.concat.clear();
/* 299 */     this.concatAll.clear();
/* 300 */     this.accumPosInc = 0;
/*     */   }
/*     */ 
/*     */   private void saveState()
/*     */   {
/* 310 */     this.savedStartOffset = this.offsetAttribute.startOffset();
/* 311 */     this.savedEndOffset = this.offsetAttribute.endOffset();
/*     */ 
/* 313 */     this.hasIllegalOffsets = (this.savedEndOffset - this.savedStartOffset != this.termAttribute.length());
/* 314 */     this.savedType = this.typeAttribute.type();
/*     */ 
/* 316 */     if (this.savedBuffer.length < this.termAttribute.length()) {
/* 317 */       this.savedBuffer = new char[ArrayUtil.oversize(this.termAttribute.length(), 2)];
/*     */     }
/*     */ 
/* 320 */     System.arraycopy(this.termAttribute.buffer(), 0, this.savedBuffer, 0, this.termAttribute.length());
/* 321 */     this.iterator.text = this.savedBuffer;
/*     */ 
/* 323 */     this.hasSavedState = true;
/*     */   }
/*     */ 
/*     */   private boolean flushConcatenation(WordDelimiterConcatenation concatenation)
/*     */   {
/* 333 */     this.lastConcatCount = concatenation.subwordCount;
/* 334 */     if ((concatenation.subwordCount != 1) || (!shouldGenerateParts(concatenation.type))) {
/* 335 */       concatenation.writeAndClear();
/* 336 */       return true;
/*     */     }
/* 338 */     concatenation.clear();
/* 339 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean shouldConcatenate(int wordType)
/*     */   {
/* 349 */     return ((has(4)) && (isAlpha(wordType))) || ((has(8)) && (isDigit(wordType)));
/*     */   }
/*     */ 
/*     */   private boolean shouldGenerateParts(int wordType)
/*     */   {
/* 359 */     return ((has(1)) && (isAlpha(wordType))) || ((has(2)) && (isDigit(wordType)));
/*     */   }
/*     */ 
/*     */   private void concatenate(WordDelimiterConcatenation concatenation)
/*     */   {
/* 368 */     if (concatenation.isEmpty()) {
/* 369 */       concatenation.startOffset = (this.savedStartOffset + this.iterator.current);
/*     */     }
/* 371 */     concatenation.append(this.savedBuffer, this.iterator.current, this.iterator.end - this.iterator.current);
/* 372 */     concatenation.endOffset = (this.savedStartOffset + this.iterator.end);
/*     */   }
/*     */ 
/*     */   private void generatePart(boolean isSingleWord)
/*     */   {
/* 381 */     clearAttributes();
/* 382 */     this.termAttribute.copyBuffer(this.savedBuffer, this.iterator.current, this.iterator.end - this.iterator.current);
/*     */ 
/* 384 */     int startOffset = this.savedStartOffset + this.iterator.current;
/* 385 */     int endOffset = this.savedStartOffset + this.iterator.end;
/*     */ 
/* 387 */     if (this.hasIllegalOffsets)
/*     */     {
/* 390 */       if ((isSingleWord) && (startOffset <= this.savedEndOffset))
/* 391 */         this.offsetAttribute.setOffset(startOffset, this.savedEndOffset);
/*     */       else
/* 393 */         this.offsetAttribute.setOffset(this.savedStartOffset, this.savedEndOffset);
/*     */     }
/*     */     else {
/* 396 */       this.offsetAttribute.setOffset(startOffset, endOffset);
/*     */     }
/* 398 */     this.posIncAttribute.setPositionIncrement(position(false));
/* 399 */     this.typeAttribute.setType(this.savedType);
/*     */   }
/*     */ 
/*     */   private int position(boolean inject)
/*     */   {
/* 409 */     int posInc = this.accumPosInc;
/*     */ 
/* 411 */     if (this.hasOutputToken) {
/* 412 */       this.accumPosInc = 0;
/* 413 */       return inject ? 0 : Math.max(1, posInc);
/*     */     }
/*     */ 
/* 416 */     this.hasOutputToken = true;
/*     */ 
/* 418 */     if (!this.hasOutputFollowingOriginal)
/*     */     {
/* 420 */       this.hasOutputFollowingOriginal = true;
/* 421 */       return 0;
/*     */     }
/*     */ 
/* 424 */     this.accumPosInc = 0;
/* 425 */     return Math.max(1, posInc);
/*     */   }
/*     */ 
/*     */   static boolean isAlpha(int type)
/*     */   {
/* 435 */     return (type & 0x3) != 0;
/*     */   }
/*     */ 
/*     */   static boolean isDigit(int type)
/*     */   {
/* 445 */     return (type & 0x4) != 0;
/*     */   }
/*     */ 
/*     */   static boolean isSubwordDelim(int type)
/*     */   {
/* 455 */     return (type & 0x8) != 0;
/*     */   }
/*     */ 
/*     */   static boolean isUpper(int type)
/*     */   {
/* 465 */     return (type & 0x2) != 0;
/*     */   }
/*     */ 
/*     */   private boolean has(int flag)
/*     */   {
/* 475 */     return (this.flags & flag) != 0;
/*     */   }
/*     */ 
/*     */   final class WordDelimiterConcatenation
/*     */   {
/* 484 */     final StringBuilder buffer = new StringBuilder();
/*     */     int startOffset;
/*     */     int endOffset;
/*     */     int type;
/*     */     int subwordCount;
/*     */ 
/*     */     WordDelimiterConcatenation()
/*     */     {
/*     */     }
/*     */ 
/*     */     void append(char[] text, int offset, int length)
/*     */     {
/* 498 */       this.buffer.append(text, offset, length);
/* 499 */       this.subwordCount += 1;
/*     */     }
/*     */ 
/*     */     void write()
/*     */     {
/* 506 */       Lucene47WordDelimiterFilter.this.clearAttributes();
/* 507 */       if (Lucene47WordDelimiterFilter.this.termAttribute.length() < this.buffer.length()) {
/* 508 */         Lucene47WordDelimiterFilter.this.termAttribute.resizeBuffer(this.buffer.length());
/*     */       }
/* 510 */       char[] termbuffer = Lucene47WordDelimiterFilter.this.termAttribute.buffer();
/*     */ 
/* 512 */       this.buffer.getChars(0, this.buffer.length(), termbuffer, 0);
/* 513 */       Lucene47WordDelimiterFilter.this.termAttribute.setLength(this.buffer.length());
/*     */ 
/* 515 */       if (Lucene47WordDelimiterFilter.this.hasIllegalOffsets) {
/* 516 */         Lucene47WordDelimiterFilter.this.offsetAttribute.setOffset(Lucene47WordDelimiterFilter.this.savedStartOffset, Lucene47WordDelimiterFilter.this.savedEndOffset);
/*     */       }
/*     */       else {
/* 519 */         Lucene47WordDelimiterFilter.this.offsetAttribute.setOffset(this.startOffset, this.endOffset);
/*     */       }
/* 521 */       Lucene47WordDelimiterFilter.this.posIncAttribute.setPositionIncrement(Lucene47WordDelimiterFilter.this.position(true));
/* 522 */       Lucene47WordDelimiterFilter.this.typeAttribute.setType(Lucene47WordDelimiterFilter.this.savedType);
/* 523 */       Lucene47WordDelimiterFilter.this.accumPosInc = 0;
/*     */     }
/*     */ 
/*     */     boolean isEmpty()
/*     */     {
/* 532 */       return this.buffer.length() == 0;
/*     */     }
/*     */ 
/*     */     void clear()
/*     */     {
/* 539 */       this.buffer.setLength(0);
/* 540 */       this.startOffset = (this.endOffset = this.type = this.subwordCount = 0);
/*     */     }
/*     */ 
/*     */     void writeAndClear()
/*     */     {
/* 547 */       write();
/* 548 */       clear();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.Lucene47WordDelimiterFilter
 * JD-Core Version:    0.6.2
 */