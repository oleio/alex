/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import org.apache.lucene.analysis.Analyzer;
/*    */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*    */ import org.apache.lucene.analysis.AnalyzerWrapper;
/*    */ 
/*    */ public final class LimitTokenCountAnalyzer extends AnalyzerWrapper
/*    */ {
/*    */   private final Analyzer delegate;
/*    */   private final int maxTokenCount;
/*    */   private final boolean consumeAllTokens;
/*    */ 
/*    */   public LimitTokenCountAnalyzer(Analyzer delegate, int maxTokenCount)
/*    */   {
/* 40 */     this(delegate, maxTokenCount, false);
/*    */   }
/*    */ 
/*    */   public LimitTokenCountAnalyzer(Analyzer delegate, int maxTokenCount, boolean consumeAllTokens)
/*    */   {
/* 49 */     super(delegate.getReuseStrategy());
/* 50 */     this.delegate = delegate;
/* 51 */     this.maxTokenCount = maxTokenCount;
/* 52 */     this.consumeAllTokens = consumeAllTokens;
/*    */   }
/*    */ 
/*    */   protected Analyzer getWrappedAnalyzer(String fieldName)
/*    */   {
/* 57 */     return this.delegate;
/*    */   }
/*    */ 
/*    */   protected Analyzer.TokenStreamComponents wrapComponents(String fieldName, Analyzer.TokenStreamComponents components)
/*    */   {
/* 62 */     return new Analyzer.TokenStreamComponents(components.getTokenizer(), new LimitTokenCountFilter(components.getTokenStream(), this.maxTokenCount, this.consumeAllTokens));
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 68 */     return "LimitTokenCountAnalyzer(" + this.delegate.toString() + ", maxTokenCount=" + this.maxTokenCount + ", consumeAllTokens=" + this.consumeAllTokens + ")";
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.LimitTokenCountAnalyzer
 * JD-Core Version:    0.6.2
 */