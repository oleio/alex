/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ 
/*    */ public final class PatternKeywordMarkerFilter extends KeywordMarkerFilter
/*    */ {
/* 32 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */   private final Matcher matcher;
/*    */ 
/*    */   public PatternKeywordMarkerFilter(TokenStream in, Pattern pattern)
/*    */   {
/* 46 */     super(in);
/* 47 */     this.matcher = pattern.matcher("");
/*    */   }
/*    */ 
/*    */   protected boolean isKeyword()
/*    */   {
/* 52 */     this.matcher.reset(this.termAtt);
/* 53 */     return this.matcher.matches();
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.PatternKeywordMarkerFilter
 * JD-Core Version:    0.6.2
 */