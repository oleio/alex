/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ 
/*     */ public final class HyphenatedWordsFilter extends TokenFilter
/*     */ {
/*  57 */   private final CharTermAttribute termAttribute = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  58 */   private final OffsetAttribute offsetAttribute = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */ 
/*  60 */   private final StringBuilder hyphenated = new StringBuilder();
/*     */   private AttributeSource.State savedState;
/*  62 */   private boolean exhausted = false;
/*  63 */   private int lastEndOffset = 0;
/*     */ 
/*     */   public HyphenatedWordsFilter(TokenStream in)
/*     */   {
/*  71 */     super(in);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*  79 */     while ((!this.exhausted) && (this.input.incrementToken())) {
/*  80 */       char[] term = this.termAttribute.buffer();
/*  81 */       int termLength = this.termAttribute.length();
/*  82 */       this.lastEndOffset = this.offsetAttribute.endOffset();
/*     */ 
/*  84 */       if ((termLength > 0) && (term[(termLength - 1)] == '-'))
/*     */       {
/*  87 */         if (this.savedState == null) {
/*  88 */           this.savedState = captureState();
/*     */         }
/*  90 */         this.hyphenated.append(term, 0, termLength - 1); } else {
/*  91 */         if (this.savedState == null)
/*     */         {
/*  93 */           return true;
/*     */         }
/*     */ 
/*  96 */         this.hyphenated.append(term, 0, termLength);
/*  97 */         unhyphenate();
/*  98 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 102 */     this.exhausted = true;
/*     */ 
/* 104 */     if (this.savedState != null)
/*     */     {
/* 107 */       this.hyphenated.append('-');
/* 108 */       unhyphenate();
/* 109 */       return true;
/*     */     }
/*     */ 
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 120 */     super.reset();
/* 121 */     this.hyphenated.setLength(0);
/* 122 */     this.savedState = null;
/* 123 */     this.exhausted = false;
/* 124 */     this.lastEndOffset = 0;
/*     */   }
/*     */ 
/*     */   private void unhyphenate()
/*     */   {
/* 133 */     restoreState(this.savedState);
/* 134 */     this.savedState = null;
/*     */ 
/* 136 */     char[] term = this.termAttribute.buffer();
/* 137 */     int length = this.hyphenated.length();
/* 138 */     if (length > this.termAttribute.length()) {
/* 139 */       term = this.termAttribute.resizeBuffer(length);
/*     */     }
/*     */ 
/* 142 */     this.hyphenated.getChars(0, length, term, 0);
/* 143 */     this.termAttribute.setLength(length);
/* 144 */     this.offsetAttribute.setOffset(this.offsetAttribute.startOffset(), this.lastEndOffset);
/* 145 */     this.hyphenated.setLength(0);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.HyphenatedWordsFilter
 * JD-Core Version:    0.6.2
 */