/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.util.StemmerUtil;
/*     */ 
/*     */ public final class ScandinavianFoldingFilter extends TokenFilter
/*     */ {
/*  57 */   private final CharTermAttribute charTermAttribute = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */   private static final char AA = 'Å';
/*     */   private static final char aa = 'å';
/*     */   private static final char AE = 'Æ';
/*     */   private static final char ae = 'æ';
/*     */   private static final char AE_se = 'Ä';
/*     */   private static final char ae_se = 'ä';
/*     */   private static final char OE = 'Ø';
/*     */   private static final char oe = 'ø';
/*     */   private static final char OE_se = 'Ö';
/*     */   private static final char oe_se = 'ö';
/*     */ 
/*     */   public ScandinavianFoldingFilter(TokenStream input)
/*     */   {
/*  54 */     super(input);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*  73 */     if (!this.input.incrementToken()) {
/*  74 */       return false;
/*     */     }
/*     */ 
/*  77 */     char[] buffer = this.charTermAttribute.buffer();
/*  78 */     int length = this.charTermAttribute.length();
/*     */ 
/*  82 */     for (int i = 0; i < length; i++)
/*     */     {
/*  84 */       if ((buffer[i] == 'å') || (buffer[i] == 'ä') || (buffer[i] == 'æ'))
/*     */       {
/*  88 */         buffer[i] = 'a';
/*     */       }
/*  90 */       else if ((buffer[i] == 'Å') || (buffer[i] == 'Ä') || (buffer[i] == 'Æ'))
/*     */       {
/*  94 */         buffer[i] = 'A';
/*     */       }
/*  96 */       else if ((buffer[i] == 'ø') || (buffer[i] == 'ö'))
/*     */       {
/*  99 */         buffer[i] = 'o';
/*     */       }
/* 101 */       else if ((buffer[i] == 'Ø') || (buffer[i] == 'Ö'))
/*     */       {
/* 104 */         buffer[i] = 'O';
/*     */       }
/* 106 */       else if (length - 1 > i)
/*     */       {
/* 108 */         if (((buffer[i] == 'a') || (buffer[i] == 'A')) && ((buffer[(i + 1)] == 'a') || (buffer[(i + 1)] == 'A') || (buffer[(i + 1)] == 'e') || (buffer[(i + 1)] == 'E') || (buffer[(i + 1)] == 'o') || (buffer[(i + 1)] == 'O')))
/*     */         {
/* 117 */           length = StemmerUtil.delete(buffer, i + 1, length);
/*     */         }
/* 119 */         else if (((buffer[i] == 'o') || (buffer[i] == 'O')) && ((buffer[(i + 1)] == 'e') || (buffer[(i + 1)] == 'E') || (buffer[(i + 1)] == 'o') || (buffer[(i + 1)] == 'O')))
/*     */         {
/* 126 */           length = StemmerUtil.delete(buffer, i + 1, length);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 132 */     this.charTermAttribute.setLength(length);
/*     */ 
/* 135 */     return true;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.ScandinavianFoldingFilter
 * JD-Core Version:    0.6.2
 */