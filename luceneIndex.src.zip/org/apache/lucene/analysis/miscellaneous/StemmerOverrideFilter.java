/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*     */ import org.apache.lucene.util.BytesRef;
/*     */ import org.apache.lucene.util.BytesRefHash;
/*     */ import org.apache.lucene.util.CharsRef;
/*     */ import org.apache.lucene.util.IntsRef;
/*     */ import org.apache.lucene.util.UnicodeUtil;
/*     */ import org.apache.lucene.util.fst.Builder;
/*     */ import org.apache.lucene.util.fst.ByteSequenceOutputs;
/*     */ import org.apache.lucene.util.fst.FST;
/*     */ import org.apache.lucene.util.fst.FST.Arc;
/*     */ import org.apache.lucene.util.fst.FST.BytesReader;
/*     */ import org.apache.lucene.util.fst.FST.INPUT_TYPE;
/*     */ import org.apache.lucene.util.fst.Outputs;
/*     */ 
/*     */ public final class StemmerOverrideFilter extends TokenFilter
/*     */ {
/*     */   private final StemmerOverrideMap stemmerOverrideMap;
/*  44 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  45 */   private final KeywordAttribute keywordAtt = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/*     */   private final FST.BytesReader fstReader;
/*  47 */   private final FST.Arc<BytesRef> scratchArc = new FST.Arc();
/*  48 */   private final CharsRef spare = new CharsRef();
/*     */ 
/*     */   public StemmerOverrideFilter(TokenStream input, StemmerOverrideMap stemmerOverrideMap)
/*     */   {
/*  59 */     super(input);
/*  60 */     this.stemmerOverrideMap = stemmerOverrideMap;
/*  61 */     this.fstReader = stemmerOverrideMap.getBytesReader();
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  66 */     if (this.input.incrementToken()) {
/*  67 */       if (this.fstReader == null)
/*     */       {
/*  69 */         return true;
/*     */       }
/*  71 */       if (!this.keywordAtt.isKeyword()) {
/*  72 */         BytesRef stem = this.stemmerOverrideMap.get(this.termAtt.buffer(), this.termAtt.length(), this.scratchArc, this.fstReader);
/*  73 */         if (stem != null) {
/*  74 */           char[] buffer = this.spare.chars = this.termAtt.buffer();
/*  75 */           UnicodeUtil.UTF8toUTF16(stem.bytes, stem.offset, stem.length, this.spare);
/*  76 */           if (this.spare.chars != buffer) {
/*  77 */             this.termAtt.copyBuffer(this.spare.chars, this.spare.offset, this.spare.length);
/*     */           }
/*  79 */           this.termAtt.setLength(this.spare.length);
/*  80 */           this.keywordAtt.setKeyword(true);
/*     */         }
/*     */       }
/*  83 */       return true;
/*     */     }
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */   public static class Builder
/*     */   {
/* 146 */     private final BytesRefHash hash = new BytesRefHash();
/* 147 */     private final BytesRef spare = new BytesRef();
/* 148 */     private final ArrayList<CharSequence> outputValues = new ArrayList();
/*     */     private final boolean ignoreCase;
/* 150 */     private final CharsRef charsSpare = new CharsRef();
/*     */ 
/*     */     public Builder()
/*     */     {
/* 156 */       this(false);
/*     */     }
/*     */ 
/*     */     public Builder(boolean ignoreCase)
/*     */     {
/* 164 */       this.ignoreCase = ignoreCase;
/*     */     }
/*     */ 
/*     */     public boolean add(CharSequence input, CharSequence output)
/*     */     {
/* 175 */       int length = input.length();
/* 176 */       if (this.ignoreCase)
/*     */       {
/* 178 */         this.charsSpare.grow(length);
/* 179 */         char[] buffer = this.charsSpare.chars;
/* 180 */         for (int i = 0; i < length; ) {
/* 181 */           i += Character.toChars(Character.toLowerCase(Character.codePointAt(input, i)), buffer, i);
/*     */         }
/*     */ 
/* 185 */         UnicodeUtil.UTF16toUTF8(buffer, 0, length, this.spare);
/*     */       } else {
/* 187 */         UnicodeUtil.UTF16toUTF8(input, 0, length, this.spare);
/*     */       }
/* 189 */       if (this.hash.add(this.spare) >= 0) {
/* 190 */         this.outputValues.add(output);
/* 191 */         return true;
/*     */       }
/* 193 */       return false;
/*     */     }
/*     */ 
/*     */     public StemmerOverrideFilter.StemmerOverrideMap build()
/*     */       throws IOException
/*     */     {
/* 202 */       ByteSequenceOutputs outputs = ByteSequenceOutputs.getSingleton();
/* 203 */       Builder builder = new Builder(FST.INPUT_TYPE.BYTE4, outputs);
/*     */ 
/* 205 */       int[] sort = this.hash.sort(BytesRef.getUTF8SortedAsUnicodeComparator());
/* 206 */       IntsRef intsSpare = new IntsRef();
/* 207 */       int size = this.hash.size();
/* 208 */       for (int i = 0; i < size; i++) {
/* 209 */         int id = sort[i];
/* 210 */         BytesRef bytesRef = this.hash.get(id, this.spare);
/* 211 */         UnicodeUtil.UTF8toUTF32(bytesRef, intsSpare);
/* 212 */         builder.add(intsSpare, new BytesRef((CharSequence)this.outputValues.get(id)));
/*     */       }
/* 214 */       return new StemmerOverrideFilter.StemmerOverrideMap(builder.finish(), this.ignoreCase);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class StemmerOverrideMap
/*     */   {
/*     */     private final FST<BytesRef> fst;
/*     */     private final boolean ignoreCase;
/*     */ 
/*     */     public StemmerOverrideMap(FST<BytesRef> fst, boolean ignoreCase)
/*     */     {
/* 104 */       this.fst = fst;
/* 105 */       this.ignoreCase = ignoreCase;
/*     */     }
/*     */ 
/*     */     public FST.BytesReader getBytesReader()
/*     */     {
/* 112 */       if (this.fst == null) {
/* 113 */         return null;
/*     */       }
/* 115 */       return this.fst.getBytesReader();
/*     */     }
/*     */ 
/*     */     public BytesRef get(char[] buffer, int bufferLen, FST.Arc<BytesRef> scratchArc, FST.BytesReader fstReader)
/*     */       throws IOException
/*     */     {
/* 123 */       BytesRef pendingOutput = (BytesRef)this.fst.outputs.getNoOutput();
/* 124 */       BytesRef matchOutput = null;
/* 125 */       int bufUpto = 0;
/* 126 */       this.fst.getFirstArc(scratchArc);
/* 127 */       while (bufUpto < bufferLen) {
/* 128 */         int codePoint = Character.codePointAt(buffer, bufUpto, bufferLen);
/* 129 */         if (this.fst.findTargetArc(this.ignoreCase ? Character.toLowerCase(codePoint) : codePoint, scratchArc, scratchArc, fstReader) == null) {
/* 130 */           return null;
/*     */         }
/* 132 */         pendingOutput = (BytesRef)this.fst.outputs.add(pendingOutput, scratchArc.output);
/* 133 */         bufUpto += Character.charCount(codePoint);
/*     */       }
/* 135 */       if (scratchArc.isFinal()) {
/* 136 */         matchOutput = (BytesRef)this.fst.outputs.add(pendingOutput, scratchArc.nextFinalOutput);
/*     */       }
/* 138 */       return matchOutput;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.StemmerOverrideFilter
 * JD-Core Version:    0.6.2
 */