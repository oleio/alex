/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.ResourceLoader;
/*     */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*     */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public class WordDelimiterFilterFactory extends TokenFilterFactory
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   public static final String PROTECTED_TOKENS = "protected";
/*     */   public static final String TYPES = "types";
/*     */   private final String wordFiles;
/*     */   private final String types;
/*     */   private final int flags;
/*  60 */   byte[] typeTable = null;
/*  61 */   private CharArraySet protectedWords = null;
/*     */ 
/* 131 */   private static Pattern typePattern = Pattern.compile("(.*)\\s*=>\\s*(.*)\\s*$");
/*     */ 
/* 175 */   char[] out = new char[256];
/*     */ 
/*     */   public WordDelimiterFilterFactory(Map<String, String> args)
/*     */   {
/*  65 */     super(args);
/*  66 */     assureMatchVersion();
/*  67 */     int flags = 0;
/*  68 */     if (getInt(args, "generateWordParts", 1) != 0) {
/*  69 */       flags |= 1;
/*     */     }
/*  71 */     if (getInt(args, "generateNumberParts", 1) != 0) {
/*  72 */       flags |= 2;
/*     */     }
/*  74 */     if (getInt(args, "catenateWords", 0) != 0) {
/*  75 */       flags |= 4;
/*     */     }
/*  77 */     if (getInt(args, "catenateNumbers", 0) != 0) {
/*  78 */       flags |= 8;
/*     */     }
/*  80 */     if (getInt(args, "catenateAll", 0) != 0) {
/*  81 */       flags |= 16;
/*     */     }
/*  83 */     if (getInt(args, "splitOnCaseChange", 1) != 0) {
/*  84 */       flags |= 64;
/*     */     }
/*  86 */     if (getInt(args, "splitOnNumerics", 1) != 0) {
/*  87 */       flags |= 128;
/*     */     }
/*  89 */     if (getInt(args, "preserveOriginal", 0) != 0) {
/*  90 */       flags |= 32;
/*     */     }
/*  92 */     if (getInt(args, "stemEnglishPossessive", 1) != 0) {
/*  93 */       flags |= 256;
/*     */     }
/*  95 */     this.wordFiles = get(args, "protected");
/*  96 */     this.types = get(args, "types");
/*  97 */     this.flags = flags;
/*  98 */     if (!args.isEmpty())
/*  99 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*     */   }
/*     */ 
/*     */   public void inform(ResourceLoader loader)
/*     */     throws IOException
/*     */   {
/* 105 */     if (this.wordFiles != null) {
/* 106 */       this.protectedWords = getWordSet(loader, this.wordFiles, false);
/*     */     }
/* 108 */     if (this.types != null) {
/* 109 */       List files = splitFileNames(this.types);
/* 110 */       List wlist = new ArrayList();
/* 111 */       for (String file : files) {
/* 112 */         List lines = getLines(loader, file.trim());
/* 113 */         wlist.addAll(lines);
/*     */       }
/* 115 */       this.typeTable = parseTypes(wlist);
/*     */     }
/*     */   }
/*     */ 
/*     */   public TokenFilter create(TokenStream input)
/*     */   {
/* 121 */     if (this.luceneMatchVersion.onOrAfter(Version.LUCENE_48)) {
/* 122 */       return new WordDelimiterFilter(this.luceneMatchVersion, input, this.typeTable == null ? WordDelimiterIterator.DEFAULT_WORD_DELIM_TABLE : this.typeTable, this.flags, this.protectedWords);
/*     */     }
/*     */ 
/* 125 */     return new Lucene47WordDelimiterFilter(input, this.typeTable == null ? WordDelimiterIterator.DEFAULT_WORD_DELIM_TABLE : this.typeTable, this.flags, this.protectedWords);
/*     */   }
/*     */ 
/*     */   private byte[] parseTypes(List<String> rules)
/*     */   {
/* 135 */     SortedMap typeMap = new TreeMap();
/* 136 */     for (String rule : rules) {
/* 137 */       Matcher m = typePattern.matcher(rule);
/* 138 */       if (!m.find())
/* 139 */         throw new IllegalArgumentException("Invalid Mapping Rule : [" + rule + "]");
/* 140 */       String lhs = parseString(m.group(1).trim());
/* 141 */       Byte rhs = parseType(m.group(2).trim());
/* 142 */       if (lhs.length() != 1)
/* 143 */         throw new IllegalArgumentException("Invalid Mapping Rule : [" + rule + "]. Only a single character is allowed.");
/* 144 */       if (rhs == null)
/* 145 */         throw new IllegalArgumentException("Invalid Mapping Rule : [" + rule + "]. Illegal type.");
/* 146 */       typeMap.put(Character.valueOf(lhs.charAt(0)), rhs);
/*     */     }
/*     */ 
/* 150 */     byte[] types = new byte[Math.max(((Character)typeMap.lastKey()).charValue() + '\001', WordDelimiterIterator.DEFAULT_WORD_DELIM_TABLE.length)];
/* 151 */     for (int i = 0; i < types.length; i++)
/* 152 */       types[i] = WordDelimiterIterator.getType(i);
/* 153 */     for (Map.Entry mapping : typeMap.entrySet())
/* 154 */       types[((Character)mapping.getKey()).charValue()] = ((Byte)mapping.getValue()).byteValue();
/* 155 */     return types;
/*     */   }
/*     */ 
/*     */   private Byte parseType(String s) {
/* 159 */     if (s.equals("LOWER"))
/* 160 */       return Byte.valueOf((byte)1);
/* 161 */     if (s.equals("UPPER"))
/* 162 */       return Byte.valueOf((byte)2);
/* 163 */     if (s.equals("ALPHA"))
/* 164 */       return Byte.valueOf((byte)3);
/* 165 */     if (s.equals("DIGIT"))
/* 166 */       return Byte.valueOf((byte)4);
/* 167 */     if (s.equals("ALPHANUM"))
/* 168 */       return Byte.valueOf((byte)7);
/* 169 */     if (s.equals("SUBWORD_DELIM")) {
/* 170 */       return Byte.valueOf((byte)8);
/*     */     }
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */   private String parseString(String s)
/*     */   {
/* 178 */     int readPos = 0;
/* 179 */     int len = s.length();
/* 180 */     int writePos = 0;
/* 181 */     while (readPos < len) {
/* 182 */       char c = s.charAt(readPos++);
/* 183 */       if (c == '\\') {
/* 184 */         if (readPos >= len)
/* 185 */           throw new IllegalArgumentException("Invalid escaped char in [" + s + "]");
/* 186 */         c = s.charAt(readPos++);
/* 187 */         switch (c) { case '\\':
/* 188 */           c = '\\'; break;
/*     */         case 'n':
/* 189 */           c = '\n'; break;
/*     */         case 't':
/* 190 */           c = '\t'; break;
/*     */         case 'r':
/* 191 */           c = '\r'; break;
/*     */         case 'b':
/* 192 */           c = '\b'; break;
/*     */         case 'f':
/* 193 */           c = '\f'; break;
/*     */         case 'u':
/* 195 */           if (readPos + 3 >= len)
/* 196 */             throw new IllegalArgumentException("Invalid escaped char in [" + s + "]");
/* 197 */           c = (char)Integer.parseInt(s.substring(readPos, readPos + 4), 16);
/* 198 */           readPos += 4;
/*     */         }
/*     */       }
/*     */ 
/* 202 */       this.out[(writePos++)] = c;
/*     */     }
/* 204 */     return new String(this.out, 0, writePos);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.WordDelimiterFilterFactory
 * JD-Core Version:    0.6.2
 */