/*     */ package org.apache.lucene.analysis.miscellaneous;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ 
/*     */ public final class LimitTokenPositionFilter extends TokenFilter
/*     */ {
/*     */   private final int maxTokenPosition;
/*     */   private final boolean consumeAllTokens;
/*  43 */   private int tokenPosition = 0;
/*  44 */   private boolean exhausted = false;
/*  45 */   private final PositionIncrementAttribute posIncAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*     */ 
/*     */   public LimitTokenPositionFilter(TokenStream in, int maxTokenPosition)
/*     */   {
/*  57 */     this(in, maxTokenPosition, false);
/*     */   }
/*     */ 
/*     */   public LimitTokenPositionFilter(TokenStream in, int maxTokenPosition, boolean consumeAllTokens)
/*     */   {
/*  69 */     super(in);
/*  70 */     if (maxTokenPosition < 1) {
/*  71 */       throw new IllegalArgumentException("maxTokenPosition must be greater than zero");
/*     */     }
/*  73 */     this.maxTokenPosition = maxTokenPosition;
/*  74 */     this.consumeAllTokens = consumeAllTokens;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  79 */     if (this.exhausted) {
/*  80 */       return false;
/*     */     }
/*  82 */     if (this.input.incrementToken()) {
/*  83 */       this.tokenPosition += this.posIncAtt.getPositionIncrement();
/*  84 */       if (this.tokenPosition <= this.maxTokenPosition) {
/*  85 */         return true;
/*     */       }
/*  87 */       while ((this.consumeAllTokens) && (this.input.incrementToken()));
/*  88 */       this.exhausted = true;
/*  89 */       return false;
/*     */     }
/*     */ 
/*  92 */     this.exhausted = true;
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/*  99 */     super.reset();
/* 100 */     this.tokenPosition = 0;
/* 101 */     this.exhausted = false;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.LimitTokenPositionFilter
 * JD-Core Version:    0.6.2
 */