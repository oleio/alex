/*    */ package org.apache.lucene.analysis.miscellaneous;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ 
/*    */ public final class LimitTokenCountFilter extends TokenFilter
/*    */ {
/*    */   private final int maxTokenCount;
/*    */   private final boolean consumeAllTokens;
/* 43 */   private int tokenCount = 0;
/* 44 */   private boolean exhausted = false;
/*    */ 
/*    */   public LimitTokenCountFilter(TokenStream in, int maxTokenCount)
/*    */   {
/* 53 */     this(in, maxTokenCount, false);
/*    */   }
/*    */ 
/*    */   public LimitTokenCountFilter(TokenStream in, int maxTokenCount, boolean consumeAllTokens)
/*    */   {
/* 63 */     super(in);
/* 64 */     if (maxTokenCount < 1) {
/* 65 */       throw new IllegalArgumentException("maxTokenCount must be greater than zero");
/*    */     }
/* 67 */     this.maxTokenCount = maxTokenCount;
/* 68 */     this.consumeAllTokens = consumeAllTokens;
/*    */   }
/*    */ 
/*    */   public boolean incrementToken() throws IOException
/*    */   {
/* 73 */     if (this.exhausted)
/* 74 */       return false;
/* 75 */     if (this.tokenCount < this.maxTokenCount) {
/* 76 */       if (this.input.incrementToken()) {
/* 77 */         this.tokenCount += 1;
/* 78 */         return true;
/*    */       }
/* 80 */       this.exhausted = true;
/* 81 */       return false;
/*    */     }
/*    */ 
/* 84 */     while ((this.consumeAllTokens) && (this.input.incrementToken()));
/* 85 */     return false;
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */     throws IOException
/*    */   {
/* 91 */     super.reset();
/* 92 */     this.tokenCount = 0;
/* 93 */     this.exhausted = false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.miscellaneous.LimitTokenCountFilter
 * JD-Core Version:    0.6.2
 */