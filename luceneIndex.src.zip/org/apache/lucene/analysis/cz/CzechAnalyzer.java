/*     */ package org.apache.lucene.analysis.cz;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.analysis.util.WordlistLoader;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class CzechAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*     */   private final CharArraySet stemExclusionTable;
/*     */ 
/*     */   public static final CharArraySet getDefaultStopSet()
/*     */   {
/*  66 */     return DefaultSetHolder.DEFAULT_SET;
/*     */   }
/*     */ 
/*     */   public CzechAnalyzer(Version matchVersion)
/*     */   {
/*  94 */     this(matchVersion, DefaultSetHolder.DEFAULT_SET);
/*     */   }
/*     */ 
/*     */   public CzechAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/* 105 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public CzechAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionTable)
/*     */   {
/* 118 */     super(matchVersion, stopwords);
/* 119 */     this.stemExclusionTable = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionTable));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 139 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 140 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/* 141 */     result = new LowerCaseFilter(this.matchVersion, result);
/* 142 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 143 */     if (this.matchVersion.onOrAfter(Version.LUCENE_31)) {
/* 144 */       if (!this.stemExclusionTable.isEmpty())
/* 145 */         result = new SetKeywordMarkerFilter(result, this.stemExclusionTable);
/* 146 */       result = new CzechStemFilter(result);
/*     */     }
/* 148 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     private static final CharArraySet DEFAULT_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  74 */         DEFAULT_SET = WordlistLoader.getWordSet(IOUtils.getDecodingReader(CzechAnalyzer.class, "stopwords.txt", StandardCharsets.UTF_8), "#", Version.LUCENE_CURRENT);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  79 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cz.CzechAnalyzer
 * JD-Core Version:    0.6.2
 */