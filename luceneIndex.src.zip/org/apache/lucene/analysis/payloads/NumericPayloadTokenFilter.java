/*    */ package org.apache.lucene.analysis.payloads;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.PayloadAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*    */ import org.apache.lucene.util.BytesRef;
/*    */ 
/*    */ public class NumericPayloadTokenFilter extends TokenFilter
/*    */ {
/*    */   private String typeMatch;
/*    */   private BytesRef thePayload;
/* 38 */   private final PayloadAttribute payloadAtt = (PayloadAttribute)addAttribute(PayloadAttribute.class);
/* 39 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/*    */ 
/*    */   public NumericPayloadTokenFilter(TokenStream input, float payload, String typeMatch) {
/* 42 */     super(input);
/* 43 */     if (typeMatch == null) {
/* 44 */       throw new IllegalArgumentException("typeMatch cannot be null");
/*    */     }
/*    */ 
/* 47 */     this.thePayload = new BytesRef(PayloadHelper.encodeFloat(payload));
/* 48 */     this.typeMatch = typeMatch;
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken() throws IOException
/*    */   {
/* 53 */     if (this.input.incrementToken()) {
/* 54 */       if (this.typeAtt.type().equals(this.typeMatch))
/* 55 */         this.payloadAtt.setPayload(this.thePayload);
/* 56 */       return true;
/*    */     }
/* 58 */     return false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.payloads.NumericPayloadTokenFilter
 * JD-Core Version:    0.6.2
 */