/*    */ package org.apache.lucene.analysis.payloads;
/*    */ 
/*    */ import org.apache.lucene.util.BytesRef;
/*    */ 
/*    */ public abstract class AbstractEncoder
/*    */   implements PayloadEncoder
/*    */ {
/*    */   public BytesRef encode(char[] buffer)
/*    */   {
/* 31 */     return encode(buffer, 0, buffer.length);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.payloads.AbstractEncoder
 * JD-Core Version:    0.6.2
 */