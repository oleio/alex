/*    */ package org.apache.lucene.analysis.payloads;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class NumericPayloadTokenFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   private final float payload;
/*    */   private final String typeMatch;
/*    */ 
/*    */   public NumericPayloadTokenFilterFactory(Map<String, String> args)
/*    */   {
/* 40 */     super(args);
/* 41 */     this.payload = requireFloat(args, "payload");
/* 42 */     this.typeMatch = require(args, "typeMatch");
/* 43 */     if (!args.isEmpty())
/* 44 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public NumericPayloadTokenFilter create(TokenStream input)
/*    */   {
/* 50 */     return new NumericPayloadTokenFilter(input, this.payload, this.typeMatch);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.payloads.NumericPayloadTokenFilterFactory
 * JD-Core Version:    0.6.2
 */