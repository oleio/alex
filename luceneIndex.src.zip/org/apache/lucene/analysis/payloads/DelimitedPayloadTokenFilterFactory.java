/*    */ package org.apache.lucene.analysis.payloads;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.ResourceLoader;
/*    */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class DelimitedPayloadTokenFilterFactory extends TokenFilterFactory
/*    */   implements ResourceLoaderAware
/*    */ {
/*    */   public static final String ENCODER_ATTR = "encoder";
/*    */   public static final String DELIMITER_ATTR = "delimiter";
/*    */   private final String encoderClass;
/*    */   private final char delimiter;
/*    */   private PayloadEncoder encoder;
/*    */ 
/*    */   public DelimitedPayloadTokenFilterFactory(Map<String, String> args)
/*    */   {
/* 48 */     super(args);
/* 49 */     this.encoderClass = require(args, "encoder");
/* 50 */     this.delimiter = getChar(args, "delimiter", '|');
/* 51 */     if (!args.isEmpty())
/* 52 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public DelimitedPayloadTokenFilter create(TokenStream input)
/*    */   {
/* 58 */     return new DelimitedPayloadTokenFilter(input, this.delimiter, this.encoder);
/*    */   }
/*    */ 
/*    */   public void inform(ResourceLoader loader)
/*    */   {
/* 63 */     if (this.encoderClass.equals("float"))
/* 64 */       this.encoder = new FloatEncoder();
/* 65 */     else if (this.encoderClass.equals("integer"))
/* 66 */       this.encoder = new IntegerEncoder();
/* 67 */     else if (this.encoderClass.equals("identity"))
/* 68 */       this.encoder = new IdentityEncoder();
/*    */     else
/* 70 */       this.encoder = ((PayloadEncoder)loader.newInstance(this.encoderClass, PayloadEncoder.class));
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.payloads.DelimitedPayloadTokenFilterFactory
 * JD-Core Version:    0.6.2
 */