/*    */ package org.apache.lucene.analysis.commongrams;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ 
/*    */ public class CommonGramsQueryFilterFactory extends CommonGramsFilterFactory
/*    */ {
/*    */   public CommonGramsQueryFilterFactory(Map<String, String> args)
/*    */   {
/* 42 */     super(args);
/*    */   }
/*    */ 
/*    */   public TokenFilter create(TokenStream input)
/*    */   {
/* 50 */     CommonGramsFilter commonGrams = (CommonGramsFilter)super.create(input);
/* 51 */     return new CommonGramsQueryFilter(commonGrams);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.commongrams.CommonGramsQueryFilterFactory
 * JD-Core Version:    0.6.2
 */