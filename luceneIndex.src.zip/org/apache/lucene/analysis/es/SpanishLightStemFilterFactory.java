/*    */ package org.apache.lucene.analysis.es;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class SpanishLightStemFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public SpanishLightStemFilterFactory(Map<String, String> args)
/*    */   {
/* 41 */     super(args);
/* 42 */     if (!args.isEmpty())
/* 43 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 49 */     return new SpanishLightStemFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.es.SpanishLightStemFilterFactory
 * JD-Core Version:    0.6.2
 */