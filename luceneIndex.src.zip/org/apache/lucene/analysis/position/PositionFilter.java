/*    */ package org.apache.lucene.analysis.position;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*    */ 
/*    */ @Deprecated
/*    */ public final class PositionFilter extends TokenFilter
/*    */ {
/*    */   private final int positionIncrement;
/* 43 */   private boolean firstTokenPositioned = false;
/*    */ 
/* 45 */   private PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*    */ 
/*    */   public PositionFilter(TokenStream input)
/*    */   {
/* 54 */     this(input, 0);
/*    */   }
/*    */ 
/*    */   public PositionFilter(TokenStream input, int positionIncrement)
/*    */   {
/* 66 */     super(input);
/* 67 */     if (positionIncrement < 0) {
/* 68 */       throw new IllegalArgumentException("positionIncrement may not be negative");
/*    */     }
/* 70 */     this.positionIncrement = positionIncrement;
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken() throws IOException
/*    */   {
/* 75 */     if (this.input.incrementToken()) {
/* 76 */       if (this.firstTokenPositioned)
/* 77 */         this.posIncrAtt.setPositionIncrement(this.positionIncrement);
/*    */       else {
/* 79 */         this.firstTokenPositioned = true;
/*    */       }
/* 81 */       return true;
/*    */     }
/* 83 */     return false;
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */     throws IOException
/*    */   {
/* 89 */     super.reset();
/* 90 */     this.firstTokenPositioned = false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.position.PositionFilter
 * JD-Core Version:    0.6.2
 */