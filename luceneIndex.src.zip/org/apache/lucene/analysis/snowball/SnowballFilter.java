/*     */ package org.apache.lucene.analysis.snowball;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*     */ import org.tartarus.snowball.SnowballProgram;
/*     */ 
/*     */ public final class SnowballFilter extends TokenFilter
/*     */ {
/*     */   private final SnowballProgram stemmer;
/*  57 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  58 */   private final KeywordAttribute keywordAttr = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/*     */ 
/*     */   public SnowballFilter(TokenStream input, SnowballProgram stemmer) {
/*  61 */     super(input);
/*  62 */     this.stemmer = stemmer;
/*     */   }
/*     */ 
/*     */   public SnowballFilter(TokenStream in, String name)
/*     */   {
/*  76 */     super(in);
/*     */     try
/*     */     {
/*  80 */       Class stemClass = Class.forName("org.tartarus.snowball.ext." + name + "Stemmer").asSubclass(SnowballProgram.class);
/*     */ 
/*  82 */       this.stemmer = ((SnowballProgram)stemClass.newInstance());
/*     */     } catch (Exception e) {
/*  84 */       throw new IllegalArgumentException("Invalid stemmer class specified: " + name, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*  91 */     if (this.input.incrementToken()) {
/*  92 */       if (!this.keywordAttr.isKeyword()) {
/*  93 */         char[] termBuffer = this.termAtt.buffer();
/*  94 */         int length = this.termAtt.length();
/*  95 */         this.stemmer.setCurrent(termBuffer, length);
/*  96 */         this.stemmer.stem();
/*  97 */         char[] finalTerm = this.stemmer.getCurrentBuffer();
/*  98 */         int newLength = this.stemmer.getCurrentBufferLength();
/*  99 */         if (finalTerm != termBuffer)
/* 100 */           this.termAtt.copyBuffer(finalTerm, 0, newLength);
/*     */         else
/* 102 */           this.termAtt.setLength(newLength);
/*     */       }
/* 104 */       return true;
/*     */     }
/* 106 */     return false;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.snowball.SnowballFilter
 * JD-Core Version:    0.6.2
 */