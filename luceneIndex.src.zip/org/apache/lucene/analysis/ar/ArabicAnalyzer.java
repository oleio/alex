/*     */ package org.apache.lucene.analysis.ar;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class ArabicAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*     */   private final CharArraySet stemExclusionSet;
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  66 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public ArabicAnalyzer(Version matchVersion)
/*     */   {
/*  93 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   public ArabicAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/* 105 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public ArabicAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/* 121 */     super(matchVersion, stopwords);
/* 122 */     this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 140 */     Tokenizer source = this.matchVersion.onOrAfter(Version.LUCENE_31) ? new StandardTokenizer(this.matchVersion, reader) : new ArabicLetterTokenizer(this.matchVersion, reader);
/*     */ 
/* 142 */     TokenStream result = new LowerCaseFilter(this.matchVersion, source);
/*     */ 
/* 144 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/*     */ 
/* 146 */     result = new ArabicNormalizationFilter(result);
/* 147 */     if (!this.stemExclusionSet.isEmpty()) {
/* 148 */       result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
/*     */     }
/* 150 */     return new Analyzer.TokenStreamComponents(source, new ArabicStemFilter(result));
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  78 */         DEFAULT_STOP_SET = ArabicAnalyzer.loadStopwordSet(false, ArabicAnalyzer.class, "stopwords.txt", "#");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  82 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ar.ArabicAnalyzer
 * JD-Core Version:    0.6.2
 */