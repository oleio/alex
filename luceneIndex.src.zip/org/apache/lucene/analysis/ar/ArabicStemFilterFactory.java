/*    */ package org.apache.lucene.analysis.ar;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class ArabicStemFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public ArabicStemFilterFactory(Map<String, String> args)
/*    */   {
/* 41 */     super(args);
/* 42 */     if (!args.isEmpty())
/* 43 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ArabicStemFilter create(TokenStream input)
/*    */   {
/* 49 */     return new ArabicStemFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ar.ArabicStemFilterFactory
 * JD-Core Version:    0.6.2
 */