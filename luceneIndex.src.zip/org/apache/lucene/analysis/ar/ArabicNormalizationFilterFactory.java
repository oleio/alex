/*    */ package org.apache.lucene.analysis.ar;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.AbstractAnalysisFactory;
/*    */ import org.apache.lucene.analysis.util.MultiTermAwareComponent;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class ArabicNormalizationFilterFactory extends TokenFilterFactory
/*    */   implements MultiTermAwareComponent
/*    */ {
/*    */   public ArabicNormalizationFilterFactory(Map<String, String> args)
/*    */   {
/* 42 */     super(args);
/* 43 */     if (!args.isEmpty())
/* 44 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ArabicNormalizationFilter create(TokenStream input)
/*    */   {
/* 50 */     return new ArabicNormalizationFilter(input);
/*    */   }
/*    */ 
/*    */   public AbstractAnalysisFactory getMultiTermComponent()
/*    */   {
/* 55 */     return this;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ar.ArabicNormalizationFilterFactory
 * JD-Core Version:    0.6.2
 */