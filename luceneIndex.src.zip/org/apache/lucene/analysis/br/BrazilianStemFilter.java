/*    */ package org.apache.lucene.analysis.br;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Set;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*    */ 
/*    */ public final class BrazilianStemFilter extends TokenFilter
/*    */ {
/* 44 */   private BrazilianStemmer stemmer = new BrazilianStemmer();
/* 45 */   private Set<?> exclusions = null;
/* 46 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 47 */   private final KeywordAttribute keywordAttr = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/*    */ 
/*    */   public BrazilianStemFilter(TokenStream in)
/*    */   {
/* 55 */     super(in);
/*    */   }
/*    */ 
/*    */   public boolean incrementToken() throws IOException
/*    */   {
/* 60 */     if (this.input.incrementToken()) {
/* 61 */       String term = this.termAtt.toString();
/*    */ 
/* 63 */       if ((!this.keywordAttr.isKeyword()) && ((this.exclusions == null) || (!this.exclusions.contains(term)))) {
/* 64 */         String s = this.stemmer.stem(term);
/*    */ 
/* 66 */         if ((s != null) && (!s.equals(term)))
/* 67 */           this.termAtt.setEmpty().append(s);
/*    */       }
/* 69 */       return true;
/*    */     }
/* 71 */     return false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.br.BrazilianStemFilter
 * JD-Core Version:    0.6.2
 */