/*    */ package org.apache.lucene.analysis.cn.smart;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ @Deprecated
/*    */ public class SmartChineseSentenceTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   public SmartChineseSentenceTokenizerFactory(Map<String, String> args)
/*    */   {
/* 36 */     super(args);
/* 37 */     if (!args.isEmpty())
/* 38 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public SentenceTokenizer create(AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 44 */     return new SentenceTokenizer(factory, input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.SmartChineseSentenceTokenizerFactory
 * JD-Core Version:    0.6.2
 */