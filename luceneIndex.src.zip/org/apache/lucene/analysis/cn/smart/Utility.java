/*     */ package org.apache.lucene.analysis.cn.smart;
/*     */ 
/*     */ public class Utility
/*     */ {
/*  28 */   public static final char[] STRING_CHAR_ARRAY = new String("未##串").toCharArray();
/*     */ 
/*  31 */   public static final char[] NUMBER_CHAR_ARRAY = new String("未##数").toCharArray();
/*     */ 
/*  34 */   public static final char[] START_CHAR_ARRAY = new String("始##始").toCharArray();
/*     */ 
/*  37 */   public static final char[] END_CHAR_ARRAY = new String("末##末").toCharArray();
/*     */ 
/*  42 */   public static final char[] COMMON_DELIMITER = { ',' };
/*     */   public static final String SPACES = " 　\t\r\n";
/*     */   public static final int MAX_FREQUENCE = 2159997;
/*     */ 
/*     */   public static int compareArray(char[] larray, int lstartIndex, char[] rarray, int rstartIndex)
/*     */   {
/*  66 */     if (larray == null) {
/*  67 */       if ((rarray == null) || (rstartIndex >= rarray.length)) {
/*  68 */         return 0;
/*     */       }
/*  70 */       return -1;
/*     */     }
/*     */ 
/*  73 */     if (rarray == null) {
/*  74 */       if (lstartIndex >= larray.length) {
/*  75 */         return 0;
/*     */       }
/*  77 */       return 1;
/*     */     }
/*     */ 
/*  81 */     int li = lstartIndex; int ri = rstartIndex;
/*  82 */     while ((li < larray.length) && (ri < rarray.length) && (larray[li] == rarray[ri])) {
/*  83 */       li++;
/*  84 */       ri++;
/*     */     }
/*  86 */     if (li == larray.length) {
/*  87 */       if (ri == rarray.length)
/*     */       {
/*  89 */         return 0;
/*     */       }
/*     */ 
/*  92 */       return -1;
/*     */     }
/*     */ 
/*  96 */     if (ri == rarray.length)
/*     */     {
/*  98 */       return 1;
/*     */     }
/*     */ 
/* 101 */     if (larray[li] > rarray[ri]) {
/* 102 */       return 1;
/*     */     }
/* 104 */     return -1;
/*     */   }
/*     */ 
/*     */   public static int compareArrayByPrefix(char[] shortArray, int shortIndex, char[] longArray, int longIndex)
/*     */   {
/* 124 */     if (shortArray == null)
/* 125 */       return 0;
/* 126 */     if (longArray == null) {
/* 127 */       return shortIndex < shortArray.length ? 1 : 0;
/*     */     }
/* 129 */     int si = shortIndex; int li = longIndex;
/*     */ 
/* 131 */     while ((si < shortArray.length) && (li < longArray.length) && (shortArray[si] == longArray[li])) {
/* 132 */       si++;
/* 133 */       li++;
/*     */     }
/* 135 */     if (si == shortArray.length)
/*     */     {
/* 137 */       return 0;
/*     */     }
/*     */ 
/* 140 */     if (li == longArray.length) {
/* 141 */       return 1;
/*     */     }
/*     */ 
/* 144 */     return shortArray[si] > longArray[li] ? 1 : -1;
/*     */   }
/*     */ 
/*     */   public static int getCharType(char ch)
/*     */   {
/* 157 */     if ((ch >= '一') && (ch <= 40869))
/* 158 */       return 3;
/* 159 */     if (((ch >= 'A') && (ch <= 'Z')) || ((ch >= 'a') && (ch <= 'z')))
/* 160 */       return 1;
/* 161 */     if ((ch >= '0') && (ch <= '9'))
/* 162 */       return 2;
/* 163 */     if ((ch == ' ') || (ch == '\t') || (ch == '\r') || (ch == '\n') || (ch == '　')) {
/* 164 */       return 4;
/*     */     }
/* 166 */     if (((ch >= '!') && (ch <= '»')) || ((ch >= '‐') && (ch <= '♂')) || ((ch >= '、') && (ch <= '〞')))
/*     */     {
/* 168 */       return 0;
/*     */     }
/*     */ 
/* 171 */     if (((ch >= 65313) && (ch <= 65338)) || ((ch >= 65345) && (ch <= 65370)))
/* 172 */       return 5;
/* 173 */     if ((ch >= 65296) && (ch <= 65305))
/* 174 */       return 6;
/* 175 */     if ((ch >= 65072) && (ch <= 65379))
/* 176 */       return 0;
/* 177 */     return 7;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.Utility
 * JD-Core Version:    0.6.2
 */