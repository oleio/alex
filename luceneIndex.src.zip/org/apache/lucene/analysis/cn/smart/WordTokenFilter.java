/*     */ package org.apache.lucene.analysis.cn.smart;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.cn.smart.hhmm.SegToken;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ 
/*     */ @Deprecated
/*     */ public final class WordTokenFilter extends TokenFilter
/*     */ {
/*     */   private WordSegmenter wordSegmenter;
/*     */   private Iterator<SegToken> tokenIter;
/*     */   private List<SegToken> tokenBuffer;
/*  45 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  46 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*  47 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/*     */   private int tokStart;
/*     */   private int tokEnd;
/*     */   private boolean hasIllegalOffsets;
/*     */ 
/*     */   public WordTokenFilter(TokenStream in)
/*     */   {
/*  59 */     super(in);
/*  60 */     this.wordSegmenter = new WordSegmenter();
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  65 */     if ((this.tokenIter == null) || (!this.tokenIter.hasNext()))
/*     */     {
/*  67 */       if (this.input.incrementToken()) {
/*  68 */         this.tokStart = this.offsetAtt.startOffset();
/*  69 */         this.tokEnd = this.offsetAtt.endOffset();
/*     */ 
/*  72 */         this.hasIllegalOffsets = (this.tokStart + this.termAtt.length() != this.tokEnd);
/*     */ 
/*  74 */         this.tokenBuffer = this.wordSegmenter.segmentSentence(this.termAtt.toString(), this.offsetAtt.startOffset());
/*  75 */         this.tokenIter = this.tokenBuffer.iterator();
/*     */ 
/*  80 */         if (!this.tokenIter.hasNext())
/*  81 */           return false;
/*     */       } else {
/*  83 */         return false;
/*     */       }
/*     */     }
/*     */ 
/*  87 */     clearAttributes();
/*     */ 
/*  89 */     SegToken nextWord = (SegToken)this.tokenIter.next();
/*  90 */     this.termAtt.copyBuffer(nextWord.charArray, 0, nextWord.charArray.length);
/*  91 */     if (this.hasIllegalOffsets)
/*  92 */       this.offsetAtt.setOffset(this.tokStart, this.tokEnd);
/*     */     else {
/*  94 */       this.offsetAtt.setOffset(nextWord.startOffset, nextWord.endOffset);
/*     */     }
/*  96 */     this.typeAtt.setType("word");
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 102 */     super.reset();
/* 103 */     this.tokenIter = null;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.WordTokenFilter
 * JD-Core Version:    0.6.2
 */