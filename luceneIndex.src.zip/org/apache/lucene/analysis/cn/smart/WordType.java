package org.apache.lucene.analysis.cn.smart;

public class WordType
{
  public static final int SENTENCE_BEGIN = 0;
  public static final int SENTENCE_END = 1;
  public static final int CHINESE_WORD = 2;
  public static final int STRING = 3;
  public static final int NUMBER = 4;
  public static final int DELIMITER = 5;
  public static final int FULLWIDTH_STRING = 6;
  public static final int FULLWIDTH_NUMBER = 7;
}

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.WordType
 * JD-Core Version:    0.6.2
 */