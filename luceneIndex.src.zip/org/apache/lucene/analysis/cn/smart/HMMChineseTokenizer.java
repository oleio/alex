/*    */ package org.apache.lucene.analysis.cn.smart;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ import java.text.BreakIterator;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import org.apache.lucene.analysis.cn.smart.hhmm.SegToken;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*    */ import org.apache.lucene.analysis.util.SegmentingTokenizerBase;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public class HMMChineseTokenizer extends SegmentingTokenizerBase
/*    */ {
/* 40 */   private static final BreakIterator sentenceProto = BreakIterator.getSentenceInstance(Locale.ROOT);
/*    */ 
/* 42 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 43 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 44 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/*    */ 
/* 46 */   private final WordSegmenter wordSegmenter = new WordSegmenter();
/*    */   private Iterator<SegToken> tokens;
/*    */ 
/*    */   public HMMChineseTokenizer(Reader reader)
/*    */   {
/* 51 */     this(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY, reader);
/*    */   }
/*    */ 
/*    */   public HMMChineseTokenizer(AttributeSource.AttributeFactory factory, Reader reader)
/*    */   {
/* 56 */     super(factory, reader, (BreakIterator)sentenceProto.clone());
/*    */   }
/*    */ 
/*    */   protected void setNextSentence(int sentenceStart, int sentenceEnd)
/*    */   {
/* 61 */     String sentence = new String(this.buffer, sentenceStart, sentenceEnd - sentenceStart);
/* 62 */     this.tokens = this.wordSegmenter.segmentSentence(sentence, this.offset + sentenceStart).iterator();
/*    */   }
/*    */ 
/*    */   protected boolean incrementWord()
/*    */   {
/* 67 */     if ((this.tokens == null) || (!this.tokens.hasNext())) {
/* 68 */       return false;
/*    */     }
/* 70 */     SegToken token = (SegToken)this.tokens.next();
/* 71 */     clearAttributes();
/* 72 */     this.termAtt.copyBuffer(token.charArray, 0, token.charArray.length);
/* 73 */     this.offsetAtt.setOffset(correctOffset(token.startOffset), correctOffset(token.endOffset));
/* 74 */     this.typeAtt.setType("word");
/* 75 */     return true;
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */     throws IOException
/*    */   {
/* 81 */     super.reset();
/* 82 */     this.tokens = null;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.HMMChineseTokenizer
 * JD-Core Version:    0.6.2
 */