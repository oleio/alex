/*    */ package org.apache.lucene.analysis.cn.smart;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class AnalyzerProfile
/*    */ {
/* 39 */   public static String ANALYSIS_DATA_DIR = "";
/*    */ 
/*    */   private static void init()
/*    */   {
/* 46 */     String dirName = "analysis-data";
/* 47 */     String propName = "analysis.properties";
/*    */ 
/* 50 */     ANALYSIS_DATA_DIR = System.getProperty("analysis.data.dir", "");
/* 51 */     if (ANALYSIS_DATA_DIR.length() != 0) {
/* 52 */       return;
/*    */     }
/* 54 */     File[] cadidateFiles = { new File("./" + dirName), new File("./lib/" + dirName), new File("./" + propName), new File("./lib/" + propName) };
/*    */ 
/* 57 */     for (int i = 0; i < cadidateFiles.length; i++) {
/* 58 */       File file = cadidateFiles[i];
/* 59 */       if (file.exists()) {
/* 60 */         if (file.isDirectory()) {
/* 61 */           ANALYSIS_DATA_DIR = file.getAbsolutePath(); break;
/* 62 */         }if ((!file.isFile()) || (getAnalysisDataDir(file).length() == 0)) break;
/* 63 */         ANALYSIS_DATA_DIR = getAnalysisDataDir(file); break;
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 69 */     if (ANALYSIS_DATA_DIR.length() == 0)
/*    */     {
/* 71 */       throw new RuntimeException("WARNING: Can not find lexical dictionary directory! This will cause unpredictable exceptions in your application! Please refer to the manual to download the dictionaries.");
/*    */     }
/*    */   }
/*    */ 
/*    */   private static String getAnalysisDataDir(File propFile)
/*    */   {
/* 79 */     Properties prop = new Properties();
/*    */     try {
/* 81 */       FileInputStream input = new FileInputStream(propFile);
/* 82 */       prop.load(new InputStreamReader(input, StandardCharsets.UTF_8));
/* 83 */       String dir = prop.getProperty("analysis.data.dir", "");
/* 84 */       input.close();
/* 85 */       return dir; } catch (IOException e) {
/*    */     }
/* 87 */     return "";
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 42 */     init();
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.AnalyzerProfile
 * JD-Core Version:    0.6.2
 */