/*    */ package org.apache.lucene.analysis.cn.smart.hhmm;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ class SegTokenPair
/*    */ {
/*    */   public char[] charArray;
/*    */   public int from;
/*    */   public int to;
/*    */   public double weight;
/*    */ 
/*    */   public SegTokenPair(char[] idArray, int from, int to, double weight)
/*    */   {
/* 43 */     this.charArray = idArray;
/* 44 */     this.from = from;
/* 45 */     this.to = to;
/* 46 */     this.weight = weight;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 54 */     int prime = 31;
/* 55 */     int result = 1;
/* 56 */     for (int i = 0; i < this.charArray.length; i++) {
/* 57 */       result = 31 * result + this.charArray[i];
/*    */     }
/* 59 */     result = 31 * result + this.from;
/* 60 */     result = 31 * result + this.to;
/*    */ 
/* 62 */     long temp = Double.doubleToLongBits(this.weight);
/* 63 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/* 64 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 72 */     if (this == obj)
/* 73 */       return true;
/* 74 */     if (obj == null)
/* 75 */       return false;
/* 76 */     if (getClass() != obj.getClass())
/* 77 */       return false;
/* 78 */     SegTokenPair other = (SegTokenPair)obj;
/* 79 */     if (!Arrays.equals(this.charArray, other.charArray))
/* 80 */       return false;
/* 81 */     if (this.from != other.from)
/* 82 */       return false;
/* 83 */     if (this.to != other.to)
/* 84 */       return false;
/* 85 */     if (Double.doubleToLongBits(this.weight) != Double.doubleToLongBits(other.weight))
/*    */     {
/* 87 */       return false;
/* 88 */     }return true;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.hhmm.SegTokenPair
 * JD-Core Version:    0.6.2
 */