/*     */ package org.apache.lucene.analysis.cn.smart.hhmm;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import org.apache.lucene.analysis.cn.smart.AnalyzerProfile;
/*     */ 
/*     */ class BigramDictionary extends AbstractDictionary
/*     */ {
/*     */   public static final char WORD_SEGMENT_CHAR = '@';
/*     */   private static BigramDictionary singleInstance;
/*     */   public static final int PRIME_BIGRAM_LENGTH = 402137;
/*     */   private long[] bigramHashTable;
/*     */   private int[] frequencyTable;
/*  57 */   private int max = 0;
/*     */ 
/*  59 */   private int repeat = 0;
/*     */ 
/*     */   public static synchronized BigramDictionary getInstance()
/*     */   {
/*  64 */     if (singleInstance == null) {
/*  65 */       singleInstance = new BigramDictionary();
/*     */       try {
/*  67 */         singleInstance.load();
/*     */       } catch (IOException e) {
/*  69 */         String dictRoot = AnalyzerProfile.ANALYSIS_DATA_DIR;
/*  70 */         singleInstance.load(dictRoot);
/*     */       } catch (ClassNotFoundException e) {
/*  72 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*  75 */     return singleInstance;
/*     */   }
/*     */ 
/*     */   private boolean loadFromObj(File serialObj) {
/*     */     try {
/*  80 */       loadFromInputStream(new FileInputStream(serialObj));
/*  81 */       return true;
/*     */     } catch (Exception e) {
/*  83 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadFromInputStream(InputStream serialObjectInputStream) throws IOException, ClassNotFoundException
/*     */   {
/*  89 */     ObjectInputStream input = new ObjectInputStream(serialObjectInputStream);
/*  90 */     this.bigramHashTable = ((long[])input.readObject());
/*  91 */     this.frequencyTable = ((int[])input.readObject());
/*     */ 
/*  93 */     input.close();
/*     */   }
/*     */ 
/*     */   private void saveToObj(File serialObj) {
/*     */     try {
/*  98 */       ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(serialObj));
/*     */ 
/* 100 */       output.writeObject(this.bigramHashTable);
/* 101 */       output.writeObject(this.frequencyTable);
/* 102 */       output.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void load() throws IOException, ClassNotFoundException {
/* 110 */     InputStream input = getClass().getResourceAsStream("bigramdict.mem");
/* 111 */     loadFromInputStream(input);
/*     */   }
/*     */ 
/*     */   private void load(String dictRoot) {
/* 115 */     String bigramDictPath = dictRoot + "/bigramdict.dct";
/*     */ 
/* 117 */     File serialObj = new File(dictRoot + "/bigramdict.mem");
/*     */ 
/* 119 */     if ((!serialObj.exists()) || (!loadFromObj(serialObj)))
/*     */     {
/*     */       try
/*     */       {
/* 123 */         this.bigramHashTable = new long[402137];
/* 124 */         this.frequencyTable = new int[402137];
/* 125 */         for (int i = 0; i < 402137; i++)
/*     */         {
/* 127 */           this.bigramHashTable[i] = 0L;
/* 128 */           this.frequencyTable[i] = 0;
/*     */         }
/* 130 */         loadFromFile(bigramDictPath);
/*     */       } catch (IOException e) {
/* 132 */         throw new RuntimeException(e.getMessage());
/*     */       }
/* 134 */       saveToObj(serialObj);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void loadFromFile(String dctFilePath)
/*     */     throws IOException
/*     */   {
/* 146 */     int total = 0;
/*     */ 
/* 149 */     int[] buffer = new int[3];
/* 150 */     byte[] intBuffer = new byte[4];
/*     */ 
/* 152 */     RandomAccessFile dctFile = new RandomAccessFile(dctFilePath, "r");
/*     */ 
/* 155 */     for (int i = 1410; i < 8178; i++) {
/* 156 */       String currentStr = getCCByGB2312Id(i);
/*     */ 
/* 160 */       dctFile.read(intBuffer);
/*     */ 
/* 162 */       int cnt = ByteBuffer.wrap(intBuffer).order(ByteOrder.LITTLE_ENDIAN).getInt();
/* 163 */       if (cnt > 0)
/*     */       {
/* 166 */         total += cnt;
/* 167 */         int j = 0;
/* 168 */         while (j < cnt) {
/* 169 */           dctFile.read(intBuffer);
/* 170 */           buffer[0] = ByteBuffer.wrap(intBuffer).order(ByteOrder.LITTLE_ENDIAN).getInt();
/*     */ 
/* 172 */           dctFile.read(intBuffer);
/* 173 */           buffer[1] = ByteBuffer.wrap(intBuffer).order(ByteOrder.LITTLE_ENDIAN).getInt();
/*     */ 
/* 175 */           dctFile.read(intBuffer);
/*     */ 
/* 179 */           int length = buffer[1];
/* 180 */           if (length > 0) {
/* 181 */             byte[] lchBuffer = new byte[length];
/* 182 */             dctFile.read(lchBuffer);
/* 183 */             String tmpword = new String(lchBuffer, "GB2312");
/* 184 */             if (i != 5165) {
/* 185 */               tmpword = currentStr + tmpword;
/*     */             }
/* 187 */             char[] carray = tmpword.toCharArray();
/* 188 */             long hashId = hash1(carray);
/* 189 */             int index = getAvaliableIndex(hashId, carray);
/* 190 */             if (index != -1) {
/* 191 */               if (this.bigramHashTable[index] == 0L) {
/* 192 */                 this.bigramHashTable[index] = hashId;
/*     */               }
/*     */ 
/* 195 */               this.frequencyTable[index] += buffer[0];
/*     */             }
/*     */           }
/* 198 */           j++;
/*     */         }
/*     */       }
/*     */     }
/* 201 */     dctFile.close();
/*     */   }
/*     */ 
/*     */   private int getAvaliableIndex(long hashId, char[] carray)
/*     */   {
/* 206 */     int hash1 = (int)(hashId % 402137L);
/* 207 */     int hash2 = hash2(carray) % 402137;
/* 208 */     if (hash1 < 0)
/* 209 */       hash1 = 402137 + hash1;
/* 210 */     if (hash2 < 0)
/* 211 */       hash2 = 402137 + hash2;
/* 212 */     int index = hash1;
/* 213 */     int i = 1;
/*     */ 
/* 215 */     while ((this.bigramHashTable[index] != 0L) && (this.bigramHashTable[index] != hashId) && (i < 402137)) {
/* 216 */       index = (hash1 + i * hash2) % 402137;
/* 217 */       i++;
/*     */     }
/*     */ 
/* 221 */     if ((i < 402137) && ((this.bigramHashTable[index] == 0L) || (this.bigramHashTable[index] == hashId)))
/*     */     {
/* 223 */       return index;
/*     */     }
/* 225 */     return -1;
/*     */   }
/*     */ 
/*     */   private int getBigramItemIndex(char[] carray)
/*     */   {
/* 232 */     long hashId = hash1(carray);
/* 233 */     int hash1 = (int)(hashId % 402137L);
/* 234 */     int hash2 = hash2(carray) % 402137;
/* 235 */     if (hash1 < 0)
/* 236 */       hash1 = 402137 + hash1;
/* 237 */     if (hash2 < 0)
/* 238 */       hash2 = 402137 + hash2;
/* 239 */     int index = hash1;
/* 240 */     int i = 1;
/* 241 */     this.repeat += 1;
/*     */ 
/* 243 */     while ((this.bigramHashTable[index] != 0L) && (this.bigramHashTable[index] != hashId) && (i < 402137)) {
/* 244 */       index = (hash1 + i * hash2) % 402137;
/* 245 */       i++;
/* 246 */       this.repeat += 1;
/* 247 */       if (i > this.max) {
/* 248 */         this.max = i;
/*     */       }
/*     */     }
/*     */ 
/* 252 */     if ((i < 402137) && (this.bigramHashTable[index] == hashId)) {
/* 253 */       return index;
/*     */     }
/* 255 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getFrequency(char[] carray) {
/* 259 */     int index = getBigramItemIndex(carray);
/* 260 */     if (index != -1)
/* 261 */       return this.frequencyTable[index];
/* 262 */     return 0;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.hhmm.BigramDictionary
 * JD-Core Version:    0.6.2
 */