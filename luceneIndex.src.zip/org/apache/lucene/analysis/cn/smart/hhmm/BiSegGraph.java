/*     */ package org.apache.lucene.analysis.cn.smart.hhmm;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ class BiSegGraph
/*     */ {
/*  37 */   private Map<Integer, ArrayList<SegTokenPair>> tokenPairListTable = new HashMap();
/*     */   private List<SegToken> segTokenList;
/*  41 */   private static BigramDictionary bigramDict = BigramDictionary.getInstance();
/*     */ 
/*     */   public BiSegGraph(SegGraph segGraph) {
/*  44 */     this.segTokenList = segGraph.makeIndex();
/*  45 */     generateBiSegGraph(segGraph);
/*     */   }
/*     */ 
/*     */   private void generateBiSegGraph(SegGraph segGraph)
/*     */   {
/*  52 */     double smooth = 0.1D;
/*  53 */     int wordPairFreq = 0;
/*  54 */     int maxStart = segGraph.getMaxStart();
/*  55 */     double tinyDouble = 4.629636059679713E-07D;
/*     */ 
/*  60 */     this.segTokenList = segGraph.makeIndex();
/*     */ 
/*  62 */     int key = -1;
/*  63 */     List nextTokens = null;
/*  64 */     while (key < maxStart)
/*     */     {
/*     */       Iterator i$;
/*  65 */       if (segGraph.isStartExist(key))
/*     */       {
/*  67 */         List tokenList = segGraph.getStartList(key);
/*     */ 
/*  70 */         for (i$ = tokenList.iterator(); i$.hasNext(); ) { t1 = (SegToken)i$.next();
/*  71 */           oneWordFreq = t1.weight;
/*  72 */           int next = t1.endOffset;
/*  73 */           nextTokens = null;
/*     */ 
/*  77 */           while (next <= maxStart)
/*     */           {
/*  79 */             if (segGraph.isStartExist(next)) {
/*  80 */               nextTokens = segGraph.getStartList(next);
/*  81 */               break;
/*     */             }
/*  83 */             next++;
/*     */           }
/*  85 */           if (nextTokens == null) {
/*     */             break;
/*     */           }
/*  88 */           for (SegToken t2 : nextTokens) {
/*  89 */             char[] idBuffer = new char[t1.charArray.length + t2.charArray.length + 1];
/*  90 */             System.arraycopy(t1.charArray, 0, idBuffer, 0, t1.charArray.length);
/*  91 */             idBuffer[t1.charArray.length] = '@';
/*  92 */             System.arraycopy(t2.charArray, 0, idBuffer, t1.charArray.length + 1, t2.charArray.length);
/*     */ 
/*  96 */             wordPairFreq = bigramDict.getFrequency(idBuffer);
/*     */ 
/* 101 */             double weight = -Math.log(smooth * (1.0D + oneWordFreq) / 2159997.0D + (1.0D - smooth) * ((1.0D - tinyDouble) * wordPairFreq / (1.0D + oneWordFreq) + tinyDouble));
/*     */ 
/* 108 */             SegTokenPair tokenPair = new SegTokenPair(idBuffer, t1.index, t2.index, weight);
/*     */ 
/* 110 */             addSegTokenPair(tokenPair);
/*     */           }
/*     */         }
/*     */       }
/*     */       SegToken t1;
/*     */       double oneWordFreq;
/* 114 */       key++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isToExist(int to)
/*     */   {
/* 126 */     return this.tokenPairListTable.get(Integer.valueOf(to)) != null;
/*     */   }
/*     */ 
/*     */   public List<SegTokenPair> getToList(int to)
/*     */   {
/* 136 */     return (List)this.tokenPairListTable.get(Integer.valueOf(to));
/*     */   }
/*     */ 
/*     */   public void addSegTokenPair(SegTokenPair tokenPair)
/*     */   {
/* 145 */     int to = tokenPair.to;
/* 146 */     if (!isToExist(to)) {
/* 147 */       ArrayList newlist = new ArrayList();
/* 148 */       newlist.add(tokenPair);
/* 149 */       this.tokenPairListTable.put(Integer.valueOf(to), newlist);
/*     */     } else {
/* 151 */       List tokenPairList = (List)this.tokenPairListTable.get(Integer.valueOf(to));
/* 152 */       tokenPairList.add(tokenPair);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getToCount()
/*     */   {
/* 161 */     return this.tokenPairListTable.size();
/*     */   }
/*     */ 
/*     */   public List<SegToken> getShortPath()
/*     */   {
/* 170 */     int nodeCount = getToCount();
/* 171 */     List path = new ArrayList();
/* 172 */     PathNode zeroPath = new PathNode();
/* 173 */     zeroPath.weight = 0.0D;
/* 174 */     zeroPath.preNode = 0;
/* 175 */     path.add(zeroPath);
/* 176 */     for (int current = 1; current <= nodeCount; current++)
/*     */     {
/* 178 */       List edges = getToList(current);
/*     */ 
/* 180 */       double minWeight = 1.7976931348623157E+308D;
/* 181 */       SegTokenPair minEdge = null;
/* 182 */       for (SegTokenPair edge : edges) {
/* 183 */         double weight = edge.weight;
/* 184 */         PathNode preNode = (PathNode)path.get(edge.from);
/* 185 */         if (preNode.weight + weight < minWeight) {
/* 186 */           minWeight = preNode.weight + weight;
/* 187 */           minEdge = edge;
/*     */         }
/*     */       }
/* 190 */       PathNode newNode = new PathNode();
/* 191 */       newNode.weight = minWeight;
/* 192 */       newNode.preNode = minEdge.from;
/* 193 */       path.add(newNode);
/*     */     }
/*     */ 
/* 198 */     int lastNode = path.size() - 1;
/* 199 */     current = lastNode;
/* 200 */     List rpath = new ArrayList();
/* 201 */     List resultPath = new ArrayList();
/*     */ 
/* 203 */     rpath.add(Integer.valueOf(current));
/* 204 */     while (current != 0) {
/* 205 */       PathNode currentPathNode = (PathNode)path.get(current);
/* 206 */       int preNode = currentPathNode.preNode;
/* 207 */       rpath.add(Integer.valueOf(preNode));
/* 208 */       current = preNode;
/*     */     }
/* 210 */     for (int j = rpath.size() - 1; j >= 0; j--) {
/* 211 */       Integer idInteger = (Integer)rpath.get(j);
/* 212 */       int id = idInteger.intValue();
/* 213 */       SegToken t = (SegToken)this.segTokenList.get(id);
/* 214 */       resultPath.add(t);
/*     */     }
/* 216 */     return resultPath;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 222 */     StringBuilder sb = new StringBuilder();
/* 223 */     Collection values = this.tokenPairListTable.values();
/* 224 */     for (ArrayList segList : values) {
/* 225 */       for (SegTokenPair pair : segList) {
/* 226 */         sb.append(new StringBuilder().append(pair).append("\n").toString());
/*     */       }
/*     */     }
/* 229 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.hhmm.BiSegGraph
 * JD-Core Version:    0.6.2
 */