/*     */ package org.apache.lucene.analysis.cn.smart.hhmm;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ abstract class AbstractDictionary
/*     */ {
/*     */   public static final int GB2312_FIRST_CHAR = 1410;
/*     */   public static final int GB2312_CHAR_NUM = 8178;
/*     */   public static final int CHAR_NUM_IN_FILE = 6768;
/*     */ 
/*     */   public String getCCByGB2312Id(int ccid)
/*     */   {
/*  88 */     if ((ccid < 0) || (ccid > 8178))
/*  89 */       return "";
/*  90 */     int cc1 = ccid / 94 + 161;
/*  91 */     int cc2 = ccid % 94 + 161;
/*  92 */     byte[] buffer = new byte[2];
/*  93 */     buffer[0] = ((byte)cc1);
/*  94 */     buffer[1] = ((byte)cc2);
/*     */     try {
/*  96 */       return new String(buffer, "GB2312");
/*     */     } catch (UnsupportedEncodingException e) {
/*     */     }
/*  99 */     return "";
/*     */   }
/*     */ 
/*     */   public short getGB2312Id(char ch)
/*     */   {
/*     */     try
/*     */     {
/* 111 */       byte[] buffer = Character.toString(ch).getBytes("GB2312");
/* 112 */       if (buffer.length != 2)
/*     */       {
/* 114 */         return -1;
/*     */       }
/* 116 */       int b0 = (buffer[0] & 0xFF) - 161;
/* 117 */       int b1 = (buffer[1] & 0xFF) - 161;
/*     */ 
/* 119 */       return (short)(b0 * 94 + b1);
/*     */     } catch (UnsupportedEncodingException e) {
/* 121 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public long hash1(char c)
/*     */   {
/* 132 */     long p = 1099511628211L;
/* 133 */     long hash = -3750763034362895579L;
/* 134 */     hash = (hash ^ c & 0xFF) * 1099511628211L;
/* 135 */     hash = (hash ^ c >> '\b') * 1099511628211L;
/* 136 */     hash += (hash << 13);
/* 137 */     hash ^= hash >> 7;
/* 138 */     hash += (hash << 3);
/* 139 */     hash ^= hash >> 17;
/* 140 */     hash += (hash << 5);
/* 141 */     return hash;
/*     */   }
/*     */ 
/*     */   public long hash1(char[] carray)
/*     */   {
/* 151 */     long p = 1099511628211L;
/* 152 */     long hash = -3750763034362895579L;
/* 153 */     for (int i = 0; i < carray.length; i++) {
/* 154 */       char d = carray[i];
/* 155 */       hash = (hash ^ d & 0xFF) * 1099511628211L;
/* 156 */       hash = (hash ^ d >> '\b') * 1099511628211L;
/*     */     }
/*     */ 
/* 164 */     return hash;
/*     */   }
/*     */ 
/*     */   public int hash2(char c)
/*     */   {
/* 178 */     int hash = 5381;
/*     */ 
/* 181 */     hash = (hash << 5) + hash + c & 0xFF;
/* 182 */     hash = (hash << 5) + hash + c >> 8;
/*     */ 
/* 184 */     return hash;
/*     */   }
/*     */ 
/*     */   public int hash2(char[] carray)
/*     */   {
/* 198 */     int hash = 5381;
/*     */ 
/* 201 */     for (int i = 0; i < carray.length; i++) {
/* 202 */       char d = carray[i];
/* 203 */       hash = (hash << 5) + hash + d & 0xFF;
/* 204 */       hash = (hash << 5) + hash + d >> 8;
/*     */     }
/*     */ 
/* 207 */     return hash;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.hhmm.AbstractDictionary
 * JD-Core Version:    0.6.2
 */