/*    */ package org.apache.lucene.analysis.cn.smart.hhmm;
/*    */ 
/*    */ class PathNode
/*    */   implements Comparable<PathNode>
/*    */ {
/*    */   public double weight;
/*    */   public int preNode;
/*    */ 
/*    */   public int compareTo(PathNode pn)
/*    */   {
/* 34 */     if (this.weight < pn.weight)
/* 35 */       return -1;
/* 36 */     if (this.weight == pn.weight) {
/* 37 */       return 0;
/*    */     }
/* 39 */     return 1;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 47 */     int prime = 31;
/* 48 */     int result = 1;
/* 49 */     result = 31 * result + this.preNode;
/*    */ 
/* 51 */     long temp = Double.doubleToLongBits(this.weight);
/* 52 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/* 53 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 61 */     if (this == obj)
/* 62 */       return true;
/* 63 */     if (obj == null)
/* 64 */       return false;
/* 65 */     if (getClass() != obj.getClass())
/* 66 */       return false;
/* 67 */     PathNode other = (PathNode)obj;
/* 68 */     if (this.preNode != other.preNode)
/* 69 */       return false;
/* 70 */     if (Double.doubleToLongBits(this.weight) != Double.doubleToLongBits(other.weight))
/*    */     {
/* 72 */       return false;
/* 73 */     }return true;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.hhmm.PathNode
 * JD-Core Version:    0.6.2
 */