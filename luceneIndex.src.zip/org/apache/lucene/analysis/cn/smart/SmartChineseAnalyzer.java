/*     */ package org.apache.lucene.analysis.cn.smart;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.en.PorterStemFilter;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.WordlistLoader;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class SmartChineseAnalyzer extends Analyzer
/*     */ {
/*     */   private final CharArraySet stopWords;
/*     */   private static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*     */   private static final String STOPWORD_FILE_COMMENT = "//";
/*     */   private final Version matchVersion;
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  68 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public SmartChineseAnalyzer(Version matchVersion)
/*     */   {
/* 103 */     this(matchVersion, true);
/*     */   }
/*     */ 
/*     */   public SmartChineseAnalyzer(Version matchVersion, boolean useDefaultStopWords)
/*     */   {
/* 118 */     this.stopWords = (useDefaultStopWords ? DefaultSetHolder.DEFAULT_STOP_SET : CharArraySet.EMPTY_SET);
/*     */ 
/* 120 */     this.matchVersion = matchVersion;
/*     */   }
/*     */ 
/*     */   public SmartChineseAnalyzer(Version matchVersion, CharArraySet stopWords)
/*     */   {
/* 133 */     this.stopWords = (stopWords == null ? CharArraySet.EMPTY_SET : stopWords);
/* 134 */     this.matchVersion = matchVersion;
/*     */   }
/*     */ 
/*     */   public Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/*     */     TokenStream result;
/*     */     Tokenizer tokenizer;
/* 141 */     if (this.matchVersion.onOrAfter(Version.LUCENE_48)) {
/* 142 */       Tokenizer tokenizer = new HMMChineseTokenizer(reader);
/* 143 */       result = tokenizer;
/*     */     } else {
/* 145 */       tokenizer = new SentenceTokenizer(reader);
/* 146 */       result = new WordTokenFilter(tokenizer);
/*     */     }
/*     */ 
/* 151 */     TokenStream result = new PorterStemFilter(result);
/* 152 */     if (!this.stopWords.isEmpty()) {
/* 153 */       result = new StopFilter(this.matchVersion, result, this.stopWords);
/*     */     }
/* 155 */     return new Analyzer.TokenStreamComponents(tokenizer, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static CharArraySet loadDefaultStopWordSet()
/*     */       throws IOException
/*     */     {
/*  90 */       return CharArraySet.unmodifiableSet(WordlistLoader.getWordSet(IOUtils.getDecodingReader(SmartChineseAnalyzer.class, "stopwords.txt", StandardCharsets.UTF_8), "//", Version.LUCENE_CURRENT));
/*     */     }
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  80 */         DEFAULT_STOP_SET = loadDefaultStopWordSet();
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  84 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.SmartChineseAnalyzer
 * JD-Core Version:    0.6.2
 */