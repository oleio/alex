/*    */ package org.apache.lucene.analysis.cn.smart;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.Tokenizer;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public final class HMMChineseTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   public HMMChineseTokenizerFactory(Map<String, String> args)
/*    */   {
/* 40 */     super(args);
/* 41 */     if (!args.isEmpty())
/* 42 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public Tokenizer create(AttributeSource.AttributeFactory factory, Reader reader)
/*    */   {
/* 48 */     return new HMMChineseTokenizer(factory, reader);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.HMMChineseTokenizerFactory
 * JD-Core Version:    0.6.2
 */