package org.apache.lucene.analysis.cn.smart;

public class CharType
{
  public static final int DELIMITER = 0;
  public static final int LETTER = 1;
  public static final int DIGIT = 2;
  public static final int HANZI = 3;
  public static final int SPACE_LIKE = 4;
  public static final int FULLWIDTH_LETTER = 5;
  public static final int FULLWIDTH_DIGIT = 6;
  public static final int OTHER = 7;
}

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.smart.CharType
 * JD-Core Version:    0.6.2
 */