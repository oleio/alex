/*    */ package org.apache.lucene.analysis.cn;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ @Deprecated
/*    */ public class ChineseTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   public ChineseTokenizerFactory(Map<String, String> args)
/*    */   {
/* 35 */     super(args);
/* 36 */     if (!args.isEmpty())
/* 37 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ChineseTokenizer create(AttributeSource.AttributeFactory factory, Reader in)
/*    */   {
/* 43 */     return new ChineseTokenizer(factory, in);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cn.ChineseTokenizerFactory
 * JD-Core Version:    0.6.2
 */