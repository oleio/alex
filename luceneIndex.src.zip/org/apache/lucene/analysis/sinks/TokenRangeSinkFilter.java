/*    */ package org.apache.lucene.analysis.sinks;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.util.AttributeSource;
/*    */ 
/*    */ public class TokenRangeSinkFilter extends TeeSinkTokenFilter.SinkFilter
/*    */ {
/*    */   private int lower;
/*    */   private int upper;
/*    */   private int count;
/*    */ 
/*    */   public TokenRangeSinkFilter(int lower, int upper)
/*    */   {
/* 34 */     if (lower < 1) {
/* 35 */       throw new IllegalArgumentException("lower must be greater than zero");
/*    */     }
/* 37 */     if (lower > upper) {
/* 38 */       throw new IllegalArgumentException("lower must not be greater than upper");
/*    */     }
/* 40 */     this.lower = lower;
/* 41 */     this.upper = upper;
/*    */   }
/*    */ 
/*    */   public boolean accept(AttributeSource source)
/*    */   {
/*    */     try
/*    */     {
/*    */       boolean bool;
/* 48 */       if ((this.count >= this.lower) && (this.count < this.upper)) {
/* 49 */         return true;
/*    */       }
/* 51 */       return false;
/*    */     } finally {
/* 53 */       this.count += 1;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void reset() throws IOException
/*    */   {
/* 59 */     this.count = 0;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.sinks.TokenRangeSinkFilter
 * JD-Core Version:    0.6.2
 */