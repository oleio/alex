/*    */ package org.apache.lucene.analysis.sinks;
/*    */ 
/*    */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*    */ import org.apache.lucene.util.AttributeSource;
/*    */ 
/*    */ public class TokenTypeSinkFilter extends TeeSinkTokenFilter.SinkFilter
/*    */ {
/*    */   private String typeToMatch;
/*    */   private TypeAttribute typeAtt;
/*    */ 
/*    */   public TokenTypeSinkFilter(String typeToMatch)
/*    */   {
/* 31 */     this.typeToMatch = typeToMatch;
/*    */   }
/*    */ 
/*    */   public boolean accept(AttributeSource source)
/*    */   {
/* 36 */     if (this.typeAtt == null) {
/* 37 */       this.typeAtt = ((TypeAttribute)source.addAttribute(TypeAttribute.class));
/*    */     }
/*    */ 
/* 41 */     return this.typeToMatch.equals(this.typeAtt.type());
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.sinks.TokenTypeSinkFilter
 * JD-Core Version:    0.6.2
 */