/*     */ package org.apache.lucene.analysis.shingle;
/*     */ 
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.AnalyzerWrapper;
/*     */ import org.apache.lucene.analysis.standard.StandardAnalyzer;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class ShingleAnalyzerWrapper extends AnalyzerWrapper
/*     */ {
/*     */   private final Analyzer delegate;
/*     */   private final int maxShingleSize;
/*     */   private final int minShingleSize;
/*     */   private final String tokenSeparator;
/*     */   private final boolean outputUnigrams;
/*     */   private final boolean outputUnigramsIfNoShingles;
/*     */   private final String fillerToken;
/*     */ 
/*     */   public ShingleAnalyzerWrapper(Analyzer defaultAnalyzer)
/*     */   {
/*  42 */     this(defaultAnalyzer, 2);
/*     */   }
/*     */ 
/*     */   public ShingleAnalyzerWrapper(Analyzer defaultAnalyzer, int maxShingleSize) {
/*  46 */     this(defaultAnalyzer, 2, maxShingleSize);
/*     */   }
/*     */ 
/*     */   public ShingleAnalyzerWrapper(Analyzer defaultAnalyzer, int minShingleSize, int maxShingleSize) {
/*  50 */     this(defaultAnalyzer, minShingleSize, maxShingleSize, " ", true, false, "_");
/*     */   }
/*     */ 
/*     */   public ShingleAnalyzerWrapper(Analyzer delegate, int minShingleSize, int maxShingleSize, String tokenSeparator, boolean outputUnigrams, boolean outputUnigramsIfNoShingles, String fillerToken)
/*     */   {
/*  78 */     super(delegate.getReuseStrategy());
/*  79 */     this.delegate = delegate;
/*     */ 
/*  81 */     if (maxShingleSize < 2) {
/*  82 */       throw new IllegalArgumentException("Max shingle size must be >= 2");
/*     */     }
/*  84 */     this.maxShingleSize = maxShingleSize;
/*     */ 
/*  86 */     if (minShingleSize < 2) {
/*  87 */       throw new IllegalArgumentException("Min shingle size must be >= 2");
/*     */     }
/*  89 */     if (minShingleSize > maxShingleSize) {
/*  90 */       throw new IllegalArgumentException("Min shingle size must be <= max shingle size");
/*     */     }
/*     */ 
/*  93 */     this.minShingleSize = minShingleSize;
/*     */ 
/*  95 */     this.tokenSeparator = (tokenSeparator == null ? "" : tokenSeparator);
/*  96 */     this.outputUnigrams = outputUnigrams;
/*  97 */     this.outputUnigramsIfNoShingles = outputUnigramsIfNoShingles;
/*  98 */     this.fillerToken = fillerToken;
/*     */   }
/*     */ 
/*     */   public ShingleAnalyzerWrapper(Version matchVersion)
/*     */   {
/* 105 */     this(matchVersion, 2, 2);
/*     */   }
/*     */ 
/*     */   public ShingleAnalyzerWrapper(Version matchVersion, int minShingleSize, int maxShingleSize)
/*     */   {
/* 112 */     this(new StandardAnalyzer(matchVersion), minShingleSize, maxShingleSize);
/*     */   }
/*     */ 
/*     */   public int getMaxShingleSize()
/*     */   {
/* 121 */     return this.maxShingleSize;
/*     */   }
/*     */ 
/*     */   public int getMinShingleSize()
/*     */   {
/* 130 */     return this.minShingleSize;
/*     */   }
/*     */ 
/*     */   public String getTokenSeparator() {
/* 134 */     return this.tokenSeparator;
/*     */   }
/*     */ 
/*     */   public boolean isOutputUnigrams() {
/* 138 */     return this.outputUnigrams;
/*     */   }
/*     */ 
/*     */   public boolean isOutputUnigramsIfNoShingles() {
/* 142 */     return this.outputUnigramsIfNoShingles;
/*     */   }
/*     */ 
/*     */   public String getFillerToken() {
/* 146 */     return this.fillerToken;
/*     */   }
/*     */ 
/*     */   public final Analyzer getWrappedAnalyzer(String fieldName)
/*     */   {
/* 151 */     return this.delegate;
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents wrapComponents(String fieldName, Analyzer.TokenStreamComponents components)
/*     */   {
/* 156 */     ShingleFilter filter = new ShingleFilter(components.getTokenStream(), this.minShingleSize, this.maxShingleSize);
/* 157 */     filter.setMinShingleSize(this.minShingleSize);
/* 158 */     filter.setMaxShingleSize(this.maxShingleSize);
/* 159 */     filter.setTokenSeparator(this.tokenSeparator);
/* 160 */     filter.setOutputUnigrams(this.outputUnigrams);
/* 161 */     filter.setOutputUnigramsIfNoShingles(this.outputUnigramsIfNoShingles);
/* 162 */     filter.setFillerToken(this.fillerToken);
/* 163 */     return new Analyzer.TokenStreamComponents(components.getTokenizer(), filter);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.shingle.ShingleAnalyzerWrapper
 * JD-Core Version:    0.6.2
 */