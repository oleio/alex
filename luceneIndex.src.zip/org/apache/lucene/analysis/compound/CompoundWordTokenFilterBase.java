/*     */ package org.apache.lucene.analysis.compound;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedList;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public abstract class CompoundWordTokenFilterBase extends TokenFilter
/*     */ {
/*     */   public static final int DEFAULT_MIN_WORD_SIZE = 5;
/*     */   public static final int DEFAULT_MIN_SUBWORD_SIZE = 2;
/*     */   public static final int DEFAULT_MAX_SUBWORD_SIZE = 15;
/*     */   protected final Version matchVersion;
/*     */   protected final CharArraySet dictionary;
/*     */   protected final LinkedList<CompoundToken> tokens;
/*     */   protected final int minWordSize;
/*     */   protected final int minSubwordSize;
/*     */   protected final int maxSubwordSize;
/*     */   protected final boolean onlyLongestMatch;
/*  70 */   protected final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  71 */   protected final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*  72 */   private final PositionIncrementAttribute posIncAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*     */   private AttributeSource.State current;
/*     */ 
/*     */   protected CompoundWordTokenFilterBase(Version matchVersion, TokenStream input, CharArraySet dictionary, boolean onlyLongestMatch)
/*     */   {
/*  77 */     this(matchVersion, input, dictionary, 5, 2, 15, onlyLongestMatch);
/*     */   }
/*     */ 
/*     */   protected CompoundWordTokenFilterBase(Version matchVersion, TokenStream input, CharArraySet dictionary) {
/*  81 */     this(matchVersion, input, dictionary, 5, 2, 15, false);
/*     */   }
/*     */ 
/*     */   protected CompoundWordTokenFilterBase(Version matchVersion, TokenStream input, CharArraySet dictionary, int minWordSize, int minSubwordSize, int maxSubwordSize, boolean onlyLongestMatch) {
/*  85 */     super(input);
/*  86 */     this.matchVersion = matchVersion;
/*  87 */     this.tokens = new LinkedList();
/*  88 */     if (minWordSize < 0) {
/*  89 */       throw new IllegalArgumentException("minWordSize cannot be negative");
/*     */     }
/*  91 */     this.minWordSize = minWordSize;
/*  92 */     if (minSubwordSize < 0) {
/*  93 */       throw new IllegalArgumentException("minSubwordSize cannot be negative");
/*     */     }
/*  95 */     this.minSubwordSize = minSubwordSize;
/*  96 */     if (maxSubwordSize < 0) {
/*  97 */       throw new IllegalArgumentException("maxSubwordSize cannot be negative");
/*     */     }
/*  99 */     this.maxSubwordSize = maxSubwordSize;
/* 100 */     this.onlyLongestMatch = onlyLongestMatch;
/* 101 */     this.dictionary = dictionary;
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken() throws IOException
/*     */   {
/* 106 */     if (!this.tokens.isEmpty()) {
/* 107 */       assert (this.current != null);
/* 108 */       CompoundToken token = (CompoundToken)this.tokens.removeFirst();
/* 109 */       restoreState(this.current);
/* 110 */       this.termAtt.setEmpty().append(token.txt);
/* 111 */       this.offsetAtt.setOffset(token.startOffset, token.endOffset);
/* 112 */       this.posIncAtt.setPositionIncrement(0);
/* 113 */       return true;
/*     */     }
/*     */ 
/* 116 */     this.current = null;
/* 117 */     if (this.input.incrementToken())
/*     */     {
/* 119 */       if (this.termAtt.length() >= this.minWordSize) {
/* 120 */         decompose();
/*     */ 
/* 122 */         if (!this.tokens.isEmpty()) {
/* 123 */           this.current = captureState();
/*     */         }
/*     */       }
/*     */ 
/* 127 */       return true;
/*     */     }
/* 129 */     return false;
/*     */   }
/*     */ 
/*     */   protected abstract void decompose();
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 140 */     super.reset();
/* 141 */     this.tokens.clear();
/* 142 */     this.current = null;
/*     */   }
/*     */ 
/*     */   protected class CompoundToken
/*     */   {
/*     */     public final CharSequence txt;
/*     */     public final int startOffset;
/*     */     public final int endOffset;
/*     */ 
/*     */     public CompoundToken(int offset, int length) {
/* 154 */       this.txt = CompoundWordTokenFilterBase.this.termAtt.subSequence(offset, offset + length);
/*     */ 
/* 157 */       int startOff = CompoundWordTokenFilterBase.this.offsetAtt.startOffset();
/* 158 */       int endOff = CompoundWordTokenFilterBase.this.offsetAtt.endOffset();
/*     */ 
/* 160 */       if ((CompoundWordTokenFilterBase.this.matchVersion.onOrAfter(Version.LUCENE_44)) || (endOff - startOff != CompoundWordTokenFilterBase.this.termAtt.length()))
/*     */       {
/* 164 */         this.startOffset = startOff;
/* 165 */         this.endOffset = endOff;
/*     */       } else {
/* 167 */         int newStart = startOff + offset;
/* 168 */         this.startOffset = newStart;
/* 169 */         this.endOffset = (newStart + length);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.compound.CompoundWordTokenFilterBase
 * JD-Core Version:    0.6.2
 */