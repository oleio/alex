/*     */ package org.apache.lucene.analysis.compound.hyphenation;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ public class HyphenationTree extends TernaryTree
/*     */   implements PatternConsumer
/*     */ {
/*     */   protected ByteVector vspace;
/*     */   protected HashMap<String, ArrayList<Object>> stoplist;
/*     */   protected TernaryTree classmap;
/*     */   private transient TernaryTree ivalues;
/*     */ 
/*     */   public HyphenationTree()
/*     */   {
/*  57 */     this.stoplist = new HashMap(23);
/*  58 */     this.classmap = new TernaryTree();
/*  59 */     this.vspace = new ByteVector();
/*  60 */     this.vspace.alloc(1);
/*     */   }
/*     */ 
/*     */   protected int packValues(String values)
/*     */   {
/*  73 */     int n = values.length();
/*  74 */     int m = (n & 0x1) == 1 ? (n >> 1) + 2 : (n >> 1) + 1;
/*  75 */     int offset = this.vspace.alloc(m);
/*  76 */     byte[] va = this.vspace.getArray();
/*  77 */     for (int i = 0; i < n; i++) {
/*  78 */       int j = i >> 1;
/*  79 */       byte v = (byte)(values.charAt(i) - '0' + 1 & 0xF);
/*  80 */       if ((i & 0x1) == 1)
/*  81 */         va[(j + offset)] = ((byte)(va[(j + offset)] | v));
/*     */       else {
/*  83 */         va[(j + offset)] = ((byte)(v << 4));
/*     */       }
/*     */     }
/*  86 */     va[(m - 1 + offset)] = 0;
/*  87 */     return offset;
/*     */   }
/*     */ 
/*     */   protected String unpackValues(int k) {
/*  91 */     StringBuilder buf = new StringBuilder();
/*  92 */     byte v = this.vspace.get(k++);
/*  93 */     while (v != 0) {
/*  94 */       char c = (char)((v >>> 4) - 1 + 48);
/*  95 */       buf.append(c);
/*  96 */       c = (char)(v & 0xF);
/*  97 */       if (c == 0) {
/*     */         break;
/*     */       }
/* 100 */       c = (char)(c - '\001' + 48);
/* 101 */       buf.append(c);
/* 102 */       v = this.vspace.get(k++);
/*     */     }
/* 104 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public void loadPatterns(File f)
/*     */     throws IOException
/*     */   {
/* 114 */     InputSource src = new InputSource(f.toURI().toASCIIString());
/* 115 */     loadPatterns(src);
/*     */   }
/*     */ 
/*     */   public void loadPatterns(InputSource source)
/*     */     throws IOException
/*     */   {
/* 125 */     PatternParser pp = new PatternParser(this);
/* 126 */     this.ivalues = new TernaryTree();
/*     */ 
/* 128 */     pp.parse(source);
/*     */ 
/* 132 */     trimToSize();
/* 133 */     this.vspace.trimToSize();
/* 134 */     this.classmap.trimToSize();
/*     */ 
/* 137 */     this.ivalues = null;
/*     */   }
/*     */ 
/*     */   public String findPattern(String pat) {
/* 141 */     int k = super.find(pat);
/* 142 */     if (k >= 0) {
/* 143 */       return unpackValues(k);
/*     */     }
/* 145 */     return "";
/*     */   }
/*     */ 
/*     */   protected int hstrcmp(char[] s, int si, char[] t, int ti)
/*     */   {
/* 152 */     for (; s[si] == t[ti]; ti++) {
/* 153 */       if (s[si] == 0)
/* 154 */         return 0;
/* 152 */       si++;
/*     */     }
/*     */ 
/* 157 */     if (t[ti] == 0) {
/* 158 */       return 0;
/*     */     }
/* 160 */     return s[si] - t[ti];
/*     */   }
/*     */ 
/*     */   protected byte[] getValues(int k) {
/* 164 */     StringBuilder buf = new StringBuilder();
/* 165 */     byte v = this.vspace.get(k++);
/* 166 */     while (v != 0) {
/* 167 */       char c = (char)((v >>> 4) - 1);
/* 168 */       buf.append(c);
/* 169 */       c = (char)(v & 0xF);
/* 170 */       if (c == 0) {
/*     */         break;
/*     */       }
/* 173 */       c = (char)(c - '\001');
/* 174 */       buf.append(c);
/* 175 */       v = this.vspace.get(k++);
/*     */     }
/* 177 */     byte[] res = new byte[buf.length()];
/* 178 */     for (int i = 0; i < res.length; i++) {
/* 179 */       res[i] = ((byte)buf.charAt(i));
/*     */     }
/* 181 */     return res;
/*     */   }
/*     */ 
/*     */   protected void searchPatterns(char[] word, int index, byte[] il)
/*     */   {
/* 212 */     int i = index;
/*     */ 
/* 214 */     char sp = word[i];
/* 215 */     char p = this.root;
/*     */ 
/* 217 */     while ((p > 0) && (p < this.sc.length)) {
/* 218 */       if (this.sc[p] == 65535) {
/* 219 */         if (hstrcmp(word, i, this.kv.getArray(), this.lo[p]) == 0) {
/* 220 */           byte[] values = getValues(this.eq[p]);
/* 221 */           int j = index;
/* 222 */           for (int k = 0; k < values.length; k++) {
/* 223 */             if ((j < il.length) && (values[k] > il[j])) {
/* 224 */               il[j] = values[k];
/*     */             }
/* 226 */             j++;
/*     */           }
/*     */         }
/* 229 */         return;
/*     */       }
/* 231 */       int d = sp - this.sc[p];
/* 232 */       if (d == 0) {
/* 233 */         if (sp == 0) {
/*     */           break;
/*     */         }
/* 236 */         sp = word[(++i)];
/* 237 */         p = this.eq[p];
/* 238 */         char q = p;
/*     */ 
/* 242 */         while ((q > 0) && (q < this.sc.length) && 
/* 243 */           (this.sc[q] != 65535))
/*     */         {
/* 246 */           if (this.sc[q] == 0) {
/* 247 */             byte[] values = getValues(this.eq[q]);
/* 248 */             int j = index;
/* 249 */             for (int k = 0; k < values.length; k++) {
/* 250 */               if ((j < il.length) && (values[k] > il[j])) {
/* 251 */                 il[j] = values[k];
/*     */               }
/* 253 */               j++;
/*     */             }
/* 255 */             break;
/*     */           }
/* 257 */           q = this.lo[q];
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 266 */       p = d < 0 ? this.lo[p] : this.hi[p];
/*     */     }
/*     */   }
/*     */ 
/*     */   public Hyphenation hyphenate(String word, int remainCharCount, int pushCharCount)
/*     */   {
/* 284 */     char[] w = word.toCharArray();
/* 285 */     return hyphenate(w, 0, w.length, remainCharCount, pushCharCount);
/*     */   }
/*     */ 
/*     */   public Hyphenation hyphenate(char[] w, int offset, int len, int remainCharCount, int pushCharCount)
/*     */   {
/* 318 */     char[] word = new char[len + 3];
/*     */ 
/* 321 */     char[] c = new char[2];
/* 322 */     int iIgnoreAtBeginning = 0;
/* 323 */     int iLength = len;
/* 324 */     boolean bEndOfLetters = false;
/* 325 */     for (int i = 1; i <= len; i++) {
/* 326 */       c[0] = w[(offset + i - 1)];
/* 327 */       int nc = this.classmap.find(c, 0);
/* 328 */       if (nc < 0) {
/* 329 */         if (i == 1 + iIgnoreAtBeginning)
/*     */         {
/* 331 */           iIgnoreAtBeginning++;
/*     */         }
/*     */         else {
/* 334 */           bEndOfLetters = true;
/*     */         }
/* 336 */         iLength--;
/*     */       }
/* 338 */       else if (!bEndOfLetters) {
/* 339 */         word[(i - iIgnoreAtBeginning)] = ((char)nc);
/*     */       } else {
/* 341 */         return null;
/*     */       }
/*     */     }
/*     */ 
/* 345 */     len = iLength;
/* 346 */     if (len < remainCharCount + pushCharCount)
/*     */     {
/* 348 */       return null;
/*     */     }
/* 350 */     int[] result = new int[len + 1];
/* 351 */     int k = 0;
/*     */ 
/* 354 */     String sw = new String(word, 1, len);
/* 355 */     if (this.stoplist.containsKey(sw))
/*     */     {
/* 358 */       ArrayList hw = (ArrayList)this.stoplist.get(sw);
/* 359 */       int j = 0;
/* 360 */       for (i = 0; i < hw.size(); i++) {
/* 361 */         Object o = hw.get(i);
/*     */ 
/* 364 */         if ((o instanceof String)) {
/* 365 */           j += ((String)o).length();
/* 366 */           if ((j >= remainCharCount) && (j < len - pushCharCount))
/* 367 */             result[(k++)] = (j + iIgnoreAtBeginning);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 373 */       word[0] = '.';
/* 374 */       word[(len + 1)] = '.';
/* 375 */       word[(len + 2)] = '\000';
/* 376 */       byte[] il = new byte[len + 3];
/* 377 */       for (i = 0; i < len + 1; i++) {
/* 378 */         searchPatterns(word, i, il);
/*     */       }
/*     */ 
/* 385 */       for (i = 0; i < len; i++) {
/* 386 */         if (((il[(i + 1)] & 0x1) == 1) && (i >= remainCharCount) && (i <= len - pushCharCount))
/*     */         {
/* 388 */           result[(k++)] = (i + iIgnoreAtBeginning);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 393 */     if (k > 0)
/*     */     {
/* 395 */       int[] res = new int[k + 2];
/* 396 */       System.arraycopy(result, 0, res, 1, k);
/*     */ 
/* 399 */       res[0] = 0;
/* 400 */       res[(k + 1)] = len;
/* 401 */       return new Hyphenation(res);
/*     */     }
/* 403 */     return null;
/*     */   }
/*     */ 
/*     */   public void addClass(String chargroup)
/*     */   {
/* 419 */     if (chargroup.length() > 0) {
/* 420 */       char equivChar = chargroup.charAt(0);
/* 421 */       char[] key = new char[2];
/* 422 */       key[1] = '\000';
/* 423 */       for (int i = 0; i < chargroup.length(); i++) {
/* 424 */         key[0] = chargroup.charAt(i);
/* 425 */         this.classmap.insert(key, 0, equivChar);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addException(String word, ArrayList<Object> hyphenatedword)
/*     */   {
/* 441 */     this.stoplist.put(word, hyphenatedword);
/*     */   }
/*     */ 
/*     */   public void addPattern(String pattern, String ivalue)
/*     */   {
/* 456 */     int k = this.ivalues.find(ivalue);
/* 457 */     if (k <= 0) {
/* 458 */       k = packValues(ivalue);
/* 459 */       this.ivalues.insert(ivalue, (char)k);
/*     */     }
/* 461 */     insert(pattern, (char)k);
/*     */   }
/*     */ 
/*     */   public void printStats(PrintStream out)
/*     */   {
/* 466 */     out.println(new StringBuilder().append("Value space size = ").append(Integer.toString(this.vspace.length())).toString());
/*     */ 
/* 468 */     super.printStats(out);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.compound.hyphenation.HyphenationTree
 * JD-Core Version:    0.6.2
 */