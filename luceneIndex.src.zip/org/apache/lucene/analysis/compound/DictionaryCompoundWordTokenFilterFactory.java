/*    */ package org.apache.lucene.analysis.compound;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.CharArraySet;
/*    */ import org.apache.lucene.analysis.util.ResourceLoader;
/*    */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class DictionaryCompoundWordTokenFilterFactory extends TokenFilterFactory
/*    */   implements ResourceLoaderAware
/*    */ {
/*    */   private CharArraySet dictionary;
/*    */   private final String dictFile;
/*    */   private final int minWordSize;
/*    */   private final int minSubwordSize;
/*    */   private final int maxSubwordSize;
/*    */   private final boolean onlyLongestMatch;
/*    */ 
/*    */   public DictionaryCompoundWordTokenFilterFactory(Map<String, String> args)
/*    */   {
/* 50 */     super(args);
/* 51 */     assureMatchVersion();
/* 52 */     this.dictFile = require(args, "dictionary");
/* 53 */     this.minWordSize = getInt(args, "minWordSize", 5);
/* 54 */     this.minSubwordSize = getInt(args, "minSubwordSize", 2);
/* 55 */     this.maxSubwordSize = getInt(args, "maxSubwordSize", 15);
/* 56 */     this.onlyLongestMatch = getBoolean(args, "onlyLongestMatch", true);
/* 57 */     if (!args.isEmpty())
/* 58 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public void inform(ResourceLoader loader)
/*    */     throws IOException
/*    */   {
/* 64 */     this.dictionary = super.getWordSet(loader, this.dictFile, false);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 70 */     return this.dictionary == null ? input : new DictionaryCompoundWordTokenFilter(this.luceneMatchVersion, input, this.dictionary, this.minWordSize, this.minSubwordSize, this.maxSubwordSize, this.onlyLongestMatch);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.compound.DictionaryCompoundWordTokenFilterFactory
 * JD-Core Version:    0.6.2
 */