/*     */ package org.apache.lucene.analysis.de;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.util.StemmerUtil;
/*     */ 
/*     */ public final class GermanNormalizationFilter extends TokenFilter
/*     */ {
/*     */   private static final int N = 0;
/*     */   private static final int V = 1;
/*     */   private static final int U = 2;
/*  49 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */ 
/*     */   public GermanNormalizationFilter(TokenStream input) {
/*  52 */     super(input);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  57 */     if (this.input.incrementToken()) {
/*  58 */       int state = 0;
/*  59 */       char[] buffer = this.termAtt.buffer();
/*  60 */       int length = this.termAtt.length();
/*  61 */       for (int i = 0; i < length; i++) {
/*  62 */         char c = buffer[i];
/*  63 */         switch (c) {
/*     */         case 'a':
/*     */         case 'o':
/*  66 */           state = 2;
/*  67 */           break;
/*     */         case 'u':
/*  69 */           state = state == 0 ? 2 : 1;
/*  70 */           break;
/*     */         case 'e':
/*  72 */           if (state == 2)
/*  73 */             length = StemmerUtil.delete(buffer, i--, length);
/*  74 */           state = 1;
/*  75 */           break;
/*     */         case 'i':
/*     */         case 'q':
/*     */         case 'y':
/*  79 */           state = 1;
/*  80 */           break;
/*     */         case 'ä':
/*  82 */           buffer[i] = 'a';
/*  83 */           state = 1;
/*  84 */           break;
/*     */         case 'ö':
/*  86 */           buffer[i] = 'o';
/*  87 */           state = 1;
/*  88 */           break;
/*     */         case 'ü':
/*  90 */           buffer[i] = 'u';
/*  91 */           state = 1;
/*  92 */           break;
/*     */         case 'ß':
/*  94 */           buffer[(i++)] = 's';
/*  95 */           buffer = this.termAtt.resizeBuffer(1 + length);
/*  96 */           if (i < length)
/*  97 */             System.arraycopy(buffer, i, buffer, i + 1, length - i);
/*  98 */           buffer[i] = 's';
/*  99 */           length++;
/* 100 */           state = 0;
/* 101 */           break;
/*     */         default:
/* 103 */           state = 0;
/*     */         }
/*     */       }
/* 106 */       this.termAtt.setLength(length);
/* 107 */       return true;
/*     */     }
/* 109 */     return false;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.de.GermanNormalizationFilter
 * JD-Core Version:    0.6.2
 */