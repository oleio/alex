/*    */ package org.apache.lucene.analysis;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public abstract class TokenFilter extends TokenStream
/*    */ {
/*    */   protected final TokenStream input;
/*    */ 
/*    */   protected TokenFilter(TokenStream input)
/*    */   {
/* 33 */     super(input);
/* 34 */     this.input = input;
/*    */   }
/*    */ 
/*    */   public void end()
/*    */     throws IOException
/*    */   {
/* 46 */     this.input.end();
/*    */   }
/*    */ 
/*    */   public void close()
/*    */     throws IOException
/*    */   {
/* 58 */     this.input.close();
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */     throws IOException
/*    */   {
/* 70 */     this.input.reset();
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.TokenFilter
 * JD-Core Version:    0.6.2
 */