/*     */ package org.apache.lucene.analysis.tokenattributes;
/*     */ 
/*     */ import java.nio.CharBuffer;
/*     */ import org.apache.lucene.util.ArrayUtil;
/*     */ import org.apache.lucene.util.AttributeImpl;
/*     */ import org.apache.lucene.util.AttributeReflector;
/*     */ import org.apache.lucene.util.BytesRef;
/*     */ import org.apache.lucene.util.UnicodeUtil;
/*     */ 
/*     */ public class CharTermAttributeImpl extends AttributeImpl
/*     */   implements CharTermAttribute, TermToBytesRefAttribute, Cloneable
/*     */ {
/*  31 */   private static int MIN_BUFFER_SIZE = 10;
/*     */ 
/*  33 */   private char[] termBuffer = new char[ArrayUtil.oversize(MIN_BUFFER_SIZE, 2)];
/*  34 */   private int termLength = 0;
/*     */ 
/*  86 */   private BytesRef bytes = new BytesRef(MIN_BUFFER_SIZE);
/*     */ 
/*     */   public final void copyBuffer(char[] buffer, int offset, int length)
/*     */   {
/*  41 */     growTermBuffer(length);
/*  42 */     System.arraycopy(buffer, offset, this.termBuffer, 0, length);
/*  43 */     this.termLength = length;
/*     */   }
/*     */ 
/*     */   public final char[] buffer()
/*     */   {
/*  48 */     return this.termBuffer;
/*     */   }
/*     */ 
/*     */   public final char[] resizeBuffer(int newSize)
/*     */   {
/*  53 */     if (this.termBuffer.length < newSize)
/*     */     {
/*  56 */       char[] newCharBuffer = new char[ArrayUtil.oversize(newSize, 2)];
/*  57 */       System.arraycopy(this.termBuffer, 0, newCharBuffer, 0, this.termBuffer.length);
/*  58 */       this.termBuffer = newCharBuffer;
/*     */     }
/*  60 */     return this.termBuffer;
/*     */   }
/*     */ 
/*     */   private void growTermBuffer(int newSize) {
/*  64 */     if (this.termBuffer.length < newSize)
/*     */     {
/*  67 */       this.termBuffer = new char[ArrayUtil.oversize(newSize, 2)];
/*     */     }
/*     */   }
/*     */ 
/*     */   public final CharTermAttribute setLength(int length)
/*     */   {
/*  73 */     if (length > this.termBuffer.length)
/*  74 */       throw new IllegalArgumentException("length " + length + " exceeds the size of the termBuffer (" + this.termBuffer.length + ")");
/*  75 */     this.termLength = length;
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */   public final CharTermAttribute setEmpty()
/*     */   {
/*  81 */     this.termLength = 0;
/*  82 */     return this;
/*     */   }
/*     */ 
/*     */   public void fillBytesRef()
/*     */   {
/*  90 */     UnicodeUtil.UTF16toUTF8(this.termBuffer, 0, this.termLength, this.bytes);
/*     */   }
/*     */ 
/*     */   public BytesRef getBytesRef()
/*     */   {
/*  95 */     return this.bytes;
/*     */   }
/*     */ 
/*     */   public final int length()
/*     */   {
/* 101 */     return this.termLength;
/*     */   }
/*     */ 
/*     */   public final char charAt(int index)
/*     */   {
/* 106 */     if (index >= this.termLength)
/* 107 */       throw new IndexOutOfBoundsException();
/* 108 */     return this.termBuffer[index];
/*     */   }
/*     */ 
/*     */   public final CharSequence subSequence(int start, int end)
/*     */   {
/* 113 */     if ((start > this.termLength) || (end > this.termLength))
/* 114 */       throw new IndexOutOfBoundsException();
/* 115 */     return new String(this.termBuffer, start, end - start);
/*     */   }
/*     */ 
/*     */   public final CharTermAttribute append(CharSequence csq)
/*     */   {
/* 122 */     if (csq == null)
/* 123 */       return appendNull();
/* 124 */     return append(csq, 0, csq.length());
/*     */   }
/*     */ 
/*     */   public final CharTermAttribute append(CharSequence csq, int start, int end)
/*     */   {
/* 129 */     if (csq == null)
/* 130 */       csq = "null";
/* 131 */     int len = end - start; int csqlen = csq.length();
/* 132 */     if ((len < 0) || (start > csqlen) || (end > csqlen))
/* 133 */       throw new IndexOutOfBoundsException();
/* 134 */     if (len == 0)
/* 135 */       return this;
/* 136 */     resizeBuffer(this.termLength + len);
/* 137 */     if (len > 4) {
/* 138 */       if ((csq instanceof String)) {
/* 139 */         ((String)csq).getChars(start, end, this.termBuffer, this.termLength);
/* 140 */       } else if ((csq instanceof StringBuilder)) {
/* 141 */         ((StringBuilder)csq).getChars(start, end, this.termBuffer, this.termLength);
/* 142 */       } else if ((csq instanceof Cloneable)) {
/* 143 */         System.arraycopy(((Cloneable)csq).buffer(), start, this.termBuffer, this.termLength, len);
/* 144 */       } else if (((csq instanceof CharBuffer)) && (((CharBuffer)csq).hasArray())) {
/* 145 */         CharBuffer cb = (CharBuffer)csq;
/* 146 */         System.arraycopy(cb.array(), cb.arrayOffset() + cb.position() + start, this.termBuffer, this.termLength, len);
/* 147 */       } else if ((csq instanceof StringBuffer)) {
/* 148 */         ((StringBuffer)csq).getChars(start, end, this.termBuffer, this.termLength);
/*     */       } else {
/* 150 */         while (start < end) {
/* 151 */           this.termBuffer[(this.termLength++)] = csq.charAt(start++);
/*     */         }
/* 153 */         return this;
/*     */       }
/* 155 */       this.termLength += len;
/* 156 */       return this;
/*     */     }
/* 158 */     while (start < end)
/* 159 */       this.termBuffer[(this.termLength++)] = csq.charAt(start++);
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */   public final CharTermAttribute append(char c)
/*     */   {
/* 166 */     resizeBuffer(this.termLength + 1)[(this.termLength++)] = c;
/* 167 */     return this;
/*     */   }
/*     */ 
/*     */   public final CharTermAttribute append(String s)
/*     */   {
/* 174 */     if (s == null)
/* 175 */       return appendNull();
/* 176 */     int len = s.length();
/* 177 */     s.getChars(0, len, resizeBuffer(this.termLength + len), this.termLength);
/* 178 */     this.termLength += len;
/* 179 */     return this;
/*     */   }
/*     */ 
/*     */   public final CharTermAttribute append(StringBuilder s)
/*     */   {
/* 184 */     if (s == null)
/* 185 */       return appendNull();
/* 186 */     int len = s.length();
/* 187 */     s.getChars(0, len, resizeBuffer(this.termLength + len), this.termLength);
/* 188 */     this.termLength += len;
/* 189 */     return this;
/*     */   }
/*     */ 
/*     */   public final CharTermAttribute append(CharTermAttribute ta)
/*     */   {
/* 194 */     if (ta == null)
/* 195 */       return appendNull();
/* 196 */     int len = ta.length();
/* 197 */     System.arraycopy(ta.buffer(), 0, resizeBuffer(this.termLength + len), this.termLength, len);
/* 198 */     this.termLength += len;
/* 199 */     return this;
/*     */   }
/*     */ 
/*     */   private CharTermAttribute appendNull() {
/* 203 */     resizeBuffer(this.termLength + 4);
/* 204 */     this.termBuffer[(this.termLength++)] = 'n';
/* 205 */     this.termBuffer[(this.termLength++)] = 'u';
/* 206 */     this.termBuffer[(this.termLength++)] = 'l';
/* 207 */     this.termBuffer[(this.termLength++)] = 'l';
/* 208 */     return this;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 215 */     int code = this.termLength;
/* 216 */     code = code * 31 + ArrayUtil.hashCode(this.termBuffer, 0, this.termLength);
/* 217 */     return code;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 222 */     this.termLength = 0;
/*     */   }
/*     */ 
/*     */   public CharTermAttributeImpl clone()
/*     */   {
/* 227 */     CharTermAttributeImpl t = (CharTermAttributeImpl)super.clone();
/*     */ 
/* 229 */     t.termBuffer = new char[this.termLength];
/* 230 */     System.arraycopy(this.termBuffer, 0, t.termBuffer, 0, this.termLength);
/* 231 */     t.bytes = BytesRef.deepCopyOf(this.bytes);
/* 232 */     return t;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 237 */     if (other == this) {
/* 238 */       return true;
/*     */     }
/*     */ 
/* 241 */     if ((other instanceof CharTermAttributeImpl)) {
/* 242 */       CharTermAttributeImpl o = (CharTermAttributeImpl)other;
/* 243 */       if (this.termLength != o.termLength)
/* 244 */         return false;
/* 245 */       for (int i = 0; i < this.termLength; i++) {
/* 246 */         if (this.termBuffer[i] != o.termBuffer[i]) {
/* 247 */           return false;
/*     */         }
/*     */       }
/* 250 */       return true;
/*     */     }
/*     */ 
/* 253 */     return false;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 267 */     return new String(this.termBuffer, 0, this.termLength);
/*     */   }
/*     */ 
/*     */   public void reflectWith(AttributeReflector reflector)
/*     */   {
/* 272 */     reflector.reflect(Cloneable.class, "term", toString());
/* 273 */     fillBytesRef();
/* 274 */     reflector.reflect(TermToBytesRefAttribute.class, "bytes", BytesRef.deepCopyOf(this.bytes));
/*     */   }
/*     */ 
/*     */   public void copyTo(AttributeImpl target)
/*     */   {
/* 279 */     CharTermAttribute t = (Cloneable)target;
/* 280 */     t.copyBuffer(this.termBuffer, 0, this.termLength);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.tokenattributes.CharTermAttributeImpl
 * JD-Core Version:    0.6.2
 */