/*    */ package org.apache.lucene.analysis.tokenattributes;
/*    */ 
/*    */ import org.apache.lucene.util.AttributeImpl;
/*    */ 
/*    */ public class FlagsAttributeImpl extends AttributeImpl
/*    */   implements FlagsAttribute, Cloneable
/*    */ {
/* 24 */   private int flags = 0;
/*    */ 
/*    */   public int getFlags()
/*    */   {
/* 31 */     return this.flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int flags)
/*    */   {
/* 36 */     this.flags = flags;
/*    */   }
/*    */ 
/*    */   public void clear()
/*    */   {
/* 41 */     this.flags = 0;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 46 */     if (this == other) {
/* 47 */       return true;
/*    */     }
/*    */ 
/* 50 */     if ((other instanceof FlagsAttributeImpl)) {
/* 51 */       return ((FlagsAttributeImpl)other).flags == this.flags;
/*    */     }
/*    */ 
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 59 */     return this.flags;
/*    */   }
/*    */ 
/*    */   public void copyTo(AttributeImpl target)
/*    */   {
/* 64 */     FlagsAttribute t = (Cloneable)target;
/* 65 */     t.setFlags(this.flags);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.tokenattributes.FlagsAttributeImpl
 * JD-Core Version:    0.6.2
 */