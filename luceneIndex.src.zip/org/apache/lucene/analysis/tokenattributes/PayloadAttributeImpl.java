/*    */ package org.apache.lucene.analysis.tokenattributes;
/*    */ 
/*    */ import org.apache.lucene.util.AttributeImpl;
/*    */ import org.apache.lucene.util.BytesRef;
/*    */ 
/*    */ public class PayloadAttributeImpl extends AttributeImpl
/*    */   implements PayloadAttribute, Cloneable
/*    */ {
/*    */   private BytesRef payload;
/*    */ 
/*    */   public PayloadAttributeImpl()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PayloadAttributeImpl(BytesRef payload)
/*    */   {
/* 36 */     this.payload = payload;
/*    */   }
/*    */ 
/*    */   public BytesRef getPayload()
/*    */   {
/* 41 */     return this.payload;
/*    */   }
/*    */ 
/*    */   public void setPayload(BytesRef payload)
/*    */   {
/* 46 */     this.payload = payload;
/*    */   }
/*    */ 
/*    */   public void clear()
/*    */   {
/* 51 */     this.payload = null;
/*    */   }
/*    */ 
/*    */   public PayloadAttributeImpl clone()
/*    */   {
/* 56 */     PayloadAttributeImpl clone = (PayloadAttributeImpl)super.clone();
/* 57 */     if (this.payload != null) {
/* 58 */       clone.payload = this.payload.clone();
/*    */     }
/* 60 */     return clone;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 65 */     if (other == this) {
/* 66 */       return true;
/*    */     }
/*    */ 
/* 69 */     if ((other instanceof Cloneable)) {
/* 70 */       PayloadAttributeImpl o = (PayloadAttributeImpl)other;
/* 71 */       if ((o.payload == null) || (this.payload == null)) {
/* 72 */         return (o.payload == null) && (this.payload == null);
/*    */       }
/*    */ 
/* 75 */       return o.payload.equals(this.payload);
/*    */     }
/*    */ 
/* 78 */     return false;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 83 */     return this.payload == null ? 0 : this.payload.hashCode();
/*    */   }
/*    */ 
/*    */   public void copyTo(AttributeImpl target)
/*    */   {
/* 88 */     PayloadAttribute t = (Cloneable)target;
/* 89 */     t.setPayload(this.payload == null ? null : this.payload.clone());
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.tokenattributes.PayloadAttributeImpl
 * JD-Core Version:    0.6.2
 */