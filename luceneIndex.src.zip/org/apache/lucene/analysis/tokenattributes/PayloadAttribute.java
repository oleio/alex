package org.apache.lucene.analysis.tokenattributes;

import org.apache.lucene.util.Attribute;
import org.apache.lucene.util.BytesRef;

public abstract interface PayloadAttribute extends Attribute
{
  public abstract BytesRef getPayload();

  public abstract void setPayload(BytesRef paramBytesRef);
}

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.tokenattributes.PayloadAttribute
 * JD-Core Version:    0.6.2
 */