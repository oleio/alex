/*    */ package org.apache.lucene.analysis.tr;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ 
/*    */ public final class ApostropheFilter extends TokenFilter
/*    */ {
/* 38 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */ 
/*    */   public ApostropheFilter(TokenStream in) {
/* 41 */     super(in);
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken() throws IOException
/*    */   {
/* 46 */     if (!this.input.incrementToken()) {
/* 47 */       return false;
/*    */     }
/* 49 */     char[] buffer = this.termAtt.buffer();
/* 50 */     int length = this.termAtt.length();
/*    */ 
/* 52 */     for (int i = 0; i < length; i++)
/* 53 */       if ((buffer[i] == '\'') || (buffer[i] == '’')) {
/* 54 */         this.termAtt.setLength(i);
/* 55 */         return true;
/*    */       }
/* 57 */     return true;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.tr.ApostropheFilter
 * JD-Core Version:    0.6.2
 */