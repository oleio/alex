/*     */ package org.apache.lucene.analysis.no;
/*     */ 
/*     */ import org.apache.lucene.analysis.util.StemmerUtil;
/*     */ 
/*     */ public class NorwegianMinimalStemmer
/*     */ {
/*     */   final boolean useBokmaal;
/*     */   final boolean useNynorsk;
/*     */ 
/*     */   public NorwegianMinimalStemmer(int flags)
/*     */   {
/*  74 */     if ((flags <= 0) || (flags > 3)) {
/*  75 */       throw new IllegalArgumentException("invalid flags");
/*     */     }
/*  77 */     this.useBokmaal = ((flags & 0x1) != 0);
/*  78 */     this.useNynorsk = ((flags & 0x2) != 0);
/*     */   }
/*     */ 
/*     */   public int stem(char[] s, int len)
/*     */   {
/*  83 */     if ((len > 4) && (s[(len - 1)] == 's')) {
/*  84 */       len--;
/*     */     }
/*  86 */     if ((len > 5) && ((StemmerUtil.endsWith(s, len, "ene")) || ((StemmerUtil.endsWith(s, len, "ane")) && (this.useNynorsk))))
/*     */     {
/*  91 */       return len - 3;
/*     */     }
/*  93 */     if ((len > 4) && ((StemmerUtil.endsWith(s, len, "er")) || (StemmerUtil.endsWith(s, len, "en")) || (StemmerUtil.endsWith(s, len, "et")) || ((StemmerUtil.endsWith(s, len, "ar")) && (this.useNynorsk))))
/*     */     {
/* 100 */       return len - 2;
/*     */     }
/* 102 */     if (len > 3) {
/* 103 */       switch (s[(len - 1)]) {
/*     */       case 'a':
/*     */       case 'e':
/* 106 */         return len - 1;
/*     */       }
/*     */     }
/* 109 */     return len;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.no.NorwegianMinimalStemmer
 * JD-Core Version:    0.6.2
 */