/*    */ package org.apache.lucene.analysis.no;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class NorwegianMinimalStemFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   private final int flags;
/*    */ 
/*    */   public NorwegianMinimalStemFilterFactory(Map<String, String> args)
/*    */   {
/* 46 */     super(args);
/* 47 */     String variant = get(args, "variant");
/* 48 */     if ((variant == null) || ("nb".equals(variant)))
/* 49 */       this.flags = 1;
/* 50 */     else if ("nn".equals(variant))
/* 51 */       this.flags = 2;
/* 52 */     else if ("no".equals(variant))
/* 53 */       this.flags = 3;
/*    */     else {
/* 55 */       throw new IllegalArgumentException("invalid variant: " + variant);
/*    */     }
/* 57 */     if (!args.isEmpty())
/* 58 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 64 */     return new NorwegianMinimalStemFilter(input, this.flags);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.no.NorwegianMinimalStemFilterFactory
 * JD-Core Version:    0.6.2
 */