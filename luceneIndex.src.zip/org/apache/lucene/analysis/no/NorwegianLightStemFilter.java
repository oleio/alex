/*    */ package org.apache.lucene.analysis.no;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.KeywordAttribute;
/*    */ 
/*    */ public final class NorwegianLightStemFilter extends TokenFilter
/*    */ {
/*    */   private final NorwegianLightStemmer stemmer;
/* 39 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 40 */   private final KeywordAttribute keywordAttr = (KeywordAttribute)addAttribute(KeywordAttribute.class);
/*    */ 
/*    */   public NorwegianLightStemFilter(TokenStream input)
/*    */   {
/* 47 */     this(input, 1);
/*    */   }
/*    */ 
/*    */   public NorwegianLightStemFilter(TokenStream input, int flags)
/*    */   {
/* 56 */     super(input);
/* 57 */     this.stemmer = new NorwegianLightStemmer(flags);
/*    */   }
/*    */ 
/*    */   public boolean incrementToken() throws IOException
/*    */   {
/* 62 */     if (this.input.incrementToken()) {
/* 63 */       if (!this.keywordAttr.isKeyword()) {
/* 64 */         int newlen = this.stemmer.stem(this.termAtt.buffer(), this.termAtt.length());
/* 65 */         this.termAtt.setLength(newlen);
/*    */       }
/* 67 */       return true;
/*    */     }
/* 69 */     return false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.no.NorwegianLightStemFilter
 * JD-Core Version:    0.6.2
 */