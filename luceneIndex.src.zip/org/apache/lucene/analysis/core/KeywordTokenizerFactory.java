/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public class KeywordTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   public KeywordTokenizerFactory(Map<String, String> args)
/*    */   {
/* 39 */     super(args);
/* 40 */     if (!args.isEmpty())
/* 41 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public KeywordTokenizer create(AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 47 */     return new KeywordTokenizer(factory, input, 256);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.core.KeywordTokenizerFactory
 * JD-Core Version:    0.6.2
 */