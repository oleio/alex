/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.ResourceLoader;
/*    */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class TypeTokenFilterFactory extends TokenFilterFactory
/*    */   implements ResourceLoaderAware
/*    */ {
/*    */   private final boolean useWhitelist;
/*    */   private final boolean enablePositionIncrements;
/*    */   private final String stopTypesFiles;
/*    */   private Set<String> stopTypes;
/*    */ 
/*    */   public TypeTokenFilterFactory(Map<String, String> args)
/*    */   {
/* 50 */     super(args);
/* 51 */     this.stopTypesFiles = require(args, "types");
/* 52 */     this.enablePositionIncrements = getBoolean(args, "enablePositionIncrements", true);
/* 53 */     this.useWhitelist = getBoolean(args, "useWhitelist", false);
/* 54 */     if (!args.isEmpty())
/* 55 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public void inform(ResourceLoader loader)
/*    */     throws IOException
/*    */   {
/* 61 */     List files = splitFileNames(this.stopTypesFiles);
/* 62 */     if (files.size() > 0) {
/* 63 */       this.stopTypes = new HashSet();
/* 64 */       for (String file : files) {
/* 65 */         List typesLines = getLines(loader, file.trim());
/* 66 */         this.stopTypes.addAll(typesLines);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean isEnablePositionIncrements() {
/* 72 */     return this.enablePositionIncrements;
/*    */   }
/*    */ 
/*    */   public Set<String> getStopTypes() {
/* 76 */     return this.stopTypes;
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 82 */     TokenStream filter = new TypeTokenFilter(this.luceneMatchVersion, this.enablePositionIncrements, input, this.stopTypes, this.useWhitelist);
/* 83 */     return filter;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.core.TypeTokenFilterFactory
 * JD-Core Version:    0.6.2
 */