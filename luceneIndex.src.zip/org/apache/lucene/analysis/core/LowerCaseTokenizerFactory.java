/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.util.AbstractAnalysisFactory;
/*    */ import org.apache.lucene.analysis.util.MultiTermAwareComponent;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public class LowerCaseTokenizerFactory extends TokenizerFactory
/*    */   implements MultiTermAwareComponent
/*    */ {
/*    */   public LowerCaseTokenizerFactory(Map<String, String> args)
/*    */   {
/* 42 */     super(args);
/* 43 */     assureMatchVersion();
/* 44 */     if (!args.isEmpty())
/* 45 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public LowerCaseTokenizer create(AttributeSource.AttributeFactory factory, Reader input)
/*    */   {
/* 51 */     return new LowerCaseTokenizer(this.luceneMatchVersion, factory, input);
/*    */   }
/*    */ 
/*    */   public AbstractAnalysisFactory getMultiTermComponent()
/*    */   {
/* 56 */     return new LowerCaseFilterFactory(new HashMap(getOriginalArgs()));
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.core.LowerCaseTokenizerFactory
 * JD-Core Version:    0.6.2
 */