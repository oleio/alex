/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.Tokenizer;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public final class KeywordTokenizer extends Tokenizer
/*    */ {
/*    */   public static final int DEFAULT_BUFFER_SIZE = 256;
/* 34 */   private boolean done = false;
/*    */   private int finalOffset;
/* 36 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 37 */   private OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*    */ 
/*    */   public KeywordTokenizer(Reader input) {
/* 40 */     this(input, 256);
/*    */   }
/*    */ 
/*    */   public KeywordTokenizer(Reader input, int bufferSize) {
/* 44 */     super(input);
/* 45 */     if (bufferSize <= 0) {
/* 46 */       throw new IllegalArgumentException("bufferSize must be > 0");
/*    */     }
/* 48 */     this.termAtt.resizeBuffer(bufferSize);
/*    */   }
/*    */ 
/*    */   public KeywordTokenizer(AttributeSource.AttributeFactory factory, Reader input, int bufferSize) {
/* 52 */     super(factory, input);
/* 53 */     if (bufferSize <= 0) {
/* 54 */       throw new IllegalArgumentException("bufferSize must be > 0");
/*    */     }
/* 56 */     this.termAtt.resizeBuffer(bufferSize);
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken() throws IOException
/*    */   {
/* 61 */     if (!this.done) {
/* 62 */       clearAttributes();
/* 63 */       this.done = true;
/* 64 */       int upto = 0;
/* 65 */       char[] buffer = this.termAtt.buffer();
/*    */       while (true) {
/* 67 */         int length = this.input.read(buffer, upto, buffer.length - upto);
/* 68 */         if (length == -1) break;
/* 69 */         upto += length;
/* 70 */         if (upto == buffer.length)
/* 71 */           buffer = this.termAtt.resizeBuffer(1 + buffer.length);
/*    */       }
/* 73 */       this.termAtt.setLength(upto);
/* 74 */       this.finalOffset = correctOffset(upto);
/* 75 */       this.offsetAtt.setOffset(correctOffset(0), this.finalOffset);
/* 76 */       return true;
/*    */     }
/* 78 */     return false;
/*    */   }
/*    */ 
/*    */   public final void end() throws IOException
/*    */   {
/* 83 */     super.end();
/*    */ 
/* 85 */     this.offsetAtt.setOffset(this.finalOffset, this.finalOffset);
/*    */   }
/*    */ 
/*    */   public void reset() throws IOException
/*    */   {
/* 90 */     super.reset();
/* 91 */     this.done = false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.core.KeywordTokenizer
 * JD-Core Version:    0.6.2
 */