/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.util.CharTokenizer;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public class LetterTokenizer extends CharTokenizer
/*    */ {
/*    */   public LetterTokenizer(Version matchVersion, Reader in)
/*    */   {
/* 57 */     super(matchVersion, in);
/*    */   }
/*    */ 
/*    */   public LetterTokenizer(Version matchVersion, AttributeSource.AttributeFactory factory, Reader in)
/*    */   {
/* 72 */     super(matchVersion, factory, in);
/*    */   }
/*    */ 
/*    */   protected boolean isTokenChar(int c)
/*    */   {
/* 79 */     return Character.isLetter(c);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.core.LetterTokenizer
 * JD-Core Version:    0.6.2
 */