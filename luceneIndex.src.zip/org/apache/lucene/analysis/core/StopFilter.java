/*     */ package org.apache.lucene.analysis.core;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.FilteringTokenFilter;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class StopFilter extends FilteringTokenFilter
/*     */ {
/*     */   private final CharArraySet stopWords;
/*  44 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */ 
/*     */   public StopFilter(Version matchVersion, TokenStream in, CharArraySet stopWords)
/*     */   {
/*  60 */     super(matchVersion, in);
/*  61 */     this.stopWords = stopWords;
/*     */   }
/*     */ 
/*     */   public static CharArraySet makeStopSet(Version matchVersion, String[] stopWords)
/*     */   {
/*  75 */     return makeStopSet(matchVersion, stopWords, false);
/*     */   }
/*     */ 
/*     */   public static CharArraySet makeStopSet(Version matchVersion, List<?> stopWords)
/*     */   {
/*  90 */     return makeStopSet(matchVersion, stopWords, false);
/*     */   }
/*     */ 
/*     */   public static CharArraySet makeStopSet(Version matchVersion, String[] stopWords, boolean ignoreCase)
/*     */   {
/* 102 */     CharArraySet stopSet = new CharArraySet(matchVersion, stopWords.length, ignoreCase);
/* 103 */     stopSet.addAll(Arrays.asList(stopWords));
/* 104 */     return stopSet;
/*     */   }
/*     */ 
/*     */   public static CharArraySet makeStopSet(Version matchVersion, List<?> stopWords, boolean ignoreCase)
/*     */   {
/* 115 */     CharArraySet stopSet = new CharArraySet(matchVersion, stopWords.size(), ignoreCase);
/* 116 */     stopSet.addAll(stopWords);
/* 117 */     return stopSet;
/*     */   }
/*     */ 
/*     */   protected boolean accept()
/*     */   {
/* 125 */     return !this.stopWords.contains(this.termAtt.buffer(), 0, this.termAtt.length());
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.core.StopFilter
 * JD-Core Version:    0.6.2
 */