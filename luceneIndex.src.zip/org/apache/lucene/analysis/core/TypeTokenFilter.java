/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*    */ import org.apache.lucene.analysis.util.FilteringTokenFilter;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public final class TypeTokenFilter extends FilteringTokenFilter
/*    */ {
/*    */   private final Set<String> stopTypes;
/* 33 */   private final TypeAttribute typeAttribute = (TypeAttribute)addAttribute(TypeAttribute.class);
/*    */   private final boolean useWhiteList;
/*    */ 
/*    */   @Deprecated
/*    */   public TypeTokenFilter(Version version, boolean enablePositionIncrements, TokenStream input, Set<String> stopTypes, boolean useWhiteList)
/*    */   {
/* 39 */     super(version, enablePositionIncrements, input);
/* 40 */     this.stopTypes = stopTypes;
/* 41 */     this.useWhiteList = useWhiteList;
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   public TypeTokenFilter(Version version, boolean enablePositionIncrements, TokenStream input, Set<String> stopTypes)
/*    */   {
/* 47 */     this(version, enablePositionIncrements, input, stopTypes, false);
/*    */   }
/*    */ 
/*    */   public TypeTokenFilter(Version version, TokenStream input, Set<String> stopTypes, boolean useWhiteList)
/*    */   {
/* 59 */     super(version, input);
/* 60 */     this.stopTypes = stopTypes;
/* 61 */     this.useWhiteList = useWhiteList;
/*    */   }
/*    */ 
/*    */   public TypeTokenFilter(Version version, TokenStream input, Set<String> stopTypes)
/*    */   {
/* 70 */     this(version, input, stopTypes, false);
/*    */   }
/*    */ 
/*    */   protected boolean accept()
/*    */   {
/* 79 */     return this.useWhiteList == this.stopTypes.contains(this.typeAttribute.type());
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.core.TypeTokenFilter
 * JD-Core Version:    0.6.2
 */