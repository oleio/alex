/*    */ package org.apache.lucene.analysis.core;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.AbstractAnalysisFactory;
/*    */ import org.apache.lucene.analysis.util.MultiTermAwareComponent;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class UpperCaseFilterFactory extends TokenFilterFactory
/*    */   implements MultiTermAwareComponent
/*    */ {
/*    */   public UpperCaseFilterFactory(Map<String, String> args)
/*    */   {
/* 47 */     super(args);
/* 48 */     assureMatchVersion();
/* 49 */     if (!args.isEmpty())
/* 50 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public UpperCaseFilter create(TokenStream input)
/*    */   {
/* 56 */     return new UpperCaseFilter(this.luceneMatchVersion, input);
/*    */   }
/*    */ 
/*    */   public AbstractAnalysisFactory getMultiTermComponent()
/*    */   {
/* 61 */     return this;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.core.UpperCaseFilterFactory
 * JD-Core Version:    0.6.2
 */