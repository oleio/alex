/*     */ package org.apache.lucene.analysis.el;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class GreekAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*     */ 
/*     */   public static final CharArraySet getDefaultStopSet()
/*     */   {
/*  62 */     return DefaultSetHolder.DEFAULT_SET;
/*     */   }
/*     */ 
/*     */   public GreekAnalyzer(Version matchVersion)
/*     */   {
/*  85 */     this(matchVersion, DefaultSetHolder.DEFAULT_SET);
/*     */   }
/*     */ 
/*     */   public GreekAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/*  99 */     super(matchVersion, stopwords);
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 115 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 116 */     TokenStream result = new GreekLowerCaseFilter(this.matchVersion, source);
/* 117 */     if (this.matchVersion.onOrAfter(Version.LUCENE_31))
/* 118 */       result = new StandardFilter(this.matchVersion, result);
/* 119 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 120 */     if (this.matchVersion.onOrAfter(Version.LUCENE_31))
/* 121 */       result = new GreekStemFilter(result);
/* 122 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     private static final CharArraySet DEFAULT_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  70 */         DEFAULT_SET = GreekAnalyzer.loadStopwordSet(false, GreekAnalyzer.class, "stopwords.txt", "#");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  74 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.el.GreekAnalyzer
 * JD-Core Version:    0.6.2
 */