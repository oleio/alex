/*      */ package org.apache.lucene.analysis.standard;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*      */ 
/*      */ public final class StandardTokenizerImpl
/*      */   implements StandardTokenizerInterface
/*      */ {
/*      */   public static final int YYEOF = -1;
/*      */   private static final int ZZ_BUFFERSIZE = 4096;
/*      */   public static final int YYINITIAL = 0;
/*   59 */   private static final int[] ZZ_LEXSTATE = { 0, 0 };
/*      */   private static final String ZZ_CMAP_PACKED = "";
/*  214 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*      */ 
/*  219 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*      */   private static final String ZZ_ACTION_PACKED_0 = "";
/*  249 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*      */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/*  299 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*      */   private static final String ZZ_TRANS_PACKED_0 = "";
/*      */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*      */   private static final int ZZ_NO_MATCH = 1;
/*      */   private static final int ZZ_PUSHBACK_2BIG = 2;
/*  842 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*      */ 
/*  851 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*      */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*      */   private Reader zzReader;
/*      */   private int zzState;
/*  883 */   private int zzLexicalState = 0;
/*      */ 
/*  887 */   private char[] zzBuffer = new char[4096];
/*      */   private int zzMarkedPos;
/*      */   private int zzCurrentPos;
/*      */   private int zzStartRead;
/*      */   private int zzEndRead;
/*      */   private int yyline;
/*      */   private int yychar;
/*      */   private int yycolumn;
/*  917 */   private boolean zzAtBOL = true;
/*      */   private boolean zzAtEOF;
/*      */   private boolean zzEOFDone;
/*      */   public static final int WORD_TYPE = 0;
/*      */   public static final int NUMERIC_TYPE = 6;
/*      */   public static final int SOUTH_EAST_ASIAN_TYPE = 9;
/*      */   public static final int IDEOGRAPHIC_TYPE = 10;
/*      */   public static final int HIRAGANA_TYPE = 11;
/*      */   public static final int KATAKANA_TYPE = 12;
/*      */   public static final int HANGUL_TYPE = 13;
/*      */ 
/*      */   private static int[] zzUnpackAction()
/*      */   {
/*  227 */     int[] result = new int['Å'];
/*  228 */     int offset = 0;
/*  229 */     offset = zzUnpackAction("", offset, result);
/*  230 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  234 */     int i = 0;
/*  235 */     int j = offset;
/*  236 */     int l = packed.length();
/*      */     int count;
/*  240 */     for (; i < l; 
/*  240 */       count > 0)
/*      */     {
/*  238 */       count = packed.charAt(i++);
/*  239 */       int value = packed.charAt(i++);
/*  240 */       result[(j++)] = value; count--;
/*      */     }
/*  242 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackRowMap()
/*      */   {
/*  279 */     int[] result = new int['Å'];
/*  280 */     int offset = 0;
/*  281 */     offset = zzUnpackRowMap("", offset, result);
/*  282 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/*  286 */     int i = 0;
/*  287 */     int j = offset;
/*  288 */     int l = packed.length();
/*  289 */     while (i < l) {
/*  290 */       int high = packed.charAt(i++) << '\020';
/*  291 */       result[(j++)] = (high | packed.charAt(i++));
/*      */     }
/*  293 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackTrans()
/*      */   {
/*  816 */     int[] result = new int[26554];
/*  817 */     int offset = 0;
/*  818 */     offset = zzUnpackTrans("", offset, result);
/*  819 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/*  823 */     int i = 0;
/*  824 */     int j = offset;
/*  825 */     int l = packed.length();
/*      */     int count;
/*  830 */     for (; i < l; 
/*  830 */       count > 0)
/*      */     {
/*  827 */       count = packed.charAt(i++);
/*  828 */       int value = packed.charAt(i++);
/*  829 */       value--;
/*  830 */       result[(j++)] = value; count--;
/*      */     }
/*  832 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackAttribute()
/*      */   {
/*  858 */     int[] result = new int['Å'];
/*  859 */     int offset = 0;
/*  860 */     offset = zzUnpackAttribute("", offset, result);
/*  861 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/*  865 */     int i = 0;
/*  866 */     int j = offset;
/*  867 */     int l = packed.length();
/*      */     int count;
/*  871 */     for (; i < l; 
/*  871 */       count > 0)
/*      */     {
/*  869 */       count = packed.charAt(i++);
/*  870 */       int value = packed.charAt(i++);
/*  871 */       result[(j++)] = value; count--;
/*      */     }
/*  873 */     return j;
/*      */   }
/*      */ 
/*      */   public final int yychar()
/*      */   {
/*  952 */     return this.yychar;
/*      */   }
/*      */ 
/*      */   public final void getText(CharTermAttribute t)
/*      */   {
/*  959 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public StandardTokenizerImpl(Reader in)
/*      */   {
/*  969 */     this.zzReader = in;
/*      */   }
/*      */ 
/*      */   private static char[] zzUnpackCMap(String packed)
/*      */   {
/*  980 */     char[] map = new char[65536];
/*  981 */     int i = 0;
/*  982 */     int j = 0;
/*      */     int count;
/*  986 */     for (; i < 2860; 
/*  986 */       count > 0)
/*      */     {
/*  984 */       count = packed.charAt(i++);
/*  985 */       char value = packed.charAt(i++);
/*  986 */       map[(j++)] = value; count--;
/*      */     }
/*  988 */     return map;
/*      */   }
/*      */ 
/*      */   private boolean zzRefill()
/*      */     throws IOException
/*      */   {
/* 1002 */     if (this.zzStartRead > 0) {
/* 1003 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*      */ 
/* 1008 */       this.zzEndRead -= this.zzStartRead;
/* 1009 */       this.zzCurrentPos -= this.zzStartRead;
/* 1010 */       this.zzMarkedPos -= this.zzStartRead;
/* 1011 */       this.zzStartRead = 0;
/*      */     }
/*      */ 
/* 1015 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*      */     {
/* 1017 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 1018 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 1019 */       this.zzBuffer = newBuffer;
/*      */     }
/*      */ 
/* 1023 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*      */ 
/* 1026 */     if (numRead > 0) {
/* 1027 */       this.zzEndRead += numRead;
/* 1028 */       return false;
/*      */     }
/*      */ 
/* 1031 */     if (numRead == 0) {
/* 1032 */       int c = this.zzReader.read();
/* 1033 */       if (c == -1) {
/* 1034 */         return true;
/*      */       }
/* 1036 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 1037 */       return false;
/*      */     }
/*      */ 
/* 1042 */     return true;
/*      */   }
/*      */ 
/*      */   public final void yyclose()
/*      */     throws IOException
/*      */   {
/* 1050 */     this.zzAtEOF = true;
/* 1051 */     this.zzEndRead = this.zzStartRead;
/*      */ 
/* 1053 */     if (this.zzReader != null)
/* 1054 */       this.zzReader.close();
/*      */   }
/*      */ 
/*      */   public final void yyreset(Reader reader)
/*      */   {
/* 1071 */     this.zzReader = reader;
/* 1072 */     this.zzAtBOL = true;
/* 1073 */     this.zzAtEOF = false;
/* 1074 */     this.zzEOFDone = false;
/* 1075 */     this.zzEndRead = (this.zzStartRead = 0);
/* 1076 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/* 1077 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 1078 */     this.zzLexicalState = 0;
/* 1079 */     if (this.zzBuffer.length > 4096)
/* 1080 */       this.zzBuffer = new char[4096];
/*      */   }
/*      */ 
/*      */   public final int yystate()
/*      */   {
/* 1088 */     return this.zzLexicalState;
/*      */   }
/*      */ 
/*      */   public final void yybegin(int newState)
/*      */   {
/* 1098 */     this.zzLexicalState = newState;
/*      */   }
/*      */ 
/*      */   public final String yytext()
/*      */   {
/* 1106 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public final char yycharat(int pos)
/*      */   {
/* 1122 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*      */   }
/*      */ 
/*      */   public final int yylength()
/*      */   {
/* 1130 */     return this.zzMarkedPos - this.zzStartRead;
/*      */   }
/*      */ 
/*      */   private void zzScanError(int errorCode)
/*      */   {
/*      */     String message;
/*      */     try
/*      */     {
/* 1151 */       message = ZZ_ERROR_MSG[errorCode];
/*      */     }
/*      */     catch (ArrayIndexOutOfBoundsException e) {
/* 1154 */       message = ZZ_ERROR_MSG[0];
/*      */     }
/*      */ 
/* 1157 */     throw new Error(message);
/*      */   }
/*      */ 
/*      */   public void yypushback(int number)
/*      */   {
/* 1170 */     if (number > yylength()) {
/* 1171 */       zzScanError(2);
/*      */     }
/* 1173 */     this.zzMarkedPos -= number;
/*      */   }
/*      */ 
/*      */   public int getNextToken()
/*      */     throws IOException
/*      */   {
/* 1191 */     int zzEndReadL = this.zzEndRead;
/* 1192 */     char[] zzBufferL = this.zzBuffer;
/* 1193 */     char[] zzCMapL = ZZ_CMAP;
/*      */ 
/* 1195 */     int[] zzTransL = ZZ_TRANS;
/* 1196 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 1197 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*      */     while (true)
/*      */     {
/* 1200 */       int zzMarkedPosL = this.zzMarkedPos;
/*      */ 
/* 1202 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*      */ 
/* 1204 */       int zzAction = -1;
/*      */ 
/* 1206 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*      */ 
/* 1208 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*      */ 
/* 1211 */       int zzAttributes = zzAttrL[this.zzState];
/* 1212 */       if ((zzAttributes & 0x1) == 1)
/* 1213 */         zzAction = this.zzState;
/*      */       int zzInput;
/*      */       while (true)
/*      */       {
/*      */         int zzInput;
/* 1220 */         if (zzCurrentPosL < zzEndReadL) {
/* 1221 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 1222 */           if (this.zzAtEOF) {
/* 1223 */             int zzInput = -1;
/* 1224 */             break;
/*      */           }
/*      */ 
/* 1228 */           this.zzCurrentPos = zzCurrentPosL;
/* 1229 */           this.zzMarkedPos = zzMarkedPosL;
/* 1230 */           boolean eof = zzRefill();
/*      */ 
/* 1232 */           zzCurrentPosL = this.zzCurrentPos;
/* 1233 */           zzMarkedPosL = this.zzMarkedPos;
/* 1234 */           zzBufferL = this.zzBuffer;
/* 1235 */           zzEndReadL = this.zzEndRead;
/* 1236 */           if (eof) {
/* 1237 */             int zzInput = -1;
/* 1238 */             break;
/*      */           }
/*      */ 
/* 1241 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*      */         }
/*      */ 
/* 1244 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 1245 */         if (zzNext == -1) break;
/* 1246 */         this.zzState = zzNext;
/*      */ 
/* 1248 */         zzAttributes = zzAttrL[this.zzState];
/* 1249 */         if ((zzAttributes & 0x1) == 1) {
/* 1250 */           zzAction = this.zzState;
/* 1251 */           zzMarkedPosL = zzCurrentPosL;
/* 1252 */           if ((zzAttributes & 0x8) == 8)
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1259 */       this.zzMarkedPos = zzMarkedPosL;
/*      */ 
/* 1261 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*      */       case 1:
/* 1263 */         break;
/*      */       case 9:
/* 1265 */         break;
/*      */       case 2:
/* 1267 */         return 0;
/*      */       case 10:
/* 1269 */         break;
/*      */       case 3:
/* 1271 */         return 6;
/*      */       case 11:
/* 1273 */         break;
/*      */       case 4:
/* 1275 */         return 12;
/*      */       case 12:
/* 1277 */         break;
/*      */       case 5:
/* 1279 */         return 9;
/*      */       case 13:
/* 1281 */         break;
/*      */       case 6:
/* 1283 */         return 10;
/*      */       case 14:
/* 1285 */         break;
/*      */       case 7:
/* 1287 */         return 11;
/*      */       case 15:
/* 1289 */         break;
/*      */       case 8:
/* 1291 */         return 13;
/*      */       case 16:
/* 1293 */         break;
/*      */       default:
/* 1295 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 1296 */           this.zzAtEOF = true;
/*      */ 
/* 1298 */           return -1;
/*      */         }
/*      */ 
/* 1302 */         zzScanError(1);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.StandardTokenizerImpl
 * JD-Core Version:    0.6.2
 */