/*     */ package org.apache.lucene.analysis.standard;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopAnalyzer;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class UAX29URLEmailAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   public static final int DEFAULT_MAX_TOKEN_LENGTH = 255;
/*  49 */   private int maxTokenLength = 255;
/*     */ 
/*  53 */   public static final CharArraySet STOP_WORDS_SET = StopAnalyzer.ENGLISH_STOP_WORDS_SET;
/*     */ 
/*     */   public UAX29URLEmailAnalyzer(Version matchVersion, CharArraySet stopWords)
/*     */   {
/*  60 */     super(matchVersion, stopWords);
/*     */   }
/*     */ 
/*     */   public UAX29URLEmailAnalyzer(Version matchVersion)
/*     */   {
/*  69 */     this(matchVersion, STOP_WORDS_SET);
/*     */   }
/*     */ 
/*     */   public UAX29URLEmailAnalyzer(Version matchVersion, Reader stopwords)
/*     */     throws IOException
/*     */   {
/*  78 */     this(matchVersion, loadStopwordSet(stopwords, matchVersion));
/*     */   }
/*     */ 
/*     */   public void setMaxTokenLength(int length)
/*     */   {
/*  88 */     this.maxTokenLength = length;
/*     */   }
/*     */ 
/*     */   public int getMaxTokenLength()
/*     */   {
/*  95 */     return this.maxTokenLength;
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 100 */     final UAX29URLEmailTokenizer src = new UAX29URLEmailTokenizer(this.matchVersion, reader);
/* 101 */     src.setMaxTokenLength(this.maxTokenLength);
/* 102 */     TokenStream tok = new StandardFilter(this.matchVersion, src);
/* 103 */     tok = new LowerCaseFilter(this.matchVersion, tok);
/* 104 */     tok = new StopFilter(this.matchVersion, tok, this.stopwords);
/* 105 */     return new Analyzer.TokenStreamComponents(src, tok)
/*     */     {
/*     */       protected void setReader(Reader reader) throws IOException {
/* 108 */         src.setMaxTokenLength(UAX29URLEmailAnalyzer.this.maxTokenLength);
/* 109 */         super.setReader(reader);
/*     */       }
/*     */     };
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.UAX29URLEmailAnalyzer
 * JD-Core Version:    0.6.2
 */