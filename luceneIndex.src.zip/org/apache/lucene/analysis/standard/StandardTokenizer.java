/*     */ package org.apache.lucene.analysis.standard;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.standard.std31.StandardTokenizerImpl31;
/*     */ import org.apache.lucene.analysis.standard.std34.StandardTokenizerImpl34;
/*     */ import org.apache.lucene.analysis.standard.std40.StandardTokenizerImpl40;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class StandardTokenizer extends Tokenizer
/*     */ {
/*     */   private StandardTokenizerInterface scanner;
/*     */   public static final int ALPHANUM = 0;
/*     */ 
/*     */   @Deprecated
/*     */   public static final int APOSTROPHE = 1;
/*     */ 
/*     */   @Deprecated
/*     */   public static final int ACRONYM = 2;
/*     */ 
/*     */   @Deprecated
/*     */   public static final int COMPANY = 3;
/*     */   public static final int EMAIL = 4;
/*     */ 
/*     */   @Deprecated
/*     */   public static final int HOST = 5;
/*     */   public static final int NUM = 6;
/*     */ 
/*     */   @Deprecated
/*     */   public static final int CJ = 7;
/*     */ 
/*     */   @Deprecated
/*     */   public static final int ACRONYM_DEP = 8;
/*     */   public static final int SOUTHEAST_ASIAN = 9;
/*     */   public static final int IDEOGRAPHIC = 10;
/*     */   public static final int HIRAGANA = 11;
/*     */   public static final int KATAKANA = 12;
/*     */   public static final int HANGUL = 13;
/*  90 */   public static final String[] TOKEN_TYPES = { "<ALPHANUM>", "<APOSTROPHE>", "<ACRONYM>", "<COMPANY>", "<EMAIL>", "<HOST>", "<NUM>", "<CJ>", "<ACRONYM_DEP>", "<SOUTHEAST_ASIAN>", "<IDEOGRAPHIC>", "<HIRAGANA>", "<KATAKANA>", "<HANGUL>" };
/*     */   private int skippedPositions;
/* 109 */   private int maxTokenLength = 255;
/*     */ 
/* 162 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 163 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 164 */   private final PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/* 165 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/*     */ 
/*     */   public void setMaxTokenLength(int length)
/*     */   {
/* 114 */     if (length < 1) {
/* 115 */       throw new IllegalArgumentException("maxTokenLength must be greater than zero");
/*     */     }
/* 117 */     this.maxTokenLength = length;
/*     */   }
/*     */ 
/*     */   public int getMaxTokenLength()
/*     */   {
/* 122 */     return this.maxTokenLength;
/*     */   }
/*     */ 
/*     */   public StandardTokenizer(Version matchVersion, Reader input)
/*     */   {
/* 134 */     super(input);
/* 135 */     init(matchVersion);
/*     */   }
/*     */ 
/*     */   public StandardTokenizer(Version matchVersion, AttributeSource.AttributeFactory factory, Reader input)
/*     */   {
/* 142 */     super(factory, input);
/* 143 */     init(matchVersion);
/*     */   }
/*     */ 
/*     */   private final void init(Version matchVersion) {
/* 147 */     if (matchVersion.onOrAfter(Version.LUCENE_47))
/* 148 */       this.scanner = new StandardTokenizerImpl(this.input);
/* 149 */     else if (matchVersion.onOrAfter(Version.LUCENE_40))
/* 150 */       this.scanner = new StandardTokenizerImpl40(this.input);
/* 151 */     else if (matchVersion.onOrAfter(Version.LUCENE_34))
/* 152 */       this.scanner = new StandardTokenizerImpl34(this.input);
/* 153 */     else if (matchVersion.onOrAfter(Version.LUCENE_31))
/* 154 */       this.scanner = new StandardTokenizerImpl31(this.input);
/*     */     else
/* 156 */       this.scanner = new ClassicTokenizerImpl(this.input);
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 174 */     clearAttributes();
/* 175 */     this.skippedPositions = 0;
/*     */     while (true)
/*     */     {
/* 178 */       int tokenType = this.scanner.getNextToken();
/*     */ 
/* 180 */       if (tokenType == -1) {
/* 181 */         return false;
/*     */       }
/*     */ 
/* 184 */       if (this.scanner.yylength() <= this.maxTokenLength) {
/* 185 */         this.posIncrAtt.setPositionIncrement(this.skippedPositions + 1);
/* 186 */         this.scanner.getText(this.termAtt);
/* 187 */         int start = this.scanner.yychar();
/* 188 */         this.offsetAtt.setOffset(correctOffset(start), correctOffset(start + this.termAtt.length()));
/*     */ 
/* 192 */         if (tokenType == 8) {
/* 193 */           this.typeAtt.setType(TOKEN_TYPES[5]);
/* 194 */           this.termAtt.setLength(this.termAtt.length() - 1);
/*     */         } else {
/* 196 */           this.typeAtt.setType(TOKEN_TYPES[tokenType]);
/*     */         }
/* 198 */         return true;
/*     */       }
/*     */ 
/* 202 */       this.skippedPositions += 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void end() throws IOException
/*     */   {
/* 208 */     super.end();
/*     */ 
/* 210 */     int finalOffset = correctOffset(this.scanner.yychar() + this.scanner.yylength());
/* 211 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */ 
/* 213 */     this.posIncrAtt.setPositionIncrement(this.posIncrAtt.getPositionIncrement() + this.skippedPositions);
/*     */   }
/*     */ 
/*     */   public void close() throws IOException
/*     */   {
/* 218 */     super.close();
/* 219 */     this.scanner.yyreset(this.input);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 224 */     super.reset();
/* 225 */     this.scanner.yyreset(this.input);
/* 226 */     this.skippedPositions = 0;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.StandardTokenizer
 * JD-Core Version:    0.6.2
 */