/*      */ package org.apache.lucene.analysis.standard.std40;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import org.apache.lucene.analysis.standard.StandardTokenizerInterface;
/*      */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*      */ 
/*      */ @Deprecated
/*      */ public final class UAX29URLEmailTokenizerImpl40
/*      */   implements StandardTokenizerInterface
/*      */ {
/*      */ 
/*      */   /** @deprecated */
/*      */   public static final int YYEOF = -1;
/*      */   private static final int ZZ_BUFFERSIZE = 4096;
/*      */   public static final int YYINITIAL = 0;
/*   49 */   private static final int[] ZZ_LEXSTATE = { 0, 0 };
/*      */   private static final String ZZ_CMAP_PACKED = "";
/*  212 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*      */ 
/*  217 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*      */   private static final String ZZ_ACTION_PACKED_0 = "";
/*  263 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*      */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/*  507 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*      */   private static final String ZZ_TRANS_PACKED_0 = "";
/*      */   private static final String ZZ_TRANS_PACKED_1 = "";
/*      */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*      */   private static final int ZZ_NO_MATCH = 1;
/*      */   private static final int ZZ_PUSHBACK_2BIG = 2;
/* 3899 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*      */ 
/* 3908 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*      */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*      */   private Reader zzReader;
/*      */   private int zzState;
/* 3954 */   private int zzLexicalState = 0;
/*      */ 
/* 3958 */   private char[] zzBuffer = new char[4096];
/*      */   private int zzMarkedPos;
/*      */   private int zzCurrentPos;
/*      */   private int zzStartRead;
/*      */   private int zzEndRead;
/*      */   private int yyline;
/*      */   private int yychar;
/*      */   private int yycolumn;
/* 3988 */   private boolean zzAtBOL = true;
/*      */   private boolean zzAtEOF;
/*      */   private boolean zzEOFDone;
/*      */   public static final int WORD_TYPE = 0;
/*      */   public static final int NUMERIC_TYPE = 1;
/*      */   public static final int SOUTH_EAST_ASIAN_TYPE = 2;
/*      */   public static final int IDEOGRAPHIC_TYPE = 3;
/*      */   public static final int HIRAGANA_TYPE = 4;
/*      */   public static final int KATAKANA_TYPE = 5;
/*      */   public static final int HANGUL_TYPE = 6;
/*      */   public static final int EMAIL_TYPE = 8;
/*      */   public static final int URL_TYPE = 7;
/*      */ 
/*      */   private static int[] zzUnpackAction()
/*      */   {
/*  241 */     int[] result = new int[1750];
/*  242 */     int offset = 0;
/*  243 */     offset = zzUnpackAction("", offset, result);
/*  244 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  248 */     int i = 0;
/*  249 */     int j = offset;
/*  250 */     int l = packed.length();
/*      */     int count;
/*  254 */     for (; i < l; 
/*  254 */       count > 0)
/*      */     {
/*  252 */       count = packed.charAt(i++);
/*  253 */       int value = packed.charAt(i++);
/*  254 */       result[(j++)] = value; count--;
/*      */     }
/*  256 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackRowMap()
/*      */   {
/*  487 */     int[] result = new int[1750];
/*  488 */     int offset = 0;
/*  489 */     offset = zzUnpackRowMap("", offset, result);
/*  490 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/*  494 */     int i = 0;
/*  495 */     int j = offset;
/*  496 */     int l = packed.length();
/*  497 */     while (i < l) {
/*  498 */       int high = packed.charAt(i++) << '\020';
/*  499 */       result[(j++)] = (high | packed.charAt(i++));
/*      */     }
/*  501 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackTrans()
/*      */   {
/* 3872 */     int[] result = new int[341204];
/* 3873 */     int offset = 0;
/* 3874 */     offset = zzUnpackTrans("", offset, result);
/* 3875 */     offset = zzUnpackTrans("", offset, result);
/* 3876 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 3880 */     int i = 0;
/* 3881 */     int j = offset;
/* 3882 */     int l = packed.length();
/*      */     int count;
/* 3887 */     for (; i < l; 
/* 3887 */       count > 0)
/*      */     {
/* 3884 */       count = packed.charAt(i++);
/* 3885 */       int value = packed.charAt(i++);
/* 3886 */       value--;
/* 3887 */       result[(j++)] = value; count--;
/*      */     }
/* 3889 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackAttribute()
/*      */   {
/* 3929 */     int[] result = new int[1750];
/* 3930 */     int offset = 0;
/* 3931 */     offset = zzUnpackAttribute("", offset, result);
/* 3932 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 3936 */     int i = 0;
/* 3937 */     int j = offset;
/* 3938 */     int l = packed.length();
/*      */     int count;
/* 3942 */     for (; i < l; 
/* 3942 */       count > 0)
/*      */     {
/* 3940 */       count = packed.charAt(i++);
/* 3941 */       int value = packed.charAt(i++);
/* 3942 */       result[(j++)] = value; count--;
/*      */     }
/* 3944 */     return j;
/*      */   }
/*      */ 
/*      */   public final int yychar()
/*      */   {
/* 4027 */     return this.yychar;
/*      */   }
/*      */ 
/*      */   public final void getText(CharTermAttribute t)
/*      */   {
/* 4034 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public UAX29URLEmailTokenizerImpl40(Reader in)
/*      */   {
/* 4044 */     this.zzReader = in;
/*      */   }
/*      */ 
/*      */   private static char[] zzUnpackCMap(String packed)
/*      */   {
/* 4055 */     char[] map = new char[65536];
/* 4056 */     int i = 0;
/* 4057 */     int j = 0;
/*      */     int count;
/* 4061 */     for (; i < 3010; 
/* 4061 */       count > 0)
/*      */     {
/* 4059 */       count = packed.charAt(i++);
/* 4060 */       char value = packed.charAt(i++);
/* 4061 */       map[(j++)] = value; count--;
/*      */     }
/* 4063 */     return map;
/*      */   }
/*      */ 
/*      */   private boolean zzRefill()
/*      */     throws IOException
/*      */   {
/* 4077 */     if (this.zzStartRead > 0) {
/* 4078 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*      */ 
/* 4083 */       this.zzEndRead -= this.zzStartRead;
/* 4084 */       this.zzCurrentPos -= this.zzStartRead;
/* 4085 */       this.zzMarkedPos -= this.zzStartRead;
/* 4086 */       this.zzStartRead = 0;
/*      */     }
/*      */ 
/* 4090 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*      */     {
/* 4092 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 4093 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 4094 */       this.zzBuffer = newBuffer;
/*      */     }
/*      */ 
/* 4098 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*      */ 
/* 4101 */     if (numRead > 0) {
/* 4102 */       this.zzEndRead += numRead;
/* 4103 */       return false;
/*      */     }
/*      */ 
/* 4106 */     if (numRead == 0) {
/* 4107 */       int c = this.zzReader.read();
/* 4108 */       if (c == -1) {
/* 4109 */         return true;
/*      */       }
/* 4111 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 4112 */       return false;
/*      */     }
/*      */ 
/* 4117 */     return true;
/*      */   }
/*      */ 
/*      */   public final void yyclose()
/*      */     throws IOException
/*      */   {
/* 4125 */     this.zzAtEOF = true;
/* 4126 */     this.zzEndRead = this.zzStartRead;
/*      */ 
/* 4128 */     if (this.zzReader != null)
/* 4129 */       this.zzReader.close();
/*      */   }
/*      */ 
/*      */   public final void yyreset(Reader reader)
/*      */   {
/* 4146 */     this.zzReader = reader;
/* 4147 */     this.zzAtBOL = true;
/* 4148 */     this.zzAtEOF = false;
/* 4149 */     this.zzEOFDone = false;
/* 4150 */     this.zzEndRead = (this.zzStartRead = 0);
/* 4151 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/* 4152 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 4153 */     this.zzLexicalState = 0;
/* 4154 */     if (this.zzBuffer.length > 4096)
/* 4155 */       this.zzBuffer = new char[4096];
/*      */   }
/*      */ 
/*      */   public final int yystate()
/*      */   {
/* 4163 */     return this.zzLexicalState;
/*      */   }
/*      */ 
/*      */   public final void yybegin(int newState)
/*      */   {
/* 4173 */     this.zzLexicalState = newState;
/*      */   }
/*      */ 
/*      */   public final String yytext()
/*      */   {
/* 4181 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public final char yycharat(int pos)
/*      */   {
/* 4197 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*      */   }
/*      */ 
/*      */   public final int yylength()
/*      */   {
/* 4205 */     return this.zzMarkedPos - this.zzStartRead;
/*      */   }
/*      */ 
/*      */   private void zzScanError(int errorCode)
/*      */   {
/*      */     String message;
/*      */     try
/*      */     {
/* 4226 */       message = ZZ_ERROR_MSG[errorCode];
/*      */     }
/*      */     catch (ArrayIndexOutOfBoundsException e) {
/* 4229 */       message = ZZ_ERROR_MSG[0];
/*      */     }
/*      */ 
/* 4232 */     throw new Error(message);
/*      */   }
/*      */ 
/*      */   public void yypushback(int number)
/*      */   {
/* 4245 */     if (number > yylength()) {
/* 4246 */       zzScanError(2);
/*      */     }
/* 4248 */     this.zzMarkedPos -= number;
/*      */   }
/*      */ 
/*      */   public int getNextToken()
/*      */     throws IOException
/*      */   {
/* 4266 */     int zzEndReadL = this.zzEndRead;
/* 4267 */     char[] zzBufferL = this.zzBuffer;
/* 4268 */     char[] zzCMapL = ZZ_CMAP;
/*      */ 
/* 4270 */     int[] zzTransL = ZZ_TRANS;
/* 4271 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 4272 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*      */     while (true)
/*      */     {
/* 4275 */       int zzMarkedPosL = this.zzMarkedPos;
/*      */ 
/* 4277 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*      */ 
/* 4279 */       int zzAction = -1;
/*      */ 
/* 4281 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*      */ 
/* 4283 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*      */ 
/* 4286 */       int zzAttributes = zzAttrL[this.zzState];
/* 4287 */       if ((zzAttributes & 0x1) == 1)
/* 4288 */         zzAction = this.zzState;
/*      */       int zzInput;
/*      */       while (true)
/*      */       {
/*      */         int zzInput;
/* 4295 */         if (zzCurrentPosL < zzEndReadL) {
/* 4296 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 4297 */           if (this.zzAtEOF) {
/* 4298 */             int zzInput = -1;
/* 4299 */             break;
/*      */           }
/*      */ 
/* 4303 */           this.zzCurrentPos = zzCurrentPosL;
/* 4304 */           this.zzMarkedPos = zzMarkedPosL;
/* 4305 */           boolean eof = zzRefill();
/*      */ 
/* 4307 */           zzCurrentPosL = this.zzCurrentPos;
/* 4308 */           zzMarkedPosL = this.zzMarkedPos;
/* 4309 */           zzBufferL = this.zzBuffer;
/* 4310 */           zzEndReadL = this.zzEndRead;
/* 4311 */           if (eof) {
/* 4312 */             int zzInput = -1;
/* 4313 */             break;
/*      */           }
/*      */ 
/* 4316 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*      */         }
/*      */ 
/* 4319 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 4320 */         if (zzNext == -1) break;
/* 4321 */         this.zzState = zzNext;
/*      */ 
/* 4323 */         zzAttributes = zzAttrL[this.zzState];
/* 4324 */         if ((zzAttributes & 0x1) == 1) {
/* 4325 */           zzAction = this.zzState;
/* 4326 */           zzMarkedPosL = zzCurrentPosL;
/* 4327 */           if ((zzAttributes & 0x8) == 8)
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 4334 */       this.zzMarkedPos = zzMarkedPosL;
/*      */ 
/* 4336 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*      */       case 1:
/* 4338 */         break;
/*      */       case 12:
/* 4340 */         break;
/*      */       case 2:
/* 4342 */         return 0;
/*      */       case 13:
/* 4344 */         break;
/*      */       case 3:
/* 4346 */         return 1;
/*      */       case 14:
/* 4348 */         break;
/*      */       case 4:
/* 4350 */         return 5;
/*      */       case 15:
/* 4352 */         break;
/*      */       case 5:
/* 4354 */         return 2;
/*      */       case 16:
/* 4356 */         break;
/*      */       case 6:
/* 4358 */         return 3;
/*      */       case 17:
/* 4360 */         break;
/*      */       case 7:
/* 4362 */         return 4;
/*      */       case 18:
/* 4364 */         break;
/*      */       case 8:
/* 4366 */         return 6;
/*      */       case 19:
/* 4368 */         break;
/*      */       case 9:
/* 4370 */         return 8;
/*      */       case 20:
/* 4372 */         break;
/*      */       case 10:
/* 4374 */         return 7;
/*      */       case 21:
/* 4376 */         break;
/*      */       case 11:
/* 4379 */         this.zzMarkedPos = (this.zzStartRead + 6);
/* 4380 */         return 0;
/*      */       case 22:
/* 4382 */         break;
/*      */       default:
/* 4384 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 4385 */           this.zzAtEOF = true;
/*      */ 
/* 4387 */           return -1;
/*      */         }
/*      */ 
/* 4391 */         zzScanError(1);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.std40.UAX29URLEmailTokenizerImpl40
 * JD-Core Version:    0.6.2
 */