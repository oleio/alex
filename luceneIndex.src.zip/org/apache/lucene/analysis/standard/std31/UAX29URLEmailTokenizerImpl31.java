/*      */ package org.apache.lucene.analysis.standard.std31;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import org.apache.lucene.analysis.standard.StandardTokenizerInterface;
/*      */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*      */ 
/*      */ @Deprecated
/*      */ public final class UAX29URLEmailTokenizerImpl31
/*      */   implements StandardTokenizerInterface
/*      */ {
/*      */ 
/*      */   /** @deprecated */
/*      */   public static final int YYEOF = -1;
/*      */   private static final int ZZ_BUFFERSIZE = 4096;
/*      */   public static final int YYINITIAL = 0;
/*   51 */   private static final int[] ZZ_LEXSTATE = { 0, 0 };
/*      */   private static final String ZZ_CMAP_PACKED = "";
/*  204 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*      */ 
/*  209 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*      */   private static final String ZZ_ACTION_PACKED_0 = "";
/*  253 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*      */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/*  445 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*      */   private static final String ZZ_TRANS_PACKED_0 = "";
/*      */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*      */   private static final int ZZ_NO_MATCH = 1;
/*      */   private static final int ZZ_PUSHBACK_2BIG = 2;
/* 3165 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*      */ 
/* 3174 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*      */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*      */   private Reader zzReader;
/*      */   private int zzState;
/* 3218 */   private int zzLexicalState = 0;
/*      */ 
/* 3222 */   private char[] zzBuffer = new char[4096];
/*      */   private int zzMarkedPos;
/*      */   private int zzCurrentPos;
/*      */   private int zzStartRead;
/*      */   private int zzEndRead;
/*      */   private int yyline;
/*      */   private int yychar;
/*      */   private int yycolumn;
/* 3252 */   private boolean zzAtBOL = true;
/*      */   private boolean zzAtEOF;
/*      */   private boolean zzEOFDone;
/*      */   public static final int WORD_TYPE = 0;
/*      */   public static final int NUMERIC_TYPE = 1;
/*      */   public static final int SOUTH_EAST_ASIAN_TYPE = 2;
/*      */   public static final int IDEOGRAPHIC_TYPE = 3;
/*      */   public static final int HIRAGANA_TYPE = 4;
/*      */   public static final int KATAKANA_TYPE = 5;
/*      */   public static final int HANGUL_TYPE = 6;
/*      */   public static final int EMAIL_TYPE = 8;
/*      */   public static final int URL_TYPE = 7;
/*      */ 
/*      */   private static int[] zzUnpackAction()
/*      */   {
/*  231 */     int[] result = new int[1331];
/*  232 */     int offset = 0;
/*  233 */     offset = zzUnpackAction("", offset, result);
/*  234 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  238 */     int i = 0;
/*  239 */     int j = offset;
/*  240 */     int l = packed.length();
/*      */     int count;
/*  244 */     for (; i < l; 
/*  244 */       count > 0)
/*      */     {
/*  242 */       count = packed.charAt(i++);
/*  243 */       int value = packed.charAt(i++);
/*  244 */       result[(j++)] = value; count--;
/*      */     }
/*  246 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackRowMap()
/*      */   {
/*  425 */     int[] result = new int[1331];
/*  426 */     int offset = 0;
/*  427 */     offset = zzUnpackRowMap("", offset, result);
/*  428 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/*  432 */     int i = 0;
/*  433 */     int j = offset;
/*  434 */     int l = packed.length();
/*  435 */     while (i < l) {
/*  436 */       int high = packed.charAt(i++) << '\020';
/*  437 */       result[(j++)] = (high | packed.charAt(i++));
/*      */     }
/*  439 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackTrans()
/*      */   {
/* 3139 */     int[] result = new int[214182];
/* 3140 */     int offset = 0;
/* 3141 */     offset = zzUnpackTrans("", offset, result);
/* 3142 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 3146 */     int i = 0;
/* 3147 */     int j = offset;
/* 3148 */     int l = packed.length();
/*      */     int count;
/* 3153 */     for (; i < l; 
/* 3153 */       count > 0)
/*      */     {
/* 3150 */       count = packed.charAt(i++);
/* 3151 */       int value = packed.charAt(i++);
/* 3152 */       value--;
/* 3153 */       result[(j++)] = value; count--;
/*      */     }
/* 3155 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackAttribute()
/*      */   {
/* 3193 */     int[] result = new int[1331];
/* 3194 */     int offset = 0;
/* 3195 */     offset = zzUnpackAttribute("", offset, result);
/* 3196 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 3200 */     int i = 0;
/* 3201 */     int j = offset;
/* 3202 */     int l = packed.length();
/*      */     int count;
/* 3206 */     for (; i < l; 
/* 3206 */       count > 0)
/*      */     {
/* 3204 */       count = packed.charAt(i++);
/* 3205 */       int value = packed.charAt(i++);
/* 3206 */       result[(j++)] = value; count--;
/*      */     }
/* 3208 */     return j;
/*      */   }
/*      */ 
/*      */   public final int yychar()
/*      */   {
/* 3291 */     return this.yychar;
/*      */   }
/*      */ 
/*      */   public final void getText(CharTermAttribute t)
/*      */   {
/* 3298 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public UAX29URLEmailTokenizerImpl31(Reader in)
/*      */   {
/* 3308 */     this.zzReader = in;
/*      */   }
/*      */ 
/*      */   private static char[] zzUnpackCMap(String packed)
/*      */   {
/* 3319 */     char[] map = new char[65536];
/* 3320 */     int i = 0;
/* 3321 */     int j = 0;
/*      */     int count;
/* 3325 */     for (; i < 2812; 
/* 3325 */       count > 0)
/*      */     {
/* 3323 */       count = packed.charAt(i++);
/* 3324 */       char value = packed.charAt(i++);
/* 3325 */       map[(j++)] = value; count--;
/*      */     }
/* 3327 */     return map;
/*      */   }
/*      */ 
/*      */   private boolean zzRefill()
/*      */     throws IOException
/*      */   {
/* 3341 */     if (this.zzStartRead > 0) {
/* 3342 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*      */ 
/* 3347 */       this.zzEndRead -= this.zzStartRead;
/* 3348 */       this.zzCurrentPos -= this.zzStartRead;
/* 3349 */       this.zzMarkedPos -= this.zzStartRead;
/* 3350 */       this.zzStartRead = 0;
/*      */     }
/*      */ 
/* 3354 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*      */     {
/* 3356 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 3357 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 3358 */       this.zzBuffer = newBuffer;
/*      */     }
/*      */ 
/* 3362 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*      */ 
/* 3365 */     if (numRead > 0) {
/* 3366 */       this.zzEndRead += numRead;
/* 3367 */       return false;
/*      */     }
/*      */ 
/* 3370 */     if (numRead == 0) {
/* 3371 */       int c = this.zzReader.read();
/* 3372 */       if (c == -1) {
/* 3373 */         return true;
/*      */       }
/* 3375 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 3376 */       return false;
/*      */     }
/*      */ 
/* 3381 */     return true;
/*      */   }
/*      */ 
/*      */   public final void yyclose()
/*      */     throws IOException
/*      */   {
/* 3389 */     this.zzAtEOF = true;
/* 3390 */     this.zzEndRead = this.zzStartRead;
/*      */ 
/* 3392 */     if (this.zzReader != null)
/* 3393 */       this.zzReader.close();
/*      */   }
/*      */ 
/*      */   public final void yyreset(Reader reader)
/*      */   {
/* 3410 */     this.zzReader = reader;
/* 3411 */     this.zzAtBOL = true;
/* 3412 */     this.zzAtEOF = false;
/* 3413 */     this.zzEOFDone = false;
/* 3414 */     this.zzEndRead = (this.zzStartRead = 0);
/* 3415 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/* 3416 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 3417 */     this.zzLexicalState = 0;
/* 3418 */     if (this.zzBuffer.length > 4096)
/* 3419 */       this.zzBuffer = new char[4096];
/*      */   }
/*      */ 
/*      */   public final int yystate()
/*      */   {
/* 3427 */     return this.zzLexicalState;
/*      */   }
/*      */ 
/*      */   public final void yybegin(int newState)
/*      */   {
/* 3437 */     this.zzLexicalState = newState;
/*      */   }
/*      */ 
/*      */   public final String yytext()
/*      */   {
/* 3445 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public final char yycharat(int pos)
/*      */   {
/* 3461 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*      */   }
/*      */ 
/*      */   public final int yylength()
/*      */   {
/* 3469 */     return this.zzMarkedPos - this.zzStartRead;
/*      */   }
/*      */ 
/*      */   private void zzScanError(int errorCode)
/*      */   {
/*      */     String message;
/*      */     try
/*      */     {
/* 3490 */       message = ZZ_ERROR_MSG[errorCode];
/*      */     }
/*      */     catch (ArrayIndexOutOfBoundsException e) {
/* 3493 */       message = ZZ_ERROR_MSG[0];
/*      */     }
/*      */ 
/* 3496 */     throw new Error(message);
/*      */   }
/*      */ 
/*      */   public void yypushback(int number)
/*      */   {
/* 3509 */     if (number > yylength()) {
/* 3510 */       zzScanError(2);
/*      */     }
/* 3512 */     this.zzMarkedPos -= number;
/*      */   }
/*      */ 
/*      */   public int getNextToken()
/*      */     throws IOException
/*      */   {
/* 3530 */     int zzEndReadL = this.zzEndRead;
/* 3531 */     char[] zzBufferL = this.zzBuffer;
/* 3532 */     char[] zzCMapL = ZZ_CMAP;
/*      */ 
/* 3534 */     int[] zzTransL = ZZ_TRANS;
/* 3535 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 3536 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*      */     while (true)
/*      */     {
/* 3539 */       int zzMarkedPosL = this.zzMarkedPos;
/*      */ 
/* 3541 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*      */ 
/* 3543 */       int zzAction = -1;
/*      */ 
/* 3545 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*      */ 
/* 3547 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*      */ 
/* 3550 */       int zzAttributes = zzAttrL[this.zzState];
/* 3551 */       if ((zzAttributes & 0x1) == 1)
/* 3552 */         zzAction = this.zzState;
/*      */       int zzInput;
/*      */       while (true)
/*      */       {
/*      */         int zzInput;
/* 3559 */         if (zzCurrentPosL < zzEndReadL) {
/* 3560 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 3561 */           if (this.zzAtEOF) {
/* 3562 */             int zzInput = -1;
/* 3563 */             break;
/*      */           }
/*      */ 
/* 3567 */           this.zzCurrentPos = zzCurrentPosL;
/* 3568 */           this.zzMarkedPos = zzMarkedPosL;
/* 3569 */           boolean eof = zzRefill();
/*      */ 
/* 3571 */           zzCurrentPosL = this.zzCurrentPos;
/* 3572 */           zzMarkedPosL = this.zzMarkedPos;
/* 3573 */           zzBufferL = this.zzBuffer;
/* 3574 */           zzEndReadL = this.zzEndRead;
/* 3575 */           if (eof) {
/* 3576 */             int zzInput = -1;
/* 3577 */             break;
/*      */           }
/*      */ 
/* 3580 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*      */         }
/*      */ 
/* 3583 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 3584 */         if (zzNext == -1) break;
/* 3585 */         this.zzState = zzNext;
/*      */ 
/* 3587 */         zzAttributes = zzAttrL[this.zzState];
/* 3588 */         if ((zzAttributes & 0x1) == 1) {
/* 3589 */           zzAction = this.zzState;
/* 3590 */           zzMarkedPosL = zzCurrentPosL;
/* 3591 */           if ((zzAttributes & 0x8) == 8)
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 3598 */       this.zzMarkedPos = zzMarkedPosL;
/*      */ 
/* 3600 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*      */       case 1:
/* 3602 */         break;
/*      */       case 11:
/* 3604 */         break;
/*      */       case 2:
/* 3606 */         return 0;
/*      */       case 12:
/* 3608 */         break;
/*      */       case 3:
/* 3610 */         return 1;
/*      */       case 13:
/* 3612 */         break;
/*      */       case 4:
/* 3614 */         return 5;
/*      */       case 14:
/* 3616 */         break;
/*      */       case 5:
/* 3618 */         return 2;
/*      */       case 15:
/* 3620 */         break;
/*      */       case 6:
/* 3622 */         return 3;
/*      */       case 16:
/* 3624 */         break;
/*      */       case 7:
/* 3626 */         return 4;
/*      */       case 17:
/* 3628 */         break;
/*      */       case 8:
/* 3630 */         return 6;
/*      */       case 18:
/* 3632 */         break;
/*      */       case 9:
/* 3634 */         return 8;
/*      */       case 19:
/* 3636 */         break;
/*      */       case 10:
/* 3638 */         return 7;
/*      */       case 20:
/* 3640 */         break;
/*      */       default:
/* 3642 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 3643 */           this.zzAtEOF = true;
/*      */ 
/* 3645 */           return -1;
/*      */         }
/*      */ 
/* 3649 */         zzScanError(1);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.std31.UAX29URLEmailTokenizerImpl31
 * JD-Core Version:    0.6.2
 */