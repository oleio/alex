/*     */ package org.apache.lucene.analysis.standard;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class ClassicTokenizer extends Tokenizer
/*     */ {
/*     */   private StandardTokenizerInterface scanner;
/*     */   public static final int ALPHANUM = 0;
/*     */   public static final int APOSTROPHE = 1;
/*     */   public static final int ACRONYM = 2;
/*     */   public static final int COMPANY = 3;
/*     */   public static final int EMAIL = 4;
/*     */   public static final int HOST = 5;
/*     */   public static final int NUM = 6;
/*     */   public static final int CJ = 7;
/*     */   public static final int ACRONYM_DEP = 8;
/*  67 */   public static final String[] TOKEN_TYPES = { "<ALPHANUM>", "<APOSTROPHE>", "<ACRONYM>", "<COMPANY>", "<EMAIL>", "<HOST>", "<NUM>", "<CJ>", "<ACRONYM_DEP>" };
/*     */   private int skippedPositions;
/*  81 */   private int maxTokenLength = 255;
/*     */ 
/* 124 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 125 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 126 */   private final PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/* 127 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/*     */ 
/*     */   public void setMaxTokenLength(int length)
/*     */   {
/*  86 */     if (length < 1) {
/*  87 */       throw new IllegalArgumentException("maxTokenLength must be greater than zero");
/*     */     }
/*  89 */     this.maxTokenLength = length;
/*     */   }
/*     */ 
/*     */   public int getMaxTokenLength()
/*     */   {
/*  94 */     return this.maxTokenLength;
/*     */   }
/*     */ 
/*     */   public ClassicTokenizer(Version matchVersion, Reader input)
/*     */   {
/* 106 */     super(input);
/* 107 */     init(matchVersion);
/*     */   }
/*     */ 
/*     */   public ClassicTokenizer(Version matchVersion, AttributeSource.AttributeFactory factory, Reader input)
/*     */   {
/* 114 */     super(factory, input);
/* 115 */     init(matchVersion);
/*     */   }
/*     */ 
/*     */   private void init(Version matchVersion) {
/* 119 */     this.scanner = new ClassicTokenizerImpl(this.input);
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 136 */     clearAttributes();
/* 137 */     this.skippedPositions = 0;
/*     */     while (true)
/*     */     {
/* 140 */       int tokenType = this.scanner.getNextToken();
/*     */ 
/* 142 */       if (tokenType == -1) {
/* 143 */         return false;
/*     */       }
/*     */ 
/* 146 */       if (this.scanner.yylength() <= this.maxTokenLength) {
/* 147 */         this.posIncrAtt.setPositionIncrement(this.skippedPositions + 1);
/* 148 */         this.scanner.getText(this.termAtt);
/* 149 */         int start = this.scanner.yychar();
/* 150 */         this.offsetAtt.setOffset(correctOffset(start), correctOffset(start + this.termAtt.length()));
/*     */ 
/* 152 */         if (tokenType == 8) {
/* 153 */           this.typeAtt.setType(TOKEN_TYPES[5]);
/* 154 */           this.termAtt.setLength(this.termAtt.length() - 1);
/*     */         } else {
/* 156 */           this.typeAtt.setType(TOKEN_TYPES[tokenType]);
/*     */         }
/* 158 */         return true;
/*     */       }
/*     */ 
/* 162 */       this.skippedPositions += 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void end() throws IOException
/*     */   {
/* 168 */     super.end();
/*     */ 
/* 170 */     int finalOffset = correctOffset(this.scanner.yychar() + this.scanner.yylength());
/* 171 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */ 
/* 173 */     this.posIncrAtt.setPositionIncrement(this.posIncrAtt.getPositionIncrement() + this.skippedPositions);
/*     */   }
/*     */ 
/*     */   public void close() throws IOException
/*     */   {
/* 178 */     super.close();
/* 179 */     this.scanner.yyreset(this.input);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 184 */     super.reset();
/* 185 */     this.scanner.yyreset(this.input);
/* 186 */     this.skippedPositions = 0;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.ClassicTokenizer
 * JD-Core Version:    0.6.2
 */