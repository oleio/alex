/*     */ package org.apache.lucene.analysis.standard.std34;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizerInterface;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ 
/*     */ @Deprecated
/*     */ public final class StandardTokenizerImpl34
/*     */   implements StandardTokenizerInterface
/*     */ {
/*     */ 
/*     */   /** @deprecated */
/*     */   public static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 4096;
/*     */   public static final int YYINITIAL = 0;
/*  49 */   private static final int[] ZZ_LEXSTATE = { 0, 0 };
/*     */   private static final String ZZ_CMAP_PACKED = "";
/* 194 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*     */ 
/* 199 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */   private static final String ZZ_ACTION_PACKED_0 = "";
/* 229 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/* 270 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */   private static final String ZZ_TRANS_PACKED_0 = "";
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/* 623 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*     */ 
/* 632 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/* 664 */   private int zzLexicalState = 0;
/*     */ 
/* 668 */   private char[] zzBuffer = new char[4096];
/*     */   private int zzMarkedPos;
/*     */   private int zzCurrentPos;
/*     */   private int zzStartRead;
/*     */   private int zzEndRead;
/*     */   private int yyline;
/*     */   private int yychar;
/*     */   private int yycolumn;
/* 698 */   private boolean zzAtBOL = true;
/*     */   private boolean zzAtEOF;
/*     */   private boolean zzEOFDone;
/*     */   public static final int WORD_TYPE = 0;
/*     */   public static final int NUMERIC_TYPE = 6;
/*     */   public static final int SOUTH_EAST_ASIAN_TYPE = 9;
/*     */   public static final int IDEOGRAPHIC_TYPE = 10;
/*     */   public static final int HIRAGANA_TYPE = 11;
/*     */   public static final int KATAKANA_TYPE = 12;
/*     */   public static final int HANGUL_TYPE = 13;
/*     */ 
/*     */   private static int[] zzUnpackAction()
/*     */   {
/* 207 */     int[] result = new int[124];
/* 208 */     int offset = 0;
/* 209 */     offset = zzUnpackAction("", offset, result);
/* 210 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/* 214 */     int i = 0;
/* 215 */     int j = offset;
/* 216 */     int l = packed.length();
/*     */     int count;
/* 220 */     for (; i < l; 
/* 220 */       count > 0)
/*     */     {
/* 218 */       count = packed.charAt(i++);
/* 219 */       int value = packed.charAt(i++);
/* 220 */       result[(j++)] = value; count--;
/*     */     }
/* 222 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackRowMap()
/*     */   {
/* 250 */     int[] result = new int[124];
/* 251 */     int offset = 0;
/* 252 */     offset = zzUnpackRowMap("", offset, result);
/* 253 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 257 */     int i = 0;
/* 258 */     int j = offset;
/* 259 */     int l = packed.length();
/* 260 */     while (i < l) {
/* 261 */       int high = packed.charAt(i++) << '\020';
/* 262 */       result[(j++)] = (high | packed.charAt(i++));
/*     */     }
/* 264 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackTrans()
/*     */   {
/* 597 */     int[] result = new int[11845];
/* 598 */     int offset = 0;
/* 599 */     offset = zzUnpackTrans("", offset, result);
/* 600 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 604 */     int i = 0;
/* 605 */     int j = offset;
/* 606 */     int l = packed.length();
/*     */     int count;
/* 611 */     for (; i < l; 
/* 611 */       count > 0)
/*     */     {
/* 608 */       count = packed.charAt(i++);
/* 609 */       int value = packed.charAt(i++);
/* 610 */       value--;
/* 611 */       result[(j++)] = value; count--;
/*     */     }
/* 613 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackAttribute()
/*     */   {
/* 639 */     int[] result = new int[124];
/* 640 */     int offset = 0;
/* 641 */     offset = zzUnpackAttribute("", offset, result);
/* 642 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 646 */     int i = 0;
/* 647 */     int j = offset;
/* 648 */     int l = packed.length();
/*     */     int count;
/* 652 */     for (; i < l; 
/* 652 */       count > 0)
/*     */     {
/* 650 */       count = packed.charAt(i++);
/* 651 */       int value = packed.charAt(i++);
/* 652 */       result[(j++)] = value; count--;
/*     */     }
/* 654 */     return j;
/*     */   }
/*     */ 
/*     */   public final int yychar()
/*     */   {
/* 733 */     return this.yychar;
/*     */   }
/*     */ 
/*     */   public final void getText(CharTermAttribute t)
/*     */   {
/* 740 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */   public StandardTokenizerImpl34(Reader in)
/*     */   {
/* 750 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */   private static char[] zzUnpackCMap(String packed)
/*     */   {
/* 761 */     char[] map = new char[65536];
/* 762 */     int i = 0;
/* 763 */     int j = 0;
/*     */     int count;
/* 767 */     for (; i < 2650; 
/* 767 */       count > 0)
/*     */     {
/* 765 */       count = packed.charAt(i++);
/* 766 */       char value = packed.charAt(i++);
/* 767 */       map[(j++)] = value; count--;
/*     */     }
/* 769 */     return map;
/*     */   }
/*     */ 
/*     */   private boolean zzRefill()
/*     */     throws IOException
/*     */   {
/* 783 */     if (this.zzStartRead > 0) {
/* 784 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*     */ 
/* 789 */       this.zzEndRead -= this.zzStartRead;
/* 790 */       this.zzCurrentPos -= this.zzStartRead;
/* 791 */       this.zzMarkedPos -= this.zzStartRead;
/* 792 */       this.zzStartRead = 0;
/*     */     }
/*     */ 
/* 796 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*     */     {
/* 798 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 799 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 800 */       this.zzBuffer = newBuffer;
/*     */     }
/*     */ 
/* 804 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*     */ 
/* 807 */     if (numRead > 0) {
/* 808 */       this.zzEndRead += numRead;
/* 809 */       return false;
/*     */     }
/*     */ 
/* 812 */     if (numRead == 0) {
/* 813 */       int c = this.zzReader.read();
/* 814 */       if (c == -1) {
/* 815 */         return true;
/*     */       }
/* 817 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 818 */       return false;
/*     */     }
/*     */ 
/* 823 */     return true;
/*     */   }
/*     */ 
/*     */   public final void yyclose()
/*     */     throws IOException
/*     */   {
/* 831 */     this.zzAtEOF = true;
/* 832 */     this.zzEndRead = this.zzStartRead;
/*     */ 
/* 834 */     if (this.zzReader != null)
/* 835 */       this.zzReader.close();
/*     */   }
/*     */ 
/*     */   public final void yyreset(Reader reader)
/*     */   {
/* 852 */     this.zzReader = reader;
/* 853 */     this.zzAtBOL = true;
/* 854 */     this.zzAtEOF = false;
/* 855 */     this.zzEOFDone = false;
/* 856 */     this.zzEndRead = (this.zzStartRead = 0);
/* 857 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/* 858 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 859 */     this.zzLexicalState = 0;
/* 860 */     if (this.zzBuffer.length > 4096)
/* 861 */       this.zzBuffer = new char[4096];
/*     */   }
/*     */ 
/*     */   public final int yystate()
/*     */   {
/* 869 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */   public final void yybegin(int newState)
/*     */   {
/* 879 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */   public final String yytext()
/*     */   {
/* 887 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */   public final char yycharat(int pos)
/*     */   {
/* 903 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*     */   }
/*     */ 
/*     */   public final int yylength()
/*     */   {
/* 911 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */   private void zzScanError(int errorCode)
/*     */   {
/*     */     String message;
/*     */     try
/*     */     {
/* 932 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 935 */       message = ZZ_ERROR_MSG[0];
/*     */     }
/*     */ 
/* 938 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */   public void yypushback(int number)
/*     */   {
/* 951 */     if (number > yylength()) {
/* 952 */       zzScanError(2);
/*     */     }
/* 954 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */   public int getNextToken()
/*     */     throws IOException
/*     */   {
/* 972 */     int zzEndReadL = this.zzEndRead;
/* 973 */     char[] zzBufferL = this.zzBuffer;
/* 974 */     char[] zzCMapL = ZZ_CMAP;
/*     */ 
/* 976 */     int[] zzTransL = ZZ_TRANS;
/* 977 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 978 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*     */     while (true)
/*     */     {
/* 981 */       int zzMarkedPosL = this.zzMarkedPos;
/*     */ 
/* 983 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*     */ 
/* 985 */       int zzAction = -1;
/*     */ 
/* 987 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */ 
/* 989 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*     */ 
/* 992 */       int zzAttributes = zzAttrL[this.zzState];
/* 993 */       if ((zzAttributes & 0x1) == 1)
/* 994 */         zzAction = this.zzState;
/*     */       int zzInput;
/*     */       while (true)
/*     */       {
/*     */         int zzInput;
/* 1001 */         if (zzCurrentPosL < zzEndReadL) {
/* 1002 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 1003 */           if (this.zzAtEOF) {
/* 1004 */             int zzInput = -1;
/* 1005 */             break;
/*     */           }
/*     */ 
/* 1009 */           this.zzCurrentPos = zzCurrentPosL;
/* 1010 */           this.zzMarkedPos = zzMarkedPosL;
/* 1011 */           boolean eof = zzRefill();
/*     */ 
/* 1013 */           zzCurrentPosL = this.zzCurrentPos;
/* 1014 */           zzMarkedPosL = this.zzMarkedPos;
/* 1015 */           zzBufferL = this.zzBuffer;
/* 1016 */           zzEndReadL = this.zzEndRead;
/* 1017 */           if (eof) {
/* 1018 */             int zzInput = -1;
/* 1019 */             break;
/*     */           }
/*     */ 
/* 1022 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*     */         }
/*     */ 
/* 1025 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 1026 */         if (zzNext == -1) break;
/* 1027 */         this.zzState = zzNext;
/*     */ 
/* 1029 */         zzAttributes = zzAttrL[this.zzState];
/* 1030 */         if ((zzAttributes & 0x1) == 1) {
/* 1031 */           zzAction = this.zzState;
/* 1032 */           zzMarkedPosL = zzCurrentPosL;
/* 1033 */           if ((zzAttributes & 0x8) == 8)
/*     */           {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 1040 */       this.zzMarkedPos = zzMarkedPosL;
/*     */ 
/* 1042 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*     */       case 1:
/* 1044 */         break;
/*     */       case 9:
/* 1046 */         break;
/*     */       case 2:
/* 1048 */         return 0;
/*     */       case 10:
/* 1050 */         break;
/*     */       case 3:
/* 1052 */         return 6;
/*     */       case 11:
/* 1054 */         break;
/*     */       case 4:
/* 1056 */         return 12;
/*     */       case 12:
/* 1058 */         break;
/*     */       case 5:
/* 1060 */         return 9;
/*     */       case 13:
/* 1062 */         break;
/*     */       case 6:
/* 1064 */         return 10;
/*     */       case 14:
/* 1066 */         break;
/*     */       case 7:
/* 1068 */         return 11;
/*     */       case 15:
/* 1070 */         break;
/*     */       case 8:
/* 1072 */         return 13;
/*     */       case 16:
/* 1074 */         break;
/*     */       default:
/* 1076 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 1077 */           this.zzAtEOF = true;
/*     */ 
/* 1079 */           return -1;
/*     */         }
/*     */ 
/* 1083 */         zzScanError(1);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.std34.StandardTokenizerImpl34
 * JD-Core Version:    0.6.2
 */