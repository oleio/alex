/*    */ package org.apache.lucene.analysis.standard;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class ClassicFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public ClassicFilterFactory(Map<String, String> args)
/*    */   {
/* 41 */     super(args);
/* 42 */     if (!args.isEmpty())
/* 43 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenFilter create(TokenStream input)
/*    */   {
/* 49 */     return new ClassicFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.ClassicFilterFactory
 * JD-Core Version:    0.6.2
 */