/*      */ package org.apache.lucene.analysis.standard.std36;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import org.apache.lucene.analysis.standard.StandardTokenizerInterface;
/*      */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*      */ 
/*      */ @Deprecated
/*      */ public final class UAX29URLEmailTokenizerImpl36
/*      */   implements StandardTokenizerInterface
/*      */ {
/*      */ 
/*      */   /** @deprecated */
/*      */   public static final int YYEOF = -1;
/*      */   private static final int ZZ_BUFFERSIZE = 4096;
/*      */   public static final int YYINITIAL = 0;
/*   49 */   private static final int[] ZZ_LEXSTATE = { 0, 0 };
/*      */   private static final String ZZ_CMAP_PACKED = "";
/*  202 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*      */ 
/*  207 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*      */   private static final String ZZ_ACTION_PACKED_0 = "";
/*  253 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*      */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/*  492 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*      */   private static final String ZZ_TRANS_PACKED_0 = "";
/*      */   private static final String ZZ_TRANS_PACKED_1 = "";
/*      */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*      */   private static final int ZZ_NO_MATCH = 1;
/*      */   private static final int ZZ_PUSHBACK_2BIG = 2;
/* 3687 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*      */ 
/* 3696 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*      */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*      */   private Reader zzReader;
/*      */   private int zzState;
/* 3742 */   private int zzLexicalState = 0;
/*      */ 
/* 3746 */   private char[] zzBuffer = new char[4096];
/*      */   private int zzMarkedPos;
/*      */   private int zzCurrentPos;
/*      */   private int zzStartRead;
/*      */   private int zzEndRead;
/*      */   private int yyline;
/*      */   private int yychar;
/*      */   private int yycolumn;
/* 3776 */   private boolean zzAtBOL = true;
/*      */   private boolean zzAtEOF;
/*      */   private boolean zzEOFDone;
/*      */   public static final int WORD_TYPE = 0;
/*      */   public static final int NUMERIC_TYPE = 1;
/*      */   public static final int SOUTH_EAST_ASIAN_TYPE = 2;
/*      */   public static final int IDEOGRAPHIC_TYPE = 3;
/*      */   public static final int HIRAGANA_TYPE = 4;
/*      */   public static final int KATAKANA_TYPE = 5;
/*      */   public static final int HANGUL_TYPE = 6;
/*      */   public static final int EMAIL_TYPE = 8;
/*      */   public static final int URL_TYPE = 7;
/*      */ 
/*      */   private static int[] zzUnpackAction()
/*      */   {
/*  231 */     int[] result = new int[1709];
/*  232 */     int offset = 0;
/*  233 */     offset = zzUnpackAction("", offset, result);
/*  234 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  238 */     int i = 0;
/*  239 */     int j = offset;
/*  240 */     int l = packed.length();
/*      */     int count;
/*  244 */     for (; i < l; 
/*  244 */       count > 0)
/*      */     {
/*  242 */       count = packed.charAt(i++);
/*  243 */       int value = packed.charAt(i++);
/*  244 */       result[(j++)] = value; count--;
/*      */     }
/*  246 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackRowMap()
/*      */   {
/*  472 */     int[] result = new int[1709];
/*  473 */     int offset = 0;
/*  474 */     offset = zzUnpackRowMap("", offset, result);
/*  475 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/*  479 */     int i = 0;
/*  480 */     int j = offset;
/*  481 */     int l = packed.length();
/*  482 */     while (i < l) {
/*  483 */       int high = packed.charAt(i++) << '\020';
/*  484 */       result[(j++)] = (high | packed.charAt(i++));
/*      */     }
/*  486 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackTrans()
/*      */   {
/* 3660 */     int[] result = new int[275796];
/* 3661 */     int offset = 0;
/* 3662 */     offset = zzUnpackTrans("", offset, result);
/* 3663 */     offset = zzUnpackTrans("", offset, result);
/* 3664 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 3668 */     int i = 0;
/* 3669 */     int j = offset;
/* 3670 */     int l = packed.length();
/*      */     int count;
/* 3675 */     for (; i < l; 
/* 3675 */       count > 0)
/*      */     {
/* 3672 */       count = packed.charAt(i++);
/* 3673 */       int value = packed.charAt(i++);
/* 3674 */       value--;
/* 3675 */       result[(j++)] = value; count--;
/*      */     }
/* 3677 */     return j;
/*      */   }
/*      */ 
/*      */   private static int[] zzUnpackAttribute()
/*      */   {
/* 3717 */     int[] result = new int[1709];
/* 3718 */     int offset = 0;
/* 3719 */     offset = zzUnpackAttribute("", offset, result);
/* 3720 */     return result;
/*      */   }
/*      */ 
/*      */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 3724 */     int i = 0;
/* 3725 */     int j = offset;
/* 3726 */     int l = packed.length();
/*      */     int count;
/* 3730 */     for (; i < l; 
/* 3730 */       count > 0)
/*      */     {
/* 3728 */       count = packed.charAt(i++);
/* 3729 */       int value = packed.charAt(i++);
/* 3730 */       result[(j++)] = value; count--;
/*      */     }
/* 3732 */     return j;
/*      */   }
/*      */ 
/*      */   public final int yychar()
/*      */   {
/* 3815 */     return this.yychar;
/*      */   }
/*      */ 
/*      */   public final void getText(CharTermAttribute t)
/*      */   {
/* 3822 */     t.copyBuffer(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public UAX29URLEmailTokenizerImpl36(Reader in)
/*      */   {
/* 3832 */     this.zzReader = in;
/*      */   }
/*      */ 
/*      */   private static char[] zzUnpackCMap(String packed)
/*      */   {
/* 3843 */     char[] map = new char[65536];
/* 3844 */     int i = 0;
/* 3845 */     int j = 0;
/*      */     int count;
/* 3849 */     for (; i < 2812; 
/* 3849 */       count > 0)
/*      */     {
/* 3847 */       count = packed.charAt(i++);
/* 3848 */       char value = packed.charAt(i++);
/* 3849 */       map[(j++)] = value; count--;
/*      */     }
/* 3851 */     return map;
/*      */   }
/*      */ 
/*      */   private boolean zzRefill()
/*      */     throws IOException
/*      */   {
/* 3865 */     if (this.zzStartRead > 0) {
/* 3866 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*      */ 
/* 3871 */       this.zzEndRead -= this.zzStartRead;
/* 3872 */       this.zzCurrentPos -= this.zzStartRead;
/* 3873 */       this.zzMarkedPos -= this.zzStartRead;
/* 3874 */       this.zzStartRead = 0;
/*      */     }
/*      */ 
/* 3878 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*      */     {
/* 3880 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 3881 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 3882 */       this.zzBuffer = newBuffer;
/*      */     }
/*      */ 
/* 3886 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*      */ 
/* 3889 */     if (numRead > 0) {
/* 3890 */       this.zzEndRead += numRead;
/* 3891 */       return false;
/*      */     }
/*      */ 
/* 3894 */     if (numRead == 0) {
/* 3895 */       int c = this.zzReader.read();
/* 3896 */       if (c == -1) {
/* 3897 */         return true;
/*      */       }
/* 3899 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 3900 */       return false;
/*      */     }
/*      */ 
/* 3905 */     return true;
/*      */   }
/*      */ 
/*      */   public final void yyclose()
/*      */     throws IOException
/*      */   {
/* 3913 */     this.zzAtEOF = true;
/* 3914 */     this.zzEndRead = this.zzStartRead;
/*      */ 
/* 3916 */     if (this.zzReader != null)
/* 3917 */       this.zzReader.close();
/*      */   }
/*      */ 
/*      */   public final void yyreset(Reader reader)
/*      */   {
/* 3934 */     this.zzReader = reader;
/* 3935 */     this.zzAtBOL = true;
/* 3936 */     this.zzAtEOF = false;
/* 3937 */     this.zzEOFDone = false;
/* 3938 */     this.zzEndRead = (this.zzStartRead = 0);
/* 3939 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/* 3940 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 3941 */     this.zzLexicalState = 0;
/* 3942 */     if (this.zzBuffer.length > 4096)
/* 3943 */       this.zzBuffer = new char[4096];
/*      */   }
/*      */ 
/*      */   public final int yystate()
/*      */   {
/* 3951 */     return this.zzLexicalState;
/*      */   }
/*      */ 
/*      */   public final void yybegin(int newState)
/*      */   {
/* 3961 */     this.zzLexicalState = newState;
/*      */   }
/*      */ 
/*      */   public final String yytext()
/*      */   {
/* 3969 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*      */   }
/*      */ 
/*      */   public final char yycharat(int pos)
/*      */   {
/* 3985 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*      */   }
/*      */ 
/*      */   public final int yylength()
/*      */   {
/* 3993 */     return this.zzMarkedPos - this.zzStartRead;
/*      */   }
/*      */ 
/*      */   private void zzScanError(int errorCode)
/*      */   {
/*      */     String message;
/*      */     try
/*      */     {
/* 4014 */       message = ZZ_ERROR_MSG[errorCode];
/*      */     }
/*      */     catch (ArrayIndexOutOfBoundsException e) {
/* 4017 */       message = ZZ_ERROR_MSG[0];
/*      */     }
/*      */ 
/* 4020 */     throw new Error(message);
/*      */   }
/*      */ 
/*      */   public void yypushback(int number)
/*      */   {
/* 4033 */     if (number > yylength()) {
/* 4034 */       zzScanError(2);
/*      */     }
/* 4036 */     this.zzMarkedPos -= number;
/*      */   }
/*      */ 
/*      */   public int getNextToken()
/*      */     throws IOException
/*      */   {
/* 4054 */     int zzEndReadL = this.zzEndRead;
/* 4055 */     char[] zzBufferL = this.zzBuffer;
/* 4056 */     char[] zzCMapL = ZZ_CMAP;
/*      */ 
/* 4058 */     int[] zzTransL = ZZ_TRANS;
/* 4059 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 4060 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*      */     while (true)
/*      */     {
/* 4063 */       int zzMarkedPosL = this.zzMarkedPos;
/*      */ 
/* 4065 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*      */ 
/* 4067 */       int zzAction = -1;
/*      */ 
/* 4069 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*      */ 
/* 4071 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*      */ 
/* 4074 */       int zzAttributes = zzAttrL[this.zzState];
/* 4075 */       if ((zzAttributes & 0x1) == 1)
/* 4076 */         zzAction = this.zzState;
/*      */       int zzInput;
/*      */       while (true)
/*      */       {
/*      */         int zzInput;
/* 4083 */         if (zzCurrentPosL < zzEndReadL) {
/* 4084 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 4085 */           if (this.zzAtEOF) {
/* 4086 */             int zzInput = -1;
/* 4087 */             break;
/*      */           }
/*      */ 
/* 4091 */           this.zzCurrentPos = zzCurrentPosL;
/* 4092 */           this.zzMarkedPos = zzMarkedPosL;
/* 4093 */           boolean eof = zzRefill();
/*      */ 
/* 4095 */           zzCurrentPosL = this.zzCurrentPos;
/* 4096 */           zzMarkedPosL = this.zzMarkedPos;
/* 4097 */           zzBufferL = this.zzBuffer;
/* 4098 */           zzEndReadL = this.zzEndRead;
/* 4099 */           if (eof) {
/* 4100 */             int zzInput = -1;
/* 4101 */             break;
/*      */           }
/*      */ 
/* 4104 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*      */         }
/*      */ 
/* 4107 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 4108 */         if (zzNext == -1) break;
/* 4109 */         this.zzState = zzNext;
/*      */ 
/* 4111 */         zzAttributes = zzAttrL[this.zzState];
/* 4112 */         if ((zzAttributes & 0x1) == 1) {
/* 4113 */           zzAction = this.zzState;
/* 4114 */           zzMarkedPosL = zzCurrentPosL;
/* 4115 */           if ((zzAttributes & 0x8) == 8)
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 4122 */       this.zzMarkedPos = zzMarkedPosL;
/*      */ 
/* 4124 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*      */       case 1:
/* 4126 */         break;
/*      */       case 12:
/* 4128 */         break;
/*      */       case 2:
/* 4130 */         return 0;
/*      */       case 13:
/* 4132 */         break;
/*      */       case 3:
/* 4134 */         return 1;
/*      */       case 14:
/* 4136 */         break;
/*      */       case 4:
/* 4138 */         return 5;
/*      */       case 15:
/* 4140 */         break;
/*      */       case 5:
/* 4142 */         return 2;
/*      */       case 16:
/* 4144 */         break;
/*      */       case 6:
/* 4146 */         return 3;
/*      */       case 17:
/* 4148 */         break;
/*      */       case 7:
/* 4150 */         return 4;
/*      */       case 18:
/* 4152 */         break;
/*      */       case 8:
/* 4154 */         return 6;
/*      */       case 19:
/* 4156 */         break;
/*      */       case 9:
/* 4158 */         return 8;
/*      */       case 20:
/* 4160 */         break;
/*      */       case 10:
/* 4162 */         return 7;
/*      */       case 21:
/* 4164 */         break;
/*      */       case 11:
/* 4167 */         this.zzMarkedPos = (this.zzStartRead + 6);
/* 4168 */         return 0;
/*      */       case 22:
/* 4170 */         break;
/*      */       default:
/* 4172 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 4173 */           this.zzAtEOF = true;
/*      */ 
/* 4175 */           return -1;
/*      */         }
/*      */ 
/* 4179 */         zzScanError(1);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.std36.UAX29URLEmailTokenizerImpl36
 * JD-Core Version:    0.6.2
 */