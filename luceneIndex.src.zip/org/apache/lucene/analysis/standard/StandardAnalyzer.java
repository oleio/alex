/*     */ package org.apache.lucene.analysis.standard;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopAnalyzer;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class StandardAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   public static final int DEFAULT_MAX_TOKEN_LENGTH = 255;
/*  60 */   private int maxTokenLength = 255;
/*     */ 
/*  64 */   public static final CharArraySet STOP_WORDS_SET = StopAnalyzer.ENGLISH_STOP_WORDS_SET;
/*     */ 
/*     */   public StandardAnalyzer(Version matchVersion, CharArraySet stopWords)
/*     */   {
/*  71 */     super(matchVersion, stopWords);
/*     */   }
/*     */ 
/*     */   public StandardAnalyzer(Version matchVersion)
/*     */   {
/*  80 */     this(matchVersion, STOP_WORDS_SET);
/*     */   }
/*     */ 
/*     */   public StandardAnalyzer(Version matchVersion, Reader stopwords)
/*     */     throws IOException
/*     */   {
/*  89 */     this(matchVersion, loadStopwordSet(stopwords, matchVersion));
/*     */   }
/*     */ 
/*     */   public void setMaxTokenLength(int length)
/*     */   {
/*  99 */     this.maxTokenLength = length;
/*     */   }
/*     */ 
/*     */   public int getMaxTokenLength()
/*     */   {
/* 106 */     return this.maxTokenLength;
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 111 */     final StandardTokenizer src = new StandardTokenizer(this.matchVersion, reader);
/* 112 */     src.setMaxTokenLength(this.maxTokenLength);
/* 113 */     TokenStream tok = new StandardFilter(this.matchVersion, src);
/* 114 */     tok = new LowerCaseFilter(this.matchVersion, tok);
/* 115 */     tok = new StopFilter(this.matchVersion, tok, this.stopwords);
/* 116 */     return new Analyzer.TokenStreamComponents(src, tok)
/*     */     {
/*     */       protected void setReader(Reader reader) throws IOException {
/* 119 */         src.setMaxTokenLength(StandardAnalyzer.this.maxTokenLength);
/* 120 */         super.setReader(reader);
/*     */       }
/*     */     };
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.standard.StandardAnalyzer
 * JD-Core Version:    0.6.2
 */