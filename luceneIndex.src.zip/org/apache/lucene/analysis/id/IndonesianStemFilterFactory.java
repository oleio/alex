/*    */ package org.apache.lucene.analysis.id;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class IndonesianStemFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   private final boolean stemDerivational;
/*    */ 
/*    */   public IndonesianStemFilterFactory(Map<String, String> args)
/*    */   {
/* 42 */     super(args);
/* 43 */     this.stemDerivational = getBoolean(args, "stemDerivational", true);
/* 44 */     if (!args.isEmpty())
/* 45 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 51 */     return new IndonesianStemFilter(input, this.stemDerivational);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.id.IndonesianStemFilterFactory
 * JD-Core Version:    0.6.2
 */