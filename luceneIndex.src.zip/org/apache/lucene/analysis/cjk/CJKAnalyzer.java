/*     */ package org.apache.lucene.analysis.cjk;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class CJKAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   public static final String DEFAULT_STOPWORD_FILE = "stopwords.txt";
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  53 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public CJKAnalyzer(Version matchVersion)
/*     */   {
/*  74 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   public CJKAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/*  86 */     super(matchVersion, stopwords);
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/*  92 */     if (this.matchVersion.onOrAfter(Version.LUCENE_36)) {
/*  93 */       Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/*     */ 
/*  95 */       TokenStream result = new CJKWidthFilter(source);
/*  96 */       result = new LowerCaseFilter(this.matchVersion, result);
/*  97 */       result = new CJKBigramFilter(result);
/*  98 */       return new Analyzer.TokenStreamComponents(source, new StopFilter(this.matchVersion, result, this.stopwords));
/*     */     }
/* 100 */     Tokenizer source = new CJKTokenizer(reader);
/* 101 */     return new Analyzer.TokenStreamComponents(source, new StopFilter(this.matchVersion, source, this.stopwords));
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  61 */         DEFAULT_STOP_SET = CJKAnalyzer.loadStopwordSet(false, CJKAnalyzer.class, "stopwords.txt", "#");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  65 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cjk.CJKAnalyzer
 * JD-Core Version:    0.6.2
 */