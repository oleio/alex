/*     */ package org.apache.lucene.analysis.cjk;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionLengthAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.ArrayUtil;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ 
/*     */ public final class CJKBigramFilter extends TokenFilter
/*     */ {
/*     */   public static final int HAN = 1;
/*     */   public static final int HIRAGANA = 2;
/*     */   public static final int KATAKANA = 4;
/*     */   public static final int HANGUL = 8;
/*     */   public static final String DOUBLE_TYPE = "<DOUBLE>";
/*     */   public static final String SINGLE_TYPE = "<SINGLE>";
/*  65 */   private static final String HAN_TYPE = org.apache.lucene.analysis.standard.StandardTokenizer.TOKEN_TYPES[10];
/*  66 */   private static final String HIRAGANA_TYPE = org.apache.lucene.analysis.standard.StandardTokenizer.TOKEN_TYPES[11];
/*  67 */   private static final String KATAKANA_TYPE = org.apache.lucene.analysis.standard.StandardTokenizer.TOKEN_TYPES[12];
/*  68 */   private static final String HANGUL_TYPE = org.apache.lucene.analysis.standard.StandardTokenizer.TOKEN_TYPES[13];
/*     */ 
/*  71 */   private static final Object NO = new Object();
/*     */   private final Object doHan;
/*     */   private final Object doHiragana;
/*     */   private final Object doKatakana;
/*     */   private final Object doHangul;
/*     */   private final boolean outputUnigrams;
/*     */   private boolean ngramState;
/*  83 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  84 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/*  85 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*  86 */   private final PositionIncrementAttribute posIncAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*  87 */   private final PositionLengthAttribute posLengthAtt = (PositionLengthAttribute)addAttribute(PositionLengthAttribute.class);
/*     */ 
/*  90 */   int[] buffer = new int[8];
/*  91 */   int[] startOffset = new int[8];
/*  92 */   int[] endOffset = new int[8];
/*     */   int bufferLen;
/*     */   int index;
/*     */   int lastEndOffset;
/*     */   private boolean exhausted;
/*     */   private AttributeSource.State loneState;
/*     */ 
/*     */   public CJKBigramFilter(TokenStream in)
/*     */   {
/* 108 */     this(in, 15);
/*     */   }
/*     */ 
/*     */   public CJKBigramFilter(TokenStream in, int flags)
/*     */   {
/* 116 */     this(in, flags, false);
/*     */   }
/*     */ 
/*     */   public CJKBigramFilter(TokenStream in, int flags, boolean outputUnigrams)
/*     */   {
/* 129 */     super(in);
/* 130 */     this.doHan = ((flags & 0x1) == 0 ? NO : HAN_TYPE);
/* 131 */     this.doHiragana = ((flags & 0x2) == 0 ? NO : HIRAGANA_TYPE);
/* 132 */     this.doKatakana = ((flags & 0x4) == 0 ? NO : KATAKANA_TYPE);
/* 133 */     this.doHangul = ((flags & 0x8) == 0 ? NO : HANGUL_TYPE);
/* 134 */     this.outputUnigrams = outputUnigrams;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*     */     while (true)
/*     */     {
/* 145 */       if (hasBufferedBigram())
/*     */       {
/* 150 */         if (this.outputUnigrams)
/*     */         {
/* 158 */           if (this.ngramState) {
/* 159 */             flushBigram();
/*     */           } else {
/* 161 */             flushUnigram();
/* 162 */             this.index -= 1;
/*     */           }
/* 164 */           this.ngramState = (!this.ngramState);
/*     */         } else {
/* 166 */           flushBigram();
/*     */         }
/* 168 */         return true;
/* 169 */       }if (!doNext())
/*     */       {
/*     */         break;
/*     */       }
/* 173 */       String type = this.typeAtt.type();
/* 174 */       if ((type == this.doHan) || (type == this.doHiragana) || (type == this.doKatakana) || (type == this.doHangul))
/*     */       {
/* 180 */         if (this.offsetAtt.startOffset() != this.lastEndOffset) {
/* 181 */           if (hasBufferedUnigram())
/*     */           {
/* 187 */             this.loneState = captureState();
/* 188 */             flushUnigram();
/* 189 */             return true;
/*     */           }
/* 191 */           this.index = 0;
/* 192 */           this.bufferLen = 0;
/*     */         }
/* 194 */         refill();
/*     */       }
/*     */       else
/*     */       {
/* 199 */         if (hasBufferedUnigram())
/*     */         {
/* 205 */           this.loneState = captureState();
/* 206 */           flushUnigram();
/* 207 */           return true;
/*     */         }
/* 209 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 218 */     if (hasBufferedUnigram()) {
/* 219 */       flushUnigram();
/* 220 */       return true;
/*     */     }
/* 222 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean doNext()
/*     */     throws IOException
/*     */   {
/* 233 */     if (this.loneState != null) {
/* 234 */       restoreState(this.loneState);
/* 235 */       this.loneState = null;
/* 236 */       return true;
/*     */     }
/* 238 */     if (this.exhausted)
/* 239 */       return false;
/* 240 */     if (this.input.incrementToken()) {
/* 241 */       return true;
/*     */     }
/* 243 */     this.exhausted = true;
/* 244 */     return false;
/*     */   }
/*     */ 
/*     */   private void refill()
/*     */   {
/* 255 */     if (this.bufferLen > 64) {
/* 256 */       int last = this.bufferLen - 1;
/* 257 */       this.buffer[0] = this.buffer[last];
/* 258 */       this.startOffset[0] = this.startOffset[last];
/* 259 */       this.endOffset[0] = this.endOffset[last];
/* 260 */       this.bufferLen = 1;
/* 261 */       this.index -= last;
/*     */     }
/*     */ 
/* 264 */     char[] termBuffer = this.termAtt.buffer();
/* 265 */     int len = this.termAtt.length();
/* 266 */     int start = this.offsetAtt.startOffset();
/* 267 */     int end = this.offsetAtt.endOffset();
/*     */ 
/* 269 */     int newSize = this.bufferLen + len;
/* 270 */     this.buffer = ArrayUtil.grow(this.buffer, newSize);
/* 271 */     this.startOffset = ArrayUtil.grow(this.startOffset, newSize);
/* 272 */     this.endOffset = ArrayUtil.grow(this.endOffset, newSize);
/* 273 */     this.lastEndOffset = end;
/*     */ 
/* 275 */     if (end - start != len)
/*     */     {
/* 277 */       int i = 0; for (int cp = 0; i < len; i += Character.charCount(cp)) {
/* 278 */         cp = this.buffer[this.bufferLen] = Character.codePointAt(termBuffer, i, len);
/* 279 */         this.startOffset[this.bufferLen] = start;
/* 280 */         this.endOffset[this.bufferLen] = end;
/* 281 */         this.bufferLen += 1;
/*     */       }
/*     */     }
/*     */     else {
/* 285 */       int i = 0; int cp = 0; for (int cpLen = 0; i < len; i += cpLen) {
/* 286 */         cp = this.buffer[this.bufferLen] = Character.codePointAt(termBuffer, i, len);
/* 287 */         cpLen = Character.charCount(cp);
/* 288 */         this.startOffset[this.bufferLen] = start;
/* 289 */         start = this.endOffset[this.bufferLen] = start + cpLen;
/* 290 */         this.bufferLen += 1;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void flushBigram()
/*     */   {
/* 300 */     clearAttributes();
/* 301 */     char[] termBuffer = this.termAtt.resizeBuffer(4);
/* 302 */     int len1 = Character.toChars(this.buffer[this.index], termBuffer, 0);
/* 303 */     int len2 = len1 + Character.toChars(this.buffer[(this.index + 1)], termBuffer, len1);
/* 304 */     this.termAtt.setLength(len2);
/* 305 */     this.offsetAtt.setOffset(this.startOffset[this.index], this.endOffset[(this.index + 1)]);
/* 306 */     this.typeAtt.setType("<DOUBLE>");
/*     */ 
/* 308 */     if (this.outputUnigrams) {
/* 309 */       this.posIncAtt.setPositionIncrement(0);
/* 310 */       this.posLengthAtt.setPositionLength(2);
/*     */     }
/* 312 */     this.index += 1;
/*     */   }
/*     */ 
/*     */   private void flushUnigram()
/*     */   {
/* 322 */     clearAttributes();
/* 323 */     char[] termBuffer = this.termAtt.resizeBuffer(2);
/* 324 */     int len = Character.toChars(this.buffer[this.index], termBuffer, 0);
/* 325 */     this.termAtt.setLength(len);
/* 326 */     this.offsetAtt.setOffset(this.startOffset[this.index], this.endOffset[this.index]);
/* 327 */     this.typeAtt.setType("<SINGLE>");
/* 328 */     this.index += 1;
/*     */   }
/*     */ 
/*     */   private boolean hasBufferedBigram()
/*     */   {
/* 335 */     return this.bufferLen - this.index > 1;
/*     */   }
/*     */ 
/*     */   private boolean hasBufferedUnigram()
/*     */   {
/* 344 */     if (this.outputUnigrams)
/*     */     {
/* 346 */       return this.bufferLen - this.index == 1;
/*     */     }
/*     */ 
/* 349 */     return (this.bufferLen == 1) && (this.index == 0);
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 355 */     super.reset();
/* 356 */     this.bufferLen = 0;
/* 357 */     this.index = 0;
/* 358 */     this.lastEndOffset = 0;
/* 359 */     this.loneState = null;
/* 360 */     this.exhausted = false;
/* 361 */     this.ngramState = false;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cjk.CJKBigramFilter
 * JD-Core Version:    0.6.2
 */