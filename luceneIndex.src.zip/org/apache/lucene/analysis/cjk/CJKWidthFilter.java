/*     */ package org.apache.lucene.analysis.cjk;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.util.StemmerUtil;
/*     */ 
/*     */ public final class CJKWidthFilter extends TokenFilter
/*     */ {
/*  39 */   private CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */ 
/*  47 */   private static final char[] KANA_NORM = { '・', 'ヲ', 'ァ', 'ィ', 'ゥ', 'ェ', 'ォ', 'ャ', 'ュ', 'ョ', 'ッ', 'ー', 'ア', 'イ', 'ウ', 'エ', 'オ', 'カ', 'キ', 'ク', 'ケ', 'コ', 'サ', 'シ', 'ス', 'セ', 'ソ', 'タ', 'チ', 'ツ', 'テ', 'ト', 'ナ', 'ニ', 'ヌ', 'ネ', 'ノ', 'ハ', 'ヒ', 'フ', 'ヘ', 'ホ', 'マ', 'ミ', 'ム', 'メ', 'モ', 'ヤ', 'ユ', 'ヨ', 'ラ', 'リ', 'ル', 'レ', 'ロ', 'ワ', 'ン', '゙', '゚' };
/*     */ 
/*  88 */   private static final byte[] KANA_COMBINE_VOICED = { 78, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 8, 8, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
/*     */ 
/*  95 */   private static final byte[] KANA_COMBINE_HALF_VOICED = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 2, 0, 0, 2, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */   public CJKWidthFilter(TokenStream input)
/*     */   {
/*  58 */     super(input);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  63 */     if (this.input.incrementToken()) {
/*  64 */       char[] text = this.termAtt.buffer();
/*  65 */       int length = this.termAtt.length();
/*  66 */       for (int i = 0; i < length; i++) {
/*  67 */         char ch = text[i];
/*  68 */         if ((ch >= 65281) && (ch <= 65374))
/*     */         {
/*     */           int tmp58_57 = i;
/*     */           char[] tmp58_56 = text; tmp58_56[tmp58_57] = ((char)(tmp58_56[tmp58_57] - 65248));
/*  71 */         } else if ((ch >= 65381) && (ch <= 65439))
/*     */         {
/*  73 */           if (((ch == 65438) || (ch == 65439)) && (i > 0) && (combine(text, i, ch)))
/*  74 */             length = StemmerUtil.delete(text, i--, length);
/*     */           else {
/*  76 */             text[i] = KANA_NORM[(ch - 65381)];
/*     */           }
/*     */         }
/*     */       }
/*  80 */       this.termAtt.setLength(length);
/*  81 */       return true;
/*     */     }
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */   private static boolean combine(char[] text, int pos, char ch)
/*     */   {
/* 104 */     char prev = text[(pos - 1)];
/* 105 */     if ((prev >= 'ウ') && (prev <= 'ヽ'))
/*     */     {
/*     */       int tmp24_23 = (pos - 1); text[tmp24_23] = ((char)(text[tmp24_23] + (ch == 65439 ? KANA_COMBINE_HALF_VOICED[(prev - 'ウ')] : KANA_COMBINE_VOICED[(prev - 'ウ')])));
/*     */ 
/* 109 */       return text[(pos - 1)] != prev;
/*     */     }
/* 111 */     return false;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.cjk.CJKWidthFilter
 * JD-Core Version:    0.6.2
 */