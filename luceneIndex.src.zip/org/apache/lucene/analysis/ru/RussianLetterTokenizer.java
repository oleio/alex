/*    */ package org.apache.lucene.analysis.ru;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.util.CharTokenizer;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ @Deprecated
/*    */ public class RussianLetterTokenizer extends CharTokenizer
/*    */ {
/*    */   private static final int DIGIT_0 = 48;
/*    */   private static final int DIGIT_9 = 57;
/*    */ 
/*    */   public RussianLetterTokenizer(Version matchVersion, Reader in)
/*    */   {
/* 56 */     super(matchVersion, in);
/*    */   }
/*    */ 
/*    */   public RussianLetterTokenizer(Version matchVersion, AttributeSource.AttributeFactory factory, Reader in)
/*    */   {
/* 71 */     super(matchVersion, factory, in);
/*    */   }
/*    */ 
/*    */   protected boolean isTokenChar(int c)
/*    */   {
/* 80 */     return (Character.isLetter(c)) || ((c >= 48) && (c <= 57));
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ru.RussianLetterTokenizer
 * JD-Core Version:    0.6.2
 */