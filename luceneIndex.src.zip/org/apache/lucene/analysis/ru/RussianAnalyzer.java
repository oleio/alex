/*     */ package org.apache.lucene.analysis.ru;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.snowball.SnowballFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.analysis.util.WordlistLoader;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.tartarus.snowball.ext.RussianStemmer;
/*     */ 
/*     */ public final class RussianAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */ 
/*     */   @Deprecated
/*  62 */   private static final String[] RUSSIAN_STOP_WORDS_30 = { "а", "без", "более", "бы", "был", "была", "были", "было", "быть", "в", "вам", "вас", "весь", "во", "вот", "все", "всего", "всех", "вы", "где", "да", "даже", "для", "до", "его", "ее", "ей", "ею", "если", "есть", "еще", "же", "за", "здесь", "и", "из", "или", "им", "их", "к", "как", "ко", "когда", "кто", "ли", "либо", "мне", "может", "мы", "на", "надо", "наш", "не", "него", "нее", "нет", "ни", "них", "но", "ну", "о", "об", "однако", "он", "она", "они", "оно", "от", "очень", "по", "под", "при", "с", "со", "так", "также", "такой", "там", "те", "тем", "то", "того", "тоже", "той", "только", "том", "ты", "у", "уже", "хотя", "чего", "чей", "чем", "что", "чтобы", "чье", "чья", "эта", "эти", "это", "я" };
/*     */   public static final String DEFAULT_STOPWORD_FILE = "russian_stop.txt";
/*     */   private final CharArraySet stemExclusionSet;
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/* 106 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public RussianAnalyzer(Version matchVersion) {
/* 110 */     this(matchVersion, matchVersion.onOrAfter(Version.LUCENE_31) ? DefaultSetHolder.DEFAULT_STOP_SET : DefaultSetHolder.DEFAULT_STOP_SET_30);
/*     */   }
/*     */ 
/*     */   public RussianAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/* 124 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public RussianAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/* 137 */     super(matchVersion, stopwords);
/* 138 */     this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 155 */     if (this.matchVersion.onOrAfter(Version.LUCENE_31)) {
/* 156 */       Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 157 */       TokenStream result = new StandardFilter(this.matchVersion, source);
/* 158 */       result = new LowerCaseFilter(this.matchVersion, result);
/* 159 */       result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 160 */       if (!this.stemExclusionSet.isEmpty()) result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
/*     */ 
/* 162 */       result = new SnowballFilter(result, new RussianStemmer());
/* 163 */       return new Analyzer.TokenStreamComponents(source, result);
/*     */     }
/* 165 */     Tokenizer source = new RussianLetterTokenizer(this.matchVersion, reader);
/* 166 */     TokenStream result = new LowerCaseFilter(this.matchVersion, source);
/* 167 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 168 */     if (!this.stemExclusionSet.isEmpty()) result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
/*     */ 
/* 170 */     result = new SnowballFilter(result, new RussianStemmer());
/* 171 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */ 
/*     */     @Deprecated
/*  81 */     static final CharArraySet DEFAULT_STOP_SET_30 = CharArraySet.unmodifiableSet(new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(RussianAnalyzer.RUSSIAN_STOP_WORDS_30), false));
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  88 */         DEFAULT_STOP_SET = WordlistLoader.getSnowballWordSet(IOUtils.getDecodingReader(SnowballFilter.class, "russian_stop.txt", StandardCharsets.UTF_8), Version.LUCENE_CURRENT);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  93 */         throw new RuntimeException("Unable to load default stopword set", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ru.RussianAnalyzer
 * JD-Core Version:    0.6.2
 */