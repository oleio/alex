/*     */ package org.apache.lucene.analysis;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.lucene.store.AlreadyClosedException;
/*     */ import org.apache.lucene.util.CloseableThreadLocal;
/*     */ 
/*     */ public abstract class Analyzer
/*     */   implements Closeable
/*     */ {
/*     */   private final ReuseStrategy reuseStrategy;
/*  76 */   CloseableThreadLocal<Object> storedValue = new CloseableThreadLocal();
/*     */ 
/* 392 */   public static final ReuseStrategy GLOBAL_REUSE_STRATEGY = new GlobalReuseStrategy();
/*     */ 
/* 423 */   public static final ReuseStrategy PER_FIELD_REUSE_STRATEGY = new PerFieldReuseStrategy();
/*     */ 
/*     */   public Analyzer()
/*     */   {
/*  83 */     this(GLOBAL_REUSE_STRATEGY);
/*     */   }
/*     */ 
/*     */   public Analyzer(ReuseStrategy reuseStrategy)
/*     */   {
/*  95 */     this.reuseStrategy = reuseStrategy;
/*     */   }
/*     */ 
/*     */   protected abstract TokenStreamComponents createComponents(String paramString, Reader paramReader);
/*     */ 
/*     */   public final TokenStream tokenStream(String fieldName, Reader reader)
/*     */     throws IOException
/*     */   {
/* 139 */     TokenStreamComponents components = this.reuseStrategy.getReusableComponents(this, fieldName);
/* 140 */     Reader r = initReader(fieldName, reader);
/* 141 */     if (components == null) {
/* 142 */       components = createComponents(fieldName, r);
/* 143 */       this.reuseStrategy.setReusableComponents(this, fieldName, components);
/*     */     } else {
/* 145 */       components.setReader(r);
/*     */     }
/* 147 */     return components.getTokenStream();
/*     */   }
/*     */ 
/*     */   public final TokenStream tokenStream(String fieldName, String text)
/*     */     throws IOException
/*     */   {
/* 173 */     TokenStreamComponents components = this.reuseStrategy.getReusableComponents(this, fieldName);
/* 174 */     ReusableStringReader strReader = (components == null) || (components.reusableStringReader == null) ? new ReusableStringReader() : components.reusableStringReader;
/*     */ 
/* 177 */     strReader.setValue(text);
/* 178 */     Reader r = initReader(fieldName, strReader);
/* 179 */     if (components == null) {
/* 180 */       components = createComponents(fieldName, r);
/* 181 */       this.reuseStrategy.setReusableComponents(this, fieldName, components);
/*     */     } else {
/* 183 */       components.setReader(r);
/*     */     }
/* 185 */     components.reusableStringReader = strReader;
/* 186 */     return components.getTokenStream();
/*     */   }
/*     */ 
/*     */   protected Reader initReader(String fieldName, Reader reader)
/*     */   {
/* 200 */     return reader;
/*     */   }
/*     */ 
/*     */   public int getPositionIncrementGap(String fieldName)
/*     */   {
/* 218 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getOffsetGap(String fieldName)
/*     */   {
/* 232 */     return 1;
/*     */   }
/*     */ 
/*     */   public final ReuseStrategy getReuseStrategy()
/*     */   {
/* 239 */     return this.reuseStrategy;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 245 */     if (this.storedValue != null) {
/* 246 */       this.storedValue.close();
/* 247 */       this.storedValue = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static class PerFieldReuseStrategy extends Analyzer.ReuseStrategy
/*     */   {
/*     */     public Analyzer.TokenStreamComponents getReusableComponents(Analyzer analyzer, String fieldName)
/*     */     {
/* 442 */       Map componentsPerField = (Map)getStoredValue(analyzer);
/* 443 */       return componentsPerField != null ? (Analyzer.TokenStreamComponents)componentsPerField.get(fieldName) : null;
/*     */     }
/*     */ 
/*     */     public void setReusableComponents(Analyzer analyzer, String fieldName, Analyzer.TokenStreamComponents components)
/*     */     {
/* 449 */       Map componentsPerField = (Map)getStoredValue(analyzer);
/* 450 */       if (componentsPerField == null) {
/* 451 */         componentsPerField = new HashMap();
/* 452 */         setStoredValue(analyzer, componentsPerField);
/*     */       }
/* 454 */       componentsPerField.put(fieldName, components);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static final class GlobalReuseStrategy extends Analyzer.ReuseStrategy
/*     */   {
/*     */     public Analyzer.TokenStreamComponents getReusableComponents(Analyzer analyzer, String fieldName)
/*     */     {
/* 410 */       return (Analyzer.TokenStreamComponents)getStoredValue(analyzer);
/*     */     }
/*     */ 
/*     */     public void setReusableComponents(Analyzer analyzer, String fieldName, Analyzer.TokenStreamComponents components)
/*     */     {
/* 415 */       setStoredValue(analyzer, components);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class ReuseStrategy
/*     */   {
/*     */     public abstract Analyzer.TokenStreamComponents getReusableComponents(Analyzer paramAnalyzer, String paramString);
/*     */ 
/*     */     public abstract void setReusableComponents(Analyzer paramAnalyzer, String paramString, Analyzer.TokenStreamComponents paramTokenStreamComponents);
/*     */ 
/*     */     protected final Object getStoredValue(Analyzer analyzer)
/*     */     {
/* 367 */       if (analyzer.storedValue == null) {
/* 368 */         throw new AlreadyClosedException("this Analyzer is closed");
/*     */       }
/* 370 */       return analyzer.storedValue.get();
/*     */     }
/*     */ 
/*     */     protected final void setStoredValue(Analyzer analyzer, Object storedValue)
/*     */     {
/* 380 */       if (analyzer.storedValue == null) {
/* 381 */         throw new AlreadyClosedException("this Analyzer is closed");
/*     */       }
/* 383 */       analyzer.storedValue.set(storedValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class TokenStreamComponents
/*     */   {
/*     */     protected final Tokenizer source;
/*     */     protected final TokenStream sink;
/*     */     transient ReusableStringReader reusableStringReader;
/*     */ 
/*     */     public TokenStreamComponents(Tokenizer source, TokenStream result)
/*     */     {
/* 282 */       this.source = source;
/* 283 */       this.sink = result;
/*     */     }
/*     */ 
/*     */     public TokenStreamComponents(Tokenizer source)
/*     */     {
/* 293 */       this.source = source;
/* 294 */       this.sink = source;
/*     */     }
/*     */ 
/*     */     protected void setReader(Reader reader)
/*     */       throws IOException
/*     */     {
/* 307 */       this.source.setReader(reader);
/*     */     }
/*     */ 
/*     */     public TokenStream getTokenStream()
/*     */     {
/* 316 */       return this.sink;
/*     */     }
/*     */ 
/*     */     public Tokenizer getTokenizer()
/*     */     {
/* 325 */       return this.source;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.Analyzer
 * JD-Core Version:    0.6.2
 */