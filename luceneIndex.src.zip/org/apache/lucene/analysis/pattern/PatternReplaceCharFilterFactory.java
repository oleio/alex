/*    */ package org.apache.lucene.analysis.pattern;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.lucene.analysis.CharFilter;
/*    */ import org.apache.lucene.analysis.util.CharFilterFactory;
/*    */ 
/*    */ public class PatternReplaceCharFilterFactory extends CharFilterFactory
/*    */ {
/*    */   private final Pattern pattern;
/*    */   private final String replacement;
/*    */   private final int maxBlockChars;
/*    */   private final String blockDelimiters;
/*    */ 
/*    */   public PatternReplaceCharFilterFactory(Map<String, String> args)
/*    */   {
/* 48 */     super(args);
/* 49 */     this.pattern = getPattern(args, "pattern");
/* 50 */     this.replacement = get(args, "replacement", "");
/*    */ 
/* 52 */     this.maxBlockChars = getInt(args, "maxBlockChars", 10000);
/* 53 */     this.blockDelimiters = ((String)args.remove("blockDelimiters"));
/* 54 */     if (!args.isEmpty())
/* 55 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public CharFilter create(Reader input)
/*    */   {
/* 61 */     return new PatternReplaceCharFilter(this.pattern, this.replacement, this.maxBlockChars, this.blockDelimiters, input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.pattern.PatternReplaceCharFilterFactory
 * JD-Core Version:    0.6.2
 */