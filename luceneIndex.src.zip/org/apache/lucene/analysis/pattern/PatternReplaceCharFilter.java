/*     */ package org.apache.lucene.analysis.pattern;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.lucene.analysis.charfilter.BaseCharFilter;
/*     */ 
/*     */ public class PatternReplaceCharFilter extends BaseCharFilter
/*     */ {
/*     */ 
/*     */   @Deprecated
/*     */   public static final int DEFAULT_MAX_BLOCK_CHARS = 10000;
/*     */   private final Pattern pattern;
/*     */   private final String replacement;
/*     */   private Reader transformedInput;
/*     */ 
/*     */   public PatternReplaceCharFilter(Pattern pattern, String replacement, Reader in)
/*     */   {
/*  59 */     super(in);
/*  60 */     this.pattern = pattern;
/*  61 */     this.replacement = replacement;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public PatternReplaceCharFilter(Pattern pattern, String replacement, int maxBlockChars, String blockDelimiter, Reader in)
/*     */   {
/*  67 */     this(pattern, replacement, in);
/*     */   }
/*     */ 
/*     */   public int read(char[] cbuf, int off, int len)
/*     */     throws IOException
/*     */   {
/*  73 */     if (this.transformedInput == null) {
/*  74 */       fill();
/*     */     }
/*     */ 
/*  77 */     return this.transformedInput.read(cbuf, off, len);
/*     */   }
/*     */ 
/*     */   private void fill() throws IOException {
/*  81 */     StringBuilder buffered = new StringBuilder();
/*  82 */     char[] temp = new char[1024];
/*  83 */     for (int cnt = this.input.read(temp); cnt > 0; cnt = this.input.read(temp)) {
/*  84 */       buffered.append(temp, 0, cnt);
/*     */     }
/*  86 */     this.transformedInput = new StringReader(processPattern(buffered).toString());
/*     */   }
/*     */ 
/*     */   public int read() throws IOException
/*     */   {
/*  91 */     if (this.transformedInput == null) {
/*  92 */       fill();
/*     */     }
/*     */ 
/*  95 */     return this.transformedInput.read();
/*     */   }
/*     */ 
/*     */   protected int correct(int currentOff)
/*     */   {
/* 100 */     return Math.max(0, super.correct(currentOff));
/*     */   }
/*     */ 
/*     */   CharSequence processPattern(CharSequence input)
/*     */   {
/* 107 */     Matcher m = this.pattern.matcher(input);
/*     */ 
/* 109 */     StringBuffer cumulativeOutput = new StringBuffer();
/* 110 */     int cumulative = 0;
/* 111 */     int lastMatchEnd = 0;
/* 112 */     while (m.find()) {
/* 113 */       int groupSize = m.end() - m.start();
/* 114 */       int skippedSize = m.start() - lastMatchEnd;
/* 115 */       lastMatchEnd = m.end();
/*     */ 
/* 117 */       int lengthBeforeReplacement = cumulativeOutput.length() + skippedSize;
/* 118 */       m.appendReplacement(cumulativeOutput, this.replacement);
/*     */ 
/* 121 */       int replacementSize = cumulativeOutput.length() - lengthBeforeReplacement;
/*     */ 
/* 123 */       if (groupSize != replacementSize) {
/* 124 */         if (replacementSize < groupSize)
/*     */         {
/* 129 */           cumulative += groupSize - replacementSize;
/* 130 */           int atIndex = lengthBeforeReplacement + replacementSize;
/*     */ 
/* 132 */           addOffCorrectMap(atIndex, cumulative);
/*     */         }
/*     */         else
/*     */         {
/* 136 */           for (int i = groupSize; i < replacementSize; i++) {
/* 137 */             addOffCorrectMap(lengthBeforeReplacement + i, --cumulative);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 145 */     m.appendTail(cumulativeOutput);
/* 146 */     return cumulativeOutput;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.pattern.PatternReplaceCharFilter
 * JD-Core Version:    0.6.2
 */