/*    */ package org.apache.lucene.analysis.pattern;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ 
/*    */ public class PatternTokenizerFactory extends TokenizerFactory
/*    */ {
/*    */   public static final String PATTERN = "pattern";
/*    */   public static final String GROUP = "group";
/*    */   protected final Pattern pattern;
/*    */   protected final int group;
/*    */ 
/*    */   public PatternTokenizerFactory(Map<String, String> args)
/*    */   {
/* 72 */     super(args);
/* 73 */     this.pattern = getPattern(args, "pattern");
/* 74 */     this.group = getInt(args, "group", -1);
/* 75 */     if (!args.isEmpty())
/* 76 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public PatternTokenizer create(AttributeSource.AttributeFactory factory, Reader in)
/*    */   {
/* 85 */     return new PatternTokenizer(factory, in, this.pattern, this.group);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.pattern.PatternTokenizerFactory
 * JD-Core Version:    0.6.2
 */