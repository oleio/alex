/*     */ package org.apache.lucene.analysis.pattern;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ import org.apache.lucene.util.CharsRef;
/*     */ 
/*     */ public final class PatternCaptureGroupTokenFilter extends TokenFilter
/*     */ {
/*  73 */   private final CharTermAttribute charTermAttr = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  74 */   private final PositionIncrementAttribute posAttr = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*     */   private AttributeSource.State state;
/*     */   private final Matcher[] matchers;
/*  77 */   private final CharsRef spare = new CharsRef();
/*     */   private final int[] groupCounts;
/*     */   private final boolean preserveOriginal;
/*     */   private int[] currentGroup;
/*     */   private int currentMatcher;
/*     */ 
/*     */   public PatternCaptureGroupTokenFilter(TokenStream input, boolean preserveOriginal, Pattern[] patterns)
/*     */   {
/*  95 */     super(input);
/*  96 */     this.preserveOriginal = preserveOriginal;
/*  97 */     this.matchers = new Matcher[patterns.length];
/*  98 */     this.groupCounts = new int[patterns.length];
/*  99 */     this.currentGroup = new int[patterns.length];
/* 100 */     for (int i = 0; i < patterns.length; i++) {
/* 101 */       this.matchers[i] = patterns[i].matcher("");
/* 102 */       this.groupCounts[i] = this.matchers[i].groupCount();
/* 103 */       this.currentGroup[i] = -1;
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean nextCapture() {
/* 108 */     int min_offset = 2147483647;
/* 109 */     this.currentMatcher = -1;
/*     */ 
/* 112 */     for (int i = 0; i < this.matchers.length; i++) {
/* 113 */       Matcher matcher = this.matchers[i];
/* 114 */       if (this.currentGroup[i] == -1) {
/* 115 */         this.currentGroup[i] = (matcher.find() ? 1 : 0);
/*     */       }
/* 117 */       if (this.currentGroup[i] != 0) {
/* 118 */         while (this.currentGroup[i] < this.groupCounts[i] + 1) {
/* 119 */           int start = matcher.start(this.currentGroup[i]);
/* 120 */           int end = matcher.end(this.currentGroup[i]);
/* 121 */           if ((start == end) || ((this.preserveOriginal) && (start == 0) && (this.spare.length == end)))
/*     */           {
/* 123 */             this.currentGroup[i] += 1;
/*     */           }
/* 126 */           else if (start < min_offset) {
/* 127 */             min_offset = start;
/* 128 */             this.currentMatcher = i;
/*     */           }
/*     */         }
/*     */ 
/* 132 */         if (this.currentGroup[i] == this.groupCounts[i] + 1) {
/* 133 */           this.currentGroup[i] = -1;
/* 134 */           i--;
/*     */         }
/*     */       }
/*     */     }
/* 138 */     return this.currentMatcher != -1;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 144 */     if ((this.currentMatcher != -1) && (nextCapture())) {
/* 145 */       assert (this.state != null);
/* 146 */       clearAttributes();
/* 147 */       restoreState(this.state);
/* 148 */       int start = this.matchers[this.currentMatcher].start(this.currentGroup[this.currentMatcher]);
/*     */ 
/* 150 */       int end = this.matchers[this.currentMatcher].end(this.currentGroup[this.currentMatcher]);
/*     */ 
/* 153 */       this.posAttr.setPositionIncrement(0);
/* 154 */       this.charTermAttr.copyBuffer(this.spare.chars, start, end - start);
/* 155 */       this.currentGroup[this.currentMatcher] += 1;
/* 156 */       return true;
/*     */     }
/*     */ 
/* 159 */     if (!this.input.incrementToken()) {
/* 160 */       return false;
/*     */     }
/*     */ 
/* 163 */     char[] buffer = this.charTermAttr.buffer();
/* 164 */     int length = this.charTermAttr.length();
/* 165 */     this.spare.copyChars(buffer, 0, length);
/* 166 */     this.state = captureState();
/*     */ 
/* 168 */     for (int i = 0; i < this.matchers.length; i++) {
/* 169 */       this.matchers[i].reset(this.spare);
/* 170 */       this.currentGroup[i] = -1;
/*     */     }
/*     */ 
/* 173 */     if (this.preserveOriginal) {
/* 174 */       this.currentMatcher = 0;
/* 175 */     } else if (nextCapture()) {
/* 176 */       int start = this.matchers[this.currentMatcher].start(this.currentGroup[this.currentMatcher]);
/*     */ 
/* 178 */       int end = this.matchers[this.currentMatcher].end(this.currentGroup[this.currentMatcher]);
/*     */ 
/* 182 */       if (start == 0)
/* 183 */         this.charTermAttr.setLength(end);
/*     */       else {
/* 185 */         this.charTermAttr.copyBuffer(this.spare.chars, start, end - start);
/*     */       }
/* 187 */       this.currentGroup[this.currentMatcher] += 1;
/*     */     }
/* 189 */     return true;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 195 */     super.reset();
/* 196 */     this.state = null;
/* 197 */     this.currentMatcher = -1;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.pattern.PatternCaptureGroupTokenFilter
 * JD-Core Version:    0.6.2
 */