/*    */ package org.apache.lucene.analysis.pattern;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class PatternCaptureGroupFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   private Pattern pattern;
/* 40 */   private boolean preserveOriginal = true;
/*    */ 
/*    */   public PatternCaptureGroupFilterFactory(Map<String, String> args) {
/* 43 */     super(args);
/* 44 */     this.pattern = getPattern(args, "pattern");
/* 45 */     this.preserveOriginal = (args.containsKey("preserve_original") ? Boolean.parseBoolean((String)args.get("preserve_original")) : true);
/*    */   }
/*    */ 
/*    */   public PatternCaptureGroupTokenFilter create(TokenStream input) {
/* 49 */     return new PatternCaptureGroupTokenFilter(input, this.preserveOriginal, new Pattern[] { this.pattern });
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.pattern.PatternCaptureGroupFilterFactory
 * JD-Core Version:    0.6.2
 */