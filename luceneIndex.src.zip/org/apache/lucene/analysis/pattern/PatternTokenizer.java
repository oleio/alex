/*     */ package org.apache.lucene.analysis.pattern;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ public final class PatternTokenizer extends Tokenizer
/*     */ {
/*  57 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  58 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */ 
/*  60 */   private final StringBuilder str = new StringBuilder();
/*     */   private int index;
/*     */   private final int group;
/*     */   private final Matcher matcher;
/* 149 */   final char[] buffer = new char[8192];
/*     */ 
/*     */   public PatternTokenizer(Reader input, Pattern pattern, int group)
/*     */   {
/*  68 */     this(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY, input, pattern, group);
/*     */   }
/*     */ 
/*     */   public PatternTokenizer(AttributeSource.AttributeFactory factory, Reader input, Pattern pattern, int group)
/*     */   {
/*  73 */     super(factory, input);
/*  74 */     this.group = group;
/*     */ 
/*  78 */     this.matcher = pattern.matcher("");
/*     */ 
/*  81 */     if ((group >= 0) && (group > this.matcher.groupCount()))
/*  82 */       throw new IllegalArgumentException("invalid group specified: pattern only has: " + this.matcher.groupCount() + " capturing groups");
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */   {
/*  88 */     if (this.index >= this.str.length()) return false;
/*  89 */     clearAttributes();
/*  90 */     if (this.group >= 0)
/*     */     {
/*  93 */       while (this.matcher.find()) {
/*  94 */         this.index = this.matcher.start(this.group);
/*  95 */         int endIndex = this.matcher.end(this.group);
/*  96 */         if (this.index != endIndex) {
/*  97 */           this.termAtt.setEmpty().append(this.str, this.index, endIndex);
/*  98 */           this.offsetAtt.setOffset(correctOffset(this.index), correctOffset(endIndex));
/*  99 */           return true;
/*     */         }
/*     */       }
/* 102 */       this.index = 2147483647;
/* 103 */       return false;
/*     */     }
/*     */ 
/* 108 */     while (this.matcher.find()) {
/* 109 */       if (this.matcher.start() - this.index > 0)
/*     */       {
/* 111 */         this.termAtt.setEmpty().append(this.str, this.index, this.matcher.start());
/* 112 */         this.offsetAtt.setOffset(correctOffset(this.index), correctOffset(this.matcher.start()));
/* 113 */         this.index = this.matcher.end();
/* 114 */         return true;
/*     */       }
/*     */ 
/* 117 */       this.index = this.matcher.end();
/*     */     }
/*     */ 
/* 120 */     if (this.str.length() - this.index == 0) {
/* 121 */       this.index = 2147483647;
/* 122 */       return false;
/*     */     }
/*     */ 
/* 125 */     this.termAtt.setEmpty().append(this.str, this.index, this.str.length());
/* 126 */     this.offsetAtt.setOffset(correctOffset(this.index), correctOffset(this.str.length()));
/* 127 */     this.index = 2147483647;
/* 128 */     return true;
/*     */   }
/*     */ 
/*     */   public void end()
/*     */     throws IOException
/*     */   {
/* 134 */     super.end();
/* 135 */     int ofs = correctOffset(this.str.length());
/* 136 */     this.offsetAtt.setOffset(ofs, ofs);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 141 */     super.reset();
/* 142 */     fillBuffer(this.str, this.input);
/* 143 */     this.matcher.reset(this.str);
/* 144 */     this.index = 0;
/*     */   }
/*     */ 
/*     */   private void fillBuffer(StringBuilder sb, Reader input)
/*     */     throws IOException
/*     */   {
/* 152 */     sb.setLength(0);
/*     */     int len;
/* 153 */     while ((len = input.read(this.buffer)) > 0)
/* 154 */       sb.append(this.buffer, 0, len);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.pattern.PatternTokenizer
 * JD-Core Version:    0.6.2
 */