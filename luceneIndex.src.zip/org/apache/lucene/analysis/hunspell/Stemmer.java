/*     */ package org.apache.lucene.analysis.hunspell;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.store.ByteArrayDataInput;
/*     */ import org.apache.lucene.util.ArrayUtil;
/*     */ import org.apache.lucene.util.BytesRef;
/*     */ import org.apache.lucene.util.BytesRefHash;
/*     */ import org.apache.lucene.util.CharsRef;
/*     */ import org.apache.lucene.util.IntsRef;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.apache.lucene.util.automaton.CharacterRunAutomaton;
/*     */ 
/*     */ final class Stemmer
/*     */ {
/*     */   private final Dictionary dictionary;
/*  41 */   private final BytesRef scratch = new BytesRef();
/*  42 */   private final StringBuilder segment = new StringBuilder();
/*     */   private final ByteArrayDataInput affixReader;
/*  46 */   private final StringBuilder scratchSegment = new StringBuilder();
/*  47 */   private char[] scratchBuffer = new char[32];
/*     */ 
/*     */   public Stemmer(Dictionary dictionary)
/*     */   {
/*  55 */     this.dictionary = dictionary;
/*  56 */     this.affixReader = new ByteArrayDataInput(dictionary.affixData);
/*     */   }
/*     */ 
/*     */   public List<CharsRef> stem(String word)
/*     */   {
/*  66 */     return stem(word.toCharArray(), word.length());
/*     */   }
/*     */ 
/*     */   public List<CharsRef> stem(char[] word, int length)
/*     */   {
/*  77 */     if (this.dictionary.needsInputCleaning) {
/*  78 */       this.scratchSegment.setLength(0);
/*  79 */       this.scratchSegment.append(word, 0, length);
/*  80 */       CharSequence cleaned = this.dictionary.cleanInput(this.scratchSegment, this.segment);
/*  81 */       this.scratchBuffer = ArrayUtil.grow(this.scratchBuffer, cleaned.length());
/*  82 */       length = this.segment.length();
/*  83 */       this.segment.getChars(0, length, this.scratchBuffer, 0);
/*  84 */       word = this.scratchBuffer;
/*     */     }
/*     */ 
/*  87 */     List stems = new ArrayList();
/*  88 */     IntsRef forms = this.dictionary.lookupWord(word, 0, length);
/*  89 */     if (forms != null)
/*     */     {
/*  92 */       for (int i = 0; i < forms.length; i++) {
/*  93 */         stems.add(newStem(word, length));
/*     */       }
/*     */     }
/*  96 */     stems.addAll(stem(word, length, -1, -1, -1, 0, true, true, false, false));
/*  97 */     return stems;
/*     */   }
/*     */ 
/*     */   public List<CharsRef> uniqueStems(char[] word, int length)
/*     */   {
/* 107 */     List stems = stem(word, length);
/* 108 */     if (stems.size() < 2) {
/* 109 */       return stems;
/*     */     }
/* 111 */     CharArraySet terms = new CharArraySet(Version.LUCENE_CURRENT, 8, this.dictionary.ignoreCase);
/* 112 */     List deduped = new ArrayList();
/* 113 */     for (CharsRef s : stems) {
/* 114 */       if (!terms.contains(s)) {
/* 115 */         deduped.add(s);
/* 116 */         terms.add(s);
/*     */       }
/*     */     }
/* 119 */     return deduped;
/*     */   }
/*     */ 
/*     */   private CharsRef newStem(char[] buffer, int length) {
/* 123 */     if (this.dictionary.needsOutputCleaning) {
/* 124 */       this.scratchSegment.setLength(0);
/* 125 */       this.scratchSegment.append(buffer, 0, length);
/*     */       try {
/* 127 */         Dictionary.applyMappings(this.dictionary.oconv, this.scratchSegment);
/*     */       } catch (IOException bogus) {
/* 129 */         throw new RuntimeException(bogus);
/*     */       }
/* 131 */       char[] cleaned = new char[this.scratchSegment.length()];
/* 132 */       this.scratchSegment.getChars(0, cleaned.length, cleaned, 0);
/* 133 */       return new CharsRef(cleaned, 0, cleaned.length);
/*     */     }
/* 135 */     return new CharsRef(buffer, 0, length);
/*     */   }
/*     */ 
/*     */   private List<CharsRef> stem(char[] word, int length, int previous, int prevFlag, int prefixFlag, int recursionDepth, boolean doPrefix, boolean doSuffix, boolean previousWasPrefix, boolean circumfix)
/*     */   {
/* 161 */     List stems = new ArrayList();
/*     */ 
/* 163 */     if ((doPrefix) && (this.dictionary.prefixes != null))
/* 164 */       for (int i = length - 1; i >= 0; i--) {
/* 165 */         IntsRef prefixes = this.dictionary.lookupPrefix(word, 0, i);
/* 166 */         if (prefixes != null)
/*     */         {
/* 170 */           for (int j = 0; j < prefixes.length; j++) {
/* 171 */             int prefix = prefixes.ints[(prefixes.offset + j)];
/* 172 */             if (prefix != previous)
/*     */             {
/* 175 */               this.affixReader.setPosition(8 * prefix);
/* 176 */               char flag = (char)(this.affixReader.readShort() & 0xFFFF);
/* 177 */               char stripOrd = (char)(this.affixReader.readShort() & 0xFFFF);
/* 178 */               int condition = (char)(this.affixReader.readShort() & 0xFFFF);
/* 179 */               boolean crossProduct = (condition & 0x1) == 1;
/* 180 */               condition >>>= 1;
/* 181 */               char append = (char)(this.affixReader.readShort() & 0xFFFF);
/*     */               boolean compatible;
/*     */               boolean compatible;
/* 184 */               if (recursionDepth == 0) {
/* 185 */                 compatible = true;
/*     */               }
/*     */               else
/*     */               {
/*     */                 boolean compatible;
/* 186 */                 if (crossProduct)
/*     */                 {
/* 188 */                   this.dictionary.flagLookup.get(append, this.scratch);
/* 189 */                   char[] appendFlags = Dictionary.decodeFlags(this.scratch);
/* 190 */                   assert (prevFlag >= 0);
/* 191 */                   compatible = hasCrossCheckedFlag((char)prevFlag, appendFlags, false);
/*     */                 } else {
/* 193 */                   compatible = false;
/*     */                 }
/*     */               }
/* 196 */               if (compatible) {
/* 197 */                 int deAffixedStart = i;
/* 198 */                 int deAffixedLength = length - deAffixedStart;
/*     */ 
/* 200 */                 int stripStart = this.dictionary.stripOffsets[stripOrd];
/* 201 */                 int stripEnd = this.dictionary.stripOffsets[(stripOrd + '\001')];
/* 202 */                 int stripLength = stripEnd - stripStart;
/*     */ 
/* 204 */                 if (checkCondition(condition, this.dictionary.stripData, stripStart, stripLength, word, deAffixedStart, deAffixedLength))
/*     */                 {
/* 208 */                   char[] strippedWord = new char[stripLength + deAffixedLength];
/* 209 */                   System.arraycopy(this.dictionary.stripData, stripStart, strippedWord, 0, stripLength);
/* 210 */                   System.arraycopy(word, deAffixedStart, strippedWord, stripLength, deAffixedLength);
/*     */ 
/* 212 */                   List stemList = applyAffix(strippedWord, strippedWord.length, prefix, -1, recursionDepth, true, circumfix);
/*     */ 
/* 214 */                   stems.addAll(stemList);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 220 */     if ((doSuffix) && (this.dictionary.suffixes != null))
/* 221 */       for (int i = 0; i < length; i++) {
/* 222 */         IntsRef suffixes = this.dictionary.lookupSuffix(word, i, length - i);
/* 223 */         if (suffixes != null)
/*     */         {
/* 227 */           for (int j = 0; j < suffixes.length; j++) {
/* 228 */             int suffix = suffixes.ints[(suffixes.offset + j)];
/* 229 */             if (suffix != previous)
/*     */             {
/* 232 */               this.affixReader.setPosition(8 * suffix);
/* 233 */               char flag = (char)(this.affixReader.readShort() & 0xFFFF);
/* 234 */               char stripOrd = (char)(this.affixReader.readShort() & 0xFFFF);
/* 235 */               int condition = (char)(this.affixReader.readShort() & 0xFFFF);
/* 236 */               boolean crossProduct = (condition & 0x1) == 1;
/* 237 */               condition >>>= 1;
/* 238 */               char append = (char)(this.affixReader.readShort() & 0xFFFF);
/*     */               boolean compatible;
/*     */               boolean compatible;
/* 241 */               if (recursionDepth == 0) {
/* 242 */                 compatible = true;
/*     */               }
/*     */               else
/*     */               {
/*     */                 boolean compatible;
/* 243 */                 if (crossProduct)
/*     */                 {
/* 245 */                   this.dictionary.flagLookup.get(append, this.scratch);
/* 246 */                   char[] appendFlags = Dictionary.decodeFlags(this.scratch);
/* 247 */                   assert (prevFlag >= 0);
/* 248 */                   compatible = hasCrossCheckedFlag((char)prevFlag, appendFlags, previousWasPrefix);
/*     */                 } else {
/* 250 */                   compatible = false;
/*     */                 }
/*     */               }
/* 253 */               if (compatible) {
/* 254 */                 int appendLength = length - i;
/* 255 */                 int deAffixedLength = length - appendLength;
/*     */ 
/* 257 */                 int stripStart = this.dictionary.stripOffsets[stripOrd];
/* 258 */                 int stripEnd = this.dictionary.stripOffsets[(stripOrd + '\001')];
/* 259 */                 int stripLength = stripEnd - stripStart;
/*     */ 
/* 261 */                 if (checkCondition(condition, word, 0, deAffixedLength, this.dictionary.stripData, stripStart, stripLength))
/*     */                 {
/* 265 */                   char[] strippedWord = new char[stripLength + deAffixedLength];
/* 266 */                   System.arraycopy(word, 0, strippedWord, 0, deAffixedLength);
/* 267 */                   System.arraycopy(this.dictionary.stripData, stripStart, strippedWord, deAffixedLength, stripLength);
/*     */ 
/* 269 */                   List stemList = applyAffix(strippedWord, strippedWord.length, suffix, prefixFlag, recursionDepth, false, circumfix);
/*     */ 
/* 271 */                   stems.addAll(stemList);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 277 */     return stems;
/*     */   }
/*     */ 
/*     */   private boolean checkCondition(int condition, char[] c1, int c1off, int c1len, char[] c2, int c2off, int c2len)
/*     */   {
/* 284 */     if (condition != 0) {
/* 285 */       CharacterRunAutomaton pattern = (CharacterRunAutomaton)this.dictionary.patterns.get(condition);
/* 286 */       int state = pattern.getInitialState();
/* 287 */       for (int i = c1off; i < c1off + c1len; i++) {
/* 288 */         state = pattern.step(state, c1[i]);
/* 289 */         if (state == -1) {
/* 290 */           return false;
/*     */         }
/*     */       }
/* 293 */       for (int i = c2off; i < c2off + c2len; i++) {
/* 294 */         state = pattern.step(state, c2[i]);
/* 295 */         if (state == -1) {
/* 296 */           return false;
/*     */         }
/*     */       }
/* 299 */       return pattern.isAccept(state);
/*     */     }
/* 301 */     return true;
/*     */   }
/*     */ 
/*     */   List<CharsRef> applyAffix(char[] strippedWord, int length, int affix, int prefixFlag, int recursionDepth, boolean prefix, boolean circumfix)
/*     */   {
/* 318 */     this.affixReader.setPosition(8 * affix);
/* 319 */     char flag = (char)(this.affixReader.readShort() & 0xFFFF);
/* 320 */     this.affixReader.skipBytes(2L);
/* 321 */     int condition = (char)(this.affixReader.readShort() & 0xFFFF);
/* 322 */     boolean crossProduct = (condition & 0x1) == 1;
/* 323 */     condition >>>= 1;
/* 324 */     char append = (char)(this.affixReader.readShort() & 0xFFFF);
/*     */ 
/* 326 */     List stems = new ArrayList();
/*     */ 
/* 328 */     IntsRef forms = this.dictionary.lookupWord(strippedWord, 0, length);
/* 329 */     if (forms != null) {
/* 330 */       for (int i = 0; i < forms.length; i++) {
/* 331 */         this.dictionary.flagLookup.get(forms.ints[(forms.offset + i)], this.scratch);
/* 332 */         char[] wordFlags = Dictionary.decodeFlags(this.scratch);
/* 333 */         if (Dictionary.hasFlag(wordFlags, flag))
/*     */         {
/* 336 */           boolean chainedPrefix = (this.dictionary.complexPrefixes) && (recursionDepth == 1) && (prefix);
/* 337 */           if ((!chainedPrefix) && (prefixFlag >= 0) && (!Dictionary.hasFlag(wordFlags, (char)prefixFlag)))
/*     */           {
/* 339 */             this.dictionary.flagLookup.get(append, this.scratch);
/* 340 */             char[] appendFlags = Dictionary.decodeFlags(this.scratch);
/* 341 */             if (!hasCrossCheckedFlag((char)prefixFlag, appendFlags, false));
/*     */           }
/* 348 */           else if (this.dictionary.circumfix != -1) { this.dictionary.flagLookup.get(append, this.scratch);
/* 350 */             char[] appendFlags = Dictionary.decodeFlags(this.scratch);
/* 351 */             boolean suffixCircumfix = Dictionary.hasFlag(appendFlags, (char)this.dictionary.circumfix);
/* 352 */             if (circumfix != suffixCircumfix);
/*     */           } else {
/* 356 */             stems.add(newStem(strippedWord, length));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 362 */     if ((this.dictionary.circumfix != -1) && (!circumfix) && (prefix)) {
/* 363 */       this.dictionary.flagLookup.get(append, this.scratch);
/* 364 */       char[] appendFlags = Dictionary.decodeFlags(this.scratch);
/* 365 */       circumfix = Dictionary.hasFlag(appendFlags, (char)this.dictionary.circumfix);
/*     */     }
/*     */ 
/* 368 */     if (crossProduct) {
/* 369 */       if (recursionDepth == 0) {
/* 370 */         if (prefix)
/*     */         {
/* 374 */           stems.addAll(stem(strippedWord, length, affix, flag, flag, ++recursionDepth, (this.dictionary.complexPrefixes) && (this.dictionary.twoStageAffix), true, true, circumfix));
/* 375 */         } else if ((!this.dictionary.complexPrefixes) && (this.dictionary.twoStageAffix))
/*     */         {
/* 379 */           stems.addAll(stem(strippedWord, length, affix, flag, prefixFlag, ++recursionDepth, false, true, false, circumfix));
/*     */         }
/* 381 */       } else if (recursionDepth == 1) {
/* 382 */         if ((prefix) && (this.dictionary.complexPrefixes))
/*     */         {
/* 384 */           stems.addAll(stem(strippedWord, length, affix, flag, flag, ++recursionDepth, false, true, true, circumfix));
/* 385 */         } else if ((!prefix) && (!this.dictionary.complexPrefixes) && (this.dictionary.twoStageAffix))
/*     */         {
/* 387 */           stems.addAll(stem(strippedWord, length, affix, flag, prefixFlag, ++recursionDepth, false, true, false, circumfix));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 392 */     return stems;
/*     */   }
/*     */ 
/*     */   private boolean hasCrossCheckedFlag(char flag, char[] flags, boolean matchEmpty)
/*     */   {
/* 403 */     return ((flags.length == 0) && (matchEmpty)) || (Arrays.binarySearch(flags, flag) >= 0);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.hunspell.Stemmer
 * JD-Core Version:    0.6.2
 */