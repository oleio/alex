/*     */ package org.apache.lucene.analysis.hunspell;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.text.ParseException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.util.ResourceLoader;
/*     */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*     */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ 
/*     */ public class HunspellStemFilterFactory extends TokenFilterFactory
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   private static final String PARAM_DICTIONARY = "dictionary";
/*     */   private static final String PARAM_AFFIX = "affix";
/*     */   private static final String PARAM_RECURSION_CAP = "recursionCap";
/*     */   private static final String PARAM_IGNORE_CASE = "ignoreCase";
/*     */   private static final String PARAM_LONGEST_ONLY = "longestOnly";
/*     */   private final String dictionaryFiles;
/*     */   private final String affixFile;
/*     */   private final boolean ignoreCase;
/*     */   private final boolean longestOnly;
/*     */   private Dictionary dictionary;
/*     */ 
/*     */   public HunspellStemFilterFactory(Map<String, String> args)
/*     */   {
/*  63 */     super(args);
/*  64 */     this.dictionaryFiles = require(args, "dictionary");
/*  65 */     this.affixFile = get(args, "affix");
/*  66 */     this.ignoreCase = getBoolean(args, "ignoreCase", false);
/*  67 */     this.longestOnly = getBoolean(args, "longestOnly", false);
/*     */ 
/*  70 */     getBoolean(args, "strictAffixParsing", true);
/*     */ 
/*  74 */     getInt(args, "recursionCap", 0);
/*  75 */     if (!args.isEmpty())
/*  76 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*     */   }
/*     */ 
/*     */   public void inform(ResourceLoader loader)
/*     */     throws IOException
/*     */   {
/*  82 */     String[] dicts = this.dictionaryFiles.split(",");
/*     */ 
/*  84 */     InputStream affix = null;
/*  85 */     List dictionaries = new ArrayList();
/*     */     try
/*     */     {
/*  88 */       dictionaries = new ArrayList();
/*  89 */       for (String file : dicts) {
/*  90 */         dictionaries.add(loader.openResource(file));
/*     */       }
/*  92 */       affix = loader.openResource(this.affixFile);
/*     */ 
/*  94 */       this.dictionary = new Dictionary(affix, dictionaries, this.ignoreCase);
/*     */     } catch (ParseException e) {
/*  96 */       throw new IOException("Unable to load hunspell data! [dictionary=" + dictionaries + ",affix=" + this.affixFile + "]", e);
/*     */     } finally {
/*  98 */       IOUtils.closeWhileHandlingException(new Closeable[] { affix });
/*  99 */       IOUtils.closeWhileHandlingException(dictionaries);
/*     */     }
/*     */   }
/*     */ 
/*     */   public TokenStream create(TokenStream tokenStream)
/*     */   {
/* 105 */     return new HunspellStemFilter(tokenStream, this.dictionary, true, this.longestOnly);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.hunspell.HunspellStemFilterFactory
 * JD-Core Version:    0.6.2
 */