/*     */ package org.apache.lucene.analysis.charfilter;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.util.Arrays;
/*     */ import org.apache.lucene.analysis.CharFilter;
/*     */ import org.apache.lucene.util.ArrayUtil;
/*     */ 
/*     */ public abstract class BaseCharFilter extends CharFilter
/*     */ {
/*     */   private int[] offsets;
/*     */   private int[] diffs;
/*  36 */   private int size = 0;
/*     */ 
/*     */   public BaseCharFilter(Reader in) {
/*  39 */     super(in);
/*     */   }
/*     */ 
/*     */   protected int correct(int currentOff)
/*     */   {
/*  45 */     if ((this.offsets == null) || (currentOff < this.offsets[0])) {
/*  46 */       return currentOff;
/*     */     }
/*     */ 
/*  49 */     int hi = this.size - 1;
/*  50 */     if (currentOff >= this.offsets[hi]) {
/*  51 */       return currentOff + this.diffs[hi];
/*     */     }
/*  53 */     int lo = 0;
/*  54 */     int mid = -1;
/*     */ 
/*  56 */     while (hi >= lo) {
/*  57 */       mid = lo + hi >>> 1;
/*  58 */       if (currentOff < this.offsets[mid])
/*  59 */         hi = mid - 1;
/*  60 */       else if (currentOff > this.offsets[mid])
/*  61 */         lo = mid + 1;
/*     */       else {
/*  63 */         return currentOff + this.diffs[mid];
/*     */       }
/*     */     }
/*  66 */     if (currentOff < this.offsets[mid]) {
/*  67 */       return mid == 0 ? currentOff : currentOff + this.diffs[(mid - 1)];
/*     */     }
/*  69 */     return currentOff + this.diffs[mid];
/*     */   }
/*     */ 
/*     */   protected int getLastCumulativeDiff() {
/*  73 */     return this.offsets == null ? 0 : this.diffs[(this.size - 1)];
/*     */   }
/*     */ 
/*     */   protected void addOffCorrectMap(int off, int cumulativeDiff)
/*     */   {
/*  91 */     if (this.offsets == null) {
/*  92 */       this.offsets = new int[64];
/*  93 */       this.diffs = new int[64];
/*  94 */     } else if (this.size == this.offsets.length) {
/*  95 */       this.offsets = ArrayUtil.grow(this.offsets);
/*  96 */       this.diffs = ArrayUtil.grow(this.diffs);
/*     */     }
/*     */ 
/* 100 */     assert ((this.size == 0) || (off >= this.offsets[(this.size - 1)])) : ("Offset #" + this.size + "(" + off + ") is less than the last recorded offset " + this.offsets[(this.size - 1)] + "\n" + Arrays.toString(this.offsets) + "\n" + Arrays.toString(this.diffs));
/*     */ 
/* 103 */     if ((this.size == 0) || (off != this.offsets[(this.size - 1)])) {
/* 104 */       this.offsets[this.size] = off;
/* 105 */       this.diffs[(this.size++)] = cumulativeDiff;
/*     */     } else {
/* 107 */       this.diffs[(this.size - 1)] = cumulativeDiff;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.charfilter.BaseCharFilter
 * JD-Core Version:    0.6.2
 */