/*     */ package org.apache.lucene.analysis.charfilter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.Map;
/*     */ import org.apache.lucene.analysis.util.RollingCharBuffer;
/*     */ import org.apache.lucene.util.CharsRef;
/*     */ import org.apache.lucene.util.fst.CharSequenceOutputs;
/*     */ import org.apache.lucene.util.fst.FST;
/*     */ import org.apache.lucene.util.fst.FST.Arc;
/*     */ import org.apache.lucene.util.fst.FST.BytesReader;
/*     */ import org.apache.lucene.util.fst.Outputs;
/*     */ 
/*     */ public class MappingCharFilter extends BaseCharFilter
/*     */ {
/*  42 */   private final Outputs<CharsRef> outputs = CharSequenceOutputs.getSingleton();
/*     */   private final FST<CharsRef> map;
/*     */   private final FST.BytesReader fstReader;
/*  45 */   private final RollingCharBuffer buffer = new RollingCharBuffer();
/*  46 */   private final FST.Arc<CharsRef> scratchArc = new FST.Arc();
/*     */   private final Map<Character, FST.Arc<CharsRef>> cachedRootArcs;
/*     */   private CharsRef replacement;
/*     */   private int replacementPointer;
/*     */   private int inputOff;
/*     */ 
/*     */   public MappingCharFilter(NormalizeCharMap normMap, Reader in)
/*     */   {
/*  55 */     super(in);
/*  56 */     this.buffer.reset(in);
/*     */ 
/*  58 */     this.map = normMap.map;
/*  59 */     this.cachedRootArcs = normMap.cachedRootArcs;
/*     */ 
/*  61 */     if (this.map != null)
/*  62 */       this.fstReader = this.map.getBytesReader();
/*     */     else
/*  64 */       this.fstReader = null;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/*  70 */     this.input.reset();
/*  71 */     this.buffer.reset(this.input);
/*  72 */     this.replacement = null;
/*  73 */     this.inputOff = 0;
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*     */     while (true)
/*     */     {
/*  82 */       if ((this.replacement != null) && (this.replacementPointer < this.replacement.length))
/*     */       {
/*  84 */         return this.replacement.chars[(this.replacement.offset + this.replacementPointer++)];
/*     */       }
/*     */ 
/*  99 */       int lastMatchLen = -1;
/* 100 */       CharsRef lastMatch = null;
/*     */ 
/* 102 */       int firstCH = this.buffer.get(this.inputOff);
/* 103 */       if (firstCH != -1) {
/* 104 */         FST.Arc arc = (FST.Arc)this.cachedRootArcs.get(Character.valueOf((char)firstCH));
/* 105 */         if (arc != null) {
/* 106 */           if (!FST.targetHasArcs(arc))
/*     */           {
/* 108 */             assert (arc.isFinal());
/* 109 */             lastMatchLen = 1;
/* 110 */             lastMatch = (CharsRef)arc.output;
/*     */           } else {
/* 112 */             int lookahead = 0;
/* 113 */             CharsRef output = (CharsRef)arc.output;
/*     */             while (true) {
/* 115 */               lookahead++;
/*     */ 
/* 117 */               if (arc.isFinal())
/*     */               {
/* 119 */                 lastMatchLen = lookahead;
/* 120 */                 lastMatch = (CharsRef)this.outputs.add(output, arc.nextFinalOutput);
/*     */               }
/*     */ 
/* 125 */               if (!FST.targetHasArcs(arc))
/*     */               {
/*     */                 break;
/*     */               }
/* 129 */               int ch = this.buffer.get(this.inputOff + lookahead);
/* 130 */               if (ch == -1) {
/*     */                 break;
/*     */               }
/* 133 */               if ((arc = this.map.findTargetArc(ch, arc, this.scratchArc, this.fstReader)) == null)
/*     */               {
/*     */                 break;
/*     */               }
/* 137 */               output = (CharsRef)this.outputs.add(output, arc.output);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 143 */       if (lastMatch != null) {
/* 144 */         this.inputOff += lastMatchLen;
/*     */ 
/* 147 */         int diff = lastMatchLen - lastMatch.length;
/*     */ 
/* 149 */         if (diff != 0) {
/* 150 */           int prevCumulativeDiff = getLastCumulativeDiff();
/* 151 */           if (diff > 0)
/*     */           {
/* 153 */             addOffCorrectMap(this.inputOff - diff - prevCumulativeDiff, prevCumulativeDiff + diff);
/*     */           }
/*     */           else
/*     */           {
/* 158 */             int outputStart = this.inputOff - prevCumulativeDiff;
/* 159 */             for (int extraIDX = 0; extraIDX < -diff; extraIDX++) {
/* 160 */               addOffCorrectMap(outputStart + extraIDX, prevCumulativeDiff - extraIDX - 1);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 165 */         this.replacement = lastMatch;
/* 166 */         this.replacementPointer = 0;
/*     */       }
/*     */       else {
/* 169 */         int ret = this.buffer.get(this.inputOff);
/* 170 */         if (ret != -1) {
/* 171 */           this.inputOff += 1;
/* 172 */           this.buffer.freeBefore(this.inputOff);
/*     */         }
/* 174 */         return ret;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int read(char[] cbuf, int off, int len) throws IOException
/*     */   {
/* 181 */     int numRead = 0;
/* 182 */     for (int i = off; i < off + len; i++) {
/* 183 */       int c = read();
/* 184 */       if (c == -1) break;
/* 185 */       cbuf[i] = ((char)c);
/* 186 */       numRead++;
/*     */     }
/*     */ 
/* 189 */     return numRead == 0 ? -1 : numRead;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.charfilter.MappingCharFilter
 * JD-Core Version:    0.6.2
 */