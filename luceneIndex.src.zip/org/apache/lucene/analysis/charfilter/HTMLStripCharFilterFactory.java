/*    */ package org.apache.lucene.analysis.charfilter;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.lucene.analysis.util.CharFilterFactory;
/*    */ 
/*    */ public class HTMLStripCharFilterFactory extends CharFilterFactory
/*    */ {
/*    */   final Set<String> escapedTags;
/* 39 */   static final Pattern TAG_NAME_PATTERN = Pattern.compile("[^\\s,]+");
/*    */ 
/*    */   public HTMLStripCharFilterFactory(Map<String, String> args)
/*    */   {
/* 43 */     super(args);
/* 44 */     this.escapedTags = getSet(args, "escapedTags");
/* 45 */     if (!args.isEmpty())
/* 46 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public HTMLStripCharFilter create(Reader input)
/*    */   {
/*    */     HTMLStripCharFilter charFilter;
/*    */     HTMLStripCharFilter charFilter;
/* 53 */     if (null == this.escapedTags)
/* 54 */       charFilter = new HTMLStripCharFilter(input);
/*    */     else {
/* 56 */       charFilter = new HTMLStripCharFilter(input, this.escapedTags);
/*    */     }
/* 58 */     return charFilter;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.charfilter.HTMLStripCharFilterFactory
 * JD-Core Version:    0.6.2
 */