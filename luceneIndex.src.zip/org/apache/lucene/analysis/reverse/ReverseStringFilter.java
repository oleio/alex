/*     */ package org.apache.lucene.analysis.reverse;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class ReverseStringFilter extends TokenFilter
/*     */ {
/*  45 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */   private final char marker;
/*     */   private final Version matchVersion;
/*     */   private static final char NOMARKER = '￿';
/*     */   public static final char START_OF_HEADING_MARKER = '\001';
/*     */   public static final char INFORMATION_SEPARATOR_MARKER = '\037';
/*     */   public static final char PUA_EC00_MARKER = '';
/*     */   public static final char RTL_DIRECTION_MARKER = '‏';
/*     */ 
/*     */   public ReverseStringFilter(Version matchVersion, TokenStream in)
/*     */   {
/*  81 */     this(matchVersion, in, 65535);
/*     */   }
/*     */ 
/*     */   public ReverseStringFilter(Version matchVersion, TokenStream in, char marker)
/*     */   {
/*  97 */     super(in);
/*  98 */     this.matchVersion = matchVersion;
/*  99 */     this.marker = marker;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/* 104 */     if (this.input.incrementToken()) {
/* 105 */       int len = this.termAtt.length();
/* 106 */       if (this.marker != 65535) {
/* 107 */         len++;
/* 108 */         this.termAtt.resizeBuffer(len);
/* 109 */         this.termAtt.buffer()[(len - 1)] = this.marker;
/*     */       }
/* 111 */       reverse(this.matchVersion, this.termAtt.buffer(), 0, len);
/* 112 */       this.termAtt.setLength(len);
/* 113 */       return true;
/*     */     }
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */   public static String reverse(Version matchVersion, String input)
/*     */   {
/* 127 */     char[] charInput = input.toCharArray();
/* 128 */     reverse(matchVersion, charInput, 0, charInput.length);
/* 129 */     return new String(charInput);
/*     */   }
/*     */ 
/*     */   public static void reverse(Version matchVersion, char[] buffer)
/*     */   {
/* 138 */     reverse(matchVersion, buffer, 0, buffer.length);
/*     */   }
/*     */ 
/*     */   public static void reverse(Version matchVersion, char[] buffer, int len)
/*     */   {
/* 151 */     reverse(matchVersion, buffer, 0, len);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   private static void reverseUnicode3(char[] buffer, int start, int len)
/*     */   {
/* 159 */     if (len <= 1) return;
/* 160 */     int num = len >> 1;
/* 161 */     for (int i = start; i < start + num; i++) {
/* 162 */       char c = buffer[i];
/* 163 */       buffer[i] = buffer[(start * 2 + len - i - 1)];
/* 164 */       buffer[(start * 2 + len - i - 1)] = c;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void reverse(Version matchVersion, char[] buffer, int start, int len)
/*     */   {
/* 179 */     if (!matchVersion.onOrAfter(Version.LUCENE_31)) {
/* 180 */       reverseUnicode3(buffer, start, len);
/* 181 */       return;
/*     */     }
/*     */ 
/* 184 */     if (len < 2)
/* 185 */       return;
/* 186 */     int end = start + len - 1;
/* 187 */     char frontHigh = buffer[start];
/* 188 */     char endLow = buffer[end];
/* 189 */     boolean allowFrontSur = true; boolean allowEndSur = true;
/* 190 */     int mid = start + (len >> 1);
/* 191 */     for (int i = start; i < mid; end--) {
/* 192 */       char frontLow = buffer[(i + 1)];
/* 193 */       char endHigh = buffer[(end - 1)];
/* 194 */       boolean surAtFront = (allowFrontSur) && (Character.isSurrogatePair(frontHigh, frontLow));
/*     */ 
/* 196 */       if ((surAtFront) && (len < 3))
/*     */       {
/* 198 */         return;
/*     */       }
/* 200 */       boolean surAtEnd = (allowEndSur) && (Character.isSurrogatePair(endHigh, endLow));
/*     */ 
/* 202 */       allowFrontSur = allowEndSur = 1;
/* 203 */       if (surAtFront == surAtEnd) {
/* 204 */         if (surAtFront)
/*     */         {
/* 206 */           buffer[end] = frontLow;
/* 207 */           buffer[(--end)] = frontHigh;
/* 208 */           buffer[i] = endHigh;
/* 209 */           buffer[(++i)] = endLow;
/* 210 */           frontHigh = buffer[(i + 1)];
/* 211 */           endLow = buffer[(end - 1)];
/*     */         }
/*     */         else {
/* 214 */           buffer[end] = frontHigh;
/* 215 */           buffer[i] = endLow;
/* 216 */           frontHigh = frontLow;
/* 217 */           endLow = endHigh;
/*     */         }
/*     */       }
/* 220 */       else if (surAtFront)
/*     */       {
/* 222 */         buffer[end] = frontLow;
/* 223 */         buffer[i] = endLow;
/* 224 */         endLow = endHigh;
/* 225 */         allowFrontSur = false;
/*     */       }
/*     */       else {
/* 228 */         buffer[end] = frontHigh;
/* 229 */         buffer[i] = endHigh;
/* 230 */         frontHigh = frontLow;
/* 231 */         allowEndSur = false;
/*     */       }
/* 191 */       i++;
/*     */     }
/*     */ 
/* 235 */     if (((len & 0x1) == 1) && ((!allowFrontSur) || (!allowEndSur)))
/*     */     {
/* 237 */       buffer[end] = (allowFrontSur ? endLow : frontHigh);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.reverse.ReverseStringFilter
 * JD-Core Version:    0.6.2
 */