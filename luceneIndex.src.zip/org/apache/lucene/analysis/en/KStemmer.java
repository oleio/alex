/*      */ package org.apache.lucene.analysis.en;
/*      */ 
/*      */ import org.apache.lucene.analysis.util.CharArrayMap;
/*      */ import org.apache.lucene.analysis.util.OpenStringBuilder;
/*      */ import org.apache.lucene.util.Version;
/*      */ 
/*      */ public class KStemmer
/*      */ {
/*      */   private static final int MaxWordLen = 50;
/*   75 */   private static final String[] exceptionWords = { "aide", "bathe", "caste", "cute", "dame", "dime", "doge", "done", "dune", "envelope", "gage", "grille", "grippe", "lobe", "mane", "mare", "nape", "node", "pane", "pate", "plane", "pope", "programme", "quite", "ripe", "rote", "rune", "sage", "severe", "shoppe", "sine", "slime", "snipe", "steppe", "suite", "swinge", "tare", "tine", "tope", "tripe", "twine" };
/*      */ 
/*   82 */   private static final String[][] directConflations = { { "aging", "age" }, { "going", "go" }, { "goes", "go" }, { "lying", "lie" }, { "using", "use" }, { "owing", "owe" }, { "suing", "sue" }, { "dying", "die" }, { "tying", "tie" }, { "vying", "vie" }, { "aged", "age" }, { "used", "use" }, { "vied", "vie" }, { "cued", "cue" }, { "died", "die" }, { "eyed", "eye" }, { "hued", "hue" }, { "iced", "ice" }, { "lied", "lie" }, { "owed", "owe" }, { "sued", "sue" }, { "toed", "toe" }, { "tied", "tie" }, { "does", "do" }, { "doing", "do" }, { "aeronautical", "aeronautics" }, { "mathematical", "mathematics" }, { "political", "politics" }, { "metaphysical", "metaphysics" }, { "cylindrical", "cylinder" }, { "nazism", "nazi" }, { "ambiguity", "ambiguous" }, { "barbarity", "barbarous" }, { "credulity", "credulous" }, { "generosity", "generous" }, { "spontaneity", "spontaneous" }, { "unanimity", "unanimous" }, { "voracity", "voracious" }, { "fled", "flee" }, { "miscarriage", "miscarry" } };
/*      */ 
/*   97 */   private static final String[][] countryNationality = { { "afghan", "afghanistan" }, { "african", "africa" }, { "albanian", "albania" }, { "algerian", "algeria" }, { "american", "america" }, { "andorran", "andorra" }, { "angolan", "angola" }, { "arabian", "arabia" }, { "argentine", "argentina" }, { "armenian", "armenia" }, { "asian", "asia" }, { "australian", "australia" }, { "austrian", "austria" }, { "azerbaijani", "azerbaijan" }, { "azeri", "azerbaijan" }, { "bangladeshi", "bangladesh" }, { "belgian", "belgium" }, { "bermudan", "bermuda" }, { "bolivian", "bolivia" }, { "bosnian", "bosnia" }, { "botswanan", "botswana" }, { "brazilian", "brazil" }, { "british", "britain" }, { "bulgarian", "bulgaria" }, { "burmese", "burma" }, { "californian", "california" }, { "cambodian", "cambodia" }, { "canadian", "canada" }, { "chadian", "chad" }, { "chilean", "chile" }, { "chinese", "china" }, { "colombian", "colombia" }, { "croat", "croatia" }, { "croatian", "croatia" }, { "cuban", "cuba" }, { "cypriot", "cyprus" }, { "czechoslovakian", "czechoslovakia" }, { "danish", "denmark" }, { "egyptian", "egypt" }, { "equadorian", "equador" }, { "eritrean", "eritrea" }, { "estonian", "estonia" }, { "ethiopian", "ethiopia" }, { "european", "europe" }, { "fijian", "fiji" }, { "filipino", "philippines" }, { "finnish", "finland" }, { "french", "france" }, { "gambian", "gambia" }, { "georgian", "georgia" }, { "german", "germany" }, { "ghanian", "ghana" }, { "greek", "greece" }, { "grenadan", "grenada" }, { "guamian", "guam" }, { "guatemalan", "guatemala" }, { "guinean", "guinea" }, { "guyanan", "guyana" }, { "haitian", "haiti" }, { "hawaiian", "hawaii" }, { "holland", "dutch" }, { "honduran", "honduras" }, { "hungarian", "hungary" }, { "icelandic", "iceland" }, { "indonesian", "indonesia" }, { "iranian", "iran" }, { "iraqi", "iraq" }, { "iraqui", "iraq" }, { "irish", "ireland" }, { "israeli", "israel" }, { "italian", "italy" }, { "jamaican", "jamaica" }, { "japanese", "japan" }, { "jordanian", "jordan" }, { "kampuchean", "cambodia" }, { "kenyan", "kenya" }, { "korean", "korea" }, { "kuwaiti", "kuwait" }, { "lankan", "lanka" }, { "laotian", "laos" }, { "latvian", "latvia" }, { "lebanese", "lebanon" }, { "liberian", "liberia" }, { "libyan", "libya" }, { "lithuanian", "lithuania" }, { "macedonian", "macedonia" }, { "madagascan", "madagascar" }, { "malaysian", "malaysia" }, { "maltese", "malta" }, { "mauritanian", "mauritania" }, { "mexican", "mexico" }, { "micronesian", "micronesia" }, { "moldovan", "moldova" }, { "monacan", "monaco" }, { "mongolian", "mongolia" }, { "montenegran", "montenegro" }, { "moroccan", "morocco" }, { "myanmar", "burma" }, { "namibian", "namibia" }, { "nepalese", "nepal" }, { "nicaraguan", "nicaragua" }, { "nigerian", "nigeria" }, { "norwegian", "norway" }, { "omani", "oman" }, { "pakistani", "pakistan" }, { "panamanian", "panama" }, { "papuan", "papua" }, { "paraguayan", "paraguay" }, { "peruvian", "peru" }, { "portuguese", "portugal" }, { "romanian", "romania" }, { "rumania", "romania" }, { "rumanian", "romania" }, { "russian", "russia" }, { "rwandan", "rwanda" }, { "samoan", "samoa" }, { "scottish", "scotland" }, { "serb", "serbia" }, { "serbian", "serbia" }, { "siam", "thailand" }, { "siamese", "thailand" }, { "slovakia", "slovak" }, { "slovakian", "slovak" }, { "slovenian", "slovenia" }, { "somali", "somalia" }, { "somalian", "somalia" }, { "spanish", "spain" }, { "swedish", "sweden" }, { "swiss", "switzerland" }, { "syrian", "syria" }, { "taiwanese", "taiwan" }, { "tanzanian", "tanzania" }, { "texan", "texas" }, { "thai", "thailand" }, { "tunisian", "tunisia" }, { "turkish", "turkey" }, { "ugandan", "uganda" }, { "ukrainian", "ukraine" }, { "uruguayan", "uruguay" }, { "uzbek", "uzbekistan" }, { "venezuelan", "venezuela" }, { "vietnamese", "viet" }, { "virginian", "virginia" }, { "yemeni", "yemen" }, { "yugoslav", "yugoslavia" }, { "yugoslavian", "yugoslavia" }, { "zambian", "zambia" }, { "zealander", "zealand" }, { "zimbabwean", "zimbabwe" } };
/*      */ 
/*  179 */   private static final String[] supplementDict = { "aids", "applicator", "capacitor", "digitize", "electromagnet", "ellipsoid", "exosphere", "extensible", "ferromagnet", "graphics", "hydromagnet", "polygraph", "toroid", "superconduct", "backscatter", "connectionism" };
/*      */ 
/*  184 */   private static final String[] properNouns = { "abrams", "achilles", "acropolis", "adams", "agnes", "aires", "alexander", "alexis", "alfred", "algiers", "alps", "amadeus", "ames", "amos", "andes", "angeles", "annapolis", "antilles", "aquarius", "archimedes", "arkansas", "asher", "ashly", "athens", "atkins", "atlantis", "avis", "bahamas", "bangor", "barbados", "barger", "bering", "brahms", "brandeis", "brussels", "bruxelles", "cairns", "camoros", "camus", "carlos", "celts", "chalker", "charles", "cheops", "ching", "christmas", "cocos", "collins", "columbus", "confucius", "conners", "connolly", "copernicus", "cramer", "cyclops", "cygnus", "cyprus", "dallas", "damascus", "daniels", "davies", "davis", "decker", "denning", "dennis", "descartes", "dickens", "doris", "douglas", "downs", "dreyfus", "dukakis", "dulles", "dumfries", "ecclesiastes", "edwards", "emily", "erasmus", "euphrates", "evans", "everglades", "fairbanks", "federales", "fisher", "fitzsimmons", "fleming", "forbes", "fowler", "france", "francis", "goering", "goodling", "goths", "grenadines", "guiness", "hades", "harding", "harris", "hastings", "hawkes", "hawking", "hayes", "heights", "hercules", "himalayas", "hippocrates", "hobbs", "holmes", "honduras", "hopkins", "hughes", "humphreys", "illinois", "indianapolis", "inverness", "iris", "iroquois", "irving", "isaacs", "italy", "james", "jarvis", "jeffreys", "jesus", "jones", "josephus", "judas", "julius", "kansas", "keynes", "kipling", "kiwanis", "lansing", "laos", "leeds", "levis", "leviticus", "lewis", "louis", "maccabees", "madras", "maimonides", "maldive", "massachusetts", "matthews", "mauritius", "memphis", "mercedes", "midas", "mingus", "minneapolis", "mohammed", "moines", "morris", "moses", "myers", "myknos", "nablus", "nanjing", "nantes", "naples", "neal", "netherlands", "nevis", "nostradamus", "oedipus", "olympus", "orleans", "orly", "papas", "paris", "parker", "pauling", "peking", "pershing", "peter", "peters", "philippines", "phineas", "pisces", "pryor", "pythagoras", "queens", "rabelais", "ramses", "reynolds", "rhesus", "rhodes", "richards", "robins", "rodgers", "rogers", "rubens", "sagittarius", "seychelles", "socrates", "texas", "thames", "thomas", "tiberias", "tunis", "venus", "vilnius", "wales", "warner", "wilkins", "williams", "wyoming", "xmas", "yonkers", "zeus", "frances", "aarhus", "adonis", "andrews", "angus", "antares", "aquinas", "arcturus", "ares", "artemis", "augustus", "ayers", "barnabas", "barnes", "becker", "bejing", "biggs", "billings", "boeing", "boris", "borroughs", "briggs", "buenos", "calais", "caracas", "cassius", "cerberus", "ceres", "cervantes", "chantilly", "chartres", "chester", "connally", "conner", "coors", "cummings", "curtis", "daedalus", "dionysus", "dobbs", "dolores", "edmonds" };
/*      */ 
/*  236 */   private static final CharArrayMap<DictEntry> dict_ht = initializeDictHash();
/*      */ 
/*  244 */   private final OpenStringBuilder word = new OpenStringBuilder();
/*      */   private int j;
/*      */   private int k;
/*  560 */   DictEntry matchedEntry = null;
/*      */ 
/*  994 */   private static char[] ization = "ization".toCharArray();
/*  995 */   private static char[] ition = "ition".toCharArray();
/*  996 */   private static char[] ation = "ation".toCharArray();
/*  997 */   private static char[] ication = "ication".toCharArray();
/*      */   String result;
/*      */ 
/*      */   private char finalChar()
/*      */   {
/*  258 */     return this.word.charAt(this.k);
/*      */   }
/*      */ 
/*      */   private char penultChar() {
/*  262 */     return this.word.charAt(this.k - 1);
/*      */   }
/*      */ 
/*      */   private boolean isVowel(int index) {
/*  266 */     return !isCons(index);
/*      */   }
/*      */ 
/*      */   private boolean isCons(int index)
/*      */   {
/*  272 */     char ch = this.word.charAt(index);
/*      */ 
/*  274 */     if ((ch == 'a') || (ch == 'e') || (ch == 'i') || (ch == 'o') || (ch == 'u')) return false;
/*  275 */     if ((ch != 'y') || (index == 0)) return true;
/*  276 */     return !isCons(index - 1);
/*      */   }
/*      */ 
/*      */   private static CharArrayMap<DictEntry> initializeDictHash()
/*      */   {
/*  283 */     CharArrayMap d = new CharArrayMap(Version.LUCENE_CURRENT, 1000, false);
/*      */     DictEntry entry;
/*  284 */     for (int i = 0; i < exceptionWords.length; i++)
/*  285 */       if (!d.containsKey(exceptionWords[i])) {
/*  286 */         DictEntry entry = new DictEntry(exceptionWords[i], true);
/*  287 */         d.put(exceptionWords[i], entry);
/*      */       } else {
/*  289 */         throw new RuntimeException("Warning: Entry [" + exceptionWords[i] + "] already in dictionary 1");
/*      */       }
/*      */     DictEntry entry;
/*  294 */     for (int i = 0; i < directConflations.length; i++)
/*  295 */       if (!d.containsKey(directConflations[i][0])) {
/*  296 */         DictEntry entry = new DictEntry(directConflations[i][1], false);
/*  297 */         d.put(directConflations[i][0], entry);
/*      */       } else {
/*  299 */         throw new RuntimeException("Warning: Entry [" + directConflations[i][0] + "] already in dictionary 2");
/*      */       }
/*      */     DictEntry entry;
/*  304 */     for (int i = 0; i < countryNationality.length; i++) {
/*  305 */       if (!d.containsKey(countryNationality[i][0])) {
/*  306 */         DictEntry entry = new DictEntry(countryNationality[i][1], false);
/*  307 */         d.put(countryNationality[i][0], entry);
/*      */       } else {
/*  309 */         throw new RuntimeException("Warning: Entry [" + countryNationality[i][0] + "] already in dictionary 3");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  314 */     DictEntry defaultEntry = new DictEntry(null, false);
/*      */ 
/*  317 */     String[] array = KStemData1.data;
/*      */ 
/*  319 */     for (int i = 0; i < array.length; i++) {
/*  320 */       if (!d.containsKey(array[i]))
/*  321 */         d.put(array[i], defaultEntry);
/*      */       else {
/*  323 */         throw new RuntimeException("Warning: Entry [" + array[i] + "] already in dictionary 4");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  328 */     array = KStemData2.data;
/*  329 */     for (int i = 0; i < array.length; i++) {
/*  330 */       if (!d.containsKey(array[i]))
/*  331 */         d.put(array[i], defaultEntry);
/*      */       else {
/*  333 */         throw new RuntimeException("Warning: Entry [" + array[i] + "] already in dictionary 4");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  338 */     array = KStemData3.data;
/*  339 */     for (int i = 0; i < array.length; i++) {
/*  340 */       if (!d.containsKey(array[i]))
/*  341 */         d.put(array[i], defaultEntry);
/*      */       else {
/*  343 */         throw new RuntimeException("Warning: Entry [" + array[i] + "] already in dictionary 4");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  348 */     array = KStemData4.data;
/*  349 */     for (int i = 0; i < array.length; i++) {
/*  350 */       if (!d.containsKey(array[i]))
/*  351 */         d.put(array[i], defaultEntry);
/*      */       else {
/*  353 */         throw new RuntimeException("Warning: Entry [" + array[i] + "] already in dictionary 4");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  358 */     array = KStemData5.data;
/*  359 */     for (int i = 0; i < array.length; i++) {
/*  360 */       if (!d.containsKey(array[i]))
/*  361 */         d.put(array[i], defaultEntry);
/*      */       else {
/*  363 */         throw new RuntimeException("Warning: Entry [" + array[i] + "] already in dictionary 4");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  368 */     array = KStemData6.data;
/*  369 */     for (int i = 0; i < array.length; i++) {
/*  370 */       if (!d.containsKey(array[i]))
/*  371 */         d.put(array[i], defaultEntry);
/*      */       else {
/*  373 */         throw new RuntimeException("Warning: Entry [" + array[i] + "] already in dictionary 4");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  378 */     array = KStemData7.data;
/*  379 */     for (int i = 0; i < array.length; i++) {
/*  380 */       if (!d.containsKey(array[i]))
/*  381 */         d.put(array[i], defaultEntry);
/*      */       else {
/*  383 */         throw new RuntimeException("Warning: Entry [" + array[i] + "] already in dictionary 4");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  388 */     for (int i = 0; i < KStemData8.data.length; i++) {
/*  389 */       if (!d.containsKey(KStemData8.data[i]))
/*  390 */         d.put(KStemData8.data[i], defaultEntry);
/*      */       else {
/*  392 */         throw new RuntimeException("Warning: Entry [" + KStemData8.data[i] + "] already in dictionary 4");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  397 */     for (int i = 0; i < supplementDict.length; i++) {
/*  398 */       if (!d.containsKey(supplementDict[i]))
/*  399 */         d.put(supplementDict[i], defaultEntry);
/*      */       else {
/*  401 */         throw new RuntimeException("Warning: Entry [" + supplementDict[i] + "] already in dictionary 5");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  406 */     for (int i = 0; i < properNouns.length; i++) {
/*  407 */       if (!d.containsKey(properNouns[i]))
/*  408 */         d.put(properNouns[i], defaultEntry);
/*      */       else {
/*  410 */         throw new RuntimeException("Warning: Entry [" + properNouns[i] + "] already in dictionary 6");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  415 */     return d;
/*      */   }
/*      */ 
/*      */   private boolean isAlpha(char ch) {
/*  419 */     return (ch >= 'a') && (ch <= 'z');
/*      */   }
/*      */ 
/*      */   private int stemLength()
/*      */   {
/*  424 */     return this.j + 1;
/*      */   }
/*      */ 
/*      */   private boolean endsIn(char[] s) {
/*  428 */     if (s.length > this.k) return false;
/*      */ 
/*  430 */     int r = this.word.length() - s.length;
/*  431 */     this.j = this.k;
/*  432 */     int r1 = r; for (int i = 0; i < s.length; r1++) {
/*  433 */       if (s[i] != this.word.charAt(r1)) return false;
/*  432 */       i++;
/*      */     }
/*      */ 
/*  435 */     this.j = (r - 1);
/*  436 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean endsIn(char a, char b) {
/*  440 */     if (2 > this.k) return false;
/*      */ 
/*  442 */     if ((this.word.charAt(this.k - 1) == a) && (this.word.charAt(this.k) == b)) {
/*  443 */       this.j = (this.k - 2);
/*  444 */       return true;
/*      */     }
/*  446 */     return false;
/*      */   }
/*      */ 
/*      */   private boolean endsIn(char a, char b, char c) {
/*  450 */     if (3 > this.k) return false;
/*  451 */     if ((this.word.charAt(this.k - 2) == a) && (this.word.charAt(this.k - 1) == b) && (this.word.charAt(this.k) == c))
/*      */     {
/*  453 */       this.j = (this.k - 3);
/*  454 */       return true;
/*      */     }
/*  456 */     return false;
/*      */   }
/*      */ 
/*      */   private boolean endsIn(char a, char b, char c, char d) {
/*  460 */     if (4 > this.k) return false;
/*  461 */     if ((this.word.charAt(this.k - 3) == a) && (this.word.charAt(this.k - 2) == b) && (this.word.charAt(this.k - 1) == c) && (this.word.charAt(this.k) == d))
/*      */     {
/*  463 */       this.j = (this.k - 4);
/*  464 */       return true;
/*      */     }
/*  466 */     return false;
/*      */   }
/*      */ 
/*      */   private DictEntry wordInDict()
/*      */   {
/*  476 */     if (this.matchedEntry != null) return this.matchedEntry;
/*  477 */     DictEntry e = (DictEntry)dict_ht.get(this.word.getArray(), 0, this.word.length());
/*  478 */     if ((e != null) && (!e.exception)) {
/*  479 */       this.matchedEntry = e;
/*      */     }
/*      */ 
/*  482 */     return e;
/*      */   }
/*      */ 
/*      */   private void plural()
/*      */   {
/*  487 */     if (this.word.charAt(this.k) == 's')
/*  488 */       if (endsIn('i', 'e', 's')) {
/*  489 */         this.word.setLength(this.j + 3);
/*  490 */         this.k -= 1;
/*  491 */         if (lookup())
/*  492 */           return;
/*  493 */         this.k += 1;
/*  494 */         this.word.unsafeWrite('s');
/*  495 */         setSuffix("y");
/*  496 */         lookup(); } else {
/*  497 */         if (endsIn('e', 's'))
/*      */         {
/*  499 */           this.word.setLength(this.j + 2);
/*  500 */           this.k -= 1;
/*      */ 
/*  515 */           boolean tryE = (this.j > 0) && ((this.word.charAt(this.j) != 's') || (this.word.charAt(this.j - 1) != 's'));
/*      */ 
/*  517 */           if ((tryE) && (lookup())) return;
/*      */ 
/*  521 */           this.word.setLength(this.j + 1);
/*  522 */           this.k -= 1;
/*  523 */           if (lookup()) return;
/*      */ 
/*  526 */           this.word.unsafeWrite('e');
/*  527 */           this.k += 1;
/*      */ 
/*  529 */           if (!tryE) lookup();
/*  530 */           return;
/*      */         }
/*  532 */         if ((this.word.length() > 3) && (penultChar() != 's') && (!endsIn('o', 'u', 's')))
/*      */         {
/*  535 */           this.word.setLength(this.k);
/*  536 */           this.k -= 1;
/*  537 */           lookup();
/*      */         }
/*      */       }
/*      */   }
/*      */ 
/*      */   private void setSuffix(String s)
/*      */   {
/*  544 */     setSuff(s, s.length());
/*      */   }
/*      */ 
/*      */   private void setSuff(String s, int len)
/*      */   {
/*  549 */     this.word.setLength(this.j + 1);
/*  550 */     for (int l = 0; l < len; l++) {
/*  551 */       this.word.unsafeWrite(s.charAt(l));
/*      */     }
/*  553 */     this.k = (this.j + len);
/*      */   }
/*      */ 
/*      */   private boolean lookup()
/*      */   {
/*  573 */     this.matchedEntry = ((DictEntry)dict_ht.get(this.word.getArray(), 0, this.word.size()));
/*  574 */     return this.matchedEntry != null;
/*      */   }
/*      */ 
/*      */   private void pastTense()
/*      */   {
/*  585 */     if (this.word.length() <= 4) return;
/*      */ 
/*  587 */     if (endsIn('i', 'e', 'd')) {
/*  588 */       this.word.setLength(this.j + 3);
/*  589 */       this.k -= 1;
/*  590 */       if (lookup())
/*  591 */         return;
/*  592 */       this.k += 1;
/*  593 */       this.word.unsafeWrite('d');
/*  594 */       setSuffix("y");
/*  595 */       lookup();
/*  596 */       return;
/*      */     }
/*      */ 
/*  600 */     if ((endsIn('e', 'd')) && (vowelInStem()))
/*      */     {
/*  602 */       this.word.setLength(this.j + 2);
/*  603 */       this.k = (this.j + 1);
/*      */ 
/*  605 */       DictEntry entry = wordInDict();
/*  606 */       if ((entry != null) && (!entry.exception))
/*      */       {
/*  610 */         return;
/*      */       }
/*      */ 
/*  613 */       this.word.setLength(this.j + 1);
/*  614 */       this.k = this.j;
/*  615 */       if (lookup()) return;
/*      */ 
/*  624 */       if (doubleC(this.k)) {
/*  625 */         this.word.setLength(this.k);
/*  626 */         this.k -= 1;
/*  627 */         if (lookup()) return;
/*  628 */         this.word.unsafeWrite(this.word.charAt(this.k));
/*  629 */         this.k += 1;
/*  630 */         lookup();
/*  631 */         return;
/*      */       }
/*      */ 
/*  638 */       if ((this.word.charAt(0) == 'u') && (this.word.charAt(1) == 'n')) {
/*  639 */         this.word.unsafeWrite('e');
/*  640 */         this.word.unsafeWrite('d');
/*  641 */         this.k += 2;
/*      */ 
/*  643 */         return;
/*      */       }
/*      */ 
/*  651 */       this.word.setLength(this.j + 1);
/*  652 */       this.word.unsafeWrite('e');
/*  653 */       this.k = (this.j + 1);
/*      */ 
/*  655 */       return;
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean doubleC(int i)
/*      */   {
/*  661 */     if (i < 1) return false;
/*      */ 
/*  663 */     if (this.word.charAt(i) != this.word.charAt(i - 1)) return false;
/*  664 */     return isCons(i);
/*      */   }
/*      */ 
/*      */   private boolean vowelInStem() {
/*  668 */     for (int i = 0; i < stemLength(); i++) {
/*  669 */       if (isVowel(i)) return true;
/*      */     }
/*  671 */     return false;
/*      */   }
/*      */ 
/*      */   private void aspect()
/*      */   {
/*  683 */     if (this.word.length() <= 5) return;
/*      */ 
/*  686 */     if ((endsIn('i', 'n', 'g')) && (vowelInStem()))
/*      */     {
/*  689 */       this.word.setCharAt(this.j + 1, 'e');
/*  690 */       this.word.setLength(this.j + 2);
/*  691 */       this.k = (this.j + 1);
/*      */ 
/*  693 */       DictEntry entry = wordInDict();
/*  694 */       if ((entry != null) && 
/*  695 */         (!entry.exception)) {
/*  696 */         return;
/*      */       }
/*      */ 
/*  700 */       this.word.setLength(this.k);
/*  701 */       this.k -= 1;
/*      */ 
/*  703 */       if (lookup()) return;
/*      */ 
/*  706 */       if (doubleC(this.k)) {
/*  707 */         this.k -= 1;
/*  708 */         this.word.setLength(this.k + 1);
/*  709 */         if (lookup()) return;
/*  710 */         this.word.unsafeWrite(this.word.charAt(this.k));
/*      */ 
/*  717 */         this.k += 1;
/*  718 */         lookup();
/*  719 */         return;
/*      */       }
/*      */ 
/*  734 */       if ((this.j > 0) && (isCons(this.j)) && (isCons(this.j - 1))) {
/*  735 */         this.k = this.j;
/*  736 */         this.word.setLength(this.k + 1);
/*      */ 
/*  738 */         return;
/*      */       }
/*      */ 
/*  741 */       this.word.setLength(this.j + 1);
/*  742 */       this.word.unsafeWrite('e');
/*  743 */       this.k = (this.j + 1);
/*      */ 
/*  745 */       return;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void ityEndings()
/*      */   {
/*  756 */     int old_k = this.k;
/*      */ 
/*  758 */     if (endsIn('i', 't', 'y')) {
/*  759 */       this.word.setLength(this.j + 1);
/*  760 */       this.k = this.j;
/*  761 */       if (lookup()) return;
/*  762 */       this.word.unsafeWrite('e');
/*  763 */       this.k = (this.j + 1);
/*  764 */       if (lookup()) return;
/*  765 */       this.word.setCharAt(this.j + 1, 'i');
/*  766 */       this.word.append("ty");
/*  767 */       this.k = old_k;
/*      */ 
/*  772 */       if ((this.j > 0) && (this.word.charAt(this.j - 1) == 'i') && (this.word.charAt(this.j) == 'l')) {
/*  773 */         this.word.setLength(this.j - 1);
/*  774 */         this.word.append("le");
/*  775 */         this.k = this.j;
/*  776 */         lookup();
/*  777 */         return;
/*      */       }
/*      */ 
/*  781 */       if ((this.j > 0) && (this.word.charAt(this.j - 1) == 'i') && (this.word.charAt(this.j) == 'v')) {
/*  782 */         this.word.setLength(this.j + 1);
/*  783 */         this.word.unsafeWrite('e');
/*  784 */         this.k = (this.j + 1);
/*  785 */         lookup();
/*  786 */         return;
/*      */       }
/*      */ 
/*  789 */       if ((this.j > 0) && (this.word.charAt(this.j - 1) == 'a') && (this.word.charAt(this.j) == 'l')) {
/*  790 */         this.word.setLength(this.j + 1);
/*  791 */         this.k = this.j;
/*  792 */         lookup();
/*  793 */         return;
/*      */       }
/*      */ 
/*  803 */       if (lookup()) return;
/*      */ 
/*  806 */       this.word.setLength(this.j + 1);
/*  807 */       this.k = this.j;
/*      */ 
/*  809 */       return;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void nceEndings()
/*      */   {
/*  815 */     int old_k = this.k;
/*      */ 
/*  818 */     if (endsIn('n', 'c', 'e')) {
/*  819 */       char word_char = this.word.charAt(this.j);
/*  820 */       if ((word_char != 'e') && (word_char != 'a')) return;
/*  821 */       this.word.setLength(this.j);
/*  822 */       this.word.unsafeWrite('e');
/*  823 */       this.k = this.j;
/*  824 */       if (lookup()) return;
/*  825 */       this.word.setLength(this.j);
/*      */ 
/*  829 */       this.k = (this.j - 1);
/*  830 */       if (lookup()) return;
/*  831 */       this.word.unsafeWrite(word_char);
/*  832 */       this.word.append("nce");
/*  833 */       this.k = old_k;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void nessEndings()
/*      */   {
/*  841 */     if (endsIn('n', 'e', 's', 's'))
/*      */     {
/*  845 */       this.word.setLength(this.j + 1);
/*  846 */       this.k = this.j;
/*  847 */       if (this.word.charAt(this.j) == 'i') this.word.setCharAt(this.j, 'y');
/*  848 */       lookup();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void ismEndings()
/*      */   {
/*  855 */     if (endsIn('i', 's', 'm'))
/*      */     {
/*  859 */       this.word.setLength(this.j + 1);
/*  860 */       this.k = this.j;
/*  861 */       lookup();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void mentEndings()
/*      */   {
/*  868 */     int old_k = this.k;
/*      */ 
/*  870 */     if (endsIn('m', 'e', 'n', 't')) {
/*  871 */       this.word.setLength(this.j + 1);
/*  872 */       this.k = this.j;
/*  873 */       if (lookup()) return;
/*  874 */       this.word.append("ment");
/*  875 */       this.k = old_k;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void izeEndings()
/*      */   {
/*  883 */     int old_k = this.k;
/*      */ 
/*  885 */     if (endsIn('i', 'z', 'e')) {
/*  886 */       this.word.setLength(this.j + 1);
/*  887 */       this.k = this.j;
/*  888 */       if (lookup()) return;
/*  889 */       this.word.unsafeWrite('i');
/*      */ 
/*  891 */       if (doubleC(this.j)) {
/*  892 */         this.word.setLength(this.j);
/*  893 */         this.k = (this.j - 1);
/*  894 */         if (lookup()) return;
/*  895 */         this.word.unsafeWrite(this.word.charAt(this.j - 1));
/*      */       }
/*      */ 
/*  898 */       this.word.setLength(this.j + 1);
/*  899 */       this.word.unsafeWrite('e');
/*  900 */       this.k = (this.j + 1);
/*  901 */       if (lookup()) return;
/*  902 */       this.word.setLength(this.j + 1);
/*  903 */       this.word.append("ize");
/*  904 */       this.k = old_k;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void ncyEndings()
/*      */   {
/*  912 */     if (endsIn('n', 'c', 'y')) {
/*  913 */       if ((this.word.charAt(this.j) != 'e') && (this.word.charAt(this.j) != 'a')) return;
/*  914 */       this.word.setCharAt(this.j + 2, 't');
/*  915 */       this.word.setLength(this.j + 3);
/*  916 */       this.k = (this.j + 2);
/*      */ 
/*  918 */       if (lookup()) return;
/*      */ 
/*  920 */       this.word.setCharAt(this.j + 2, 'c');
/*  921 */       this.word.unsafeWrite('e');
/*  922 */       this.k = (this.j + 3);
/*  923 */       lookup();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void bleEndings()
/*      */   {
/*  930 */     int old_k = this.k;
/*      */ 
/*  933 */     if (endsIn('b', 'l', 'e')) {
/*  934 */       if ((this.word.charAt(this.j) != 'a') && (this.word.charAt(this.j) != 'i')) return;
/*  935 */       char word_char = this.word.charAt(this.j);
/*  936 */       this.word.setLength(this.j);
/*  937 */       this.k = (this.j - 1);
/*  938 */       if (lookup()) return;
/*  939 */       if (doubleC(this.k)) {
/*  940 */         this.word.setLength(this.k);
/*  941 */         this.k -= 1;
/*  942 */         if (lookup()) return;
/*  943 */         this.k += 1;
/*  944 */         this.word.unsafeWrite(this.word.charAt(this.k - 1));
/*      */       }
/*  946 */       this.word.setLength(this.j);
/*  947 */       this.word.unsafeWrite('e');
/*  948 */       this.k = this.j;
/*  949 */       if (lookup()) return;
/*  950 */       this.word.setLength(this.j);
/*  951 */       this.word.append("ate");
/*      */ 
/*  953 */       this.k = (this.j + 2);
/*  954 */       if (lookup()) return;
/*  955 */       this.word.setLength(this.j);
/*  956 */       this.word.unsafeWrite(word_char);
/*  957 */       this.word.append("ble");
/*  958 */       this.k = old_k;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void icEndings()
/*      */   {
/*  970 */     if (endsIn('i', 'c')) {
/*  971 */       this.word.setLength(this.j + 3);
/*  972 */       this.word.append("al");
/*  973 */       this.k = (this.j + 4);
/*  974 */       if (lookup()) return;
/*      */ 
/*  976 */       this.word.setCharAt(this.j + 1, 'y');
/*  977 */       this.word.setLength(this.j + 2);
/*  978 */       this.k = (this.j + 1);
/*  979 */       if (lookup()) return;
/*      */ 
/*  981 */       this.word.setCharAt(this.j + 1, 'e');
/*  982 */       if (lookup()) return;
/*      */ 
/*  984 */       this.word.setLength(this.j + 1);
/*  985 */       this.k = this.j;
/*  986 */       if (lookup()) return;
/*  987 */       this.word.append("ic");
/*  988 */       this.k = (this.j + 2);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void ionEndings()
/*      */   {
/* 1005 */     int old_k = this.k;
/* 1006 */     if (!endsIn('i', 'o', 'n')) {
/* 1007 */       return;
/*      */     }
/*      */ 
/* 1010 */     if (endsIn(ization))
/*      */     {
/* 1014 */       this.word.setLength(this.j + 3);
/* 1015 */       this.word.unsafeWrite('e');
/* 1016 */       this.k = (this.j + 3);
/* 1017 */       lookup();
/* 1018 */       return;
/*      */     }
/*      */ 
/* 1021 */     if (endsIn(ition)) {
/* 1022 */       this.word.setLength(this.j + 1);
/* 1023 */       this.word.unsafeWrite('e');
/* 1024 */       this.k = (this.j + 1);
/* 1025 */       if (lookup())
/*      */       {
/* 1029 */         return;
/*      */       }
/*      */ 
/* 1032 */       this.word.setLength(this.j + 1);
/* 1033 */       this.word.append("ition");
/* 1034 */       this.k = old_k;
/*      */     }
/* 1036 */     else if (endsIn(ation)) {
/* 1037 */       this.word.setLength(this.j + 3);
/* 1038 */       this.word.unsafeWrite('e');
/* 1039 */       this.k = (this.j + 3);
/* 1040 */       if (lookup()) {
/* 1041 */         return;
/*      */       }
/* 1043 */       this.word.setLength(this.j + 1);
/* 1044 */       this.word.unsafeWrite('e');
/*      */ 
/* 1048 */       this.k = (this.j + 1);
/* 1049 */       if (lookup()) return;
/*      */ 
/* 1051 */       this.word.setLength(this.j + 1);
/*      */ 
/* 1055 */       this.k = this.j;
/* 1056 */       if (lookup()) return;
/*      */ 
/* 1059 */       this.word.setLength(this.j + 1);
/* 1060 */       this.word.append("ation");
/* 1061 */       this.k = old_k;
/*      */     }
/*      */ 
/* 1071 */     if (endsIn(ication)) {
/* 1072 */       this.word.setLength(this.j + 1);
/* 1073 */       this.word.unsafeWrite('y');
/* 1074 */       this.k = (this.j + 1);
/* 1075 */       if (lookup())
/*      */       {
/* 1079 */         return;
/*      */       }
/*      */ 
/* 1082 */       this.word.setLength(this.j + 1);
/* 1083 */       this.word.append("ication");
/* 1084 */       this.k = old_k;
/*      */     }
/*      */ 
/* 1090 */     this.j = (this.k - 3);
/*      */ 
/* 1092 */     this.word.setLength(this.j + 1);
/* 1093 */     this.word.unsafeWrite('e');
/* 1094 */     this.k = (this.j + 1);
/* 1095 */     if (lookup()) {
/* 1096 */       return;
/*      */     }
/* 1098 */     this.word.setLength(this.j + 1);
/* 1099 */     this.k = this.j;
/* 1100 */     if (lookup()) {
/* 1101 */       return;
/*      */     }
/*      */ 
/* 1104 */     this.word.setLength(this.j + 1);
/* 1105 */     this.word.append("ion");
/* 1106 */     this.k = old_k;
/*      */   }
/*      */ 
/*      */   private void erAndOrEndings()
/*      */   {
/* 1119 */     int old_k = this.k;
/*      */ 
/* 1121 */     if (this.word.charAt(this.k) != 'r') return;
/*      */ 
/* 1125 */     if (endsIn('i', 'z', 'e', 'r'))
/*      */     {
/* 1129 */       this.word.setLength(this.j + 4);
/* 1130 */       this.k = (this.j + 3);
/* 1131 */       lookup();
/* 1132 */       return;
/*      */     }
/*      */ 
/* 1135 */     if ((endsIn('e', 'r')) || (endsIn('o', 'r'))) {
/* 1136 */       char word_char = this.word.charAt(this.j + 1);
/* 1137 */       if (doubleC(this.j)) {
/* 1138 */         this.word.setLength(this.j);
/* 1139 */         this.k = (this.j - 1);
/* 1140 */         if (lookup()) return;
/* 1141 */         this.word.unsafeWrite(this.word.charAt(this.j - 1));
/*      */       }
/*      */ 
/* 1144 */       if (this.word.charAt(this.j) == 'i') {
/* 1145 */         this.word.setCharAt(this.j, 'y');
/* 1146 */         this.word.setLength(this.j + 1);
/* 1147 */         this.k = this.j;
/* 1148 */         if (lookup())
/* 1149 */           return;
/* 1150 */         this.word.setCharAt(this.j, 'i');
/* 1151 */         this.word.unsafeWrite('e');
/*      */       }
/*      */ 
/* 1154 */       if (this.word.charAt(this.j) == 'e') {
/* 1155 */         this.word.setLength(this.j);
/* 1156 */         this.k = (this.j - 1);
/* 1157 */         if (lookup()) return;
/* 1158 */         this.word.unsafeWrite('e');
/*      */       }
/*      */ 
/* 1161 */       this.word.setLength(this.j + 2);
/* 1162 */       this.k = (this.j + 1);
/* 1163 */       if (lookup()) return;
/* 1164 */       this.word.setLength(this.j + 1);
/* 1165 */       this.k = this.j;
/* 1166 */       if (lookup()) return;
/* 1167 */       this.word.unsafeWrite('e');
/* 1168 */       this.k = (this.j + 1);
/* 1169 */       if (lookup()) return;
/* 1170 */       this.word.setLength(this.j + 1);
/* 1171 */       this.word.unsafeWrite(word_char);
/* 1172 */       this.word.unsafeWrite('r');
/* 1173 */       this.k = old_k;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void lyEndings()
/*      */   {
/* 1186 */     int old_k = this.k;
/*      */ 
/* 1188 */     if (endsIn('l', 'y'))
/*      */     {
/* 1190 */       this.word.setCharAt(this.j + 2, 'e');
/*      */ 
/* 1192 */       if (lookup()) return;
/* 1193 */       this.word.setCharAt(this.j + 2, 'y');
/*      */ 
/* 1195 */       this.word.setLength(this.j + 1);
/* 1196 */       this.k = this.j;
/*      */ 
/* 1198 */       if (lookup()) return;
/*      */ 
/* 1200 */       if ((this.j > 0) && (this.word.charAt(this.j - 1) == 'a') && (this.word.charAt(this.j) == 'l'))
/*      */       {
/* 1209 */         return;
/* 1210 */       }this.word.append("ly");
/* 1211 */       this.k = old_k;
/*      */ 
/* 1213 */       if ((this.j > 0) && (this.word.charAt(this.j - 1) == 'a') && (this.word.charAt(this.j) == 'b'))
/*      */       {
/* 1222 */         this.word.setCharAt(this.j + 2, 'e');
/* 1223 */         this.k = (this.j + 2);
/* 1224 */         return;
/*      */       }
/*      */ 
/* 1227 */       if (this.word.charAt(this.j) == 'i') {
/* 1228 */         this.word.setLength(this.j);
/* 1229 */         this.word.unsafeWrite('y');
/* 1230 */         this.k = this.j;
/* 1231 */         if (lookup()) return;
/* 1232 */         this.word.setLength(this.j);
/* 1233 */         this.word.append("ily");
/* 1234 */         this.k = old_k;
/*      */       }
/*      */ 
/* 1237 */       this.word.setLength(this.j + 1);
/*      */ 
/* 1239 */       this.k = this.j;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void alEndings()
/*      */   {
/* 1250 */     int old_k = this.k;
/*      */ 
/* 1252 */     if (this.word.length() < 4) return;
/* 1253 */     if (endsIn('a', 'l')) {
/* 1254 */       this.word.setLength(this.j + 1);
/* 1255 */       this.k = this.j;
/* 1256 */       if (lookup()) {
/* 1257 */         return;
/*      */       }
/* 1259 */       if (doubleC(this.j)) {
/* 1260 */         this.word.setLength(this.j);
/* 1261 */         this.k = (this.j - 1);
/* 1262 */         if (lookup()) return;
/* 1263 */         this.word.unsafeWrite(this.word.charAt(this.j - 1));
/*      */       }
/*      */ 
/* 1266 */       this.word.setLength(this.j + 1);
/* 1267 */       this.word.unsafeWrite('e');
/* 1268 */       this.k = (this.j + 1);
/* 1269 */       if (lookup()) return;
/*      */ 
/* 1271 */       this.word.setLength(this.j + 1);
/* 1272 */       this.word.append("um");
/*      */ 
/* 1274 */       this.k = (this.j + 2);
/* 1275 */       if (lookup()) return;
/*      */ 
/* 1277 */       this.word.setLength(this.j + 1);
/* 1278 */       this.word.append("al");
/* 1279 */       this.k = old_k;
/*      */ 
/* 1281 */       if ((this.j > 0) && (this.word.charAt(this.j - 1) == 'i') && (this.word.charAt(this.j) == 'c')) {
/* 1282 */         this.word.setLength(this.j - 1);
/* 1283 */         this.k = (this.j - 2);
/* 1284 */         if (lookup()) return;
/*      */ 
/* 1286 */         this.word.setLength(this.j - 1);
/* 1287 */         this.word.unsafeWrite('y');
/* 1288 */         this.k = (this.j - 1);
/* 1289 */         if (lookup()) return;
/*      */ 
/* 1291 */         this.word.setLength(this.j - 1);
/* 1292 */         this.word.append("ic");
/* 1293 */         this.k = this.j;
/*      */ 
/* 1297 */         lookup();
/* 1298 */         return;
/*      */       }
/*      */ 
/* 1301 */       if (this.word.charAt(this.j) == 'i') {
/* 1302 */         this.word.setLength(this.j);
/* 1303 */         this.k = (this.j - 1);
/* 1304 */         if (lookup()) return;
/* 1305 */         this.word.append("ial");
/* 1306 */         this.k = old_k;
/* 1307 */         lookup();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void iveEndings()
/*      */   {
/* 1319 */     int old_k = this.k;
/*      */ 
/* 1321 */     if (endsIn('i', 'v', 'e')) {
/* 1322 */       this.word.setLength(this.j + 1);
/* 1323 */       this.k = this.j;
/* 1324 */       if (lookup()) return;
/*      */ 
/* 1326 */       this.word.unsafeWrite('e');
/* 1327 */       this.k = (this.j + 1);
/* 1328 */       if (lookup()) return;
/* 1329 */       this.word.setLength(this.j + 1);
/* 1330 */       this.word.append("ive");
/* 1331 */       if ((this.j > 0) && (this.word.charAt(this.j - 1) == 'a') && (this.word.charAt(this.j) == 't')) {
/* 1332 */         this.word.setCharAt(this.j - 1, 'e');
/* 1333 */         this.word.setLength(this.j);
/* 1334 */         this.k = (this.j - 1);
/* 1335 */         if (lookup()) return;
/* 1336 */         this.word.setLength(this.j - 1);
/* 1337 */         if (lookup()) return;
/*      */ 
/* 1339 */         this.word.append("ative");
/* 1340 */         this.k = old_k;
/*      */       }
/*      */ 
/* 1344 */       this.word.setCharAt(this.j + 2, 'o');
/* 1345 */       this.word.setCharAt(this.j + 3, 'n');
/* 1346 */       if (lookup()) return;
/*      */ 
/* 1348 */       this.word.setCharAt(this.j + 2, 'v');
/* 1349 */       this.word.setCharAt(this.j + 3, 'e');
/* 1350 */       this.k = old_k;
/*      */     }
/*      */   }
/*      */ 
/*      */   String stem(String term)
/*      */   {
/* 1359 */     boolean changed = stem(term.toCharArray(), term.length());
/* 1360 */     if (!changed) return term;
/* 1361 */     return asString();
/*      */   }
/*      */ 
/*      */   String asString()
/*      */   {
/* 1368 */     String s = getString();
/* 1369 */     if (s != null) return s;
/* 1370 */     return this.word.toString();
/*      */   }
/*      */ 
/*      */   CharSequence asCharSequence() {
/* 1374 */     return this.result != null ? this.result : this.word;
/*      */   }
/*      */ 
/*      */   String getString() {
/* 1378 */     return this.result;
/*      */   }
/*      */ 
/*      */   char[] getChars() {
/* 1382 */     return this.word.getArray();
/*      */   }
/*      */ 
/*      */   int getLength() {
/* 1386 */     return this.word.length();
/*      */   }
/*      */ 
/*      */   private boolean matched()
/*      */   {
/* 1398 */     return this.matchedEntry != null;
/*      */   }
/*      */ 
/*      */   boolean stem(char[] term, int len)
/*      */   {
/* 1406 */     this.result = null;
/*      */ 
/* 1408 */     this.k = (len - 1);
/* 1409 */     if ((this.k <= 1) || (this.k >= 49)) {
/* 1410 */       return false;
/*      */     }
/*      */ 
/* 1415 */     DictEntry entry = (DictEntry)dict_ht.get(term, 0, len);
/* 1416 */     if (entry != null) {
/* 1417 */       if (entry.root != null) {
/* 1418 */         this.result = entry.root;
/* 1419 */         return true;
/*      */       }
/* 1421 */       return false;
/*      */     }
/*      */ 
/* 1432 */     this.word.reset();
/*      */ 
/* 1434 */     this.word.reserve(len + 10);
/* 1435 */     for (int i = 0; i < len; i++) {
/* 1436 */       char ch = term[i];
/* 1437 */       if (!isAlpha(ch)) return false;
/*      */ 
/* 1440 */       this.word.unsafeWrite(ch);
/*      */     }
/*      */ 
/* 1443 */     this.matchedEntry = null;
/*      */ 
/* 1456 */     plural();
/* 1457 */     if (!matched()) {
/* 1458 */       pastTense();
/* 1459 */       if (!matched()) {
/* 1460 */         aspect();
/* 1461 */         if (!matched()) {
/* 1462 */           ityEndings();
/* 1463 */           if (!matched()) {
/* 1464 */             nessEndings();
/* 1465 */             if (!matched()) {
/* 1466 */               ionEndings();
/* 1467 */               if (!matched()) {
/* 1468 */                 erAndOrEndings();
/* 1469 */                 if (!matched()) {
/* 1470 */                   lyEndings();
/* 1471 */                   if (!matched()) {
/* 1472 */                     alEndings();
/* 1473 */                     if (!matched()) {
/* 1474 */                       entry = wordInDict();
/* 1475 */                       iveEndings();
/* 1476 */                       if (!matched()) {
/* 1477 */                         izeEndings();
/* 1478 */                         if (!matched()) {
/* 1479 */                           mentEndings();
/* 1480 */                           if (!matched()) {
/* 1481 */                             bleEndings();
/* 1482 */                             if (!matched()) {
/* 1483 */                               ismEndings();
/* 1484 */                               if (!matched()) {
/* 1485 */                                 icEndings();
/* 1486 */                                 if (!matched()) {
/* 1487 */                                   ncyEndings();
/* 1488 */                                   if (!matched()) {
/* 1489 */                                     nceEndings();
/* 1490 */                                     matched();
/*      */                                   }
/*      */                                 }
/*      */                               }
/*      */                             }
/*      */                           }
/*      */                         }
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1498 */     entry = this.matchedEntry;
/* 1499 */     if (entry != null) {
/* 1500 */       this.result = entry.root;
/*      */     }
/*      */ 
/* 1519 */     return true;
/*      */   }
/*      */ 
/*      */   static class DictEntry
/*      */   {
/*      */     boolean exception;
/*      */     String root;
/*      */ 
/*      */     DictEntry(String root, boolean isException)
/*      */     {
/*  231 */       this.root = root;
/*  232 */       this.exception = isException;
/*      */     }
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.en.KStemmer
 * JD-Core Version:    0.6.2
 */