/*    */ package org.apache.lucene.analysis.en;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class KStemFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public KStemFilterFactory(Map<String, String> args)
/*    */   {
/* 42 */     super(args);
/* 43 */     if (!args.isEmpty())
/* 44 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenFilter create(TokenStream input)
/*    */   {
/* 50 */     return new KStemFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.en.KStemFilterFactory
 * JD-Core Version:    0.6.2
 */