/*    */ package org.apache.lucene.analysis.en;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class EnglishPossessiveFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public EnglishPossessiveFilterFactory(Map<String, String> args)
/*    */   {
/* 41 */     super(args);
/* 42 */     assureMatchVersion();
/* 43 */     if (!args.isEmpty())
/* 44 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 50 */     return new EnglishPossessiveFilter(this.luceneMatchVersion, input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.en.EnglishPossessiveFilterFactory
 * JD-Core Version:    0.6.2
 */