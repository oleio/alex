/*    */ package org.apache.lucene.analysis;
/*    */ 
/*    */ import java.io.Reader;
/*    */ 
/*    */ final class ReusableStringReader extends Reader
/*    */ {
/* 24 */   private int pos = 0; private int size = 0;
/* 25 */   private String s = null;
/*    */ 
/*    */   void setValue(String s) {
/* 28 */     this.s = s;
/* 29 */     this.size = s.length();
/* 30 */     this.pos = 0;
/*    */   }
/*    */ 
/*    */   public int read()
/*    */   {
/* 35 */     if (this.pos < this.size) {
/* 36 */       return this.s.charAt(this.pos++);
/*    */     }
/* 38 */     this.s = null;
/* 39 */     return -1;
/*    */   }
/*    */ 
/*    */   public int read(char[] c, int off, int len)
/*    */   {
/* 45 */     if (this.pos < this.size) {
/* 46 */       len = Math.min(len, this.size - this.pos);
/* 47 */       this.s.getChars(this.pos, this.pos + len, c, off);
/* 48 */       this.pos += len;
/* 49 */       return len;
/*    */     }
/* 51 */     this.s = null;
/* 52 */     return -1;
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/* 58 */     this.pos = this.size;
/* 59 */     this.s = null;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ReusableStringReader
 * JD-Core Version:    0.6.2
 */