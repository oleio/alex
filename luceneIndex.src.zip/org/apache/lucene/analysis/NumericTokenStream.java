/*     */ package org.apache.lucene.analysis;
/*     */ 
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TermToBytesRefAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.util.Attribute;
/*     */ import org.apache.lucene.util.AttributeImpl;
/*     */ import org.apache.lucene.util.AttributeReflector;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ import org.apache.lucene.util.BytesRef;
/*     */ import org.apache.lucene.util.NumericUtils;
/*     */ 
/*     */ public final class NumericTokenStream extends TokenStream
/*     */ {
/*     */   public static final String TOKEN_TYPE_FULL_PREC = "fullPrecNumeric";
/*     */   public static final String TOKEN_TYPE_LOWER_PREC = "lowerPrecNumeric";
/* 319 */   private final NumericTermAttribute numericAtt = (NumericTermAttribute)addAttribute(NumericTermAttribute.class);
/* 320 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/* 321 */   private final PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*     */ 
/* 323 */   private int valSize = 0;
/*     */   private final int precisionStep;
/*     */ 
/*     */   public NumericTokenStream()
/*     */   {
/* 221 */     this(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY, 4);
/*     */   }
/*     */ 
/*     */   public NumericTokenStream(int precisionStep)
/*     */   {
/* 230 */     this(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY, precisionStep);
/*     */   }
/*     */ 
/*     */   public NumericTokenStream(AttributeSource.AttributeFactory factory, int precisionStep)
/*     */   {
/* 241 */     super(new NumericAttributeFactory(factory));
/* 242 */     if (precisionStep < 1)
/* 243 */       throw new IllegalArgumentException("precisionStep must be >=1");
/* 244 */     this.precisionStep = precisionStep;
/* 245 */     this.numericAtt.setShift(-precisionStep);
/*     */   }
/*     */ 
/*     */   public NumericTokenStream setLongValue(long value)
/*     */   {
/* 255 */     this.numericAtt.init(value, this.valSize = 64, this.precisionStep, -this.precisionStep);
/* 256 */     return this;
/*     */   }
/*     */ 
/*     */   public NumericTokenStream setIntValue(int value)
/*     */   {
/* 266 */     this.numericAtt.init(value, this.valSize = 32, this.precisionStep, -this.precisionStep);
/* 267 */     return this;
/*     */   }
/*     */ 
/*     */   public NumericTokenStream setDoubleValue(double value)
/*     */   {
/* 277 */     this.numericAtt.init(NumericUtils.doubleToSortableLong(value), this.valSize = 64, this.precisionStep, -this.precisionStep);
/* 278 */     return this;
/*     */   }
/*     */ 
/*     */   public NumericTokenStream setFloatValue(float value)
/*     */   {
/* 288 */     this.numericAtt.init(NumericUtils.floatToSortableInt(value), this.valSize = 32, this.precisionStep, -this.precisionStep);
/* 289 */     return this;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */   {
/* 294 */     if (this.valSize == 0)
/* 295 */       throw new IllegalStateException("call set???Value() before usage");
/* 296 */     this.numericAtt.setShift(-this.precisionStep);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */   {
/* 301 */     if (this.valSize == 0) {
/* 302 */       throw new IllegalStateException("call set???Value() before usage");
/*     */     }
/*     */ 
/* 305 */     clearAttributes();
/*     */ 
/* 307 */     int shift = this.numericAtt.incShift();
/* 308 */     this.typeAtt.setType(shift == 0 ? "fullPrecNumeric" : "lowerPrecNumeric");
/* 309 */     this.posIncrAtt.setPositionIncrement(shift == 0 ? 1 : 0);
/* 310 */     return shift < this.valSize;
/*     */   }
/*     */ 
/*     */   public int getPrecisionStep()
/*     */   {
/* 315 */     return this.precisionStep;
/*     */   }
/*     */ 
/*     */   public static final class NumericTermAttributeImpl extends AttributeImpl
/*     */     implements NumericTokenStream.NumericTermAttribute, TermToBytesRefAttribute
/*     */   {
/* 146 */     private long value = 0L;
/* 147 */     private int valueSize = 0; private int shift = 0; private int precisionStep = 0;
/* 148 */     private BytesRef bytes = new BytesRef();
/*     */ 
/*     */     public BytesRef getBytesRef()
/*     */     {
/* 158 */       return this.bytes;
/*     */     }
/*     */ 
/*     */     public void fillBytesRef()
/*     */     {
/* 163 */       assert ((this.valueSize == 64) || (this.valueSize == 32));
/* 164 */       if (this.valueSize == 64)
/* 165 */         NumericUtils.longToPrefixCoded(this.value, this.shift, this.bytes);
/*     */       else
/* 167 */         NumericUtils.intToPrefixCoded((int)this.value, this.shift, this.bytes);
/*     */     }
/*     */ 
/*     */     public int getShift()
/*     */     {
/* 172 */       return this.shift;
/*     */     }
/* 174 */     public void setShift(int shift) { this.shift = shift; }
/*     */ 
/*     */     public int incShift() {
/* 177 */       return this.shift += this.precisionStep;
/*     */     }
/*     */ 
/*     */     public long getRawValue() {
/* 181 */       return this.value & ((1L << this.shift) - 1L ^ 0xFFFFFFFF);
/*     */     }
/* 183 */     public int getValueSize() { return this.valueSize; }
/*     */ 
/*     */     public void init(long value, int valueSize, int precisionStep, int shift)
/*     */     {
/* 187 */       this.value = value;
/* 188 */       this.valueSize = valueSize;
/* 189 */       this.precisionStep = precisionStep;
/* 190 */       this.shift = shift;
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void reflectWith(AttributeReflector reflector)
/*     */     {
/* 201 */       fillBytesRef();
/* 202 */       reflector.reflect(TermToBytesRefAttribute.class, "bytes", BytesRef.deepCopyOf(this.bytes));
/* 203 */       reflector.reflect(TermToBytesRefAttribute.class, "shift", Integer.valueOf(this.shift));
/* 204 */       reflector.reflect(TermToBytesRefAttribute.class, "rawValue", Long.valueOf(getRawValue()));
/* 205 */       reflector.reflect(TermToBytesRefAttribute.class, "valueSize", Integer.valueOf(this.valueSize));
/*     */     }
/*     */ 
/*     */     public void copyTo(AttributeImpl target)
/*     */     {
/* 210 */       NumericTokenStream.NumericTermAttribute a = (TermToBytesRefAttribute)target;
/* 211 */       a.init(this.value, this.valueSize, this.precisionStep, this.shift);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class NumericAttributeFactory extends AttributeSource.AttributeFactory
/*     */   {
/*     */     private final AttributeSource.AttributeFactory delegate;
/*     */ 
/*     */     NumericAttributeFactory(AttributeSource.AttributeFactory delegate)
/*     */     {
/* 130 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     public AttributeImpl createAttributeInstance(Class<? extends Attribute> attClass)
/*     */     {
/* 135 */       if (CharTermAttribute.class.isAssignableFrom(attClass))
/* 136 */         throw new IllegalArgumentException("NumericTokenStream does not support CharTermAttribute.");
/* 137 */       return this.delegate.createAttributeInstance(attClass);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface NumericTermAttribute extends Attribute
/*     */   {
/*     */     public abstract int getShift();
/*     */ 
/*     */     public abstract long getRawValue();
/*     */ 
/*     */     public abstract int getValueSize();
/*     */ 
/*     */     public abstract void init(long paramLong, int paramInt1, int paramInt2, int paramInt3);
/*     */ 
/*     */     public abstract void setShift(int paramInt);
/*     */ 
/*     */     public abstract int incShift();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.NumericTokenStream
 * JD-Core Version:    0.6.2
 */