/*    */ package org.apache.lucene.analysis.th;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ @Deprecated
/*    */ public class ThaiWordFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public ThaiWordFilterFactory(Map<String, String> args)
/*    */   {
/* 43 */     super(args);
/* 44 */     assureMatchVersion();
/* 45 */     if (!args.isEmpty())
/* 46 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public ThaiWordFilter create(TokenStream input)
/*    */   {
/* 52 */     return new ThaiWordFilter(this.luceneMatchVersion, input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.th.ThaiWordFilterFactory
 * JD-Core Version:    0.6.2
 */