/*     */ package org.apache.lucene.analysis.th;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.BreakIterator;
/*     */ import java.util.Locale;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArrayIterator;
/*     */ import org.apache.lucene.util.AttributeSource;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ @Deprecated
/*     */ public final class ThaiWordFilter extends TokenFilter
/*     */ {
/*  53 */   public static final boolean DBBI_AVAILABLE = ThaiTokenizer.DBBI_AVAILABLE;
/*  54 */   private static final BreakIterator proto = BreakIterator.getWordInstance(new Locale("th"));
/*  55 */   private final BreakIterator breaker = (BreakIterator)proto.clone();
/*  56 */   private final CharArrayIterator charIterator = CharArrayIterator.newWordInstance();
/*     */   private final boolean handlePosIncr;
/*  60 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  61 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*  62 */   private final PositionIncrementAttribute posAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*     */ 
/*  64 */   private AttributeSource clonedToken = null;
/*  65 */   private CharTermAttribute clonedTermAtt = null;
/*  66 */   private OffsetAttribute clonedOffsetAtt = null;
/*  67 */   private boolean hasMoreTokensInClone = false;
/*  68 */   private boolean hasIllegalOffsets = false;
/*     */ 
/*     */   public ThaiWordFilter(Version matchVersion, TokenStream input)
/*     */   {
/*  72 */     super(matchVersion.onOrAfter(Version.LUCENE_31) ? input : new LowerCaseFilter(matchVersion, input));
/*     */ 
/*  74 */     if (!DBBI_AVAILABLE)
/*  75 */       throw new UnsupportedOperationException("This JRE does not have support for Thai segmentation");
/*  76 */     this.handlePosIncr = matchVersion.onOrAfter(Version.LUCENE_31);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  81 */     if (this.hasMoreTokensInClone) {
/*  82 */       int start = this.breaker.current();
/*  83 */       int end = this.breaker.next();
/*  84 */       if (end != -1) {
/*  85 */         this.clonedToken.copyTo(this);
/*  86 */         this.termAtt.copyBuffer(this.clonedTermAtt.buffer(), start, end - start);
/*  87 */         if (this.hasIllegalOffsets)
/*  88 */           this.offsetAtt.setOffset(this.clonedOffsetAtt.startOffset(), this.clonedOffsetAtt.endOffset());
/*     */         else {
/*  90 */           this.offsetAtt.setOffset(this.clonedOffsetAtt.startOffset() + start, this.clonedOffsetAtt.startOffset() + end);
/*     */         }
/*  92 */         if (this.handlePosIncr) this.posAtt.setPositionIncrement(1);
/*  93 */         return true;
/*     */       }
/*  95 */       this.hasMoreTokensInClone = false;
/*     */     }
/*     */ 
/*  98 */     if (!this.input.incrementToken()) {
/*  99 */       return false;
/*     */     }
/*     */ 
/* 102 */     if ((this.termAtt.length() == 0) || (Character.UnicodeBlock.of(this.termAtt.charAt(0)) != Character.UnicodeBlock.THAI)) {
/* 103 */       return true;
/*     */     }
/*     */ 
/* 106 */     this.hasMoreTokensInClone = true;
/*     */ 
/* 110 */     this.hasIllegalOffsets = (this.offsetAtt.endOffset() - this.offsetAtt.startOffset() != this.termAtt.length());
/*     */ 
/* 113 */     if (this.clonedToken == null) {
/* 114 */       this.clonedToken = cloneAttributes();
/* 115 */       this.clonedTermAtt = ((CharTermAttribute)this.clonedToken.getAttribute(CharTermAttribute.class));
/* 116 */       this.clonedOffsetAtt = ((OffsetAttribute)this.clonedToken.getAttribute(OffsetAttribute.class));
/*     */     } else {
/* 118 */       copyTo(this.clonedToken);
/*     */     }
/*     */ 
/* 122 */     this.charIterator.setText(this.clonedTermAtt.buffer(), 0, this.clonedTermAtt.length());
/* 123 */     this.breaker.setText(this.charIterator);
/* 124 */     int end = this.breaker.next();
/* 125 */     if (end != -1) {
/* 126 */       this.termAtt.setLength(end);
/* 127 */       if (this.hasIllegalOffsets)
/* 128 */         this.offsetAtt.setOffset(this.clonedOffsetAtt.startOffset(), this.clonedOffsetAtt.endOffset());
/*     */       else {
/* 130 */         this.offsetAtt.setOffset(this.clonedOffsetAtt.startOffset(), this.clonedOffsetAtt.startOffset() + end);
/*     */       }
/*     */ 
/* 133 */       return true;
/*     */     }
/* 135 */     return false;
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 140 */     super.reset();
/* 141 */     this.hasMoreTokensInClone = false;
/* 142 */     this.clonedToken = null;
/* 143 */     this.clonedTermAtt = null;
/* 144 */     this.clonedOffsetAtt = null;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.th.ThaiWordFilter
 * JD-Core Version:    0.6.2
 */