/*     */ package org.apache.lucene.analysis.th;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.text.BreakIterator;
/*     */ import java.util.Locale;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArrayIterator;
/*     */ import org.apache.lucene.analysis.util.SegmentingTokenizerBase;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ public class ThaiTokenizer extends SegmentingTokenizerBase
/*     */ {
/*  46 */   public static final boolean DBBI_AVAILABLE = proto.isBoundary(4);
/*     */ 
/*  42 */   private static final BreakIterator proto = BreakIterator.getWordInstance(new Locale("th"));
/*     */ 
/*  50 */   private static final BreakIterator sentenceProto = BreakIterator.getSentenceInstance(Locale.ROOT);
/*     */   private final BreakIterator wordBreaker;
/*  53 */   private final CharArrayIterator wrapper = CharArrayIterator.newWordInstance();
/*     */   int sentenceStart;
/*     */   int sentenceEnd;
/*  58 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  59 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */ 
/*     */   public ThaiTokenizer(Reader reader)
/*     */   {
/*  63 */     this(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY, reader);
/*     */   }
/*     */ 
/*     */   public ThaiTokenizer(AttributeSource.AttributeFactory factory, Reader reader)
/*     */   {
/*  68 */     super(factory, reader, (BreakIterator)sentenceProto.clone());
/*  69 */     if (!DBBI_AVAILABLE) {
/*  70 */       throw new UnsupportedOperationException("This JRE does not have support for Thai segmentation");
/*     */     }
/*  72 */     this.wordBreaker = ((BreakIterator)proto.clone());
/*     */   }
/*     */ 
/*     */   protected void setNextSentence(int sentenceStart, int sentenceEnd)
/*     */   {
/*  77 */     this.sentenceStart = sentenceStart;
/*  78 */     this.sentenceEnd = sentenceEnd;
/*  79 */     this.wrapper.setText(this.buffer, sentenceStart, sentenceEnd - sentenceStart);
/*  80 */     this.wordBreaker.setText(this.wrapper);
/*     */   }
/*     */ 
/*     */   protected boolean incrementWord()
/*     */   {
/*  85 */     int start = this.wordBreaker.current();
/*  86 */     if (start == -1) {
/*  87 */       return false;
/*     */     }
/*     */ 
/*  91 */     int end = this.wordBreaker.next();
/*  92 */     while ((end != -1) && (!Character.isLetterOrDigit(Character.codePointAt(this.buffer, this.sentenceStart + start, this.sentenceEnd))))
/*     */     {
/*  94 */       start = end;
/*  95 */       end = this.wordBreaker.next();
/*     */     }
/*     */ 
/*  98 */     if (end == -1) {
/*  99 */       return false;
/*     */     }
/*     */ 
/* 102 */     clearAttributes();
/* 103 */     this.termAtt.copyBuffer(this.buffer, this.sentenceStart + start, end - start);
/* 104 */     this.offsetAtt.setOffset(correctOffset(this.offset + this.sentenceStart + start), correctOffset(this.offset + this.sentenceStart + end));
/* 105 */     return true;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  45 */     proto.setText("ภาษาไทย");
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.th.ThaiTokenizer
 * JD-Core Version:    0.6.2
 */