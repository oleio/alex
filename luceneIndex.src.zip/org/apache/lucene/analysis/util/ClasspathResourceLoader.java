/*    */ package org.apache.lucene.analysis.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public final class ClasspathResourceLoader
/*    */   implements ResourceLoader
/*    */ {
/*    */   private final Class<?> clazz;
/*    */   private final ClassLoader loader;
/*    */ 
/*    */   public ClasspathResourceLoader()
/*    */   {
/* 37 */     this(Thread.currentThread().getContextClassLoader());
/*    */   }
/*    */ 
/*    */   public ClasspathResourceLoader(ClassLoader loader)
/*    */   {
/* 45 */     this(null, loader);
/*    */   }
/*    */ 
/*    */   public ClasspathResourceLoader(Class<?> clazz)
/*    */   {
/* 53 */     this(clazz, clazz.getClassLoader());
/*    */   }
/*    */ 
/*    */   private ClasspathResourceLoader(Class<?> clazz, ClassLoader loader) {
/* 57 */     this.clazz = clazz;
/* 58 */     this.loader = loader;
/*    */   }
/*    */ 
/*    */   public InputStream openResource(String resource) throws IOException
/*    */   {
/* 63 */     InputStream stream = this.clazz != null ? this.clazz.getResourceAsStream(resource) : this.loader.getResourceAsStream(resource);
/*    */ 
/* 66 */     if (stream == null)
/* 67 */       throw new IOException("Resource not found: " + resource);
/* 68 */     return stream;
/*    */   }
/*    */ 
/*    */   public <T> Class<? extends T> findClass(String cname, Class<T> expectedType)
/*    */   {
/*    */     try {
/* 74 */       return Class.forName(cname, true, this.loader).asSubclass(expectedType);
/*    */     } catch (Exception e) {
/* 76 */       throw new RuntimeException("Cannot load class: " + cname, e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public <T> T newInstance(String cname, Class<T> expectedType)
/*    */   {
/* 82 */     Class clazz = findClass(cname, expectedType);
/*    */     try {
/* 84 */       return clazz.newInstance();
/*    */     } catch (Exception e) {
/* 86 */       throw new RuntimeException("Cannot create instance: " + cname, e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.util.ClasspathResourceLoader
 * JD-Core Version:    0.6.2
 */