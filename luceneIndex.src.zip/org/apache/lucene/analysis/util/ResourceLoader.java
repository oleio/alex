package org.apache.lucene.analysis.util;

import java.io.IOException;
import java.io.InputStream;

public abstract interface ResourceLoader
{
  public abstract InputStream openResource(String paramString)
    throws IOException;

  public abstract <T> Class<? extends T> findClass(String paramString, Class<T> paramClass);

  public abstract <T> T newInstance(String paramString, Class<T> paramClass);
}

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.util.ResourceLoader
 * JD-Core Version:    0.6.2
 */