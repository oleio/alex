package org.apache.lucene.analysis.util;

import java.io.IOException;

public abstract interface ResourceLoaderAware
{
  public abstract void inform(ResourceLoader paramResourceLoader)
    throws IOException;
}

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.util.ResourceLoaderAware
 * JD-Core Version:    0.6.2
 */