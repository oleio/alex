/*    */ package org.apache.lucene.analysis.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.lucene.analysis.TokenFilter;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ 
/*    */ public final class ElisionFilter extends TokenFilter
/*    */ {
/*    */   private final CharArraySet articles;
/* 35 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*    */ 
/*    */   public ElisionFilter(TokenStream input, CharArraySet articles)
/*    */   {
/* 43 */     super(input);
/* 44 */     this.articles = articles;
/*    */   }
/*    */ 
/*    */   public final boolean incrementToken()
/*    */     throws IOException
/*    */   {
/* 52 */     if (this.input.incrementToken()) {
/* 53 */       char[] termBuffer = this.termAtt.buffer();
/* 54 */       int termLength = this.termAtt.length();
/*    */ 
/* 56 */       int index = -1;
/* 57 */       for (int i = 0; i < termLength; i++) {
/* 58 */         char ch = termBuffer[i];
/* 59 */         if ((ch == '\'') || (ch == '’')) {
/* 60 */           index = i;
/* 61 */           break;
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 66 */       if ((index >= 0) && (this.articles.contains(termBuffer, 0, index))) {
/* 67 */         this.termAtt.copyBuffer(termBuffer, index + 1, termLength - (index + 1));
/*    */       }
/*    */ 
/* 70 */       return true;
/*    */     }
/* 72 */     return false;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.util.ElisionFilter
 * JD-Core Version:    0.6.2
 */