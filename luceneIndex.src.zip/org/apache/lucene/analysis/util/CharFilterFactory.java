/*    */ package org.apache.lucene.analysis.util;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public abstract class CharFilterFactory extends AbstractAnalysisFactory
/*    */ {
/* 32 */   private static final AnalysisSPILoader<CharFilterFactory> loader = new AnalysisSPILoader(CharFilterFactory.class);
/*    */ 
/*    */   public static CharFilterFactory forName(String name, Map<String, String> args)
/*    */   {
/* 37 */     return (CharFilterFactory)loader.newInstance(name, args);
/*    */   }
/*    */ 
/*    */   public static Class<? extends CharFilterFactory> lookupClass(String name)
/*    */   {
/* 42 */     return loader.lookupClass(name);
/*    */   }
/*    */ 
/*    */   public static Set<String> availableCharFilters()
/*    */   {
/* 47 */     return loader.availableServices();
/*    */   }
/*    */ 
/*    */   public static void reloadCharFilters(ClassLoader classloader)
/*    */   {
/* 62 */     loader.reload(classloader);
/*    */   }
/*    */ 
/*    */   protected CharFilterFactory(Map<String, String> args)
/*    */   {
/* 69 */     super(args);
/*    */   }
/*    */ 
/*    */   public abstract Reader create(Reader paramReader);
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.util.CharFilterFactory
 * JD-Core Version:    0.6.2
 */