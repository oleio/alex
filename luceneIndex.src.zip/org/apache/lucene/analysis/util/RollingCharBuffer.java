/*     */ package org.apache.lucene.analysis.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.util.ArrayUtil;
/*     */ 
/*     */ public final class RollingCharBuffer
/*     */ {
/*     */   private Reader reader;
/*  38 */   private char[] buffer = new char[512];
/*     */   private int nextWrite;
/*     */   private int nextPos;
/*     */   private int count;
/*     */   private boolean end;
/*     */ 
/*     */   public void reset(Reader reader)
/*     */   {
/*  54 */     this.reader = reader;
/*  55 */     this.nextPos = 0;
/*  56 */     this.nextWrite = 0;
/*  57 */     this.count = 0;
/*  58 */     this.end = false;
/*     */   }
/*     */ 
/*     */   public int get(int pos)
/*     */     throws IOException
/*     */   {
/*  68 */     if (pos == this.nextPos) {
/*  69 */       if (this.end) {
/*  70 */         return -1;
/*     */       }
/*  72 */       if (this.count == this.buffer.length)
/*     */       {
/*  74 */         char[] newBuffer = new char[ArrayUtil.oversize(1 + this.count, 2)];
/*     */ 
/*  76 */         System.arraycopy(this.buffer, this.nextWrite, newBuffer, 0, this.buffer.length - this.nextWrite);
/*  77 */         System.arraycopy(this.buffer, 0, newBuffer, this.buffer.length - this.nextWrite, this.nextWrite);
/*  78 */         this.nextWrite = this.buffer.length;
/*  79 */         this.buffer = newBuffer;
/*     */       }
/*  81 */       if (this.nextWrite == this.buffer.length) {
/*  82 */         this.nextWrite = 0;
/*     */       }
/*     */ 
/*  85 */       int toRead = this.buffer.length - Math.max(this.count, this.nextWrite);
/*  86 */       int readCount = this.reader.read(this.buffer, this.nextWrite, toRead);
/*  87 */       if (readCount == -1) {
/*  88 */         this.end = true;
/*  89 */         return -1;
/*     */       }
/*  91 */       int ch = this.buffer[this.nextWrite];
/*  92 */       this.nextWrite += readCount;
/*  93 */       this.count += readCount;
/*  94 */       this.nextPos += readCount;
/*  95 */       return ch;
/*     */     }
/*     */ 
/*  98 */     assert (pos < this.nextPos);
/*     */ 
/* 101 */     assert (this.nextPos - pos <= this.count) : ("nextPos=" + this.nextPos + " pos=" + pos + " count=" + this.count);
/*     */ 
/* 103 */     return this.buffer[getIndex(pos)];
/*     */   }
/*     */ 
/*     */   private boolean inBounds(int pos)
/*     */   {
/* 109 */     return (pos >= 0) && (pos < this.nextPos) && (pos >= this.nextPos - this.count);
/*     */   }
/*     */ 
/*     */   private int getIndex(int pos) {
/* 113 */     int index = this.nextWrite - (this.nextPos - pos);
/* 114 */     if (index < 0)
/*     */     {
/* 116 */       index += this.buffer.length;
/* 117 */       assert (index >= 0);
/*     */     }
/* 119 */     return index;
/*     */   }
/*     */ 
/*     */   public char[] get(int posStart, int length) {
/* 123 */     assert (length > 0);
/* 124 */     assert (inBounds(posStart)) : ("posStart=" + posStart + " length=" + length);
/*     */ 
/* 127 */     int startIndex = getIndex(posStart);
/* 128 */     int endIndex = getIndex(posStart + length);
/*     */ 
/* 131 */     char[] result = new char[length];
/* 132 */     if ((endIndex >= startIndex) && (length < this.buffer.length)) {
/* 133 */       System.arraycopy(this.buffer, startIndex, result, 0, endIndex - startIndex);
/*     */     }
/*     */     else {
/* 136 */       int part1 = this.buffer.length - startIndex;
/* 137 */       System.arraycopy(this.buffer, startIndex, result, 0, part1);
/* 138 */       System.arraycopy(this.buffer, 0, result, this.buffer.length - startIndex, length - part1);
/*     */     }
/* 140 */     return result;
/*     */   }
/*     */ 
/*     */   public void freeBefore(int pos)
/*     */   {
/* 146 */     assert (pos >= 0);
/* 147 */     assert (pos <= this.nextPos);
/* 148 */     int newCount = this.nextPos - pos;
/* 149 */     assert (newCount <= this.count) : ("newCount=" + newCount + " count=" + this.count);
/* 150 */     assert (newCount <= this.buffer.length) : ("newCount=" + newCount + " buf.length=" + this.buffer.length);
/* 151 */     this.count = newCount;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.util.RollingCharBuffer
 * JD-Core Version:    0.6.2
 */