/*     */ package org.apache.lucene.analysis.synonym;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.util.ResourceLoader;
/*     */ import org.apache.lucene.analysis.util.ResourceLoaderAware;
/*     */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*     */ import org.apache.lucene.analysis.util.TokenizerFactory;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ @Deprecated
/*     */ final class SlowSynonymFilterFactory extends TokenFilterFactory
/*     */   implements ResourceLoaderAware
/*     */ {
/*  56 */   private final String synonyms = require(args, "synonyms");
/*  57 */   private final boolean ignoreCase = getBoolean(args, "ignoreCase", false);
/*  58 */   private final boolean expand = getBoolean(args, "expand", true);
/*     */ 
/*  60 */   private final String tf = get(args, "tokenizerFactory");
/*     */ 
/*  52 */   private final Map<String, String> tokArgs = new HashMap();
/*     */   private SlowSynonymMap synMap;
/*     */ 
/*     */   public SlowSynonymFilterFactory(Map<String, String> args)
/*     */   {
/*  55 */     super(args);
/*     */     Iterator itr;
/*  61 */     if (this.tf != null) {
/*  62 */       assureMatchVersion();
/*  63 */       this.tokArgs.put("luceneMatchVersion", getLuceneMatchVersion().toString());
/*  64 */       for (itr = args.keySet().iterator(); itr.hasNext(); ) {
/*  65 */         String key = (String)itr.next();
/*  66 */         this.tokArgs.put(key.replaceAll("^tokenizerFactory\\.", ""), args.get(key));
/*  67 */         itr.remove();
/*     */       }
/*     */     }
/*  70 */     if (!args.isEmpty())
/*  71 */       throw new IllegalArgumentException(new StringBuilder().append("Unknown parameters: ").append(args).toString());
/*     */   }
/*     */ 
/*     */   public void inform(ResourceLoader loader) throws IOException
/*     */   {
/*  76 */     TokenizerFactory tokFactory = null;
/*  77 */     if (this.tf != null) {
/*  78 */       tokFactory = loadTokenizerFactory(loader, this.tf);
/*     */     }
/*     */ 
/*  81 */     Iterable wlist = loadRules(this.synonyms, loader);
/*     */ 
/*  83 */     this.synMap = new SlowSynonymMap(this.ignoreCase);
/*  84 */     parseRules(wlist, this.synMap, "=>", ",", this.expand, tokFactory);
/*     */   }
/*     */ 
/*     */   protected Iterable<String> loadRules(String synonyms, ResourceLoader loader)
/*     */     throws IOException
/*     */   {
/*  91 */     List wlist = null;
/*  92 */     File synonymFile = new File(synonyms);
/*  93 */     if (synonymFile.exists()) {
/*  94 */       wlist = getLines(loader, synonyms);
/*     */     } else {
/*  96 */       List files = splitFileNames(synonyms);
/*  97 */       wlist = new ArrayList();
/*  98 */       for (String file : files) {
/*  99 */         List lines = getLines(loader, file.trim());
/* 100 */         wlist.addAll(lines);
/*     */       }
/*     */     }
/* 103 */     return wlist;
/*     */   }
/*     */ 
/*     */   static void parseRules(Iterable<String> rules, SlowSynonymMap map, String mappingSep, String synSep, boolean expansion, TokenizerFactory tokFactory)
/*     */     throws IOException
/*     */   {
/* 110 */     int count = 0;
/* 111 */     for (String rule : rules)
/*     */     {
/* 117 */       List mapping = splitSmart(rule, mappingSep, false);
/*     */ 
/* 122 */       if (mapping.size() > 2)
/* 123 */         throw new IllegalArgumentException(new StringBuilder().append("Invalid Synonym Rule:").append(rule).toString());
/*     */       List target;
/*     */       List source;
/* 124 */       if (mapping.size() == 2) {
/* 125 */         List source = getSynList((String)mapping.get(0), synSep, tokFactory);
/* 126 */         target = getSynList((String)mapping.get(1), synSep, tokFactory);
/*     */       } else {
/* 128 */         source = getSynList((String)mapping.get(0), synSep, tokFactory);
/*     */         List target;
/* 129 */         if (expansion)
/*     */         {
/* 131 */           target = source;
/*     */         }
/*     */         else {
/* 134 */           target = new ArrayList(1);
/* 135 */           target.add(source.get(0));
/*     */         }
/*     */       }
/*     */ 
/* 139 */       includeOrig = false;
/* 140 */       for (i$ = source.iterator(); i$.hasNext(); ) { fromToks = (List)i$.next();
/* 141 */         count++;
/* 142 */         for (List toToks : target)
/* 143 */           map.add(fromToks, SlowSynonymMap.makeTokens(toToks), includeOrig, true); }
/*     */     }
/*     */     List target;
/*     */     boolean includeOrig;
/*     */     Iterator i$;
/*     */     List fromToks;
/*     */   }
/*     */ 
/*     */   private static List<List<String>> getSynList(String str, String separator, TokenizerFactory tokFactory) throws IOException {
/* 155 */     List strList = splitSmart(str, separator, false);
/*     */ 
/* 157 */     List synList = new ArrayList();
/* 158 */     for (String toks : strList) {
/* 159 */       List tokList = tokFactory == null ? splitWS(toks, true) : splitByTokenizer(toks, tokFactory);
/*     */ 
/* 161 */       synList.add(tokList);
/*     */     }
/* 163 */     return synList;
/*     */   }
/*     */ 
/*     */   private static List<String> splitByTokenizer(String source, TokenizerFactory tokFactory) throws IOException {
/* 167 */     StringReader reader = new StringReader(source);
/* 168 */     TokenStream ts = loadTokenizer(tokFactory, reader);
/* 169 */     List tokList = new ArrayList();
/*     */     try {
/* 171 */       CharTermAttribute termAtt = (CharTermAttribute)ts.addAttribute(CharTermAttribute.class);
/* 172 */       ts.reset();
/* 173 */       while (ts.incrementToken())
/* 174 */         if (termAtt.length() > 0)
/* 175 */           tokList.add(termAtt.toString());
/*     */     }
/*     */     finally {
/* 178 */       reader.close();
/*     */     }
/* 180 */     return tokList;
/*     */   }
/*     */ 
/*     */   private TokenizerFactory loadTokenizerFactory(ResourceLoader loader, String cname) throws IOException {
/* 184 */     Class clazz = loader.findClass(cname, TokenizerFactory.class);
/*     */     try {
/* 186 */       TokenizerFactory tokFactory = (TokenizerFactory)clazz.getConstructor(new Class[] { Map.class }).newInstance(new Object[] { this.tokArgs });
/* 187 */       if ((tokFactory instanceof ResourceLoaderAware)) {
/* 188 */         ((ResourceLoaderAware)tokFactory).inform(loader);
/*     */       }
/* 190 */       return tokFactory;
/*     */     } catch (Exception e) {
/* 192 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static TokenStream loadTokenizer(TokenizerFactory tokFactory, Reader reader) {
/* 197 */     return tokFactory.create(reader);
/*     */   }
/*     */ 
/*     */   public SlowSynonymMap getSynonymMap() {
/* 201 */     return this.synMap;
/*     */   }
/*     */ 
/*     */   public SlowSynonymFilter create(TokenStream input) {
/* 205 */     return new SlowSynonymFilter(input, this.synMap);
/*     */   }
/*     */ 
/*     */   public static List<String> splitWS(String s, boolean decode) {
/* 209 */     ArrayList lst = new ArrayList(2);
/* 210 */     StringBuilder sb = new StringBuilder();
/* 211 */     int pos = 0; int end = s.length();
/* 212 */     while (pos < end) {
/* 213 */       char ch = s.charAt(pos++);
/* 214 */       if (Character.isWhitespace(ch)) {
/* 215 */         if (sb.length() > 0) {
/* 216 */           lst.add(sb.toString());
/* 217 */           sb = new StringBuilder();
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 222 */         if (ch == '\\') {
/* 223 */           if (!decode) sb.append(ch);
/* 224 */           if (pos >= end) break;
/* 225 */           ch = s.charAt(pos++);
/* 226 */           if (decode) {
/* 227 */             switch (ch) { case 'n':
/* 228 */               ch = '\n'; break;
/*     */             case 't':
/* 229 */               ch = '\t'; break;
/*     */             case 'r':
/* 230 */               ch = '\r'; break;
/*     */             case 'b':
/* 231 */               ch = '\b'; break;
/*     */             case 'f':
/* 232 */               ch = '\f';
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 237 */         sb.append(ch);
/*     */       }
/*     */     }
/* 240 */     if (sb.length() > 0) {
/* 241 */       lst.add(sb.toString());
/*     */     }
/*     */ 
/* 244 */     return lst;
/*     */   }
/*     */ 
/*     */   public static List<String> splitSmart(String s, String separator, boolean decode)
/*     */   {
/* 258 */     ArrayList lst = new ArrayList(2);
/* 259 */     StringBuilder sb = new StringBuilder();
/* 260 */     int pos = 0; int end = s.length();
/* 261 */     while (pos < end) {
/* 262 */       if (s.startsWith(separator, pos)) {
/* 263 */         if (sb.length() > 0) {
/* 264 */           lst.add(sb.toString());
/* 265 */           sb = new StringBuilder();
/*     */         }
/* 267 */         pos += separator.length();
/*     */       }
/*     */       else
/*     */       {
/* 271 */         char ch = s.charAt(pos++);
/* 272 */         if (ch == '\\') {
/* 273 */           if (!decode) sb.append(ch);
/* 274 */           if (pos >= end) break;
/* 275 */           ch = s.charAt(pos++);
/* 276 */           if (decode) {
/* 277 */             switch (ch) { case 'n':
/* 278 */               ch = '\n'; break;
/*     */             case 't':
/* 279 */               ch = '\t'; break;
/*     */             case 'r':
/* 280 */               ch = '\r'; break;
/*     */             case 'b':
/* 281 */               ch = '\b'; break;
/*     */             case 'f':
/* 282 */               ch = '\f';
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 287 */         sb.append(ch);
/*     */       }
/*     */     }
/* 290 */     if (sb.length() > 0) {
/* 291 */       lst.add(sb.toString());
/*     */     }
/*     */ 
/* 294 */     return lst;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.synonym.SlowSynonymFilterFactory
 * JD-Core Version:    0.6.2
 */