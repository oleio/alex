/*     */ package org.apache.lucene.analysis.synonym;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionLengthAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.store.ByteArrayDataInput;
/*     */ import org.apache.lucene.util.ArrayUtil;
/*     */ import org.apache.lucene.util.AttributeSource.State;
/*     */ import org.apache.lucene.util.BytesRef;
/*     */ import org.apache.lucene.util.BytesRefHash;
/*     */ import org.apache.lucene.util.CharsRef;
/*     */ import org.apache.lucene.util.RamUsageEstimator;
/*     */ import org.apache.lucene.util.UnicodeUtil;
/*     */ import org.apache.lucene.util.fst.FST;
/*     */ import org.apache.lucene.util.fst.FST.Arc;
/*     */ import org.apache.lucene.util.fst.FST.BytesReader;
/*     */ import org.apache.lucene.util.fst.Outputs;
/*     */ 
/*     */ public final class SynonymFilter extends TokenFilter
/*     */ {
/*     */   public static final String TYPE_SYNONYM = "SYNONYM";
/*     */   private final SynonymMap synonyms;
/*     */   private final boolean ignoreCase;
/*     */   private final int rollBufferSize;
/*     */   private int captureCount;
/* 119 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 120 */   private final PositionIncrementAttribute posIncrAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/* 121 */   private final PositionLengthAttribute posLenAtt = (PositionLengthAttribute)addAttribute(PositionLengthAttribute.class);
/* 122 */   private final TypeAttribute typeAtt = (TypeAttribute)addAttribute(TypeAttribute.class);
/* 123 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */   private int inputSkipCount;
/*     */   private final PendingInput[] futureInputs;
/* 229 */   private final ByteArrayDataInput bytesReader = new ByteArrayDataInput();
/*     */   private final PendingOutputs[] futureOutputs;
/*     */   private int nextWrite;
/*     */   private int nextRead;
/*     */   private boolean finished;
/*     */   private final FST.Arc<BytesRef> scratchArc;
/*     */   private final FST<BytesRef> fst;
/*     */   private final FST.BytesReader fstReader;
/* 251 */   private final BytesRef scratchBytes = new BytesRef();
/* 252 */   private final CharsRef scratchChars = new CharsRef();
/*     */   private int lastStartOffset;
/*     */   private int lastEndOffset;
/*     */ 
/*     */   public SynonymFilter(TokenStream input, SynonymMap synonyms, boolean ignoreCase)
/*     */   {
/* 262 */     super(input);
/* 263 */     this.synonyms = synonyms;
/* 264 */     this.ignoreCase = ignoreCase;
/* 265 */     this.fst = synonyms.fst;
/* 266 */     if (this.fst == null) {
/* 267 */       throw new IllegalArgumentException("fst must be non-null");
/*     */     }
/* 269 */     this.fstReader = this.fst.getBytesReader();
/*     */ 
/* 274 */     this.rollBufferSize = (1 + synonyms.maxHorizontalContext);
/*     */ 
/* 276 */     this.futureInputs = new PendingInput[this.rollBufferSize];
/* 277 */     this.futureOutputs = new PendingOutputs[this.rollBufferSize];
/* 278 */     for (int pos = 0; pos < this.rollBufferSize; pos++) {
/* 279 */       this.futureInputs[pos] = new PendingInput(null);
/* 280 */       this.futureOutputs[pos] = new PendingOutputs();
/*     */     }
/*     */ 
/* 285 */     this.scratchArc = new FST.Arc();
/*     */   }
/*     */ 
/*     */   private void capture() {
/* 289 */     this.captureCount += 1;
/*     */ 
/* 291 */     PendingInput input = this.futureInputs[this.nextWrite];
/*     */ 
/* 293 */     input.state = captureState();
/* 294 */     input.consumed = false;
/* 295 */     input.term.copyChars(this.termAtt.buffer(), 0, this.termAtt.length());
/*     */ 
/* 297 */     this.nextWrite = rollIncr(this.nextWrite);
/*     */ 
/* 300 */     assert (this.nextWrite != this.nextRead);
/*     */   }
/*     */ 
/*     */   private void parse()
/*     */     throws IOException
/*     */   {
/* 318 */     assert (this.inputSkipCount == 0);
/*     */ 
/* 320 */     int curNextRead = this.nextRead;
/*     */ 
/* 323 */     BytesRef matchOutput = null;
/* 324 */     int matchInputLength = 0;
/* 325 */     int matchEndOffset = -1;
/*     */ 
/* 327 */     BytesRef pendingOutput = (BytesRef)this.fst.outputs.getNoOutput();
/* 328 */     this.fst.getFirstArc(this.scratchArc);
/*     */ 
/* 330 */     assert (this.scratchArc.output == this.fst.outputs.getNoOutput());
/*     */ 
/* 332 */     int tokenCount = 0;
/*     */     while (true)
/*     */     {
/* 342 */       int inputEndOffset = 0;
/*     */       char[] buffer;
/*     */       int bufferLen;
/* 344 */       if (curNextRead == this.nextWrite)
/*     */       {
/* 349 */         if (this.finished)
/*     */         {
/*     */           break;
/*     */         }
/* 353 */         assert (this.futureInputs[this.nextWrite].consumed);
/*     */ 
/* 358 */         if (this.input.incrementToken()) {
/* 359 */           char[] buffer = this.termAtt.buffer();
/* 360 */           int bufferLen = this.termAtt.length();
/* 361 */           PendingInput input = this.futureInputs[this.nextWrite];
/* 362 */           this.lastStartOffset = (input.startOffset = this.offsetAtt.startOffset());
/* 363 */           this.lastEndOffset = (input.endOffset = this.offsetAtt.endOffset());
/* 364 */           inputEndOffset = input.endOffset;
/*     */ 
/* 366 */           if (this.nextRead != this.nextWrite)
/* 367 */             capture();
/*     */           else {
/* 369 */             input.consumed = false;
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 375 */           this.finished = true;
/* 376 */           break;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 381 */         buffer = this.futureInputs[curNextRead].term.chars;
/* 382 */         bufferLen = this.futureInputs[curNextRead].term.length;
/* 383 */         inputEndOffset = this.futureInputs[curNextRead].endOffset;
/*     */       }
/*     */ 
/* 387 */       tokenCount++;
/*     */ 
/* 390 */       int bufUpto = 0;
/* 391 */       while (bufUpto < bufferLen) {
/* 392 */         int codePoint = Character.codePointAt(buffer, bufUpto, bufferLen);
/* 393 */         if (this.fst.findTargetArc(this.ignoreCase ? Character.toLowerCase(codePoint) : codePoint, this.scratchArc, this.scratchArc, this.fstReader) == null)
/*     */         {
/*     */           break label526;
/*     */         }
/*     */ 
/* 399 */         pendingOutput = (BytesRef)this.fst.outputs.add(pendingOutput, this.scratchArc.output);
/*     */ 
/* 401 */         bufUpto += Character.charCount(codePoint);
/*     */       }
/*     */ 
/* 406 */       if (this.scratchArc.isFinal()) {
/* 407 */         matchOutput = (BytesRef)this.fst.outputs.add(pendingOutput, this.scratchArc.nextFinalOutput);
/* 408 */         matchInputLength = tokenCount;
/* 409 */         matchEndOffset = inputEndOffset;
/*     */       }
/*     */ 
/* 415 */       if (this.fst.findTargetArc(0, this.scratchArc, this.scratchArc, this.fstReader) == null)
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 423 */       pendingOutput = (BytesRef)this.fst.outputs.add(pendingOutput, this.scratchArc.output);
/* 424 */       if (this.nextRead == this.nextWrite) {
/* 425 */         capture();
/*     */       }
/*     */ 
/* 429 */       curNextRead = rollIncr(curNextRead);
/*     */     }
/*     */ 
/* 432 */     label526: if ((this.nextRead == this.nextWrite) && (!this.finished))
/*     */     {
/* 434 */       this.nextWrite = rollIncr(this.nextWrite);
/*     */     }
/*     */ 
/* 437 */     if (matchOutput != null)
/*     */     {
/* 439 */       this.inputSkipCount = matchInputLength;
/* 440 */       addOutput(matchOutput, matchInputLength, matchEndOffset);
/* 441 */     } else if (this.nextRead != this.nextWrite)
/*     */     {
/* 445 */       this.inputSkipCount = 1;
/*     */     } else {
/* 447 */       assert (this.finished);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void addOutput(BytesRef bytes, int matchInputLength, int matchEndOffset)
/*     */   {
/* 455 */     this.bytesReader.reset(bytes.bytes, bytes.offset, bytes.length);
/*     */ 
/* 457 */     int code = this.bytesReader.readVInt();
/* 458 */     boolean keepOrig = (code & 0x1) == 0;
/* 459 */     int count = code >>> 1;
/*     */ 
/* 461 */     for (int outputIDX = 0; outputIDX < count; outputIDX++) {
/* 462 */       this.synonyms.words.get(this.bytesReader.readVInt(), this.scratchBytes);
/*     */ 
/* 465 */       UnicodeUtil.UTF8toUTF16(this.scratchBytes, this.scratchChars);
/* 466 */       int lastStart = this.scratchChars.offset;
/* 467 */       int chEnd = lastStart + this.scratchChars.length;
/* 468 */       int outputUpto = this.nextRead;
/* 469 */       for (int chIDX = lastStart; chIDX <= chEnd; chIDX++) {
/* 470 */         if ((chIDX == chEnd) || (this.scratchChars.chars[chIDX] == 0)) {
/* 471 */           int outputLen = chIDX - lastStart;
/*     */ 
/* 474 */           assert (outputLen > 0) : ("output contains empty string: " + this.scratchChars);
/*     */           int posLen;
/*     */           int endOffset;
/*     */           int posLen;
/* 477 */           if ((chIDX == chEnd) && (lastStart == this.scratchChars.offset))
/*     */           {
/* 482 */             int endOffset = matchEndOffset;
/* 483 */             posLen = keepOrig ? matchInputLength : 1;
/*     */           }
/*     */           else
/*     */           {
/* 489 */             endOffset = -1;
/* 490 */             posLen = 1;
/*     */           }
/* 492 */           this.futureOutputs[outputUpto].add(this.scratchChars.chars, lastStart, outputLen, endOffset, posLen);
/*     */ 
/* 494 */           lastStart = 1 + chIDX;
/*     */ 
/* 496 */           outputUpto = rollIncr(outputUpto);
/* 497 */           assert (this.futureOutputs[outputUpto].posIncr == 1) : ("outputUpto=" + outputUpto + " vs nextWrite=" + this.nextWrite);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 502 */     int upto = this.nextRead;
/* 503 */     for (int idx = 0; idx < matchInputLength; idx++) {
/* 504 */       this.futureInputs[upto].keepOrig |= keepOrig;
/* 505 */       this.futureInputs[upto].matched = true;
/* 506 */       upto = rollIncr(upto);
/*     */     }
/*     */   }
/*     */ 
/*     */   private int rollIncr(int count)
/*     */   {
/* 512 */     count++;
/* 513 */     if (count == this.rollBufferSize) {
/* 514 */       return 0;
/*     */     }
/* 516 */     return count;
/*     */   }
/*     */ 
/*     */   int getCaptureCount()
/*     */   {
/* 522 */     return this.captureCount;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*     */     while (true)
/* 534 */       if (this.inputSkipCount != 0)
/*     */       {
/* 541 */         PendingInput input = this.futureInputs[this.nextRead];
/* 542 */         PendingOutputs outputs = this.futureOutputs[this.nextRead];
/*     */ 
/* 546 */         if ((!input.consumed) && ((input.keepOrig) || (!input.matched))) {
/* 547 */           if (input.state != null)
/*     */           {
/* 550 */             restoreState(input.state);
/*     */           }
/*     */           else
/*     */           {
/* 554 */             assert (this.inputSkipCount == 1) : ("inputSkipCount=" + this.inputSkipCount + " nextRead=" + this.nextRead);
/*     */           }
/* 556 */           input.reset();
/* 557 */           if (outputs.count > 0) {
/* 558 */             outputs.posIncr = 0;
/*     */           } else {
/* 560 */             this.nextRead = rollIncr(this.nextRead);
/* 561 */             this.inputSkipCount -= 1;
/*     */           }
/*     */ 
/* 564 */           return true;
/* 565 */         }if (outputs.upto < outputs.count)
/*     */         {
/* 568 */           input.reset();
/* 569 */           int posIncr = outputs.posIncr;
/* 570 */           CharsRef output = outputs.pullNext();
/* 571 */           clearAttributes();
/* 572 */           this.termAtt.copyBuffer(output.chars, output.offset, output.length);
/* 573 */           this.typeAtt.setType("SYNONYM");
/* 574 */           int endOffset = outputs.getLastEndOffset();
/* 575 */           if (endOffset == -1) {
/* 576 */             endOffset = input.endOffset;
/*     */           }
/* 578 */           this.offsetAtt.setOffset(input.startOffset, endOffset);
/* 579 */           this.posIncrAtt.setPositionIncrement(posIncr);
/* 580 */           this.posLenAtt.setPositionLength(outputs.getLastPosLength());
/* 581 */           if (outputs.count == 0)
/*     */           {
/* 584 */             this.nextRead = rollIncr(this.nextRead);
/* 585 */             this.inputSkipCount -= 1;
/*     */           }
/*     */ 
/* 588 */           return true;
/*     */         }
/*     */ 
/* 592 */         input.reset();
/* 593 */         this.nextRead = rollIncr(this.nextRead);
/* 594 */         this.inputSkipCount -= 1;
/*     */       }
/*     */       else
/*     */       {
/* 598 */         if ((this.finished) && (this.nextRead == this.nextWrite))
/*     */         {
/* 601 */           PendingOutputs outputs = this.futureOutputs[this.nextRead];
/* 602 */           if (outputs.upto < outputs.count) {
/* 603 */             int posIncr = outputs.posIncr;
/* 604 */             CharsRef output = outputs.pullNext();
/* 605 */             this.futureInputs[this.nextRead].reset();
/* 606 */             if (outputs.count == 0) {
/* 607 */               this.nextWrite = (this.nextRead = rollIncr(this.nextRead));
/*     */             }
/* 609 */             clearAttributes();
/*     */ 
/* 611 */             this.offsetAtt.setOffset(this.lastStartOffset, this.lastEndOffset);
/* 612 */             this.termAtt.copyBuffer(output.chars, output.offset, output.length);
/* 613 */             this.typeAtt.setType("SYNONYM");
/*     */ 
/* 615 */             this.posIncrAtt.setPositionIncrement(posIncr);
/*     */ 
/* 617 */             return true;
/*     */           }
/* 619 */           return false;
/*     */         }
/*     */ 
/* 624 */         parse();
/*     */       }
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 630 */     super.reset();
/* 631 */     this.captureCount = 0;
/* 632 */     this.finished = false;
/* 633 */     this.inputSkipCount = 0;
/* 634 */     this.nextRead = (this.nextWrite = 0);
/*     */ 
/* 641 */     for (PendingInput input : this.futureInputs) {
/* 642 */       input.reset();
/*     */     }
/* 644 */     for (PendingOutputs output : this.futureOutputs)
/* 645 */       output.reset();
/*     */   }
/*     */ 
/*     */   private static class PendingOutputs
/*     */   {
/*     */     CharsRef[] outputs;
/*     */     int[] endOffsets;
/*     */     int[] posLengths;
/*     */     int upto;
/*     */     int count;
/* 165 */     int posIncr = 1;
/*     */     int lastEndOffset;
/*     */     int lastPosLength;
/*     */ 
/*     */     public PendingOutputs()
/*     */     {
/* 170 */       this.outputs = new CharsRef[1];
/* 171 */       this.endOffsets = new int[1];
/* 172 */       this.posLengths = new int[1];
/*     */     }
/*     */ 
/*     */     public void reset() {
/* 176 */       this.upto = (this.count = 0);
/* 177 */       this.posIncr = 1;
/*     */     }
/*     */ 
/*     */     public CharsRef pullNext() {
/* 181 */       assert (this.upto < this.count);
/* 182 */       this.lastEndOffset = this.endOffsets[this.upto];
/* 183 */       this.lastPosLength = this.posLengths[this.upto];
/* 184 */       CharsRef result = this.outputs[(this.upto++)];
/* 185 */       this.posIncr = 0;
/* 186 */       if (this.upto == this.count) {
/* 187 */         reset();
/*     */       }
/* 189 */       return result;
/*     */     }
/*     */ 
/*     */     public int getLastEndOffset() {
/* 193 */       return this.lastEndOffset;
/*     */     }
/*     */ 
/*     */     public int getLastPosLength() {
/* 197 */       return this.lastPosLength;
/*     */     }
/*     */ 
/*     */     public void add(char[] output, int offset, int len, int endOffset, int posLength) {
/* 201 */       if (this.count == this.outputs.length) {
/* 202 */         CharsRef[] next = new CharsRef[ArrayUtil.oversize(1 + this.count, RamUsageEstimator.NUM_BYTES_OBJECT_REF)];
/* 203 */         System.arraycopy(this.outputs, 0, next, 0, this.count);
/* 204 */         this.outputs = next;
/*     */       }
/* 206 */       if (this.count == this.endOffsets.length) {
/* 207 */         int[] next = new int[ArrayUtil.oversize(1 + this.count, 4)];
/* 208 */         System.arraycopy(this.endOffsets, 0, next, 0, this.count);
/* 209 */         this.endOffsets = next;
/*     */       }
/* 211 */       if (this.count == this.posLengths.length) {
/* 212 */         int[] next = new int[ArrayUtil.oversize(1 + this.count, 4)];
/* 213 */         System.arraycopy(this.posLengths, 0, next, 0, this.count);
/* 214 */         this.posLengths = next;
/*     */       }
/* 216 */       if (this.outputs[this.count] == null) {
/* 217 */         this.outputs[this.count] = new CharsRef();
/*     */       }
/* 219 */       this.outputs[this.count].copyChars(output, offset, len);
/*     */ 
/* 223 */       this.endOffsets[this.count] = endOffset;
/* 224 */       this.posLengths[this.count] = posLength;
/* 225 */       this.count += 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PendingInput
/*     */   {
/* 137 */     final CharsRef term = new CharsRef();
/*     */     AttributeSource.State state;
/*     */     boolean keepOrig;
/*     */     boolean matched;
/* 141 */     boolean consumed = true;
/*     */     int startOffset;
/*     */     int endOffset;
/*     */ 
/*     */     public void reset()
/*     */     {
/* 146 */       this.state = null;
/* 147 */       this.consumed = true;
/* 148 */       this.keepOrig = false;
/* 149 */       this.matched = false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.synonym.SynonymFilter
 * JD-Core Version:    0.6.2
 */