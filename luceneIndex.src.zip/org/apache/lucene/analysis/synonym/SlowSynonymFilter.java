/*     */ package org.apache.lucene.analysis.synonym;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import org.apache.lucene.analysis.Token;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
/*     */ import org.apache.lucene.analysis.util.CharArrayMap;
/*     */ import org.apache.lucene.util.AttributeSource;
/*     */ 
/*     */ @Deprecated
/*     */ final class SlowSynonymFilter extends TokenFilter
/*     */ {
/*     */   private final SlowSynonymMap map;
/*     */   private Iterator<AttributeSource> replacement;
/*     */   private LinkedList<AttributeSource> buffer;
/*     */   private LinkedList<AttributeSource> matched;
/*     */   private boolean exhausted;
/*     */ 
/*     */   public SlowSynonymFilter(TokenStream in, SlowSynonymMap map)
/*     */   {
/*  50 */     super(in);
/*  51 */     if (map == null) {
/*  52 */       throw new IllegalArgumentException("map is required");
/*     */     }
/*  54 */     this.map = map;
/*     */ 
/*  56 */     addAttribute(CharTermAttribute.class);
/*  57 */     addAttribute(PositionIncrementAttribute.class);
/*  58 */     addAttribute(OffsetAttribute.class);
/*  59 */     addAttribute(TypeAttribute.class);
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*     */     while (true)
/*     */     {
/*  85 */       if ((this.replacement != null) && (this.replacement.hasNext())) {
/*  86 */         copy(this, (AttributeSource)this.replacement.next());
/*  87 */         return true;
/*     */       }
/*     */ 
/*  91 */       AttributeSource firstTok = nextTok();
/*  92 */       if (firstTok == null) return false;
/*  93 */       CharTermAttribute termAtt = (CharTermAttribute)firstTok.addAttribute(CharTermAttribute.class);
/*  94 */       SlowSynonymMap result = this.map.submap != null ? (SlowSynonymMap)this.map.submap.get(termAtt.buffer(), 0, termAtt.length()) : null;
/*  95 */       if (result == null) {
/*  96 */         copy(this, firstTok);
/*  97 */         return true;
/*     */       }
/*     */ 
/* 101 */       if (firstTok == this) {
/* 102 */         firstTok = cloneAttributes();
/*     */       }
/*     */ 
/* 105 */       this.matched = new LinkedList();
/*     */ 
/* 107 */       result = match(result);
/*     */ 
/* 109 */       if (result == null)
/*     */       {
/* 111 */         copy(this, firstTok);
/* 112 */         return true;
/*     */       }
/*     */ 
/* 116 */       ArrayList generated = new ArrayList(result.synonyms.length + this.matched.size() + 1);
/*     */ 
/* 122 */       AttributeSource lastTok = this.matched.isEmpty() ? firstTok : (AttributeSource)this.matched.getLast();
/* 123 */       boolean includeOrig = result.includeOrig();
/*     */ 
/* 125 */       AttributeSource origTok = includeOrig ? firstTok : null;
/* 126 */       PositionIncrementAttribute firstPosIncAtt = (PositionIncrementAttribute)firstTok.addAttribute(PositionIncrementAttribute.class);
/* 127 */       int origPos = firstPosIncAtt.getPositionIncrement();
/* 128 */       int repPos = 0;
/* 129 */       int pos = 0;
/*     */ 
/* 131 */       for (int i = 0; i < result.synonyms.length; i++) {
/* 132 */         Token repTok = result.synonyms[i];
/* 133 */         AttributeSource newTok = firstTok.cloneAttributes();
/* 134 */         CharTermAttribute newTermAtt = (CharTermAttribute)newTok.addAttribute(CharTermAttribute.class);
/* 135 */         OffsetAttribute newOffsetAtt = (OffsetAttribute)newTok.addAttribute(OffsetAttribute.class);
/* 136 */         PositionIncrementAttribute newPosIncAtt = (PositionIncrementAttribute)newTok.addAttribute(PositionIncrementAttribute.class);
/*     */ 
/* 138 */         OffsetAttribute lastOffsetAtt = (OffsetAttribute)lastTok.addAttribute(OffsetAttribute.class);
/*     */ 
/* 140 */         newOffsetAtt.setOffset(newOffsetAtt.startOffset(), lastOffsetAtt.endOffset());
/* 141 */         newTermAtt.copyBuffer(repTok.buffer(), 0, repTok.length());
/* 142 */         repPos += repTok.getPositionIncrement();
/* 143 */         if (i == 0) repPos = origPos;
/*     */ 
/* 146 */         while ((origTok != null) && (origPos <= repPos)) {
/* 147 */           PositionIncrementAttribute origPosInc = (PositionIncrementAttribute)origTok.addAttribute(PositionIncrementAttribute.class);
/* 148 */           origPosInc.setPositionIncrement(origPos - pos);
/* 149 */           generated.add(origTok);
/* 150 */           pos += origPosInc.getPositionIncrement();
/* 151 */           origTok = this.matched.isEmpty() ? null : (AttributeSource)this.matched.removeFirst();
/* 152 */           if (origTok != null) {
/* 153 */             origPosInc = (PositionIncrementAttribute)origTok.addAttribute(PositionIncrementAttribute.class);
/* 154 */             origPos += origPosInc.getPositionIncrement();
/*     */           }
/*     */         }
/*     */ 
/* 158 */         newPosIncAtt.setPositionIncrement(repPos - pos);
/* 159 */         generated.add(newTok);
/* 160 */         pos += newPosIncAtt.getPositionIncrement();
/*     */       }
/*     */ 
/* 164 */       while (origTok != null) {
/* 165 */         PositionIncrementAttribute origPosInc = (PositionIncrementAttribute)origTok.addAttribute(PositionIncrementAttribute.class);
/* 166 */         origPosInc.setPositionIncrement(origPos - pos);
/* 167 */         generated.add(origTok);
/* 168 */         pos += origPosInc.getPositionIncrement();
/* 169 */         origTok = this.matched.isEmpty() ? null : (AttributeSource)this.matched.removeFirst();
/* 170 */         if (origTok != null) {
/* 171 */           origPosInc = (PositionIncrementAttribute)origTok.addAttribute(PositionIncrementAttribute.class);
/* 172 */           origPos += origPosInc.getPositionIncrement();
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 180 */       this.replacement = generated.iterator();
/*     */     }
/*     */   }
/*     */ 
/*     */   private AttributeSource nextTok()
/*     */     throws IOException
/*     */   {
/* 198 */     if ((this.buffer != null) && (!this.buffer.isEmpty())) {
/* 199 */       return (AttributeSource)this.buffer.removeFirst();
/*     */     }
/* 201 */     if ((!this.exhausted) && (this.input.incrementToken())) {
/* 202 */       return this;
/*     */     }
/* 204 */     this.exhausted = true;
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */   private void pushTok(AttributeSource t)
/*     */   {
/* 211 */     if (this.buffer == null) this.buffer = new LinkedList();
/* 212 */     this.buffer.addFirst(t);
/*     */   }
/*     */ 
/*     */   private SlowSynonymMap match(SlowSynonymMap map) throws IOException {
/* 216 */     SlowSynonymMap result = null;
/*     */ 
/* 218 */     if (map.submap != null) {
/* 219 */       AttributeSource tok = nextTok();
/* 220 */       if (tok != null)
/*     */       {
/* 222 */         if (tok == this) {
/* 223 */           tok = cloneAttributes();
/*     */         }
/* 225 */         CharTermAttribute termAtt = (CharTermAttribute)tok.getAttribute(CharTermAttribute.class);
/* 226 */         SlowSynonymMap subMap = (SlowSynonymMap)map.submap.get(termAtt.buffer(), 0, termAtt.length());
/*     */ 
/* 228 */         if (subMap != null)
/*     */         {
/* 230 */           result = match(subMap);
/*     */         }
/*     */ 
/* 233 */         if (result != null) {
/* 234 */           this.matched.addFirst(tok);
/*     */         }
/*     */         else {
/* 237 */           pushTok(tok);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 243 */     if ((result == null) && (map.synonyms != null)) {
/* 244 */       result = map;
/*     */     }
/*     */ 
/* 247 */     return result;
/*     */   }
/*     */ 
/*     */   private void copy(AttributeSource target, AttributeSource source) {
/* 251 */     if (target != source)
/* 252 */       source.copyTo(target);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 257 */     this.input.reset();
/* 258 */     this.replacement = null;
/* 259 */     this.exhausted = false;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.synonym.SlowSynonymFilter
 * JD-Core Version:    0.6.2
 */