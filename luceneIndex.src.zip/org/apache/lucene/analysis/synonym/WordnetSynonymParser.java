/*    */ package org.apache.lucene.analysis.synonym;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.LineNumberReader;
/*    */ import java.io.Reader;
/*    */ import java.text.ParseException;
/*    */ import org.apache.lucene.analysis.Analyzer;
/*    */ import org.apache.lucene.util.CharsRef;
/*    */ 
/*    */ public class WordnetSynonymParser extends SynonymMap.Parser
/*    */ {
/*    */   private final boolean expand;
/*    */ 
/*    */   public WordnetSynonymParser(boolean dedup, boolean expand, Analyzer analyzer)
/*    */   {
/* 39 */     super(dedup, analyzer);
/* 40 */     this.expand = expand;
/*    */   }
/*    */ 
/*    */   public void parse(Reader in) throws IOException, ParseException
/*    */   {
/* 45 */     LineNumberReader br = new LineNumberReader(in);
/*    */     try {
/* 47 */       String line = null;
/* 48 */       String lastSynSetID = "";
/* 49 */       CharsRef[] synset = new CharsRef[8];
/* 50 */       int synsetSize = 0;
/*    */ 
/* 52 */       while ((line = br.readLine()) != null) {
/* 53 */         String synSetID = line.substring(2, 11);
/*    */ 
/* 55 */         if (!synSetID.equals(lastSynSetID)) {
/* 56 */           addInternal(synset, synsetSize);
/* 57 */           synsetSize = 0;
/*    */         }
/*    */ 
/* 60 */         if (synset.length <= synsetSize + 1) {
/* 61 */           CharsRef[] larger = new CharsRef[synset.length * 2];
/* 62 */           System.arraycopy(synset, 0, larger, 0, synsetSize);
/* 63 */           synset = larger;
/*    */         }
/*    */ 
/* 66 */         synset[synsetSize] = parseSynonym(line, synset[synsetSize]);
/* 67 */         synsetSize++;
/* 68 */         lastSynSetID = synSetID;
/*    */       }
/*    */ 
/* 72 */       addInternal(synset, synsetSize);
/*    */     } catch (IllegalArgumentException e) {
/* 74 */       ParseException ex = new ParseException("Invalid synonym rule at line " + br.getLineNumber(), 0);
/* 75 */       ex.initCause(e);
/* 76 */       throw ex;
/*    */     } finally {
/* 78 */       br.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   private CharsRef parseSynonym(String line, CharsRef reuse) throws IOException {
/* 83 */     if (reuse == null) {
/* 84 */       reuse = new CharsRef(8);
/*    */     }
/*    */ 
/* 87 */     int start = line.indexOf('\'') + 1;
/* 88 */     int end = line.lastIndexOf('\'');
/*    */ 
/* 90 */     String text = line.substring(start, end).replace("''", "'");
/* 91 */     return analyze(text, reuse);
/*    */   }
/*    */ 
/*    */   private void addInternal(CharsRef[] synset, int size) {
/* 95 */     if (size <= 1) {
/* 96 */       return;
/*    */     }
/*    */ 
/* 99 */     if (this.expand) {
/* 100 */       for (int i = 0; i < size; i++) {
/* 101 */         for (int j = 0; j < size; j++)
/* 102 */           add(synset[i], synset[j], false);
/*    */       }
/*    */     }
/*    */     else
/* 106 */       for (int i = 0; i < size; i++)
/* 107 */         add(synset[i], synset[0], false);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.synonym.WordnetSynonymParser
 * JD-Core Version:    0.6.2
 */