/*     */ package org.apache.lucene.analysis.path;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ public class PathHierarchyTokenizer extends Tokenizer
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 1024;
/*     */   public static final char DEFAULT_DELIMITER = '/';
/*     */   public static final int DEFAULT_SKIP = 0;
/*     */   private final char delimiter;
/*     */   private final char replacement;
/*     */   private final int skip;
/*  99 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/* 100 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/* 101 */   private final PositionIncrementAttribute posAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/* 102 */   private int startPosition = 0;
/* 103 */   private int skipped = 0;
/* 104 */   private boolean endDelimiter = false;
/*     */   private StringBuilder resultToken;
/* 107 */   private int charsRead = 0;
/*     */ 
/*     */   public PathHierarchyTokenizer(Reader input)
/*     */   {
/*  47 */     this(input, 1024, '/', '/', 0);
/*     */   }
/*     */ 
/*     */   public PathHierarchyTokenizer(Reader input, int skip) {
/*  51 */     this(input, 1024, '/', '/', skip);
/*     */   }
/*     */ 
/*     */   public PathHierarchyTokenizer(Reader input, int bufferSize, char delimiter) {
/*  55 */     this(input, bufferSize, delimiter, delimiter, 0);
/*     */   }
/*     */ 
/*     */   public PathHierarchyTokenizer(Reader input, char delimiter, char replacement) {
/*  59 */     this(input, 1024, delimiter, replacement, 0);
/*     */   }
/*     */ 
/*     */   public PathHierarchyTokenizer(Reader input, char delimiter, char replacement, int skip) {
/*  63 */     this(input, 1024, delimiter, replacement, skip);
/*     */   }
/*     */ 
/*     */   public PathHierarchyTokenizer(AttributeSource.AttributeFactory factory, Reader input, char delimiter, char replacement, int skip) {
/*  67 */     this(factory, input, 1024, delimiter, replacement, skip);
/*     */   }
/*     */ 
/*     */   public PathHierarchyTokenizer(Reader input, int bufferSize, char delimiter, char replacement, int skip) {
/*  71 */     this(AttributeSource.AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY, input, bufferSize, delimiter, replacement, skip);
/*     */   }
/*     */ 
/*     */   public PathHierarchyTokenizer(AttributeSource.AttributeFactory factory, Reader input, int bufferSize, char delimiter, char replacement, int skip)
/*     */   {
/*  76 */     super(factory, input);
/*  77 */     if (bufferSize < 0) {
/*  78 */       throw new IllegalArgumentException("bufferSize cannot be negative");
/*     */     }
/*  80 */     if (skip < 0) {
/*  81 */       throw new IllegalArgumentException("skip cannot be negative");
/*     */     }
/*  83 */     this.termAtt.resizeBuffer(bufferSize);
/*     */ 
/*  85 */     this.delimiter = delimiter;
/*  86 */     this.replacement = replacement;
/*  87 */     this.skip = skip;
/*  88 */     this.resultToken = new StringBuilder(bufferSize);
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken()
/*     */     throws IOException
/*     */   {
/* 112 */     clearAttributes();
/* 113 */     this.termAtt.append(this.resultToken);
/* 114 */     if (this.resultToken.length() == 0) {
/* 115 */       this.posAtt.setPositionIncrement(1);
/*     */     }
/*     */     else {
/* 118 */       this.posAtt.setPositionIncrement(0);
/*     */     }
/* 120 */     int length = 0;
/* 121 */     boolean added = false;
/* 122 */     if (this.endDelimiter) {
/* 123 */       this.termAtt.append(this.replacement);
/* 124 */       length++;
/* 125 */       this.endDelimiter = false;
/* 126 */       added = true;
/*     */     }
/*     */     while (true)
/*     */     {
/* 130 */       int c = this.input.read();
/* 131 */       if (c >= 0) {
/* 132 */         this.charsRead += 1;
/*     */       } else {
/* 134 */         if (this.skipped > this.skip) {
/* 135 */           length += this.resultToken.length();
/* 136 */           this.termAtt.setLength(length);
/* 137 */           this.offsetAtt.setOffset(correctOffset(this.startPosition), correctOffset(this.startPosition + length));
/* 138 */           if (added) {
/* 139 */             this.resultToken.setLength(0);
/* 140 */             this.resultToken.append(this.termAtt.buffer(), 0, length);
/*     */           }
/* 142 */           return added;
/*     */         }
/*     */ 
/* 145 */         return false;
/*     */       }
/*     */ 
/* 148 */       if (!added) {
/* 149 */         added = true;
/* 150 */         this.skipped += 1;
/* 151 */         if (this.skipped > this.skip) {
/* 152 */           this.termAtt.append(c == this.delimiter ? this.replacement : (char)c);
/* 153 */           length++;
/*     */         }
/*     */         else {
/* 156 */           this.startPosition += 1;
/*     */         }
/*     */ 
/*     */       }
/* 160 */       else if (c == this.delimiter) {
/* 161 */         if (this.skipped > this.skip) {
/* 162 */           this.endDelimiter = true;
/* 163 */           break;
/*     */         }
/* 165 */         this.skipped += 1;
/* 166 */         if (this.skipped > this.skip) {
/* 167 */           this.termAtt.append(this.replacement);
/* 168 */           length++;
/*     */         }
/*     */         else {
/* 171 */           this.startPosition += 1;
/*     */         }
/*     */ 
/*     */       }
/* 175 */       else if (this.skipped > this.skip) {
/* 176 */         this.termAtt.append((char)c);
/* 177 */         length++;
/*     */       }
/*     */       else {
/* 180 */         this.startPosition += 1;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 185 */     length += this.resultToken.length();
/* 186 */     this.termAtt.setLength(length);
/* 187 */     this.offsetAtt.setOffset(correctOffset(this.startPosition), correctOffset(this.startPosition + length));
/* 188 */     this.resultToken.setLength(0);
/* 189 */     this.resultToken.append(this.termAtt.buffer(), 0, length);
/* 190 */     return true;
/*     */   }
/*     */ 
/*     */   public final void end() throws IOException
/*     */   {
/* 195 */     super.end();
/*     */ 
/* 197 */     int finalOffset = correctOffset(this.charsRead);
/* 198 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 203 */     super.reset();
/* 204 */     this.resultToken.setLength(0);
/* 205 */     this.charsRead = 0;
/* 206 */     this.endDelimiter = false;
/* 207 */     this.skipped = 0;
/* 208 */     this.startPosition = 0;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.path.PathHierarchyTokenizer
 * JD-Core Version:    0.6.2
 */