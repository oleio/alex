/*    */ package org.apache.lucene.analysis.fa;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.analysis.CharFilter;
/*    */ 
/*    */ public class PersianCharFilter extends CharFilter
/*    */ {
/*    */   public PersianCharFilter(Reader in)
/*    */   {
/* 32 */     super(in);
/*    */   }
/*    */ 
/*    */   public int read(char[] cbuf, int off, int len) throws IOException
/*    */   {
/* 37 */     int charsRead = this.input.read(cbuf, off, len);
/* 38 */     if (charsRead > 0) {
/* 39 */       int end = off + charsRead;
/* 40 */       while (off < end) {
/* 41 */         if (cbuf[off] == '‌')
/* 42 */           cbuf[off] = ' ';
/* 43 */         off++;
/*    */       }
/*    */     }
/* 46 */     return charsRead;
/*    */   }
/*    */ 
/*    */   public int read()
/*    */     throws IOException
/*    */   {
/* 52 */     int ch = this.input.read();
/* 53 */     if (ch == 8204) {
/* 54 */       return 32;
/*    */     }
/* 56 */     return ch;
/*    */   }
/*    */ 
/*    */   protected int correct(int currentOff)
/*    */   {
/* 62 */     return currentOff;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.fa.PersianCharFilter
 * JD-Core Version:    0.6.2
 */