/*     */ package org.apache.lucene.analysis.fr;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ @Deprecated
/*     */ public class FrenchStemmer
/*     */ {
/*  35 */   private static final Locale locale = new Locale("fr", "FR");
/*     */ 
/*  41 */   private StringBuilder sb = new StringBuilder();
/*     */ 
/*  46 */   private StringBuilder tb = new StringBuilder();
/*     */   private String R0;
/*     */   private String RV;
/*     */   private String R1;
/*     */   private String R2;
/*     */   private boolean suite;
/*     */   private boolean modified;
/*     */ 
/*     */   protected String stem(String term)
/*     */   {
/*  94 */     if (!isStemmable(term)) {
/*  95 */       return term;
/*     */     }
/*     */ 
/*  99 */     term = term.toLowerCase(locale);
/*     */ 
/* 102 */     this.sb.delete(0, this.sb.length());
/* 103 */     this.sb.insert(0, term);
/*     */ 
/* 106 */     this.modified = false;
/* 107 */     this.suite = false;
/*     */ 
/* 109 */     this.sb = treatVowels(this.sb);
/*     */ 
/* 111 */     setStrings();
/*     */ 
/* 113 */     step1();
/*     */ 
/* 115 */     if ((!this.modified) || (this.suite))
/*     */     {
/* 117 */       if (this.RV != null)
/*     */       {
/* 119 */         this.suite = step2a();
/* 120 */         if (!this.suite) {
/* 121 */           step2b();
/*     */         }
/*     */       }
/*     */     }
/* 125 */     if ((this.modified) || (this.suite))
/* 126 */       step3();
/*     */     else {
/* 128 */       step4();
/*     */     }
/* 130 */     step5();
/*     */ 
/* 132 */     step6();
/*     */ 
/* 134 */     return this.sb.toString();
/*     */   }
/*     */ 
/*     */   private void setStrings()
/*     */   {
/* 143 */     this.R0 = this.sb.toString();
/* 144 */     this.RV = retrieveRV(this.sb);
/* 145 */     this.R1 = retrieveR(this.sb);
/* 146 */     if (this.R1 != null)
/*     */     {
/* 148 */       this.tb.delete(0, this.tb.length());
/* 149 */       this.tb.insert(0, this.R1);
/* 150 */       this.R2 = retrieveR(this.tb);
/*     */     }
/*     */     else {
/* 153 */       this.R2 = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void step1()
/*     */   {
/* 161 */     String[] suffix = { "ances", "iqUes", "ismes", "ables", "istes", "ance", "iqUe", "isme", "able", "iste" };
/* 162 */     deleteFrom(this.R2, suffix);
/*     */ 
/* 164 */     replaceFrom(this.R2, new String[] { "logies", "logie" }, "log");
/* 165 */     replaceFrom(this.R2, new String[] { "usions", "utions", "usion", "ution" }, "u");
/* 166 */     replaceFrom(this.R2, new String[] { "ences", "ence" }, "ent");
/*     */ 
/* 168 */     String[] search = { "atrices", "ateurs", "ations", "atrice", "ateur", "ation" };
/* 169 */     deleteButSuffixFromElseReplace(this.R2, search, "ic", true, this.R0, "iqU");
/*     */ 
/* 171 */     deleteButSuffixFromElseReplace(this.R2, new String[] { "ements", "ement" }, "eus", false, this.R0, "eux");
/* 172 */     deleteButSuffixFrom(this.R2, new String[] { "ements", "ement" }, "ativ", false);
/* 173 */     deleteButSuffixFrom(this.R2, new String[] { "ements", "ement" }, "iv", false);
/* 174 */     deleteButSuffixFrom(this.R2, new String[] { "ements", "ement" }, "abl", false);
/* 175 */     deleteButSuffixFrom(this.R2, new String[] { "ements", "ement" }, "iqU", false);
/*     */ 
/* 177 */     deleteFromIfTestVowelBeforeIn(this.R1, new String[] { "issements", "issement" }, false, this.R0);
/* 178 */     deleteFrom(this.RV, new String[] { "ements", "ement" });
/*     */ 
/* 180 */     deleteButSuffixFromElseReplace(this.R2, new String[] { "ités", "ité" }, "abil", false, this.R0, "abl");
/* 181 */     deleteButSuffixFromElseReplace(this.R2, new String[] { "ités", "ité" }, "ic", false, this.R0, "iqU");
/* 182 */     deleteButSuffixFrom(this.R2, new String[] { "ités", "ité" }, "iv", true);
/*     */ 
/* 184 */     String[] autre = { "ifs", "ives", "if", "ive" };
/* 185 */     deleteButSuffixFromElseReplace(this.R2, autre, "icat", false, this.R0, "iqU");
/* 186 */     deleteButSuffixFromElseReplace(this.R2, autre, "at", true, this.R2, "iqU");
/*     */ 
/* 188 */     replaceFrom(this.R0, new String[] { "eaux" }, "eau");
/*     */ 
/* 190 */     replaceFrom(this.R1, new String[] { "aux" }, "al");
/*     */ 
/* 192 */     deleteButSuffixFromElseReplace(this.R2, new String[] { "euses", "euse" }, "", true, this.R1, "eux");
/*     */ 
/* 194 */     deleteFrom(this.R2, new String[] { "eux" });
/*     */ 
/* 197 */     boolean temp = false;
/* 198 */     temp = replaceFrom(this.RV, new String[] { "amment" }, "ant");
/* 199 */     if (temp == true)
/* 200 */       this.suite = true;
/* 201 */     temp = replaceFrom(this.RV, new String[] { "emment" }, "ent");
/* 202 */     if (temp == true)
/* 203 */       this.suite = true;
/* 204 */     temp = deleteFromIfTestVowelBeforeIn(this.RV, new String[] { "ments", "ment" }, true, this.RV);
/* 205 */     if (temp == true)
/* 206 */       this.suite = true;
/*     */   }
/*     */ 
/*     */   private boolean step2a()
/*     */   {
/* 219 */     String[] search = { "îmes", "îtes", "iraIent", "irait", "irais", "irai", "iras", "ira", "irent", "iriez", "irez", "irions", "irons", "iront", "issaIent", "issais", "issantes", "issante", "issants", "issant", "issait", "issais", "issions", "issons", "issiez", "issez", "issent", "isses", "isse", "ir", "is", "ît", "it", "ies", "ie", "i" };
/*     */ 
/* 224 */     return deleteFromIfTestVowelBeforeIn(this.RV, search, false, this.RV);
/*     */   }
/*     */ 
/*     */   private void step2b()
/*     */   {
/* 233 */     String[] suffix = { "eraIent", "erais", "erait", "erai", "eras", "erions", "eriez", "erons", "eront", "erez", "èrent", "era", "ées", "iez", "ée", "és", "er", "ez", "é" };
/*     */ 
/* 236 */     deleteFrom(this.RV, suffix);
/*     */ 
/* 238 */     String[] search = { "assions", "assiez", "assent", "asses", "asse", "aIent", "antes", "aIent", "Aient", "ante", "âmes", "âtes", "ants", "ant", "ait", "aît", "ais", "Ait", "Aît", "Ais", "ât", "as", "ai", "Ai", "a" };
/*     */ 
/* 241 */     deleteButSuffixFrom(this.RV, search, "e", true);
/*     */ 
/* 243 */     deleteFrom(this.R2, new String[] { "ions" });
/*     */   }
/*     */ 
/*     */   private void step3()
/*     */   {
/* 251 */     if (this.sb.length() > 0)
/*     */     {
/* 253 */       char ch = this.sb.charAt(this.sb.length() - 1);
/* 254 */       if (ch == 'Y')
/*     */       {
/* 256 */         this.sb.setCharAt(this.sb.length() - 1, 'i');
/* 257 */         setStrings();
/*     */       }
/* 259 */       else if (ch == 'ç')
/*     */       {
/* 261 */         this.sb.setCharAt(this.sb.length() - 1, 'c');
/* 262 */         setStrings();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void step4()
/*     */   {
/* 272 */     if (this.sb.length() > 1)
/*     */     {
/* 274 */       char ch = this.sb.charAt(this.sb.length() - 1);
/* 275 */       if (ch == 's')
/*     */       {
/* 277 */         char b = this.sb.charAt(this.sb.length() - 2);
/* 278 */         if ((b != 'a') && (b != 'i') && (b != 'o') && (b != 'u') && (b != 'è') && (b != 's'))
/*     */         {
/* 280 */           this.sb.delete(this.sb.length() - 1, this.sb.length());
/* 281 */           setStrings();
/*     */         }
/*     */       }
/*     */     }
/* 285 */     boolean found = deleteFromIfPrecededIn(this.R2, new String[] { "ion" }, this.RV, "s");
/* 286 */     if (!found) {
/* 287 */       found = deleteFromIfPrecededIn(this.R2, new String[] { "ion" }, this.RV, "t");
/*     */     }
/* 289 */     replaceFrom(this.RV, new String[] { "Ière", "ière", "Ier", "ier" }, "i");
/* 290 */     deleteFrom(this.RV, new String[] { "e" });
/* 291 */     deleteFromIfPrecededIn(this.RV, new String[] { "ë" }, this.R0, "gu");
/*     */   }
/*     */ 
/*     */   private void step5()
/*     */   {
/* 299 */     if (this.R0 != null)
/*     */     {
/* 301 */       if ((this.R0.endsWith("enn")) || (this.R0.endsWith("onn")) || (this.R0.endsWith("ett")) || (this.R0.endsWith("ell")) || (this.R0.endsWith("eill")))
/*     */       {
/* 303 */         this.sb.delete(this.sb.length() - 1, this.sb.length());
/* 304 */         setStrings();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void step6()
/*     */   {
/* 314 */     if ((this.R0 != null) && (this.R0.length() > 0))
/*     */     {
/* 316 */       boolean seenVowel = false;
/* 317 */       boolean seenConson = false;
/* 318 */       int pos = -1;
/* 319 */       for (int i = this.R0.length() - 1; i > -1; i--)
/*     */       {
/* 321 */         char ch = this.R0.charAt(i);
/* 322 */         if (isVowel(ch))
/*     */         {
/* 324 */           if (!seenVowel)
/*     */           {
/* 326 */             if ((ch == 'é') || (ch == 'è'))
/*     */             {
/* 328 */               pos = i;
/* 329 */               break;
/*     */             }
/*     */           }
/* 332 */           seenVowel = true;
/*     */         }
/*     */         else
/*     */         {
/* 336 */           if (seenVowel) {
/*     */             break;
/*     */           }
/* 339 */           seenConson = true;
/*     */         }
/*     */       }
/* 342 */       if ((pos > -1) && (seenConson) && (!seenVowel))
/* 343 */         this.sb.setCharAt(pos, 'e');
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean deleteFromIfPrecededIn(String source, String[] search, String from, String prefix)
/*     */   {
/* 357 */     boolean found = false;
/* 358 */     if (source != null)
/*     */     {
/* 360 */       for (int i = 0; i < search.length; i++) {
/* 361 */         if (source.endsWith(search[i]))
/*     */         {
/* 363 */           if ((from != null) && (from.endsWith(prefix + search[i])))
/*     */           {
/* 365 */             this.sb.delete(this.sb.length() - search[i].length(), this.sb.length());
/* 366 */             found = true;
/* 367 */             setStrings();
/* 368 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 373 */     return found;
/*     */   }
/*     */ 
/*     */   private boolean deleteFromIfTestVowelBeforeIn(String source, String[] search, boolean vowel, String from)
/*     */   {
/* 386 */     boolean found = false;
/* 387 */     if ((source != null) && (from != null))
/*     */     {
/* 389 */       for (int i = 0; i < search.length; i++) {
/* 390 */         if (source.endsWith(search[i]))
/*     */         {
/* 392 */           if (search[i].length() + 1 <= from.length())
/*     */           {
/* 394 */             boolean test = isVowel(this.sb.charAt(this.sb.length() - (search[i].length() + 1)));
/* 395 */             if (test == vowel)
/*     */             {
/* 397 */               this.sb.delete(this.sb.length() - search[i].length(), this.sb.length());
/* 398 */               this.modified = true;
/* 399 */               found = true;
/* 400 */               setStrings();
/* 401 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 407 */     return found;
/*     */   }
/*     */ 
/*     */   private void deleteButSuffixFrom(String source, String[] search, String prefix, boolean without)
/*     */   {
/* 419 */     if (source != null)
/*     */     {
/* 421 */       for (int i = 0; i < search.length; i++) {
/* 422 */         if (source.endsWith(prefix + search[i]))
/*     */         {
/* 424 */           this.sb.delete(this.sb.length() - (prefix.length() + search[i].length()), this.sb.length());
/* 425 */           this.modified = true;
/* 426 */           setStrings();
/* 427 */           break;
/*     */         }
/* 429 */         if ((without) && (source.endsWith(search[i])))
/*     */         {
/* 431 */           this.sb.delete(this.sb.length() - search[i].length(), this.sb.length());
/* 432 */           this.modified = true;
/* 433 */           setStrings();
/* 434 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void deleteButSuffixFromElseReplace(String source, String[] search, String prefix, boolean without, String from, String replace)
/*     */   {
/* 451 */     if (source != null)
/*     */     {
/* 453 */       for (int i = 0; i < search.length; i++) {
/* 454 */         if (source.endsWith(prefix + search[i]))
/*     */         {
/* 456 */           this.sb.delete(this.sb.length() - (prefix.length() + search[i].length()), this.sb.length());
/* 457 */           this.modified = true;
/* 458 */           setStrings();
/* 459 */           break;
/*     */         }
/* 461 */         if ((from != null) && (from.endsWith(prefix + search[i])))
/*     */         {
/* 463 */           this.sb.replace(this.sb.length() - (prefix.length() + search[i].length()), this.sb.length(), replace);
/* 464 */           this.modified = true;
/* 465 */           setStrings();
/* 466 */           break;
/*     */         }
/* 468 */         if ((without) && (source.endsWith(search[i])))
/*     */         {
/* 470 */           this.sb.delete(this.sb.length() - search[i].length(), this.sb.length());
/* 471 */           this.modified = true;
/* 472 */           setStrings();
/* 473 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean replaceFrom(String source, String[] search, String replace)
/*     */   {
/* 487 */     boolean found = false;
/* 488 */     if (source != null)
/*     */     {
/* 490 */       for (int i = 0; i < search.length; i++) {
/* 491 */         if (source.endsWith(search[i]))
/*     */         {
/* 493 */           this.sb.replace(this.sb.length() - search[i].length(), this.sb.length(), replace);
/* 494 */           this.modified = true;
/* 495 */           found = true;
/* 496 */           setStrings();
/* 497 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 501 */     return found;
/*     */   }
/*     */ 
/*     */   private void deleteFrom(String source, String[] suffix)
/*     */   {
/* 511 */     if (source != null)
/*     */     {
/* 513 */       for (int i = 0; i < suffix.length; i++)
/* 514 */         if (source.endsWith(suffix[i]))
/*     */         {
/* 516 */           this.sb.delete(this.sb.length() - suffix[i].length(), this.sb.length());
/* 517 */           this.modified = true;
/* 518 */           setStrings();
/* 519 */           break;
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isVowel(char ch)
/*     */   {
/* 532 */     switch (ch)
/*     */     {
/*     */     case 'a':
/*     */     case 'e':
/*     */     case 'i':
/*     */     case 'o':
/*     */     case 'u':
/*     */     case 'y':
/*     */     case 'à':
/*     */     case 'â':
/*     */     case 'è':
/*     */     case 'é':
/*     */     case 'ê':
/*     */     case 'ë':
/*     */     case 'î':
/*     */     case 'ï':
/*     */     case 'ô':
/*     */     case 'ù':
/*     */     case 'û':
/*     */     case 'ü':
/* 552 */       return true;
/*     */     }
/* 554 */     return false;
/*     */   }
/*     */ 
/*     */   private String retrieveR(StringBuilder buffer)
/*     */   {
/* 566 */     int len = buffer.length();
/* 567 */     int pos = -1;
/* 568 */     for (int c = 0; c < len; c++) {
/* 569 */       if (isVowel(buffer.charAt(c)))
/*     */       {
/* 571 */         pos = c;
/* 572 */         break;
/*     */       }
/*     */     }
/* 575 */     if (pos > -1)
/*     */     {
/* 577 */       int consonne = -1;
/* 578 */       for (int c = pos; c < len; c++) {
/* 579 */         if (!isVowel(buffer.charAt(c)))
/*     */         {
/* 581 */           consonne = c;
/* 582 */           break;
/*     */         }
/*     */       }
/* 585 */       if ((consonne > -1) && (consonne + 1 < len)) {
/* 586 */         return buffer.substring(consonne + 1, len);
/*     */       }
/* 588 */       return null;
/*     */     }
/*     */ 
/* 591 */     return null;
/*     */   }
/*     */ 
/*     */   private String retrieveRV(StringBuilder buffer)
/*     */   {
/* 603 */     int len = buffer.length();
/* 604 */     if (buffer.length() > 3)
/*     */     {
/* 606 */       if ((isVowel(buffer.charAt(0))) && (isVowel(buffer.charAt(1)))) {
/* 607 */         return buffer.substring(3, len);
/*     */       }
/*     */ 
/* 611 */       int pos = 0;
/* 612 */       for (int c = 1; c < len; c++) {
/* 613 */         if (isVowel(buffer.charAt(c)))
/*     */         {
/* 615 */           pos = c;
/* 616 */           break;
/*     */         }
/*     */       }
/* 619 */       if (pos + 1 < len) {
/* 620 */         return buffer.substring(pos + 1, len);
/*     */       }
/* 622 */       return null;
/*     */     }
/*     */ 
/* 626 */     return null;
/*     */   }
/*     */ 
/*     */   private StringBuilder treatVowels(StringBuilder buffer)
/*     */   {
/* 640 */     for (int c = 0; c < buffer.length(); c++) {
/* 641 */       char ch = buffer.charAt(c);
/*     */ 
/* 643 */       if (c == 0)
/*     */       {
/* 645 */         if (buffer.length() > 1)
/*     */         {
/* 647 */           if ((ch == 'y') && (isVowel(buffer.charAt(c + 1))))
/* 648 */             buffer.setCharAt(c, 'Y');
/*     */         }
/*     */       }
/* 651 */       else if (c == buffer.length() - 1)
/*     */       {
/* 653 */         if ((ch == 'u') && (buffer.charAt(c - 1) == 'q'))
/* 654 */           buffer.setCharAt(c, 'U');
/* 655 */         if ((ch == 'y') && (isVowel(buffer.charAt(c - 1))))
/* 656 */           buffer.setCharAt(c, 'Y');
/*     */       }
/*     */       else
/*     */       {
/* 660 */         if (ch == 'u')
/*     */         {
/* 662 */           if (buffer.charAt(c - 1) == 'q')
/* 663 */             buffer.setCharAt(c, 'U');
/* 664 */           else if ((isVowel(buffer.charAt(c - 1))) && (isVowel(buffer.charAt(c + 1))))
/* 665 */             buffer.setCharAt(c, 'U');
/*     */         }
/* 667 */         if (ch == 'i')
/*     */         {
/* 669 */           if ((isVowel(buffer.charAt(c - 1))) && (isVowel(buffer.charAt(c + 1))))
/* 670 */             buffer.setCharAt(c, 'I');
/*     */         }
/* 672 */         if (ch == 'y')
/*     */         {
/* 674 */           if ((isVowel(buffer.charAt(c - 1))) || (isVowel(buffer.charAt(c + 1)))) {
/* 675 */             buffer.setCharAt(c, 'Y');
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 680 */     return buffer;
/*     */   }
/*     */ 
/*     */   private boolean isStemmable(String term)
/*     */   {
/* 689 */     boolean upper = false;
/* 690 */     int first = -1;
/* 691 */     for (int c = 0; c < term.length(); c++)
/*     */     {
/* 693 */       if (!Character.isLetter(term.charAt(c))) {
/* 694 */         return false;
/*     */       }
/*     */ 
/* 697 */       if (Character.isUpperCase(term.charAt(c))) {
/* 698 */         if (upper) {
/* 699 */           return false;
/*     */         }
/*     */ 
/* 704 */         first = c;
/* 705 */         upper = true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 711 */     if (first > 0) {
/* 712 */       return false;
/*     */     }
/* 714 */     return true;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.fr.FrenchStemmer
 * JD-Core Version:    0.6.2
 */