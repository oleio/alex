/*    */ package org.apache.lucene.analysis.pt;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class PortugueseStemFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   public PortugueseStemFilterFactory(Map<String, String> args)
/*    */   {
/* 41 */     super(args);
/* 42 */     if (!args.isEmpty())
/* 43 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public TokenStream create(TokenStream input)
/*    */   {
/* 49 */     return new PortugueseStemFilter(input);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.pt.PortugueseStemFilterFactory
 * JD-Core Version:    0.6.2
 */