/*     */ package org.apache.lucene.analysis.pt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.snowball.SnowballFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
/*     */ import org.apache.lucene.analysis.util.WordlistLoader;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.tartarus.snowball.ext.PortugueseStemmer;
/*     */ 
/*     */ public final class PortugueseAnalyzer extends StopwordAnalyzerBase
/*     */ {
/*     */   private final CharArraySet stemExclusionSet;
/*     */   public static final String DEFAULT_STOPWORD_FILE = "portuguese_stop.txt";
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  61 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public PortugueseAnalyzer(Version matchVersion)
/*     */   {
/*  87 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET);
/*     */   }
/*     */ 
/*     */   public PortugueseAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/*  97 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET);
/*     */   }
/*     */ 
/*     */   public PortugueseAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionSet)
/*     */   {
/* 110 */     super(matchVersion, stopwords);
/* 111 */     this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionSet));
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader reader)
/*     */   {
/* 130 */     Tokenizer source = new StandardTokenizer(this.matchVersion, reader);
/* 131 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/* 132 */     result = new LowerCaseFilter(this.matchVersion, result);
/* 133 */     result = new StopFilter(this.matchVersion, result, this.stopwords);
/* 134 */     if (!this.stemExclusionSet.isEmpty())
/* 135 */       result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
/* 136 */     if (this.matchVersion.onOrAfter(Version.LUCENE_36))
/* 137 */       result = new PortugueseLightStemFilter(result);
/*     */     else {
/* 139 */       result = new SnowballFilter(result, new PortugueseStemmer());
/*     */     }
/* 141 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  73 */         DEFAULT_STOP_SET = WordlistLoader.getSnowballWordSet(IOUtils.getDecodingReader(SnowballFilter.class, "portuguese_stop.txt", StandardCharsets.UTF_8), Version.LUCENE_CURRENT);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  78 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.pt.PortugueseAnalyzer
 * JD-Core Version:    0.6.2
 */