/*     */ package org.apache.lucene.analysis.pt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.LineNumberReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.StemmerUtil;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public abstract class RSLPStemmerBase
/*     */ {
/* 265 */   private static final Pattern headerPattern = Pattern.compile("^\\{\\s*\"([^\"]*)\",\\s*([0-9]+),\\s*(0|1),\\s*\\{(.*)\\},\\s*$");
/*     */ 
/* 267 */   private static final Pattern stripPattern = Pattern.compile("^\\{\\s*\"([^\"]*)\",\\s*([0-9]+)\\s*\\}\\s*(,|(\\}\\s*;))$");
/*     */ 
/* 269 */   private static final Pattern repPattern = Pattern.compile("^\\{\\s*\"([^\"]*)\",\\s*([0-9]+),\\s*\"([^\"]*)\"\\}\\s*(,|(\\}\\s*;))$");
/*     */ 
/* 271 */   private static final Pattern excPattern = Pattern.compile("^\\{\\s*\"([^\"]*)\",\\s*([0-9]+),\\s*\"([^\"]*)\",\\s*\\{(.*)\\}\\s*\\}\\s*(,|(\\}\\s*;))$");
/*     */ 
/*     */   protected static Map<String, Step> parse(Class<? extends RSLPStemmerBase> clazz, String resource)
/*     */   {
/*     */     try
/*     */     {
/* 250 */       InputStream is = clazz.getResourceAsStream(resource);
/* 251 */       LineNumberReader r = new LineNumberReader(new InputStreamReader(is, StandardCharsets.UTF_8));
/* 252 */       Map steps = new HashMap();
/*     */       String step;
/* 254 */       while ((step = readLine(r)) != null) {
/* 255 */         Step s = parseStep(r, step);
/* 256 */         steps.put(s.name, s);
/*     */       }
/* 258 */       r.close();
/* 259 */       return steps;
/*     */     } catch (IOException e) {
/* 261 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Step parseStep(LineNumberReader r, String header)
/*     */     throws IOException
/*     */   {
/* 275 */     Matcher matcher = headerPattern.matcher(header);
/* 276 */     if (!matcher.find()) {
/* 277 */       throw new RuntimeException("Illegal Step header specified at line " + r.getLineNumber());
/*     */     }
/* 279 */     assert (matcher.groupCount() == 4);
/* 280 */     String name = matcher.group(1);
/* 281 */     int min = Integer.parseInt(matcher.group(2));
/* 282 */     int type = Integer.parseInt(matcher.group(3));
/* 283 */     String[] suffixes = parseList(matcher.group(4));
/* 284 */     Rule[] rules = parseRules(r, type);
/* 285 */     return new Step(name, rules, min, suffixes);
/*     */   }
/*     */ 
/*     */   private static Rule[] parseRules(LineNumberReader r, int type) throws IOException {
/* 289 */     List rules = new ArrayList();
/*     */     String line;
/* 291 */     while ((line = readLine(r)) != null) {
/* 292 */       Matcher matcher = stripPattern.matcher(line);
/* 293 */       if (matcher.matches()) {
/* 294 */         rules.add(new Rule(matcher.group(1), Integer.parseInt(matcher.group(2)), ""));
/*     */       } else {
/* 296 */         matcher = repPattern.matcher(line);
/* 297 */         if (matcher.matches()) {
/* 298 */           rules.add(new Rule(matcher.group(1), Integer.parseInt(matcher.group(2)), matcher.group(3)));
/*     */         } else {
/* 300 */           matcher = excPattern.matcher(line);
/* 301 */           if (matcher.matches()) {
/* 302 */             if (type == 0) {
/* 303 */               rules.add(new RuleWithSuffixExceptions(matcher.group(1), Integer.parseInt(matcher.group(2)), matcher.group(3), parseList(matcher.group(4))));
/*     */             }
/*     */             else
/*     */             {
/* 308 */               rules.add(new RuleWithSetExceptions(matcher.group(1), Integer.parseInt(matcher.group(2)), matcher.group(3), parseList(matcher.group(4))));
/*     */             }
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 314 */             throw new RuntimeException("Illegal Step rule specified at line " + r.getLineNumber());
/*     */           }
/*     */         }
/*     */       }
/* 318 */       if (line.endsWith(";"))
/* 319 */         return (Rule[])rules.toArray(new Rule[rules.size()]);
/*     */     }
/* 321 */     return null;
/*     */   }
/*     */ 
/*     */   private static String[] parseList(String s) {
/* 325 */     if (s.length() == 0)
/* 326 */       return null;
/* 327 */     String[] list = s.split(",");
/* 328 */     for (int i = 0; i < list.length; i++)
/* 329 */       list[i] = parseString(list[i].trim());
/* 330 */     return list;
/*     */   }
/*     */ 
/*     */   private static String parseString(String s) {
/* 334 */     return s.substring(1, s.length() - 1);
/*     */   }
/*     */ 
/*     */   private static String readLine(LineNumberReader r) throws IOException {
/* 338 */     String line = null;
/* 339 */     while ((line = r.readLine()) != null) {
/* 340 */       line = line.trim();
/* 341 */       if ((line.length() > 0) && (line.charAt(0) != '#'))
/* 342 */         return line;
/*     */     }
/* 344 */     return line;
/*     */   }
/*     */ 
/*     */   protected static class Step
/*     */   {
/*     */     protected final String name;
/*     */     protected final RSLPStemmerBase.Rule[] rules;
/*     */     protected final int min;
/*     */     protected final char[][] suffixes;
/*     */ 
/*     */     public Step(String name, RSLPStemmerBase.Rule[] rules, int min, String[] suffixes)
/*     */     {
/* 197 */       this.name = name;
/* 198 */       this.rules = rules;
/* 199 */       if (min == 0) {
/* 200 */         min = 2147483647;
/* 201 */         for (RSLPStemmerBase.Rule r : rules)
/* 202 */           min = Math.min(min, r.min + r.suffix.length);
/*     */       }
/* 204 */       this.min = min;
/*     */ 
/* 206 */       if ((suffixes == null) || (suffixes.length == 0)) {
/* 207 */         this.suffixes = ((char[][])null);
/*     */       } else {
/* 209 */         this.suffixes = new char[suffixes.length][];
/* 210 */         for (int i = 0; i < suffixes.length; i++)
/* 211 */           this.suffixes[i] = suffixes[i].toCharArray();
/*     */       }
/*     */     }
/*     */ 
/*     */     public int apply(char[] s, int len)
/*     */     {
/* 219 */       if (len < this.min) {
/* 220 */         return len;
/*     */       }
/* 222 */       if (this.suffixes != null) {
/* 223 */         boolean found = false;
/*     */ 
/* 225 */         for (int i = 0; i < this.suffixes.length; i++) {
/* 226 */           if (StemmerUtil.endsWith(s, len, this.suffixes[i])) {
/* 227 */             found = true;
/* 228 */             break;
/*     */           }
/*     */         }
/* 231 */         if (!found) return len;
/*     */       }
/*     */ 
/* 234 */       for (int i = 0; i < this.rules.length; i++) {
/* 235 */         if (this.rules[i].matches(s, len)) {
/* 236 */           return this.rules[i].replace(s, len);
/*     */         }
/*     */       }
/* 239 */       return len;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class RuleWithSuffixExceptions extends RSLPStemmerBase.Rule
/*     */   {
/*     */     protected final char[][] exceptions;
/*     */ 
/*     */     public RuleWithSuffixExceptions(String suffix, int min, String replacement, String[] exceptions)
/*     */     {
/* 157 */       super(min, replacement);
/* 158 */       for (int i = 0; i < exceptions.length; i++) {
/* 159 */         if (!exceptions[i].endsWith(suffix))
/* 160 */           throw new RuntimeException("warning: useless exception '" + exceptions[i] + "' does not end with '" + suffix + "'");
/*     */       }
/* 162 */       this.exceptions = new char[exceptions.length][];
/* 163 */       for (int i = 0; i < exceptions.length; i++)
/* 164 */         this.exceptions[i] = exceptions[i].toCharArray();
/*     */     }
/*     */ 
/*     */     public boolean matches(char[] s, int len)
/*     */     {
/* 169 */       if (!super.matches(s, len)) {
/* 170 */         return false;
/*     */       }
/* 172 */       for (int i = 0; i < this.exceptions.length; i++) {
/* 173 */         if (StemmerUtil.endsWith(s, len, this.exceptions[i]))
/* 174 */           return false;
/*     */       }
/* 176 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class RuleWithSetExceptions extends RSLPStemmerBase.Rule
/*     */   {
/*     */     protected final CharArraySet exceptions;
/*     */ 
/*     */     public RuleWithSetExceptions(String suffix, int min, String replacement, String[] exceptions)
/*     */     {
/* 133 */       super(min, replacement);
/* 134 */       for (int i = 0; i < exceptions.length; i++) {
/* 135 */         if (!exceptions[i].endsWith(suffix))
/* 136 */           throw new RuntimeException("useless exception '" + exceptions[i] + "' does not end with '" + suffix + "'");
/*     */       }
/* 138 */       this.exceptions = new CharArraySet(Version.LUCENE_CURRENT, Arrays.asList(exceptions), false);
/*     */     }
/*     */ 
/*     */     public boolean matches(char[] s, int len)
/*     */     {
/* 144 */       return (super.matches(s, len)) && (!this.exceptions.contains(s, 0, len));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class Rule
/*     */   {
/*     */     protected final char[] suffix;
/*     */     protected final char[] replacement;
/*     */     protected final int min;
/*     */ 
/*     */     public Rule(String suffix, int min, String replacement)
/*     */     {
/* 102 */       this.suffix = suffix.toCharArray();
/* 103 */       this.replacement = replacement.toCharArray();
/* 104 */       this.min = min;
/*     */     }
/*     */ 
/*     */     public boolean matches(char[] s, int len)
/*     */     {
/* 111 */       return (len - this.suffix.length >= this.min) && (StemmerUtil.endsWith(s, len, this.suffix));
/*     */     }
/*     */ 
/*     */     public int replace(char[] s, int len)
/*     */     {
/* 118 */       if (this.replacement.length > 0) {
/* 119 */         System.arraycopy(this.replacement, 0, s, len - this.suffix.length, this.replacement.length);
/*     */       }
/* 121 */       return len - this.suffix.length + this.replacement.length;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.pt.RSLPStemmerBase
 * JD-Core Version:    0.6.2
 */