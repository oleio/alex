/*     */ package org.apache.lucene.analysis.nl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.core.LowerCaseFilter;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.StemmerOverrideFilter;
/*     */ import org.apache.lucene.analysis.miscellaneous.StemmerOverrideFilter.Builder;
/*     */ import org.apache.lucene.analysis.miscellaneous.StemmerOverrideFilter.StemmerOverrideMap;
/*     */ import org.apache.lucene.analysis.snowball.SnowballFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardFilter;
/*     */ import org.apache.lucene.analysis.standard.StandardTokenizer;
/*     */ import org.apache.lucene.analysis.util.CharArrayMap;
/*     */ import org.apache.lucene.analysis.util.CharArrayMap.EntryIterator;
/*     */ import org.apache.lucene.analysis.util.CharArrayMap.EntrySet;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.analysis.util.WordlistLoader;
/*     */ import org.apache.lucene.util.CharsRef;
/*     */ import org.apache.lucene.util.IOUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ import org.tartarus.snowball.ext.DutchStemmer;
/*     */ 
/*     */ public final class DutchAnalyzer extends Analyzer
/*     */ {
/*     */   public static final String DEFAULT_STOPWORD_FILE = "dutch_stop.txt";
/*     */   private final CharArraySet stoptable;
/* 114 */   private CharArraySet excltable = CharArraySet.EMPTY_SET;
/*     */   private final StemmerOverrideFilter.StemmerOverrideMap stemdict;
/*     */   private final CharArrayMap<String> origStemdict;
/*     */   private final Version matchVersion;
/*     */ 
/*     */   public static CharArraySet getDefaultStopSet()
/*     */   {
/*  81 */     return DefaultSetHolder.DEFAULT_STOP_SET;
/*     */   }
/*     */ 
/*     */   public DutchAnalyzer(Version matchVersion)
/*     */   {
/* 129 */     this(matchVersion, DefaultSetHolder.DEFAULT_STOP_SET, CharArraySet.EMPTY_SET, DefaultSetHolder.DEFAULT_STEM_DICT);
/*     */   }
/*     */ 
/*     */   public DutchAnalyzer(Version matchVersion, CharArraySet stopwords)
/*     */   {
/* 135 */     this(matchVersion, stopwords, CharArraySet.EMPTY_SET, matchVersion.onOrAfter(Version.LUCENE_36) ? DefaultSetHolder.DEFAULT_STEM_DICT : CharArrayMap.emptyMap());
/*     */   }
/*     */ 
/*     */   public DutchAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionTable)
/*     */   {
/* 144 */     this(matchVersion, stopwords, stemExclusionTable, matchVersion.onOrAfter(Version.LUCENE_36) ? DefaultSetHolder.DEFAULT_STEM_DICT : CharArrayMap.emptyMap());
/*     */   }
/*     */ 
/*     */   public DutchAnalyzer(Version matchVersion, CharArraySet stopwords, CharArraySet stemExclusionTable, CharArrayMap<String> stemOverrideDict)
/*     */   {
/* 151 */     this.matchVersion = matchVersion;
/* 152 */     this.stoptable = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stopwords));
/* 153 */     this.excltable = CharArraySet.unmodifiableSet(CharArraySet.copy(matchVersion, stemExclusionTable));
/* 154 */     if ((stemOverrideDict.isEmpty()) || (!matchVersion.onOrAfter(Version.LUCENE_31))) {
/* 155 */       this.stemdict = null;
/* 156 */       this.origStemdict = CharArrayMap.unmodifiableMap(CharArrayMap.copy(matchVersion, stemOverrideDict));
/*     */     } else {
/* 158 */       this.origStemdict = null;
/*     */ 
/* 160 */       StemmerOverrideFilter.Builder builder = new StemmerOverrideFilter.Builder(false);
/* 161 */       CharArrayMap.EntryIterator iter = stemOverrideDict.entrySet().iterator();
/* 162 */       CharsRef spare = new CharsRef();
/* 163 */       while (iter.hasNext()) {
/* 164 */         char[] nextKey = iter.nextKey();
/* 165 */         spare.copyChars(nextKey, 0, nextKey.length);
/* 166 */         builder.add(spare, (CharSequence)iter.currentValue());
/*     */       }
/*     */       try {
/* 169 */         this.stemdict = builder.build();
/*     */       } catch (IOException ex) {
/* 171 */         throw new RuntimeException("can not build stem dict", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents createComponents(String fieldName, Reader aReader)
/*     */   {
/* 188 */     if (this.matchVersion.onOrAfter(Version.LUCENE_31)) {
/* 189 */       Tokenizer source = new StandardTokenizer(this.matchVersion, aReader);
/* 190 */       TokenStream result = new StandardFilter(this.matchVersion, source);
/* 191 */       result = new LowerCaseFilter(this.matchVersion, result);
/* 192 */       result = new StopFilter(this.matchVersion, result, this.stoptable);
/* 193 */       if (!this.excltable.isEmpty())
/* 194 */         result = new SetKeywordMarkerFilter(result, this.excltable);
/* 195 */       if (this.stemdict != null)
/* 196 */         result = new StemmerOverrideFilter(result, this.stemdict);
/* 197 */       result = new SnowballFilter(result, new DutchStemmer());
/* 198 */       return new Analyzer.TokenStreamComponents(source, result);
/*     */     }
/* 200 */     Tokenizer source = new StandardTokenizer(this.matchVersion, aReader);
/* 201 */     TokenStream result = new StandardFilter(this.matchVersion, source);
/* 202 */     result = new StopFilter(this.matchVersion, result, this.stoptable);
/* 203 */     if (!this.excltable.isEmpty())
/* 204 */       result = new SetKeywordMarkerFilter(result, this.excltable);
/* 205 */     result = new DutchStemFilter(result, this.origStemdict);
/* 206 */     return new Analyzer.TokenStreamComponents(source, result);
/*     */   }
/*     */ 
/*     */   private static class DefaultSetHolder
/*     */   {
/*     */     static final CharArraySet DEFAULT_STOP_SET;
/*     */     static final CharArrayMap<String> DEFAULT_STEM_DICT;
/*     */ 
/*     */     static
/*     */     {
/*     */       try
/*     */       {
/*  89 */         DEFAULT_STOP_SET = WordlistLoader.getSnowballWordSet(IOUtils.getDecodingReader(SnowballFilter.class, "dutch_stop.txt", StandardCharsets.UTF_8), Version.LUCENE_CURRENT);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  94 */         throw new RuntimeException("Unable to load default stopword set");
/*     */       }
/*     */ 
/*  97 */       DEFAULT_STEM_DICT = new CharArrayMap(Version.LUCENE_CURRENT, 4, false);
/*  98 */       DEFAULT_STEM_DICT.put("fiets", "fiets");
/*  99 */       DEFAULT_STEM_DICT.put("bromfiets", "bromfiets");
/* 100 */       DEFAULT_STEM_DICT.put("ei", "eier");
/* 101 */       DEFAULT_STEM_DICT.put("kind", "kinder");
/*     */     }
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.nl.DutchAnalyzer
 * JD-Core Version:    0.6.2
 */