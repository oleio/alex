/*    */ package org.apache.lucene.analysis;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ 
/*    */ public abstract class CharFilter extends Reader
/*    */ {
/*    */   protected final Reader input;
/*    */ 
/*    */   public CharFilter(Reader input)
/*    */   {
/* 52 */     super(input);
/* 53 */     this.input = input;
/*    */   }
/*    */ 
/*    */   public void close()
/*    */     throws IOException
/*    */   {
/* 65 */     this.input.close();
/*    */   }
/*    */ 
/*    */   protected abstract int correct(int paramInt);
/*    */ 
/*    */   public final int correctOffset(int currentOff)
/*    */   {
/* 81 */     int corrected = correct(currentOff);
/* 82 */     return (this.input instanceof CharFilter) ? ((CharFilter)this.input).correctOffset(corrected) : corrected;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.CharFilter
 * JD-Core Version:    0.6.2
 */