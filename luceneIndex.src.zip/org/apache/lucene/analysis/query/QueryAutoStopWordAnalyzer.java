/*     */ package org.apache.lucene.analysis.query;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
/*     */ import org.apache.lucene.analysis.AnalyzerWrapper;
/*     */ import org.apache.lucene.analysis.core.StopFilter;
/*     */ import org.apache.lucene.analysis.util.CharArraySet;
/*     */ import org.apache.lucene.index.IndexReader;
/*     */ import org.apache.lucene.index.MultiFields;
/*     */ import org.apache.lucene.index.Term;
/*     */ import org.apache.lucene.index.Terms;
/*     */ import org.apache.lucene.index.TermsEnum;
/*     */ import org.apache.lucene.util.BytesRef;
/*     */ import org.apache.lucene.util.CharsRef;
/*     */ import org.apache.lucene.util.UnicodeUtil;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class QueryAutoStopWordAnalyzer extends AnalyzerWrapper
/*     */ {
/*     */   private final Analyzer delegate;
/*  49 */   private final Map<String, Set<String>> stopWordsPerField = new HashMap();
/*     */   public static final float defaultMaxDocFreqPercent = 0.4F;
/*     */   private final Version matchVersion;
/*     */ 
/*     */   public QueryAutoStopWordAnalyzer(Version matchVersion, Analyzer delegate, IndexReader indexReader)
/*     */     throws IOException
/*     */   {
/*  69 */     this(matchVersion, delegate, indexReader, 0.4F);
/*     */   }
/*     */ 
/*     */   public QueryAutoStopWordAnalyzer(Version matchVersion, Analyzer delegate, IndexReader indexReader, int maxDocFreq)
/*     */     throws IOException
/*     */   {
/*  88 */     this(matchVersion, delegate, indexReader, MultiFields.getIndexedFields(indexReader), maxDocFreq);
/*     */   }
/*     */ 
/*     */   public QueryAutoStopWordAnalyzer(Version matchVersion, Analyzer delegate, IndexReader indexReader, float maxPercentDocs)
/*     */     throws IOException
/*     */   {
/* 108 */     this(matchVersion, delegate, indexReader, MultiFields.getIndexedFields(indexReader), maxPercentDocs);
/*     */   }
/*     */ 
/*     */   public QueryAutoStopWordAnalyzer(Version matchVersion, Analyzer delegate, IndexReader indexReader, Collection<String> fields, float maxPercentDocs)
/*     */     throws IOException
/*     */   {
/* 130 */     this(matchVersion, delegate, indexReader, fields, (int)(indexReader.numDocs() * maxPercentDocs));
/*     */   }
/*     */ 
/*     */   public QueryAutoStopWordAnalyzer(Version matchVersion, Analyzer delegate, IndexReader indexReader, Collection<String> fields, int maxDocFreq)
/*     */     throws IOException
/*     */   {
/* 151 */     super(delegate.getReuseStrategy());
/* 152 */     this.matchVersion = matchVersion;
/* 153 */     this.delegate = delegate;
/*     */ 
/* 155 */     for (String field : fields) {
/* 156 */       Set stopWords = new HashSet();
/* 157 */       Terms terms = MultiFields.getTerms(indexReader, field);
/* 158 */       CharsRef spare = new CharsRef();
/* 159 */       if (terms != null) {
/* 160 */         TermsEnum te = terms.iterator(null);
/*     */         BytesRef text;
/* 162 */         while ((text = te.next()) != null) {
/* 163 */           if (te.docFreq() > maxDocFreq) {
/* 164 */             UnicodeUtil.UTF8toUTF16(text, spare);
/* 165 */             stopWords.add(spare.toString());
/*     */           }
/*     */         }
/*     */       }
/* 169 */       this.stopWordsPerField.put(field, stopWords);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Analyzer getWrappedAnalyzer(String fieldName)
/*     */   {
/* 175 */     return this.delegate;
/*     */   }
/*     */ 
/*     */   protected Analyzer.TokenStreamComponents wrapComponents(String fieldName, Analyzer.TokenStreamComponents components)
/*     */   {
/* 180 */     Set stopWords = (Set)this.stopWordsPerField.get(fieldName);
/* 181 */     if (stopWords == null) {
/* 182 */       return components;
/*     */     }
/* 184 */     StopFilter stopFilter = new StopFilter(this.matchVersion, components.getTokenStream(), new CharArraySet(this.matchVersion, stopWords, false));
/*     */ 
/* 186 */     return new Analyzer.TokenStreamComponents(components.getTokenizer(), stopFilter);
/*     */   }
/*     */ 
/*     */   public String[] getStopWords(String fieldName)
/*     */   {
/* 197 */     Set stopWords = (Set)this.stopWordsPerField.get(fieldName);
/* 198 */     return stopWords != null ? (String[])stopWords.toArray(new String[stopWords.size()]) : new String[0];
/*     */   }
/*     */ 
/*     */   public Term[] getStopWords()
/*     */   {
/* 207 */     List allStopWords = new ArrayList();
/* 208 */     for (Iterator i$ = this.stopWordsPerField.keySet().iterator(); i$.hasNext(); ) { fieldName = (String)i$.next();
/* 209 */       Set stopWords = (Set)this.stopWordsPerField.get(fieldName);
/* 210 */       for (String text : stopWords)
/* 211 */         allStopWords.add(new Term(fieldName, text));
/*     */     }
/*     */     String fieldName;
/* 214 */     return (Term[])allStopWords.toArray(new Term[allStopWords.size()]);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.query.QueryAutoStopWordAnalyzer
 * JD-Core Version:    0.6.2
 */