/*     */ package org.apache.lucene.analysis.ngram;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.miscellaneous.CodepointCountFilter;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionLengthAttribute;
/*     */ import org.apache.lucene.analysis.util.CharacterUtils;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public final class NGramTokenFilter extends TokenFilter
/*     */ {
/*     */   public static final int DEFAULT_MIN_NGRAM_SIZE = 1;
/*     */   public static final int DEFAULT_MAX_NGRAM_SIZE = 2;
/*     */   private final int minGram;
/*     */   private final int maxGram;
/*     */   private char[] curTermBuffer;
/*     */   private int curTermLength;
/*     */   private int curCodePointCount;
/*     */   private int curGramSize;
/*     */   private int curPos;
/*     */   private int curPosInc;
/*     */   private int curPosLen;
/*     */   private int tokStart;
/*     */   private int tokEnd;
/*     */   private boolean hasIllegalOffsets;
/*     */   private final Version version;
/*     */   private final CharacterUtils charUtils;
/*  70 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */   private final PositionIncrementAttribute posIncAtt;
/*     */   private final PositionLengthAttribute posLenAtt;
/*  73 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */ 
/*     */   public NGramTokenFilter(Version version, TokenStream input, int minGram, int maxGram)
/*     */   {
/*  84 */     super(new CodepointCountFilter(version, input, minGram, 2147483647));
/*  85 */     this.version = version;
/*  86 */     this.charUtils = (version.onOrAfter(Version.LUCENE_44) ? CharacterUtils.getInstance(version) : CharacterUtils.getJava4Instance());
/*     */ 
/*  89 */     if (minGram < 1) {
/*  90 */       throw new IllegalArgumentException("minGram must be greater than zero");
/*     */     }
/*  92 */     if (minGram > maxGram) {
/*  93 */       throw new IllegalArgumentException("minGram must not be greater than maxGram");
/*     */     }
/*  95 */     this.minGram = minGram;
/*  96 */     this.maxGram = maxGram;
/*  97 */     if (version.onOrAfter(Version.LUCENE_44)) {
/*  98 */       this.posIncAtt = ((PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class));
/*  99 */       this.posLenAtt = ((PositionLengthAttribute)addAttribute(PositionLengthAttribute.class));
/*     */     } else {
/* 101 */       this.posIncAtt = new PositionIncrementAttribute() {
/*     */         public void setPositionIncrement(int positionIncrement) {
/*     */         }
/*     */ 
/*     */         public int getPositionIncrement() {
/* 106 */           return 0;
/*     */         }
/*     */       };
/* 109 */       this.posLenAtt = new PositionLengthAttribute() {
/*     */         public void setPositionLength(int positionLength) {
/*     */         }
/*     */ 
/*     */         public int getPositionLength() {
/* 114 */           return 0;
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ 
/*     */   public NGramTokenFilter(Version version, TokenStream input)
/*     */   {
/* 127 */     this(version, input, 1, 2);
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken() throws IOException
/*     */   {
/*     */     while (true)
/*     */     {
/* 134 */       if (this.curTermBuffer == null) {
/* 135 */         if (!this.input.incrementToken()) {
/* 136 */           return false;
/*     */         }
/* 138 */         this.curTermBuffer = ((char[])this.termAtt.buffer().clone());
/* 139 */         this.curTermLength = this.termAtt.length();
/* 140 */         this.curCodePointCount = this.charUtils.codePointCount(this.termAtt);
/* 141 */         this.curGramSize = this.minGram;
/* 142 */         this.curPos = 0;
/* 143 */         this.curPosInc = this.posIncAtt.getPositionIncrement();
/* 144 */         this.curPosLen = this.posLenAtt.getPositionLength();
/* 145 */         this.tokStart = this.offsetAtt.startOffset();
/* 146 */         this.tokEnd = this.offsetAtt.endOffset();
/*     */ 
/* 149 */         this.hasIllegalOffsets = (this.tokStart + this.curTermLength != this.tokEnd);
/*     */       }
/*     */ 
/* 152 */       if (this.version.onOrAfter(Version.LUCENE_44)) {
/* 153 */         if ((this.curGramSize > this.maxGram) || (this.curPos + this.curGramSize > this.curCodePointCount)) {
/* 154 */           this.curPos += 1;
/* 155 */           this.curGramSize = this.minGram;
/*     */         }
/* 157 */         if (this.curPos + this.curGramSize <= this.curCodePointCount) {
/* 158 */           clearAttributes();
/* 159 */           int start = this.charUtils.offsetByCodePoints(this.curTermBuffer, 0, this.curTermLength, 0, this.curPos);
/* 160 */           int end = this.charUtils.offsetByCodePoints(this.curTermBuffer, 0, this.curTermLength, start, this.curGramSize);
/* 161 */           this.termAtt.copyBuffer(this.curTermBuffer, start, end - start);
/* 162 */           this.posIncAtt.setPositionIncrement(this.curPosInc);
/* 163 */           this.curPosInc = 0;
/* 164 */           this.posLenAtt.setPositionLength(this.curPosLen);
/* 165 */           this.offsetAtt.setOffset(this.tokStart, this.tokEnd);
/* 166 */           this.curGramSize += 1;
/* 167 */           return true;
/*     */         }
/*     */       } else {
/* 170 */         while (this.curGramSize <= this.maxGram) {
/* 171 */           if (this.curPos + this.curGramSize <= this.curTermLength) {
/* 172 */             clearAttributes();
/* 173 */             this.termAtt.copyBuffer(this.curTermBuffer, this.curPos, this.curGramSize);
/* 174 */             if (this.hasIllegalOffsets)
/* 175 */               this.offsetAtt.setOffset(this.tokStart, this.tokEnd);
/*     */             else {
/* 177 */               this.offsetAtt.setOffset(this.tokStart + this.curPos, this.tokStart + this.curPos + this.curGramSize);
/*     */             }
/* 179 */             this.curPos += 1;
/* 180 */             return true;
/*     */           }
/* 182 */           this.curGramSize += 1;
/* 183 */           this.curPos = 0;
/*     */         }
/*     */       }
/* 186 */       this.curTermBuffer = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 192 */     super.reset();
/* 193 */     this.curTermBuffer = null;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ngram.NGramTokenFilter
 * JD-Core Version:    0.6.2
 */