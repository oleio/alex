/*     */ package org.apache.lucene.analysis.ngram;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ 
/*     */ @Deprecated
/*     */ public final class Lucene43NGramTokenizer extends Tokenizer
/*     */ {
/*     */   public static final int DEFAULT_MIN_NGRAM_SIZE = 1;
/*     */   public static final int DEFAULT_MAX_NGRAM_SIZE = 2;
/*     */   private int minGram;
/*     */   private int maxGram;
/*     */   private int gramSize;
/*     */   private int pos;
/*     */   private int inLen;
/*     */   private int charsRead;
/*     */   private String inStr;
/*     */   private boolean started;
/*  43 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  44 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */ 
/*     */   public Lucene43NGramTokenizer(Reader input, int minGram, int maxGram)
/*     */   {
/*  53 */     super(input);
/*  54 */     init(minGram, maxGram);
/*     */   }
/*     */ 
/*     */   public Lucene43NGramTokenizer(AttributeSource.AttributeFactory factory, Reader input, int minGram, int maxGram)
/*     */   {
/*  65 */     super(factory, input);
/*  66 */     init(minGram, maxGram);
/*     */   }
/*     */ 
/*     */   public Lucene43NGramTokenizer(Reader input)
/*     */   {
/*  74 */     this(input, 1, 2);
/*     */   }
/*     */ 
/*     */   private void init(int minGram, int maxGram) {
/*  78 */     if (minGram < 1) {
/*  79 */       throw new IllegalArgumentException("minGram must be greater than zero");
/*     */     }
/*  81 */     if (minGram > maxGram) {
/*  82 */       throw new IllegalArgumentException("minGram must not be greater than maxGram");
/*     */     }
/*  84 */     this.minGram = minGram;
/*  85 */     this.maxGram = maxGram;
/*     */   }
/*     */ 
/*     */   public boolean incrementToken()
/*     */     throws IOException
/*     */   {
/*  91 */     clearAttributes();
/*  92 */     if (!this.started) {
/*  93 */       this.started = true;
/*  94 */       this.gramSize = this.minGram;
/*  95 */       char[] chars = new char[1024];
/*  96 */       this.charsRead = 0;
/*     */ 
/*  98 */       while (this.charsRead < chars.length) {
/*  99 */         int inc = this.input.read(chars, this.charsRead, chars.length - this.charsRead);
/* 100 */         if (inc == -1) {
/*     */           break;
/*     */         }
/* 103 */         this.charsRead += inc;
/*     */       }
/* 105 */       this.inStr = new String(chars, 0, this.charsRead).trim();
/*     */ 
/* 107 */       if (this.charsRead == chars.length)
/*     */       {
/* 110 */         char[] throwaway = new char[1024];
/*     */         while (true) {
/* 112 */           int inc = this.input.read(throwaway, 0, throwaway.length);
/* 113 */           if (inc == -1) {
/*     */             break;
/*     */           }
/* 116 */           this.charsRead += inc;
/*     */         }
/*     */       }
/*     */ 
/* 120 */       this.inLen = this.inStr.length();
/* 121 */       if (this.inLen == 0) {
/* 122 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 126 */     if (this.pos + this.gramSize > this.inLen) {
/* 127 */       this.pos = 0;
/* 128 */       this.gramSize += 1;
/* 129 */       if (this.gramSize > this.maxGram)
/* 130 */         return false;
/* 131 */       if (this.pos + this.gramSize > this.inLen) {
/* 132 */         return false;
/*     */       }
/*     */     }
/* 135 */     int oldPos = this.pos;
/* 136 */     this.pos += 1;
/* 137 */     this.termAtt.setEmpty().append(this.inStr, oldPos, oldPos + this.gramSize);
/* 138 */     this.offsetAtt.setOffset(correctOffset(oldPos), correctOffset(oldPos + this.gramSize));
/* 139 */     return true;
/*     */   }
/*     */ 
/*     */   public void end() throws IOException
/*     */   {
/* 144 */     super.end();
/*     */ 
/* 146 */     int finalOffset = correctOffset(this.charsRead);
/* 147 */     this.offsetAtt.setOffset(finalOffset, finalOffset);
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 152 */     super.reset();
/* 153 */     this.started = false;
/* 154 */     this.pos = 0;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ngram.Lucene43NGramTokenizer
 * JD-Core Version:    0.6.2
 */