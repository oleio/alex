/*    */ package org.apache.lucene.analysis.ngram;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public class EdgeNGramTokenizer extends NGramTokenizer
/*    */ {
/*    */   public static final int DEFAULT_MAX_GRAM_SIZE = 1;
/*    */   public static final int DEFAULT_MIN_GRAM_SIZE = 1;
/*    */ 
/*    */   public EdgeNGramTokenizer(Version version, Reader input, int minGram, int maxGram)
/*    */   {
/* 53 */     super(version, input, minGram, maxGram, true);
/*    */   }
/*    */ 
/*    */   public EdgeNGramTokenizer(Version version, AttributeSource.AttributeFactory factory, Reader input, int minGram, int maxGram)
/*    */   {
/* 66 */     super(version, factory, input, minGram, maxGram, true);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ngram.EdgeNGramTokenizer
 * JD-Core Version:    0.6.2
 */