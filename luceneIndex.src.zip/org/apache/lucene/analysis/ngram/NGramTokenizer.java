/*     */ package org.apache.lucene.analysis.ngram;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.lucene.analysis.Tokenizer;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
/*     */ import org.apache.lucene.analysis.tokenattributes.PositionLengthAttribute;
/*     */ import org.apache.lucene.analysis.util.CharacterUtils;
/*     */ import org.apache.lucene.analysis.util.CharacterUtils.CharacterBuffer;
/*     */ import org.apache.lucene.util.AttributeSource.AttributeFactory;
/*     */ import org.apache.lucene.util.Version;
/*     */ 
/*     */ public class NGramTokenizer extends Tokenizer
/*     */ {
/*     */   public static final int DEFAULT_MIN_NGRAM_SIZE = 1;
/*     */   public static final int DEFAULT_MAX_NGRAM_SIZE = 2;
/*     */   private CharacterUtils charUtils;
/*     */   private CharacterUtils.CharacterBuffer charBuffer;
/*     */   private int[] buffer;
/*     */   private int bufferStart;
/*     */   private int bufferEnd;
/*     */   private int offset;
/*     */   private int gramSize;
/*     */   private int minGram;
/*     */   private int maxGram;
/*     */   private boolean exhausted;
/*     */   private int lastCheckedChar;
/*     */   private int lastNonTokenChar;
/*     */   private boolean edgesOnly;
/*  75 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*  76 */   private final PositionIncrementAttribute posIncAtt = (PositionIncrementAttribute)addAttribute(PositionIncrementAttribute.class);
/*  77 */   private final PositionLengthAttribute posLenAtt = (PositionLengthAttribute)addAttribute(PositionLengthAttribute.class);
/*  78 */   private final OffsetAttribute offsetAtt = (OffsetAttribute)addAttribute(OffsetAttribute.class);
/*     */ 
/*     */   NGramTokenizer(Version version, Reader input, int minGram, int maxGram, boolean edgesOnly) {
/*  81 */     super(input);
/*  82 */     init(version, minGram, maxGram, edgesOnly);
/*     */   }
/*     */ 
/*     */   public NGramTokenizer(Version version, Reader input, int minGram, int maxGram)
/*     */   {
/*  93 */     this(version, input, minGram, maxGram, false);
/*     */   }
/*     */ 
/*     */   NGramTokenizer(Version version, AttributeSource.AttributeFactory factory, Reader input, int minGram, int maxGram, boolean edgesOnly) {
/*  97 */     super(factory, input);
/*  98 */     init(version, minGram, maxGram, edgesOnly);
/*     */   }
/*     */ 
/*     */   public NGramTokenizer(Version version, AttributeSource.AttributeFactory factory, Reader input, int minGram, int maxGram)
/*     */   {
/* 110 */     this(version, factory, input, minGram, maxGram, false);
/*     */   }
/*     */ 
/*     */   public NGramTokenizer(Version version, Reader input)
/*     */   {
/* 119 */     this(version, input, 1, 2);
/*     */   }
/*     */ 
/*     */   private void init(Version version, int minGram, int maxGram, boolean edgesOnly) {
/* 123 */     if (!version.onOrAfter(Version.LUCENE_44)) {
/* 124 */       throw new IllegalArgumentException("This class only works with Lucene 4.4+. To emulate the old (broken) behavior of NGramTokenizer, use Lucene43NGramTokenizer/Lucene43EdgeNGramTokenizer");
/*     */     }
/* 126 */     this.charUtils = (version.onOrAfter(Version.LUCENE_44) ? CharacterUtils.getInstance(version) : CharacterUtils.getJava4Instance());
/*     */ 
/* 129 */     if (minGram < 1) {
/* 130 */       throw new IllegalArgumentException("minGram must be greater than zero");
/*     */     }
/* 132 */     if (minGram > maxGram) {
/* 133 */       throw new IllegalArgumentException("minGram must not be greater than maxGram");
/*     */     }
/* 135 */     this.minGram = minGram;
/* 136 */     this.maxGram = maxGram;
/* 137 */     this.edgesOnly = edgesOnly;
/* 138 */     this.charBuffer = CharacterUtils.newCharacterBuffer(2 * maxGram + 1024);
/* 139 */     this.buffer = new int[this.charBuffer.getBuffer().length];
/*     */ 
/* 141 */     this.termAtt.resizeBuffer(2 * maxGram);
/*     */   }
/*     */ 
/*     */   public final boolean incrementToken() throws IOException
/*     */   {
/* 146 */     clearAttributes();
/*     */     while (true)
/*     */     {
/* 152 */       if ((this.bufferStart >= this.bufferEnd - this.maxGram - 1) && (!this.exhausted)) {
/* 153 */         System.arraycopy(this.buffer, this.bufferStart, this.buffer, 0, this.bufferEnd - this.bufferStart);
/* 154 */         this.bufferEnd -= this.bufferStart;
/* 155 */         this.lastCheckedChar -= this.bufferStart;
/* 156 */         this.lastNonTokenChar -= this.bufferStart;
/* 157 */         this.bufferStart = 0;
/*     */ 
/* 160 */         this.exhausted = (!this.charUtils.fill(this.charBuffer, this.input, this.buffer.length - this.bufferEnd));
/*     */ 
/* 162 */         this.bufferEnd += this.charUtils.toCodePoints(this.charBuffer.getBuffer(), 0, this.charBuffer.getLength(), this.buffer, this.bufferEnd);
/*     */       }
/*     */ 
/* 166 */       if ((this.gramSize > this.maxGram) || (this.bufferStart + this.gramSize > this.bufferEnd)) {
/* 167 */         if (this.bufferStart + 1 + this.minGram > this.bufferEnd) {
/* 168 */           assert (this.exhausted);
/* 169 */           return false;
/*     */         }
/* 171 */         consume();
/* 172 */         this.gramSize = this.minGram;
/*     */       }
/*     */ 
/* 175 */       updateLastNonTokenChar();
/*     */ 
/* 178 */       boolean termContainsNonTokenChar = (this.lastNonTokenChar >= this.bufferStart) && (this.lastNonTokenChar < this.bufferStart + this.gramSize);
/* 179 */       boolean isEdgeAndPreviousCharIsTokenChar = (this.edgesOnly) && (this.lastNonTokenChar != this.bufferStart - 1);
/* 180 */       if ((!termContainsNonTokenChar) && (!isEdgeAndPreviousCharIsTokenChar)) break;
/* 181 */       consume();
/* 182 */       this.gramSize = this.minGram;
/*     */     }
/*     */ 
/* 186 */     int length = this.charUtils.toChars(this.buffer, this.bufferStart, this.gramSize, this.termAtt.buffer(), 0);
/* 187 */     this.termAtt.setLength(length);
/* 188 */     this.posIncAtt.setPositionIncrement(1);
/* 189 */     this.posLenAtt.setPositionLength(1);
/* 190 */     this.offsetAtt.setOffset(correctOffset(this.offset), correctOffset(this.offset + length));
/* 191 */     this.gramSize += 1;
/* 192 */     return true;
/*     */   }
/*     */ 
/*     */   private void updateLastNonTokenChar()
/*     */   {
/* 197 */     int termEnd = this.bufferStart + this.gramSize - 1;
/* 198 */     if (termEnd > this.lastCheckedChar) {
/* 199 */       for (int i = termEnd; i > this.lastCheckedChar; i--) {
/* 200 */         if (!isTokenChar(this.buffer[i])) {
/* 201 */           this.lastNonTokenChar = i;
/* 202 */           break;
/*     */         }
/*     */       }
/* 205 */       this.lastCheckedChar = termEnd;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void consume()
/*     */   {
/* 211 */     this.offset += Character.charCount(this.buffer[(this.bufferStart++)]);
/*     */   }
/*     */ 
/*     */   protected boolean isTokenChar(int chr)
/*     */   {
/* 216 */     return true;
/*     */   }
/*     */ 
/*     */   public final void end() throws IOException
/*     */   {
/* 221 */     super.end();
/* 222 */     assert (this.bufferStart <= this.bufferEnd);
/* 223 */     int endOffset = this.offset;
/* 224 */     for (int i = this.bufferStart; i < this.bufferEnd; i++) {
/* 225 */       endOffset += Character.charCount(this.buffer[i]);
/*     */     }
/* 227 */     endOffset = correctOffset(endOffset);
/*     */ 
/* 229 */     this.offsetAtt.setOffset(endOffset, endOffset);
/*     */   }
/*     */ 
/*     */   public final void reset() throws IOException
/*     */   {
/* 234 */     super.reset();
/* 235 */     this.bufferStart = (this.bufferEnd = this.buffer.length);
/* 236 */     this.lastNonTokenChar = (this.lastCheckedChar = this.bufferStart - 1);
/* 237 */     this.offset = 0;
/* 238 */     this.gramSize = this.minGram;
/* 239 */     this.exhausted = false;
/* 240 */     this.charBuffer.reset();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ngram.NGramTokenizer
 * JD-Core Version:    0.6.2
 */