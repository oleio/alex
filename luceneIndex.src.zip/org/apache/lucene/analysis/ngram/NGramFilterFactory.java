/*    */ package org.apache.lucene.analysis.ngram;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.util.TokenFilterFactory;
/*    */ 
/*    */ public class NGramFilterFactory extends TokenFilterFactory
/*    */ {
/*    */   private final int maxGramSize;
/*    */   private final int minGramSize;
/*    */ 
/*    */   public NGramFilterFactory(Map<String, String> args)
/*    */   {
/* 40 */     super(args);
/* 41 */     this.minGramSize = getInt(args, "minGramSize", 1);
/* 42 */     this.maxGramSize = getInt(args, "maxGramSize", 2);
/* 43 */     if (!args.isEmpty())
/* 44 */       throw new IllegalArgumentException("Unknown parameters: " + args);
/*    */   }
/*    */ 
/*    */   public NGramTokenFilter create(TokenStream input)
/*    */   {
/* 50 */     return new NGramTokenFilter(this.luceneMatchVersion, input, this.minGramSize, this.maxGramSize);
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.analysis.ngram.NGramFilterFactory
 * JD-Core Version:    0.6.2
 */