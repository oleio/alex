/*     */ package org.apache.lucene.collation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.CollationKey;
/*     */ import java.text.Collator;
/*     */ import org.apache.lucene.analysis.TokenFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.util.IndexableBinaryStringTools;
/*     */ 
/*     */ @Deprecated
/*     */ public final class CollationKeyFilter extends TokenFilter
/*     */ {
/*     */   private final Collator collator;
/*  80 */   private final CharTermAttribute termAtt = (CharTermAttribute)addAttribute(CharTermAttribute.class);
/*     */ 
/*     */   public CollationKeyFilter(TokenStream input, Collator collator)
/*     */   {
/*  87 */     super(input);
/*     */ 
/*  90 */     this.collator = ((Collator)collator.clone());
/*     */   }
/*     */ 
/*     */   public boolean incrementToken() throws IOException
/*     */   {
/*  95 */     if (this.input.incrementToken()) {
/*  96 */       byte[] collationKey = this.collator.getCollationKey(this.termAtt.toString()).toByteArray();
/*  97 */       int encodedLength = IndexableBinaryStringTools.getEncodedLength(collationKey, 0, collationKey.length);
/*     */ 
/*  99 */       this.termAtt.resizeBuffer(encodedLength);
/* 100 */       this.termAtt.setLength(encodedLength);
/* 101 */       IndexableBinaryStringTools.encode(collationKey, 0, collationKey.length, this.termAtt.buffer(), 0, encodedLength);
/*     */ 
/* 103 */       return true;
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.apache.lucene.collation.CollationKeyFilter
 * JD-Core Version:    0.6.2
 */