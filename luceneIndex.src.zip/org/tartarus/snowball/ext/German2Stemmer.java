/*     */ package org.tartarus.snowball.ext;
/*     */ 
/*     */ import org.tartarus.snowball.Among;
/*     */ import org.tartarus.snowball.SnowballProgram;
/*     */ 
/*     */ public class German2Stemmer extends SnowballProgram
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  17 */   private static final German2Stemmer methodObject = new German2Stemmer();
/*     */ 
/*  19 */   private static final Among[] a_0 = { new Among("", -1, 6, "", methodObject), new Among("ae", 0, 2, "", methodObject), new Among("oe", 0, 3, "", methodObject), new Among("qu", 0, 5, "", methodObject), new Among("ue", 0, 4, "", methodObject), new Among("ß", 0, 1, "", methodObject) };
/*     */ 
/*  28 */   private static final Among[] a_1 = { new Among("", -1, 6, "", methodObject), new Among("U", 0, 2, "", methodObject), new Among("Y", 0, 1, "", methodObject), new Among("ä", 0, 3, "", methodObject), new Among("ö", 0, 4, "", methodObject), new Among("ü", 0, 5, "", methodObject) };
/*     */ 
/*  37 */   private static final Among[] a_2 = { new Among("e", -1, 1, "", methodObject), new Among("em", -1, 1, "", methodObject), new Among("en", -1, 1, "", methodObject), new Among("ern", -1, 1, "", methodObject), new Among("er", -1, 1, "", methodObject), new Among("s", -1, 2, "", methodObject), new Among("es", 5, 1, "", methodObject) };
/*     */ 
/*  47 */   private static final Among[] a_3 = { new Among("en", -1, 1, "", methodObject), new Among("er", -1, 1, "", methodObject), new Among("st", -1, 2, "", methodObject), new Among("est", 2, 1, "", methodObject) };
/*     */ 
/*  54 */   private static final Among[] a_4 = { new Among("ig", -1, 1, "", methodObject), new Among("lich", -1, 1, "", methodObject) };
/*     */ 
/*  59 */   private static final Among[] a_5 = { new Among("end", -1, 1, "", methodObject), new Among("ig", -1, 2, "", methodObject), new Among("ung", -1, 1, "", methodObject), new Among("lich", -1, 3, "", methodObject), new Among("isch", -1, 2, "", methodObject), new Among("ik", -1, 2, "", methodObject), new Among("heit", -1, 3, "", methodObject), new Among("keit", -1, 4, "", methodObject) };
/*     */ 
/*  70 */   private static final char[] g_v = { '\021', 'A', '\020', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\b', '\000', ' ', '\b' };
/*     */ 
/*  72 */   private static final char[] g_s_ending = { 'u', '\036', '\005' };
/*     */ 
/*  74 */   private static final char[] g_st_ending = { 'u', '\036', '\004' };
/*     */   private int I_x;
/*     */   private int I_p2;
/*     */   private int I_p1;
/*     */ 
/*     */   private void copy_from(German2Stemmer other)
/*     */   {
/*  81 */     this.I_x = other.I_x;
/*  82 */     this.I_p2 = other.I_p2;
/*  83 */     this.I_p1 = other.I_p1;
/*  84 */     super.copy_from(other);
/*     */   }
/*     */ 
/*     */   private boolean r_prelude()
/*     */   {
/*  96 */     int v_1 = this.cursor;
/*     */ 
/* 100 */     int v_2 = this.cursor;
/*     */     while (true)
/*     */     {
/* 105 */       int v_3 = this.cursor;
/*     */ 
/* 108 */       if (in_grouping(g_v, 97, 252))
/*     */       {
/* 113 */         this.bra = this.cursor;
/*     */ 
/* 116 */         int v_4 = this.cursor;
/*     */ 
/* 120 */         if (eq_s(1, "u"))
/*     */         {
/* 125 */           this.ket = this.cursor;
/* 126 */           if (in_grouping(g_v, 97, 252))
/*     */           {
/* 131 */             slice_from("U");
/* 132 */             break label147;
/*     */           }
/*     */         }
/* 134 */         this.cursor = v_4;
/*     */ 
/* 137 */         if (eq_s(1, "y"))
/*     */         {
/* 142 */           this.ket = this.cursor;
/* 143 */           if (in_grouping(g_v, 97, 252))
/*     */           {
/* 148 */             slice_from("Y");
/*     */ 
/* 150 */             label147: this.cursor = v_3;
/* 151 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 153 */       this.cursor = v_3;
/* 154 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label189;
/*     */       }
/* 158 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 162 */     label189: this.cursor = v_2;
/*     */ 
/* 165 */     this.cursor = v_1;
/*     */     int v_5;
/*     */     while (true)
/*     */     {
/* 169 */       v_5 = this.cursor;
/*     */ 
/* 173 */       this.bra = this.cursor;
/*     */ 
/* 175 */       int among_var = find_among(a_0, 6);
/* 176 */       if (among_var == 0)
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 181 */       this.ket = this.cursor;
/* 182 */       switch (among_var) {
/*     */       case 0:
/* 184 */         break;
/*     */       case 1:
/* 188 */         slice_from("ss");
/* 189 */         break;
/*     */       case 2:
/* 193 */         slice_from("ä");
/* 194 */         break;
/*     */       case 3:
/* 198 */         slice_from("ö");
/* 199 */         break;
/*     */       case 4:
/* 203 */         slice_from("ü");
/* 204 */         break;
/*     */       case 5:
/* 209 */         int c = this.cursor + 2;
/* 210 */         if ((0 > c) || (c > this.limit))
/*     */         {
/*     */           break label385;
/*     */         }
/* 214 */         this.cursor = c;
/*     */ 
/* 216 */         break;
/*     */       case 6:
/* 220 */         if (this.cursor >= this.limit)
/*     */         {
/*     */           break label385;
/*     */         }
/* 224 */         this.cursor += 1;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 229 */     label385: this.cursor = v_5;
/*     */ 
/* 232 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_mark_regions()
/*     */   {
/* 238 */     this.I_p1 = this.limit;
/* 239 */     this.I_p2 = this.limit;
/*     */ 
/* 241 */     int v_1 = this.cursor;
/*     */ 
/* 245 */     int c = this.cursor + 3;
/* 246 */     if ((0 > c) || (c > this.limit))
/*     */     {
/* 248 */       return false;
/*     */     }
/* 250 */     this.cursor = c;
/*     */ 
/* 253 */     this.I_x = this.cursor;
/* 254 */     this.cursor = v_1;
/*     */ 
/* 259 */     while (!in_grouping(g_v, 97, 252))
/*     */     {
/* 265 */       if (this.cursor >= this.limit)
/*     */       {
/* 267 */         return false;
/*     */       }
/* 269 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 275 */     while (!out_grouping(g_v, 97, 252))
/*     */     {
/* 281 */       if (this.cursor >= this.limit)
/*     */       {
/* 283 */         return false;
/*     */       }
/* 285 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 288 */     this.I_p1 = this.cursor;
/*     */ 
/* 292 */     if (this.I_p1 < this.I_x)
/*     */     {
/* 296 */       this.I_p1 = this.I_x;
/*     */     }
/*     */ 
/* 302 */     while (!in_grouping(g_v, 97, 252))
/*     */     {
/* 308 */       if (this.cursor >= this.limit)
/*     */       {
/* 310 */         return false;
/*     */       }
/* 312 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 318 */     while (!out_grouping(g_v, 97, 252))
/*     */     {
/* 324 */       if (this.cursor >= this.limit)
/*     */       {
/* 326 */         return false;
/*     */       }
/* 328 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 331 */     this.I_p2 = this.cursor;
/* 332 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_postlude()
/*     */   {
/*     */     int v_1;
/*     */     while (true)
/*     */     {
/* 341 */       v_1 = this.cursor;
/*     */ 
/* 345 */       this.bra = this.cursor;
/*     */ 
/* 347 */       int among_var = find_among(a_1, 6);
/* 348 */       if (among_var == 0)
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 353 */       this.ket = this.cursor;
/* 354 */       switch (among_var) {
/*     */       case 0:
/* 356 */         break;
/*     */       case 1:
/* 360 */         slice_from("y");
/* 361 */         break;
/*     */       case 2:
/* 365 */         slice_from("u");
/* 366 */         break;
/*     */       case 3:
/* 370 */         slice_from("a");
/* 371 */         break;
/*     */       case 4:
/* 375 */         slice_from("o");
/* 376 */         break;
/*     */       case 5:
/* 380 */         slice_from("u");
/* 381 */         break;
/*     */       case 6:
/* 385 */         if (this.cursor >= this.limit)
/*     */         {
/*     */           break label155;
/*     */         }
/* 389 */         this.cursor += 1;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 394 */     label155: this.cursor = v_1;
/*     */ 
/* 397 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R1() {
/* 401 */     if (this.I_p1 > this.cursor)
/*     */     {
/* 403 */       return false;
/*     */     }
/* 405 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R2() {
/* 409 */     if (this.I_p2 > this.cursor)
/*     */     {
/* 411 */       return false;
/*     */     }
/* 413 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_standard_suffix()
/*     */   {
/* 429 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 433 */     this.ket = this.cursor;
/*     */ 
/* 435 */     int among_var = find_among_b(a_2, 7);
/* 436 */     if (among_var != 0)
/*     */     {
/* 441 */       this.bra = this.cursor;
/*     */ 
/* 443 */       if (r_R1())
/*     */       {
/* 447 */         switch (among_var) {
/*     */         case 0:
/* 449 */           break;
/*     */         case 1:
/* 453 */           slice_del();
/* 454 */           break;
/*     */         case 2:
/* 457 */           if (in_grouping_b(g_s_ending, 98, 116))
/*     */           {
/* 462 */             slice_del(); } break;
/*     */         }
/*     */       }
/*     */     }
/* 466 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 468 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 472 */     this.ket = this.cursor;
/*     */ 
/* 474 */     among_var = find_among_b(a_3, 4);
/* 475 */     if (among_var != 0)
/*     */     {
/* 480 */       this.bra = this.cursor;
/*     */ 
/* 482 */       if (r_R1())
/*     */       {
/* 486 */         switch (among_var) {
/*     */         case 0:
/* 488 */           break;
/*     */         case 1:
/* 492 */           slice_del();
/* 493 */           break;
/*     */         case 2:
/* 496 */           if (in_grouping_b(g_st_ending, 98, 116))
/*     */           {
/* 502 */             int c = this.cursor - 3;
/* 503 */             if ((this.limit_backward <= c) && (c <= this.limit))
/*     */             {
/* 507 */               this.cursor = c;
/*     */ 
/* 510 */               slice_del(); }  } break;
/*     */         }
/*     */       }
/*     */     }
/* 514 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 516 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 520 */     this.ket = this.cursor;
/*     */ 
/* 522 */     among_var = find_among_b(a_5, 8);
/* 523 */     if (among_var != 0)
/*     */     {
/* 528 */       this.bra = this.cursor;
/*     */ 
/* 530 */       if (r_R2())
/*     */       {
/* 534 */         switch (among_var) {
/*     */         case 0:
/* 536 */           break;
/*     */         case 1:
/* 540 */           slice_del();
/*     */ 
/* 542 */           int v_4 = this.limit - this.cursor;
/*     */ 
/* 546 */           this.ket = this.cursor;
/*     */ 
/* 548 */           if (!eq_s_b(2, "ig"))
/*     */           {
/* 550 */             this.cursor = (this.limit - v_4);
/*     */           }
/*     */           else
/*     */           {
/* 554 */             this.bra = this.cursor;
/*     */ 
/* 557 */             int v_5 = this.limit - this.cursor;
/*     */ 
/* 560 */             if (eq_s_b(1, "e"))
/*     */             {
/* 564 */               this.cursor = (this.limit - v_4);
/*     */             }
/*     */             else {
/* 567 */               this.cursor = (this.limit - v_5);
/*     */ 
/* 570 */               if (!r_R2())
/*     */               {
/* 572 */                 this.cursor = (this.limit - v_4);
/*     */               }
/*     */               else
/*     */               {
/* 576 */                 slice_del();
/*     */               }
/*     */             }
/*     */           }
/* 578 */           break;
/*     */         case 2:
/* 583 */           int v_6 = this.limit - this.cursor;
/*     */ 
/* 586 */           if (!eq_s_b(1, "e"))
/*     */           {
/* 592 */             this.cursor = (this.limit - v_6);
/*     */ 
/* 595 */             slice_del();
/* 596 */           }break;
/*     */         case 3:
/* 600 */           slice_del();
/*     */ 
/* 602 */           int v_7 = this.limit - this.cursor;
/*     */ 
/* 606 */           this.ket = this.cursor;
/*     */ 
/* 609 */           int v_8 = this.limit - this.cursor;
/*     */ 
/* 612 */           if (!eq_s_b(2, "er"))
/*     */           {
/* 618 */             this.cursor = (this.limit - v_8);
/*     */ 
/* 620 */             if (!eq_s_b(2, "en"))
/*     */             {
/* 622 */               this.cursor = (this.limit - v_7);
/* 623 */               break;
/*     */             }
/*     */           }
/*     */ 
/* 627 */           this.bra = this.cursor;
/*     */ 
/* 629 */           if (!r_R1())
/*     */           {
/* 631 */             this.cursor = (this.limit - v_7);
/*     */           }
/*     */           else
/*     */           {
/* 635 */             slice_del();
/*     */           }
/* 637 */           break;
/*     */         case 4:
/* 641 */           slice_del();
/*     */ 
/* 643 */           int v_9 = this.limit - this.cursor;
/*     */ 
/* 647 */           this.ket = this.cursor;
/*     */ 
/* 649 */           among_var = find_among_b(a_4, 2);
/* 650 */           if (among_var == 0)
/*     */           {
/* 652 */             this.cursor = (this.limit - v_9);
/*     */           }
/*     */           else
/*     */           {
/* 656 */             this.bra = this.cursor;
/*     */ 
/* 658 */             if (!r_R2())
/*     */             {
/* 660 */               this.cursor = (this.limit - v_9);
/*     */             }
/*     */             else
/* 663 */               switch (among_var) {
/*     */               case 0:
/* 665 */                 this.cursor = (this.limit - v_9);
/* 666 */                 break;
/*     */               case 1:
/* 670 */                 slice_del();
/*     */               }
/*     */           }
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 677 */     this.cursor = (this.limit - v_3);
/* 678 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean stem()
/*     */   {
/* 689 */     int v_1 = this.cursor;
/*     */ 
/* 692 */     if (!r_prelude());
/* 697 */     this.cursor = v_1;
/*     */ 
/* 699 */     int v_2 = this.cursor;
/*     */ 
/* 702 */     if (!r_mark_regions());
/* 707 */     this.cursor = v_2;
/*     */ 
/* 709 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*     */ 
/* 711 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 714 */     if (!r_standard_suffix());
/* 719 */     this.cursor = (this.limit - v_3);
/* 720 */     this.cursor = this.limit_backward;
/* 721 */     int v_4 = this.cursor;
/*     */ 
/* 724 */     if (!r_postlude());
/* 729 */     this.cursor = v_4;
/* 730 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 735 */     return o instanceof German2Stemmer;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 740 */     return German2Stemmer.class.getName().hashCode();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.ext.German2Stemmer
 * JD-Core Version:    0.6.2
 */