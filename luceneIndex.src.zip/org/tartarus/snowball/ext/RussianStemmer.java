/*     */ package org.tartarus.snowball.ext;
/*     */ 
/*     */ import org.tartarus.snowball.Among;
/*     */ import org.tartarus.snowball.SnowballProgram;
/*     */ 
/*     */ public class RussianStemmer extends SnowballProgram
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  17 */   private static final RussianStemmer methodObject = new RussianStemmer();
/*     */ 
/*  19 */   private static final Among[] a_0 = { new Among("в", -1, 1, "", methodObject), new Among("ив", 0, 2, "", methodObject), new Among("ыв", 0, 2, "", methodObject), new Among("вши", -1, 1, "", methodObject), new Among("ивши", 3, 2, "", methodObject), new Among("ывши", 3, 2, "", methodObject), new Among("вшись", -1, 1, "", methodObject), new Among("ившись", 6, 2, "", methodObject), new Among("ывшись", 6, 2, "", methodObject) };
/*     */ 
/*  31 */   private static final Among[] a_1 = { new Among("ее", -1, 1, "", methodObject), new Among("ие", -1, 1, "", methodObject), new Among("ое", -1, 1, "", methodObject), new Among("ые", -1, 1, "", methodObject), new Among("ими", -1, 1, "", methodObject), new Among("ыми", -1, 1, "", methodObject), new Among("ей", -1, 1, "", methodObject), new Among("ий", -1, 1, "", methodObject), new Among("ой", -1, 1, "", methodObject), new Among("ый", -1, 1, "", methodObject), new Among("ем", -1, 1, "", methodObject), new Among("им", -1, 1, "", methodObject), new Among("ом", -1, 1, "", methodObject), new Among("ым", -1, 1, "", methodObject), new Among("его", -1, 1, "", methodObject), new Among("ого", -1, 1, "", methodObject), new Among("ему", -1, 1, "", methodObject), new Among("ому", -1, 1, "", methodObject), new Among("их", -1, 1, "", methodObject), new Among("ых", -1, 1, "", methodObject), new Among("ею", -1, 1, "", methodObject), new Among("ою", -1, 1, "", methodObject), new Among("ую", -1, 1, "", methodObject), new Among("юю", -1, 1, "", methodObject), new Among("ая", -1, 1, "", methodObject), new Among("яя", -1, 1, "", methodObject) };
/*     */ 
/*  60 */   private static final Among[] a_2 = { new Among("ем", -1, 1, "", methodObject), new Among("нн", -1, 1, "", methodObject), new Among("вш", -1, 1, "", methodObject), new Among("ивш", 2, 2, "", methodObject), new Among("ывш", 2, 2, "", methodObject), new Among("щ", -1, 1, "", methodObject), new Among("ющ", 5, 1, "", methodObject), new Among("ующ", 6, 2, "", methodObject) };
/*     */ 
/*  71 */   private static final Among[] a_3 = { new Among("сь", -1, 1, "", methodObject), new Among("ся", -1, 1, "", methodObject) };
/*     */ 
/*  76 */   private static final Among[] a_4 = { new Among("ла", -1, 1, "", methodObject), new Among("ила", 0, 2, "", methodObject), new Among("ыла", 0, 2, "", methodObject), new Among("на", -1, 1, "", methodObject), new Among("ена", 3, 2, "", methodObject), new Among("ете", -1, 1, "", methodObject), new Among("ите", -1, 2, "", methodObject), new Among("йте", -1, 1, "", methodObject), new Among("ейте", 7, 2, "", methodObject), new Among("уйте", 7, 2, "", methodObject), new Among("ли", -1, 1, "", methodObject), new Among("или", 10, 2, "", methodObject), new Among("ыли", 10, 2, "", methodObject), new Among("й", -1, 1, "", methodObject), new Among("ей", 13, 2, "", methodObject), new Among("уй", 13, 2, "", methodObject), new Among("л", -1, 1, "", methodObject), new Among("ил", 16, 2, "", methodObject), new Among("ыл", 16, 2, "", methodObject), new Among("ем", -1, 1, "", methodObject), new Among("им", -1, 2, "", methodObject), new Among("ым", -1, 2, "", methodObject), new Among("н", -1, 1, "", methodObject), new Among("ен", 22, 2, "", methodObject), new Among("ло", -1, 1, "", methodObject), new Among("ило", 24, 2, "", methodObject), new Among("ыло", 24, 2, "", methodObject), new Among("но", -1, 1, "", methodObject), new Among("ено", 27, 2, "", methodObject), new Among("нно", 27, 1, "", methodObject), new Among("ет", -1, 1, "", methodObject), new Among("ует", 30, 2, "", methodObject), new Among("ит", -1, 2, "", methodObject), new Among("ыт", -1, 2, "", methodObject), new Among("ют", -1, 1, "", methodObject), new Among("уют", 34, 2, "", methodObject), new Among("ят", -1, 2, "", methodObject), new Among("ны", -1, 1, "", methodObject), new Among("ены", 37, 2, "", methodObject), new Among("ть", -1, 1, "", methodObject), new Among("ить", 39, 2, "", methodObject), new Among("ыть", 39, 2, "", methodObject), new Among("ешь", -1, 1, "", methodObject), new Among("ишь", -1, 2, "", methodObject), new Among("ю", -1, 2, "", methodObject), new Among("ую", 44, 2, "", methodObject) };
/*     */ 
/* 125 */   private static final Among[] a_5 = { new Among("а", -1, 1, "", methodObject), new Among("ев", -1, 1, "", methodObject), new Among("ов", -1, 1, "", methodObject), new Among("е", -1, 1, "", methodObject), new Among("ие", 3, 1, "", methodObject), new Among("ье", 3, 1, "", methodObject), new Among("и", -1, 1, "", methodObject), new Among("еи", 6, 1, "", methodObject), new Among("ии", 6, 1, "", methodObject), new Among("ами", 6, 1, "", methodObject), new Among("ями", 6, 1, "", methodObject), new Among("иями", 10, 1, "", methodObject), new Among("й", -1, 1, "", methodObject), new Among("ей", 12, 1, "", methodObject), new Among("ией", 13, 1, "", methodObject), new Among("ий", 12, 1, "", methodObject), new Among("ой", 12, 1, "", methodObject), new Among("ам", -1, 1, "", methodObject), new Among("ем", -1, 1, "", methodObject), new Among("ием", 18, 1, "", methodObject), new Among("ом", -1, 1, "", methodObject), new Among("ям", -1, 1, "", methodObject), new Among("иям", 21, 1, "", methodObject), new Among("о", -1, 1, "", methodObject), new Among("у", -1, 1, "", methodObject), new Among("ах", -1, 1, "", methodObject), new Among("ях", -1, 1, "", methodObject), new Among("иях", 26, 1, "", methodObject), new Among("ы", -1, 1, "", methodObject), new Among("ь", -1, 1, "", methodObject), new Among("ю", -1, 1, "", methodObject), new Among("ию", 30, 1, "", methodObject), new Among("ью", 30, 1, "", methodObject), new Among("я", -1, 1, "", methodObject), new Among("ия", 33, 1, "", methodObject), new Among("ья", 33, 1, "", methodObject) };
/*     */ 
/* 164 */   private static final Among[] a_6 = { new Among("ост", -1, 1, "", methodObject), new Among("ость", -1, 1, "", methodObject) };
/*     */ 
/* 169 */   private static final Among[] a_7 = { new Among("ейше", -1, 1, "", methodObject), new Among("н", -1, 2, "", methodObject), new Among("ейш", -1, 1, "", methodObject), new Among("ь", -1, 3, "", methodObject) };
/*     */ 
/* 176 */   private static final char[] g_v = { '!', 'A', '\b', 'è' };
/*     */   private int I_p2;
/*     */   private int I_pV;
/*     */ 
/*     */   private void copy_from(RussianStemmer other)
/*     */   {
/* 182 */     this.I_p2 = other.I_p2;
/* 183 */     this.I_pV = other.I_pV;
/* 184 */     super.copy_from(other);
/*     */   }
/*     */ 
/*     */   private boolean r_mark_regions()
/*     */   {
/* 190 */     this.I_pV = this.limit;
/* 191 */     this.I_p2 = this.limit;
/*     */ 
/* 193 */     int v_1 = this.cursor;
/*     */ 
/* 200 */     while (!in_grouping(g_v, 1072, 1103))
/*     */     {
/* 206 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label209;
/*     */       }
/* 210 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 213 */     this.I_pV = this.cursor;
/*     */ 
/* 218 */     while (!out_grouping(g_v, 1072, 1103))
/*     */     {
/* 224 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label209;
/*     */       }
/* 228 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 234 */     while (!in_grouping(g_v, 1072, 1103))
/*     */     {
/* 240 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label209;
/*     */       }
/* 244 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 250 */     while (!out_grouping(g_v, 1072, 1103))
/*     */     {
/* 256 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label209;
/*     */       }
/* 260 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 263 */     this.I_p2 = this.cursor;
/*     */ 
/* 265 */     label209: this.cursor = v_1;
/* 266 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R2() {
/* 270 */     if (this.I_p2 > this.cursor)
/*     */     {
/* 272 */       return false;
/*     */     }
/* 274 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_perfective_gerund()
/*     */   {
/* 282 */     this.ket = this.cursor;
/*     */ 
/* 284 */     int among_var = find_among_b(a_0, 9);
/* 285 */     if (among_var == 0)
/*     */     {
/* 287 */       return false;
/*     */     }
/*     */ 
/* 290 */     this.bra = this.cursor;
/* 291 */     switch (among_var) {
/*     */     case 0:
/* 293 */       return false;
/*     */     case 1:
/* 298 */       int v_1 = this.limit - this.cursor;
/*     */ 
/* 301 */       if (!eq_s_b(1, "а"))
/*     */       {
/* 307 */         this.cursor = (this.limit - v_1);
/*     */ 
/* 309 */         if (!eq_s_b(1, "я"))
/*     */         {
/* 311 */           return false;
/*     */         }
/*     */       }
/*     */ 
/* 315 */       slice_del();
/* 316 */       break;
/*     */     case 2:
/* 320 */       slice_del();
/*     */     }
/*     */ 
/* 323 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_adjective()
/*     */   {
/* 330 */     this.ket = this.cursor;
/*     */ 
/* 332 */     int among_var = find_among_b(a_1, 26);
/* 333 */     if (among_var == 0)
/*     */     {
/* 335 */       return false;
/*     */     }
/*     */ 
/* 338 */     this.bra = this.cursor;
/* 339 */     switch (among_var) {
/*     */     case 0:
/* 341 */       return false;
/*     */     case 1:
/* 345 */       slice_del();
/*     */     }
/*     */ 
/* 348 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_adjectival()
/*     */   {
/* 357 */     if (!r_adjective())
/*     */     {
/* 359 */       return false;
/*     */     }
/*     */ 
/* 362 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 366 */     this.ket = this.cursor;
/*     */ 
/* 368 */     int among_var = find_among_b(a_2, 8);
/* 369 */     if (among_var == 0)
/*     */     {
/* 371 */       this.cursor = (this.limit - v_1);
/*     */     }
/*     */     else
/*     */     {
/* 375 */       this.bra = this.cursor;
/* 376 */       switch (among_var) {
/*     */       case 0:
/* 378 */         this.cursor = (this.limit - v_1);
/* 379 */         break;
/*     */       case 1:
/* 384 */         int v_2 = this.limit - this.cursor;
/*     */ 
/* 387 */         if (!eq_s_b(1, "а"))
/*     */         {
/* 393 */           this.cursor = (this.limit - v_2);
/*     */ 
/* 395 */           if (!eq_s_b(1, "я"))
/*     */           {
/* 397 */             this.cursor = (this.limit - v_1);
/* 398 */             break;
/*     */           }
/*     */         }
/*     */ 
/* 402 */         slice_del();
/* 403 */         break;
/*     */       case 2:
/* 407 */         slice_del();
/*     */       }
/*     */     }
/*     */ 
/* 411 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_reflexive()
/*     */   {
/* 418 */     this.ket = this.cursor;
/*     */ 
/* 420 */     int among_var = find_among_b(a_3, 2);
/* 421 */     if (among_var == 0)
/*     */     {
/* 423 */       return false;
/*     */     }
/*     */ 
/* 426 */     this.bra = this.cursor;
/* 427 */     switch (among_var) {
/*     */     case 0:
/* 429 */       return false;
/*     */     case 1:
/* 433 */       slice_del();
/*     */     }
/*     */ 
/* 436 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_verb()
/*     */   {
/* 444 */     this.ket = this.cursor;
/*     */ 
/* 446 */     int among_var = find_among_b(a_4, 46);
/* 447 */     if (among_var == 0)
/*     */     {
/* 449 */       return false;
/*     */     }
/*     */ 
/* 452 */     this.bra = this.cursor;
/* 453 */     switch (among_var) {
/*     */     case 0:
/* 455 */       return false;
/*     */     case 1:
/* 460 */       int v_1 = this.limit - this.cursor;
/*     */ 
/* 463 */       if (!eq_s_b(1, "а"))
/*     */       {
/* 469 */         this.cursor = (this.limit - v_1);
/*     */ 
/* 471 */         if (!eq_s_b(1, "я"))
/*     */         {
/* 473 */           return false;
/*     */         }
/*     */       }
/*     */ 
/* 477 */       slice_del();
/* 478 */       break;
/*     */     case 2:
/* 482 */       slice_del();
/*     */     }
/*     */ 
/* 485 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_noun()
/*     */   {
/* 492 */     this.ket = this.cursor;
/*     */ 
/* 494 */     int among_var = find_among_b(a_5, 36);
/* 495 */     if (among_var == 0)
/*     */     {
/* 497 */       return false;
/*     */     }
/*     */ 
/* 500 */     this.bra = this.cursor;
/* 501 */     switch (among_var) {
/*     */     case 0:
/* 503 */       return false;
/*     */     case 1:
/* 507 */       slice_del();
/*     */     }
/*     */ 
/* 510 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_derivational()
/*     */   {
/* 517 */     this.ket = this.cursor;
/*     */ 
/* 519 */     int among_var = find_among_b(a_6, 2);
/* 520 */     if (among_var == 0)
/*     */     {
/* 522 */       return false;
/*     */     }
/*     */ 
/* 525 */     this.bra = this.cursor;
/*     */ 
/* 527 */     if (!r_R2())
/*     */     {
/* 529 */       return false;
/*     */     }
/* 531 */     switch (among_var) {
/*     */     case 0:
/* 533 */       return false;
/*     */     case 1:
/* 537 */       slice_del();
/*     */     }
/*     */ 
/* 540 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_tidy_up()
/*     */   {
/* 547 */     this.ket = this.cursor;
/*     */ 
/* 549 */     int among_var = find_among_b(a_7, 4);
/* 550 */     if (among_var == 0)
/*     */     {
/* 552 */       return false;
/*     */     }
/*     */ 
/* 555 */     this.bra = this.cursor;
/* 556 */     switch (among_var) {
/*     */     case 0:
/* 558 */       return false;
/*     */     case 1:
/* 562 */       slice_del();
/*     */ 
/* 564 */       this.ket = this.cursor;
/*     */ 
/* 566 */       if (!eq_s_b(1, "н"))
/*     */       {
/* 568 */         return false;
/*     */       }
/*     */ 
/* 571 */       this.bra = this.cursor;
/*     */ 
/* 573 */       if (!eq_s_b(1, "н"))
/*     */       {
/* 575 */         return false;
/*     */       }
/*     */ 
/* 578 */       slice_del();
/* 579 */       break;
/*     */     case 2:
/* 583 */       if (!eq_s_b(1, "н"))
/*     */       {
/* 585 */         return false;
/*     */       }
/*     */ 
/* 588 */       slice_del();
/* 589 */       break;
/*     */     case 3:
/* 593 */       slice_del();
/*     */     }
/*     */ 
/* 596 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean stem()
/*     */   {
/* 613 */     int v_1 = this.cursor;
/*     */ 
/* 616 */     if (!r_mark_regions());
/* 621 */     this.cursor = v_1;
/*     */ 
/* 623 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*     */ 
/* 625 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 627 */     if (this.cursor < this.I_pV)
/*     */     {
/* 629 */       return false;
/*     */     }
/* 631 */     this.cursor = this.I_pV;
/* 632 */     int v_3 = this.limit_backward;
/* 633 */     this.limit_backward = this.cursor;
/* 634 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 637 */     int v_4 = this.limit - this.cursor;
/*     */ 
/* 642 */     int v_5 = this.limit - this.cursor;
/*     */ 
/* 645 */     if (!r_perfective_gerund())
/*     */     {
/* 651 */       this.cursor = (this.limit - v_5);
/*     */ 
/* 654 */       int v_6 = this.limit - this.cursor;
/*     */ 
/* 657 */       if (!r_reflexive())
/*     */       {
/* 659 */         this.cursor = (this.limit - v_6);
/*     */       }
/*     */ 
/* 665 */       int v_7 = this.limit - this.cursor;
/*     */ 
/* 668 */       if (!r_adjectival())
/*     */       {
/* 674 */         this.cursor = (this.limit - v_7);
/*     */ 
/* 677 */         if (!r_verb())
/*     */         {
/* 683 */           this.cursor = (this.limit - v_7);
/*     */ 
/* 685 */           if (r_noun());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 692 */     this.cursor = (this.limit - v_4);
/*     */ 
/* 694 */     int v_8 = this.limit - this.cursor;
/*     */ 
/* 698 */     this.ket = this.cursor;
/*     */ 
/* 700 */     if (!eq_s_b(1, "и"))
/*     */     {
/* 702 */       this.cursor = (this.limit - v_8);
/*     */     }
/*     */     else
/*     */     {
/* 706 */       this.bra = this.cursor;
/*     */ 
/* 708 */       slice_del();
/*     */     }
/*     */ 
/* 711 */     int v_9 = this.limit - this.cursor;
/*     */ 
/* 714 */     if (!r_derivational());
/* 719 */     this.cursor = (this.limit - v_9);
/*     */ 
/* 721 */     int v_10 = this.limit - this.cursor;
/*     */ 
/* 724 */     if (!r_tidy_up());
/* 729 */     this.cursor = (this.limit - v_10);
/* 730 */     this.limit_backward = v_3;
/* 731 */     this.cursor = this.limit_backward; return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 736 */     return o instanceof RussianStemmer;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 741 */     return RussianStemmer.class.getName().hashCode();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.ext.RussianStemmer
 * JD-Core Version:    0.6.2
 */