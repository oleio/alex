/*      */ package org.tartarus.snowball.ext;
/*      */ 
/*      */ import org.tartarus.snowball.Among;
/*      */ import org.tartarus.snowball.SnowballProgram;
/*      */ 
/*      */ public class TurkishStemmer extends SnowballProgram
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   17 */   private static final TurkishStemmer methodObject = new TurkishStemmer();
/*      */ 
/*   19 */   private static final Among[] a_0 = { new Among("m", -1, -1, "", methodObject), new Among("n", -1, -1, "", methodObject), new Among("miz", -1, -1, "", methodObject), new Among("niz", -1, -1, "", methodObject), new Among("muz", -1, -1, "", methodObject), new Among("nuz", -1, -1, "", methodObject), new Among("müz", -1, -1, "", methodObject), new Among("nüz", -1, -1, "", methodObject), new Among("mız", -1, -1, "", methodObject), new Among("nız", -1, -1, "", methodObject) };
/*      */ 
/*   32 */   private static final Among[] a_1 = { new Among("leri", -1, -1, "", methodObject), new Among("ları", -1, -1, "", methodObject) };
/*      */ 
/*   37 */   private static final Among[] a_2 = { new Among("ni", -1, -1, "", methodObject), new Among("nu", -1, -1, "", methodObject), new Among("nü", -1, -1, "", methodObject), new Among("nı", -1, -1, "", methodObject) };
/*      */ 
/*   44 */   private static final Among[] a_3 = { new Among("in", -1, -1, "", methodObject), new Among("un", -1, -1, "", methodObject), new Among("ün", -1, -1, "", methodObject), new Among("ın", -1, -1, "", methodObject) };
/*      */ 
/*   51 */   private static final Among[] a_4 = { new Among("a", -1, -1, "", methodObject), new Among("e", -1, -1, "", methodObject) };
/*      */ 
/*   56 */   private static final Among[] a_5 = { new Among("na", -1, -1, "", methodObject), new Among("ne", -1, -1, "", methodObject) };
/*      */ 
/*   61 */   private static final Among[] a_6 = { new Among("da", -1, -1, "", methodObject), new Among("ta", -1, -1, "", methodObject), new Among("de", -1, -1, "", methodObject), new Among("te", -1, -1, "", methodObject) };
/*      */ 
/*   68 */   private static final Among[] a_7 = { new Among("nda", -1, -1, "", methodObject), new Among("nde", -1, -1, "", methodObject) };
/*      */ 
/*   73 */   private static final Among[] a_8 = { new Among("dan", -1, -1, "", methodObject), new Among("tan", -1, -1, "", methodObject), new Among("den", -1, -1, "", methodObject), new Among("ten", -1, -1, "", methodObject) };
/*      */ 
/*   80 */   private static final Among[] a_9 = { new Among("ndan", -1, -1, "", methodObject), new Among("nden", -1, -1, "", methodObject) };
/*      */ 
/*   85 */   private static final Among[] a_10 = { new Among("la", -1, -1, "", methodObject), new Among("le", -1, -1, "", methodObject) };
/*      */ 
/*   90 */   private static final Among[] a_11 = { new Among("ca", -1, -1, "", methodObject), new Among("ce", -1, -1, "", methodObject) };
/*      */ 
/*   95 */   private static final Among[] a_12 = { new Among("im", -1, -1, "", methodObject), new Among("um", -1, -1, "", methodObject), new Among("üm", -1, -1, "", methodObject), new Among("ım", -1, -1, "", methodObject) };
/*      */ 
/*  102 */   private static final Among[] a_13 = { new Among("sin", -1, -1, "", methodObject), new Among("sun", -1, -1, "", methodObject), new Among("sün", -1, -1, "", methodObject), new Among("sın", -1, -1, "", methodObject) };
/*      */ 
/*  109 */   private static final Among[] a_14 = { new Among("iz", -1, -1, "", methodObject), new Among("uz", -1, -1, "", methodObject), new Among("üz", -1, -1, "", methodObject), new Among("ız", -1, -1, "", methodObject) };
/*      */ 
/*  116 */   private static final Among[] a_15 = { new Among("siniz", -1, -1, "", methodObject), new Among("sunuz", -1, -1, "", methodObject), new Among("sünüz", -1, -1, "", methodObject), new Among("sınız", -1, -1, "", methodObject) };
/*      */ 
/*  123 */   private static final Among[] a_16 = { new Among("lar", -1, -1, "", methodObject), new Among("ler", -1, -1, "", methodObject) };
/*      */ 
/*  128 */   private static final Among[] a_17 = { new Among("niz", -1, -1, "", methodObject), new Among("nuz", -1, -1, "", methodObject), new Among("nüz", -1, -1, "", methodObject), new Among("nız", -1, -1, "", methodObject) };
/*      */ 
/*  135 */   private static final Among[] a_18 = { new Among("dir", -1, -1, "", methodObject), new Among("tir", -1, -1, "", methodObject), new Among("dur", -1, -1, "", methodObject), new Among("tur", -1, -1, "", methodObject), new Among("dür", -1, -1, "", methodObject), new Among("tür", -1, -1, "", methodObject), new Among("dır", -1, -1, "", methodObject), new Among("tır", -1, -1, "", methodObject) };
/*      */ 
/*  146 */   private static final Among[] a_19 = { new Among("casına", -1, -1, "", methodObject), new Among("cesine", -1, -1, "", methodObject) };
/*      */ 
/*  151 */   private static final Among[] a_20 = { new Among("di", -1, -1, "", methodObject), new Among("ti", -1, -1, "", methodObject), new Among("dik", -1, -1, "", methodObject), new Among("tik", -1, -1, "", methodObject), new Among("duk", -1, -1, "", methodObject), new Among("tuk", -1, -1, "", methodObject), new Among("dük", -1, -1, "", methodObject), new Among("tük", -1, -1, "", methodObject), new Among("dık", -1, -1, "", methodObject), new Among("tık", -1, -1, "", methodObject), new Among("dim", -1, -1, "", methodObject), new Among("tim", -1, -1, "", methodObject), new Among("dum", -1, -1, "", methodObject), new Among("tum", -1, -1, "", methodObject), new Among("düm", -1, -1, "", methodObject), new Among("tüm", -1, -1, "", methodObject), new Among("dım", -1, -1, "", methodObject), new Among("tım", -1, -1, "", methodObject), new Among("din", -1, -1, "", methodObject), new Among("tin", -1, -1, "", methodObject), new Among("dun", -1, -1, "", methodObject), new Among("tun", -1, -1, "", methodObject), new Among("dün", -1, -1, "", methodObject), new Among("tün", -1, -1, "", methodObject), new Among("dın", -1, -1, "", methodObject), new Among("tın", -1, -1, "", methodObject), new Among("du", -1, -1, "", methodObject), new Among("tu", -1, -1, "", methodObject), new Among("dü", -1, -1, "", methodObject), new Among("tü", -1, -1, "", methodObject), new Among("dı", -1, -1, "", methodObject), new Among("tı", -1, -1, "", methodObject) };
/*      */ 
/*  186 */   private static final Among[] a_21 = { new Among("sa", -1, -1, "", methodObject), new Among("se", -1, -1, "", methodObject), new Among("sak", -1, -1, "", methodObject), new Among("sek", -1, -1, "", methodObject), new Among("sam", -1, -1, "", methodObject), new Among("sem", -1, -1, "", methodObject), new Among("san", -1, -1, "", methodObject), new Among("sen", -1, -1, "", methodObject) };
/*      */ 
/*  197 */   private static final Among[] a_22 = { new Among("miş", -1, -1, "", methodObject), new Among("muş", -1, -1, "", methodObject), new Among("müş", -1, -1, "", methodObject), new Among("mış", -1, -1, "", methodObject) };
/*      */ 
/*  204 */   private static final Among[] a_23 = { new Among("b", -1, 1, "", methodObject), new Among("c", -1, 2, "", methodObject), new Among("d", -1, 3, "", methodObject), new Among("ğ", -1, 4, "", methodObject) };
/*      */ 
/*  211 */   private static final char[] g_vowel = { '\021', 'A', '\020', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', ' ', '\b', '\000', '\000', '\000', '\000', '\000', '\000', '\001' };
/*      */ 
/*  213 */   private static final char[] g_U = { '\001', '\020', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\b', '\000', '\000', '\000', '\000', '\000', '\000', '\001' };
/*      */ 
/*  215 */   private static final char[] g_vowel1 = { '\001', '@', '\020', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\001' };
/*      */ 
/*  217 */   private static final char[] g_vowel2 = { '\021', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '' };
/*      */ 
/*  219 */   private static final char[] g_vowel3 = { '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\001' };
/*      */ 
/*  221 */   private static final char[] g_vowel4 = { '\021' };
/*      */ 
/*  223 */   private static final char[] g_vowel5 = { 'A' };
/*      */ 
/*  225 */   private static final char[] g_vowel6 = { 'A' };
/*      */   private boolean B_continue_stemming_noun_suffixes;
/*      */   private int I_strlen;
/*      */ 
/*      */   private void copy_from(TurkishStemmer other)
/*      */   {
/*  231 */     this.B_continue_stemming_noun_suffixes = other.B_continue_stemming_noun_suffixes;
/*  232 */     this.I_strlen = other.I_strlen;
/*  233 */     super.copy_from(other);
/*      */   }
/*      */ 
/*      */   private boolean r_check_vowel_harmony()
/*      */   {
/*  250 */     int v_1 = this.limit - this.cursor;
/*      */     while (true)
/*      */     {
/*  256 */       int v_2 = this.limit - this.cursor;
/*      */ 
/*  258 */       if (in_grouping_b(g_vowel, 97, 305))
/*      */       {
/*  262 */         this.cursor = (this.limit - v_2);
/*  263 */         break;
/*      */       }
/*  265 */       this.cursor = (this.limit - v_2);
/*  266 */       if (this.cursor <= this.limit_backward)
/*      */       {
/*  268 */         return false;
/*      */       }
/*  270 */       this.cursor -= 1;
/*      */     }
/*      */ 
/*  275 */     int v_3 = this.limit - this.cursor;
/*      */ 
/*  279 */     if (eq_s_b(1, "a"))
/*      */     {
/*      */       while (true)
/*      */       {
/*  286 */         int v_4 = this.limit - this.cursor;
/*      */ 
/*  288 */         if (in_grouping_b(g_vowel1, 97, 305))
/*      */         {
/*  292 */           this.cursor = (this.limit - v_4);
/*  293 */           break label916;
/*      */         }
/*  295 */         this.cursor = (this.limit - v_4);
/*  296 */         if (this.cursor <= this.limit_backward)
/*      */         {
/*      */           break;
/*      */         }
/*  300 */         this.cursor -= 1;
/*      */       }
/*      */     }
/*      */ 
/*  304 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  308 */     if (eq_s_b(1, "e"))
/*      */     {
/*      */       while (true)
/*      */       {
/*  315 */         int v_5 = this.limit - this.cursor;
/*      */ 
/*  317 */         if (in_grouping_b(g_vowel2, 101, 252))
/*      */         {
/*  321 */           this.cursor = (this.limit - v_5);
/*  322 */           break label916;
/*      */         }
/*  324 */         this.cursor = (this.limit - v_5);
/*  325 */         if (this.cursor <= this.limit_backward)
/*      */         {
/*      */           break;
/*      */         }
/*  329 */         this.cursor -= 1;
/*      */       }
/*      */     }
/*      */ 
/*  333 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  337 */     if (eq_s_b(1, "ı"))
/*      */     {
/*      */       while (true)
/*      */       {
/*  344 */         int v_6 = this.limit - this.cursor;
/*      */ 
/*  346 */         if (in_grouping_b(g_vowel3, 97, 305))
/*      */         {
/*  350 */           this.cursor = (this.limit - v_6);
/*  351 */           break label916;
/*      */         }
/*  353 */         this.cursor = (this.limit - v_6);
/*  354 */         if (this.cursor <= this.limit_backward)
/*      */         {
/*      */           break;
/*      */         }
/*  358 */         this.cursor -= 1;
/*      */       }
/*      */     }
/*      */ 
/*  362 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  366 */     if (eq_s_b(1, "i"))
/*      */     {
/*      */       while (true)
/*      */       {
/*  373 */         int v_7 = this.limit - this.cursor;
/*      */ 
/*  375 */         if (in_grouping_b(g_vowel4, 101, 105))
/*      */         {
/*  379 */           this.cursor = (this.limit - v_7);
/*  380 */           break label916;
/*      */         }
/*  382 */         this.cursor = (this.limit - v_7);
/*  383 */         if (this.cursor <= this.limit_backward)
/*      */         {
/*      */           break;
/*      */         }
/*  387 */         this.cursor -= 1;
/*      */       }
/*      */     }
/*      */ 
/*  391 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  395 */     if (eq_s_b(1, "o"))
/*      */     {
/*      */       while (true)
/*      */       {
/*  402 */         int v_8 = this.limit - this.cursor;
/*      */ 
/*  404 */         if (in_grouping_b(g_vowel5, 111, 117))
/*      */         {
/*  408 */           this.cursor = (this.limit - v_8);
/*  409 */           break label916;
/*      */         }
/*  411 */         this.cursor = (this.limit - v_8);
/*  412 */         if (this.cursor <= this.limit_backward)
/*      */         {
/*      */           break;
/*      */         }
/*  416 */         this.cursor -= 1;
/*      */       }
/*      */     }
/*      */ 
/*  420 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  424 */     if (eq_s_b(1, "ö"))
/*      */     {
/*      */       while (true)
/*      */       {
/*  431 */         int v_9 = this.limit - this.cursor;
/*      */ 
/*  433 */         if (in_grouping_b(g_vowel6, 246, 252))
/*      */         {
/*  437 */           this.cursor = (this.limit - v_9);
/*  438 */           break label916;
/*      */         }
/*  440 */         this.cursor = (this.limit - v_9);
/*  441 */         if (this.cursor <= this.limit_backward)
/*      */         {
/*      */           break;
/*      */         }
/*  445 */         this.cursor -= 1;
/*      */       }
/*      */     }
/*      */ 
/*  449 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  453 */     if (eq_s_b(1, "u"))
/*      */     {
/*      */       while (true)
/*      */       {
/*  460 */         int v_10 = this.limit - this.cursor;
/*      */ 
/*  462 */         if (in_grouping_b(g_vowel5, 111, 117))
/*      */         {
/*  466 */           this.cursor = (this.limit - v_10);
/*  467 */           break label916;
/*      */         }
/*  469 */         this.cursor = (this.limit - v_10);
/*  470 */         if (this.cursor <= this.limit_backward)
/*      */         {
/*      */           break;
/*      */         }
/*  474 */         this.cursor -= 1;
/*      */       }
/*      */     }
/*      */ 
/*  478 */     this.cursor = (this.limit - v_3);
/*      */ 
/*  481 */     if (!eq_s_b(1, "ü"))
/*      */     {
/*  483 */       return false;
/*      */     }
/*      */ 
/*      */     while (true)
/*      */     {
/*  488 */       int v_11 = this.limit - this.cursor;
/*      */ 
/*  490 */       if (in_grouping_b(g_vowel6, 246, 252))
/*      */       {
/*  494 */         this.cursor = (this.limit - v_11);
/*  495 */         break;
/*      */       }
/*  497 */       this.cursor = (this.limit - v_11);
/*  498 */       if (this.cursor <= this.limit_backward)
/*      */       {
/*  500 */         return false;
/*      */       }
/*  502 */       this.cursor -= 1;
/*      */     }
/*      */ 
/*  505 */     label916: this.cursor = (this.limit - v_1);
/*  506 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_suffix_with_optional_n_consonant()
/*      */   {
/*  520 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  525 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  527 */     if (eq_s_b(1, "n"))
/*      */     {
/*  531 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  533 */       if (this.cursor > this.limit_backward)
/*      */       {
/*  537 */         this.cursor -= 1;
/*      */ 
/*  540 */         int v_3 = this.limit - this.cursor;
/*  541 */         if (in_grouping_b(g_vowel, 97, 305))
/*      */         {
/*  545 */           this.cursor = (this.limit - v_3);
/*  546 */           break label261;
/*      */         }
/*      */       }
/*      */     }
/*  548 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  553 */     int v_4 = this.limit - this.cursor;
/*      */ 
/*  557 */     int v_5 = this.limit - this.cursor;
/*      */ 
/*  559 */     if (eq_s_b(1, "n"))
/*      */     {
/*  563 */       this.cursor = (this.limit - v_5);
/*  564 */       return false;
/*      */     }
/*  566 */     this.cursor = (this.limit - v_4);
/*      */ 
/*  569 */     int v_6 = this.limit - this.cursor;
/*      */ 
/*  572 */     if (this.cursor <= this.limit_backward)
/*      */     {
/*  574 */       return false;
/*      */     }
/*  576 */     this.cursor -= 1;
/*      */ 
/*  579 */     int v_7 = this.limit - this.cursor;
/*  580 */     if (!in_grouping_b(g_vowel, 97, 305))
/*      */     {
/*  582 */       return false;
/*      */     }
/*  584 */     this.cursor = (this.limit - v_7);
/*  585 */     this.cursor = (this.limit - v_6);
/*      */ 
/*  587 */     label261: return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_suffix_with_optional_s_consonant()
/*      */   {
/*  601 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  606 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  608 */     if (eq_s_b(1, "s"))
/*      */     {
/*  612 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  614 */       if (this.cursor > this.limit_backward)
/*      */       {
/*  618 */         this.cursor -= 1;
/*      */ 
/*  621 */         int v_3 = this.limit - this.cursor;
/*  622 */         if (in_grouping_b(g_vowel, 97, 305))
/*      */         {
/*  626 */           this.cursor = (this.limit - v_3);
/*  627 */           break label261;
/*      */         }
/*      */       }
/*      */     }
/*  629 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  634 */     int v_4 = this.limit - this.cursor;
/*      */ 
/*  638 */     int v_5 = this.limit - this.cursor;
/*      */ 
/*  640 */     if (eq_s_b(1, "s"))
/*      */     {
/*  644 */       this.cursor = (this.limit - v_5);
/*  645 */       return false;
/*      */     }
/*  647 */     this.cursor = (this.limit - v_4);
/*      */ 
/*  650 */     int v_6 = this.limit - this.cursor;
/*      */ 
/*  653 */     if (this.cursor <= this.limit_backward)
/*      */     {
/*  655 */       return false;
/*      */     }
/*  657 */     this.cursor -= 1;
/*      */ 
/*  660 */     int v_7 = this.limit - this.cursor;
/*  661 */     if (!in_grouping_b(g_vowel, 97, 305))
/*      */     {
/*  663 */       return false;
/*      */     }
/*  665 */     this.cursor = (this.limit - v_7);
/*  666 */     this.cursor = (this.limit - v_6);
/*      */ 
/*  668 */     label261: return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_suffix_with_optional_y_consonant()
/*      */   {
/*  682 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  687 */     int v_2 = this.limit - this.cursor;
/*      */ 
/*  689 */     if (eq_s_b(1, "y"))
/*      */     {
/*  693 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  695 */       if (this.cursor > this.limit_backward)
/*      */       {
/*  699 */         this.cursor -= 1;
/*      */ 
/*  702 */         int v_3 = this.limit - this.cursor;
/*  703 */         if (in_grouping_b(g_vowel, 97, 305))
/*      */         {
/*  707 */           this.cursor = (this.limit - v_3);
/*  708 */           break label261;
/*      */         }
/*      */       }
/*      */     }
/*  710 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  715 */     int v_4 = this.limit - this.cursor;
/*      */ 
/*  719 */     int v_5 = this.limit - this.cursor;
/*      */ 
/*  721 */     if (eq_s_b(1, "y"))
/*      */     {
/*  725 */       this.cursor = (this.limit - v_5);
/*  726 */       return false;
/*      */     }
/*  728 */     this.cursor = (this.limit - v_4);
/*      */ 
/*  731 */     int v_6 = this.limit - this.cursor;
/*      */ 
/*  734 */     if (this.cursor <= this.limit_backward)
/*      */     {
/*  736 */       return false;
/*      */     }
/*  738 */     this.cursor -= 1;
/*      */ 
/*  741 */     int v_7 = this.limit - this.cursor;
/*  742 */     if (!in_grouping_b(g_vowel, 97, 305))
/*      */     {
/*  744 */       return false;
/*      */     }
/*  746 */     this.cursor = (this.limit - v_7);
/*  747 */     this.cursor = (this.limit - v_6);
/*      */ 
/*  749 */     label261: return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_suffix_with_optional_U_vowel()
/*      */   {
/*  763 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  768 */     int v_2 = this.limit - this.cursor;
/*  769 */     if (in_grouping_b(g_U, 105, 305))
/*      */     {
/*  773 */       this.cursor = (this.limit - v_2);
/*      */ 
/*  775 */       if (this.cursor > this.limit_backward)
/*      */       {
/*  779 */         this.cursor -= 1;
/*      */ 
/*  782 */         int v_3 = this.limit - this.cursor;
/*  783 */         if (out_grouping_b(g_vowel, 97, 305))
/*      */         {
/*  787 */           this.cursor = (this.limit - v_3);
/*  788 */           break label271;
/*      */         }
/*      */       }
/*      */     }
/*  790 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  795 */     int v_4 = this.limit - this.cursor;
/*      */ 
/*  799 */     int v_5 = this.limit - this.cursor;
/*  800 */     if (in_grouping_b(g_U, 105, 305))
/*      */     {
/*  804 */       this.cursor = (this.limit - v_5);
/*  805 */       return false;
/*      */     }
/*  807 */     this.cursor = (this.limit - v_4);
/*      */ 
/*  810 */     int v_6 = this.limit - this.cursor;
/*      */ 
/*  813 */     if (this.cursor <= this.limit_backward)
/*      */     {
/*  815 */       return false;
/*      */     }
/*  817 */     this.cursor -= 1;
/*      */ 
/*  820 */     int v_7 = this.limit - this.cursor;
/*  821 */     if (!out_grouping_b(g_vowel, 97, 305))
/*      */     {
/*  823 */       return false;
/*      */     }
/*  825 */     this.cursor = (this.limit - v_7);
/*  826 */     this.cursor = (this.limit - v_6);
/*      */ 
/*  828 */     label271: return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_possessives()
/*      */   {
/*  834 */     if (find_among_b(a_0, 10) == 0)
/*      */     {
/*  836 */       return false;
/*      */     }
/*      */ 
/*  840 */     if (!r_mark_suffix_with_optional_U_vowel())
/*      */     {
/*  842 */       return false;
/*      */     }
/*  844 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_sU()
/*      */   {
/*  850 */     if (!r_check_vowel_harmony())
/*      */     {
/*  852 */       return false;
/*      */     }
/*  854 */     if (!in_grouping_b(g_U, 105, 305))
/*      */     {
/*  856 */       return false;
/*      */     }
/*      */ 
/*  860 */     if (!r_mark_suffix_with_optional_s_consonant())
/*      */     {
/*  862 */       return false;
/*      */     }
/*  864 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_lArI()
/*      */   {
/*  870 */     if (find_among_b(a_1, 2) == 0)
/*      */     {
/*  872 */       return false;
/*      */     }
/*  874 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_yU()
/*      */   {
/*  880 */     if (!r_check_vowel_harmony())
/*      */     {
/*  882 */       return false;
/*      */     }
/*  884 */     if (!in_grouping_b(g_U, 105, 305))
/*      */     {
/*  886 */       return false;
/*      */     }
/*      */ 
/*  890 */     if (!r_mark_suffix_with_optional_y_consonant())
/*      */     {
/*  892 */       return false;
/*      */     }
/*  894 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_nU()
/*      */   {
/*  900 */     if (!r_check_vowel_harmony())
/*      */     {
/*  902 */       return false;
/*      */     }
/*      */ 
/*  905 */     if (find_among_b(a_2, 4) == 0)
/*      */     {
/*  907 */       return false;
/*      */     }
/*  909 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_nUn()
/*      */   {
/*  915 */     if (!r_check_vowel_harmony())
/*      */     {
/*  917 */       return false;
/*      */     }
/*      */ 
/*  920 */     if (find_among_b(a_3, 4) == 0)
/*      */     {
/*  922 */       return false;
/*      */     }
/*      */ 
/*  926 */     if (!r_mark_suffix_with_optional_n_consonant())
/*      */     {
/*  928 */       return false;
/*      */     }
/*  930 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_yA()
/*      */   {
/*  936 */     if (!r_check_vowel_harmony())
/*      */     {
/*  938 */       return false;
/*      */     }
/*      */ 
/*  941 */     if (find_among_b(a_4, 2) == 0)
/*      */     {
/*  943 */       return false;
/*      */     }
/*      */ 
/*  947 */     if (!r_mark_suffix_with_optional_y_consonant())
/*      */     {
/*  949 */       return false;
/*      */     }
/*  951 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_nA()
/*      */   {
/*  957 */     if (!r_check_vowel_harmony())
/*      */     {
/*  959 */       return false;
/*      */     }
/*      */ 
/*  962 */     if (find_among_b(a_5, 2) == 0)
/*      */     {
/*  964 */       return false;
/*      */     }
/*  966 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_DA()
/*      */   {
/*  972 */     if (!r_check_vowel_harmony())
/*      */     {
/*  974 */       return false;
/*      */     }
/*      */ 
/*  977 */     if (find_among_b(a_6, 4) == 0)
/*      */     {
/*  979 */       return false;
/*      */     }
/*  981 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_ndA()
/*      */   {
/*  987 */     if (!r_check_vowel_harmony())
/*      */     {
/*  989 */       return false;
/*      */     }
/*      */ 
/*  992 */     if (find_among_b(a_7, 2) == 0)
/*      */     {
/*  994 */       return false;
/*      */     }
/*  996 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_DAn()
/*      */   {
/* 1002 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1004 */       return false;
/*      */     }
/*      */ 
/* 1007 */     if (find_among_b(a_8, 4) == 0)
/*      */     {
/* 1009 */       return false;
/*      */     }
/* 1011 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_ndAn()
/*      */   {
/* 1017 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1019 */       return false;
/*      */     }
/*      */ 
/* 1022 */     if (find_among_b(a_9, 2) == 0)
/*      */     {
/* 1024 */       return false;
/*      */     }
/* 1026 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_ylA()
/*      */   {
/* 1032 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1034 */       return false;
/*      */     }
/*      */ 
/* 1037 */     if (find_among_b(a_10, 2) == 0)
/*      */     {
/* 1039 */       return false;
/*      */     }
/*      */ 
/* 1043 */     if (!r_mark_suffix_with_optional_y_consonant())
/*      */     {
/* 1045 */       return false;
/*      */     }
/* 1047 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_ki()
/*      */   {
/* 1053 */     if (!eq_s_b(2, "ki"))
/*      */     {
/* 1055 */       return false;
/*      */     }
/* 1057 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_ncA()
/*      */   {
/* 1063 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1065 */       return false;
/*      */     }
/*      */ 
/* 1068 */     if (find_among_b(a_11, 2) == 0)
/*      */     {
/* 1070 */       return false;
/*      */     }
/*      */ 
/* 1074 */     if (!r_mark_suffix_with_optional_n_consonant())
/*      */     {
/* 1076 */       return false;
/*      */     }
/* 1078 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_yUm()
/*      */   {
/* 1084 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1086 */       return false;
/*      */     }
/*      */ 
/* 1089 */     if (find_among_b(a_12, 4) == 0)
/*      */     {
/* 1091 */       return false;
/*      */     }
/*      */ 
/* 1095 */     if (!r_mark_suffix_with_optional_y_consonant())
/*      */     {
/* 1097 */       return false;
/*      */     }
/* 1099 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_sUn()
/*      */   {
/* 1105 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1107 */       return false;
/*      */     }
/*      */ 
/* 1110 */     if (find_among_b(a_13, 4) == 0)
/*      */     {
/* 1112 */       return false;
/*      */     }
/* 1114 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_yUz()
/*      */   {
/* 1120 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1122 */       return false;
/*      */     }
/*      */ 
/* 1125 */     if (find_among_b(a_14, 4) == 0)
/*      */     {
/* 1127 */       return false;
/*      */     }
/*      */ 
/* 1131 */     if (!r_mark_suffix_with_optional_y_consonant())
/*      */     {
/* 1133 */       return false;
/*      */     }
/* 1135 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_sUnUz()
/*      */   {
/* 1141 */     if (find_among_b(a_15, 4) == 0)
/*      */     {
/* 1143 */       return false;
/*      */     }
/* 1145 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_lAr()
/*      */   {
/* 1151 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1153 */       return false;
/*      */     }
/*      */ 
/* 1156 */     if (find_among_b(a_16, 2) == 0)
/*      */     {
/* 1158 */       return false;
/*      */     }
/* 1160 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_nUz()
/*      */   {
/* 1166 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1168 */       return false;
/*      */     }
/*      */ 
/* 1171 */     if (find_among_b(a_17, 4) == 0)
/*      */     {
/* 1173 */       return false;
/*      */     }
/* 1175 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_DUr()
/*      */   {
/* 1181 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1183 */       return false;
/*      */     }
/*      */ 
/* 1186 */     if (find_among_b(a_18, 8) == 0)
/*      */     {
/* 1188 */       return false;
/*      */     }
/* 1190 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_cAsInA()
/*      */   {
/* 1196 */     if (find_among_b(a_19, 2) == 0)
/*      */     {
/* 1198 */       return false;
/*      */     }
/* 1200 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_yDU()
/*      */   {
/* 1206 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1208 */       return false;
/*      */     }
/*      */ 
/* 1211 */     if (find_among_b(a_20, 32) == 0)
/*      */     {
/* 1213 */       return false;
/*      */     }
/*      */ 
/* 1217 */     if (!r_mark_suffix_with_optional_y_consonant())
/*      */     {
/* 1219 */       return false;
/*      */     }
/* 1221 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_ysA()
/*      */   {
/* 1227 */     if (find_among_b(a_21, 8) == 0)
/*      */     {
/* 1229 */       return false;
/*      */     }
/*      */ 
/* 1233 */     if (!r_mark_suffix_with_optional_y_consonant())
/*      */     {
/* 1235 */       return false;
/*      */     }
/* 1237 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_ymUs_()
/*      */   {
/* 1243 */     if (!r_check_vowel_harmony())
/*      */     {
/* 1245 */       return false;
/*      */     }
/*      */ 
/* 1248 */     if (find_among_b(a_22, 4) == 0)
/*      */     {
/* 1250 */       return false;
/*      */     }
/*      */ 
/* 1254 */     if (!r_mark_suffix_with_optional_y_consonant())
/*      */     {
/* 1256 */       return false;
/*      */     }
/* 1258 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_yken()
/*      */   {
/* 1264 */     if (!eq_s_b(3, "ken"))
/*      */     {
/* 1266 */       return false;
/*      */     }
/*      */ 
/* 1270 */     if (!r_mark_suffix_with_optional_y_consonant())
/*      */     {
/* 1272 */       return false;
/*      */     }
/* 1274 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_stem_nominal_verb_suffixes()
/*      */   {
/* 1290 */     this.ket = this.cursor;
/*      */ 
/* 1292 */     this.B_continue_stemming_noun_suffixes = true;
/*      */ 
/* 1295 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1300 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1303 */     if (!r_mark_ymUs_())
/*      */     {
/* 1309 */       this.cursor = (this.limit - v_2);
/*      */ 
/* 1312 */       if (!r_mark_yDU())
/*      */       {
/* 1318 */         this.cursor = (this.limit - v_2);
/*      */ 
/* 1321 */         if (!r_mark_ysA())
/*      */         {
/* 1327 */           this.cursor = (this.limit - v_2);
/*      */ 
/* 1329 */           if (!r_mark_yken())
/*      */           {
/* 1336 */             this.cursor = (this.limit - v_1);
/*      */ 
/* 1340 */             if (r_mark_cAsInA())
/*      */             {
/* 1347 */               int v_3 = this.limit - this.cursor;
/*      */ 
/* 1350 */               if (!r_mark_sUnUz())
/*      */               {
/* 1356 */                 this.cursor = (this.limit - v_3);
/*      */ 
/* 1359 */                 if (!r_mark_lAr())
/*      */                 {
/* 1365 */                   this.cursor = (this.limit - v_3);
/*      */ 
/* 1368 */                   if (!r_mark_yUm())
/*      */                   {
/* 1374 */                     this.cursor = (this.limit - v_3);
/*      */ 
/* 1377 */                     if (!r_mark_sUn())
/*      */                     {
/* 1383 */                       this.cursor = (this.limit - v_3);
/*      */ 
/* 1386 */                       if (!r_mark_yUz())
/*      */                       {
/* 1392 */                         this.cursor = (this.limit - v_3);
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/* 1395 */               if (r_mark_ymUs_());
/*      */             }
/*      */             else {
/* 1401 */               this.cursor = (this.limit - v_1);
/*      */ 
/* 1405 */               if (r_mark_lAr())
/*      */               {
/* 1410 */                 this.bra = this.cursor;
/*      */ 
/* 1412 */                 slice_del();
/*      */ 
/* 1414 */                 int v_4 = this.limit - this.cursor;
/*      */ 
/* 1418 */                 this.ket = this.cursor;
/*      */ 
/* 1422 */                 int v_5 = this.limit - this.cursor;
/*      */ 
/* 1425 */                 if (!r_mark_DUr())
/*      */                 {
/* 1431 */                   this.cursor = (this.limit - v_5);
/*      */ 
/* 1434 */                   if (!r_mark_yDU())
/*      */                   {
/* 1440 */                     this.cursor = (this.limit - v_5);
/*      */ 
/* 1443 */                     if (!r_mark_ysA())
/*      */                     {
/* 1449 */                       this.cursor = (this.limit - v_5);
/*      */ 
/* 1451 */                       if (!r_mark_ymUs_())
/*      */                       {
/* 1453 */                         this.cursor = (this.limit - v_4);
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */ 
/* 1459 */                 this.B_continue_stemming_noun_suffixes = false;
/*      */               }
/*      */               else {
/* 1462 */                 this.cursor = (this.limit - v_1);
/*      */ 
/* 1466 */                 if (r_mark_nUz())
/*      */                 {
/* 1473 */                   int v_6 = this.limit - this.cursor;
/*      */ 
/* 1476 */                   if (!r_mark_yDU())
/*      */                   {
/* 1482 */                     this.cursor = (this.limit - v_6);
/*      */ 
/* 1484 */                     if (r_mark_ysA());
/*      */                   }
/*      */ 
/*      */                 }
/*      */                 else
/*      */                 {
/* 1491 */                   this.cursor = (this.limit - v_1);
/*      */ 
/* 1497 */                   int v_7 = this.limit - this.cursor;
/*      */ 
/* 1500 */                   if (!r_mark_sUnUz())
/*      */                   {
/* 1506 */                     this.cursor = (this.limit - v_7);
/*      */ 
/* 1509 */                     if (!r_mark_yUz())
/*      */                     {
/* 1515 */                       this.cursor = (this.limit - v_7);
/*      */ 
/* 1518 */                       if (!r_mark_sUn())
/*      */                       {
/* 1524 */                         this.cursor = (this.limit - v_7);
/*      */ 
/* 1526 */                         if (!r_mark_yUm()) {
/*      */                           break label548;
/*      */                         }
/*      */                       }
/*      */                     }
/*      */                   }
/* 1532 */                   this.bra = this.cursor;
/*      */ 
/* 1534 */                   slice_del();
/*      */ 
/* 1536 */                   int v_8 = this.limit - this.cursor;
/*      */ 
/* 1540 */                   this.ket = this.cursor;
/*      */ 
/* 1542 */                   if (!r_mark_ymUs_())
/*      */                   {
/* 1544 */                     this.cursor = (this.limit - v_8);
/* 1545 */                     break label717;
/*      */ 
/* 1550 */                     label548: this.cursor = (this.limit - v_1);
/*      */ 
/* 1553 */                     if (!r_mark_DUr())
/*      */                     {
/* 1555 */                       return false;
/*      */                     }
/*      */ 
/* 1558 */                     this.bra = this.cursor;
/*      */ 
/* 1560 */                     slice_del();
/*      */ 
/* 1562 */                     int v_9 = this.limit - this.cursor;
/*      */ 
/* 1566 */                     this.ket = this.cursor;
/*      */ 
/* 1570 */                     int v_10 = this.limit - this.cursor;
/*      */ 
/* 1573 */                     if (!r_mark_sUnUz())
/*      */                     {
/* 1579 */                       this.cursor = (this.limit - v_10);
/*      */ 
/* 1582 */                       if (!r_mark_lAr())
/*      */                       {
/* 1588 */                         this.cursor = (this.limit - v_10);
/*      */ 
/* 1591 */                         if (!r_mark_yUm())
/*      */                         {
/* 1597 */                           this.cursor = (this.limit - v_10);
/*      */ 
/* 1600 */                           if (!r_mark_sUn())
/*      */                           {
/* 1606 */                             this.cursor = (this.limit - v_10);
/*      */ 
/* 1609 */                             if (!r_mark_yUz())
/*      */                             {
/* 1615 */                               this.cursor = (this.limit - v_10);
/*      */                             }
/*      */                           }
/*      */                         }
/*      */                       }
/*      */                     }
/* 1618 */                     if (!r_mark_ymUs_())
/*      */                     {
/* 1620 */                       this.cursor = (this.limit - v_9);
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1626 */     label717: this.bra = this.cursor;
/*      */ 
/* 1628 */     slice_del();
/* 1629 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_stem_suffix_chain_before_ki()
/*      */   {
/* 1646 */     this.ket = this.cursor;
/*      */ 
/* 1648 */     if (!r_mark_ki())
/*      */     {
/* 1650 */       return false;
/*      */     }
/*      */ 
/* 1655 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1659 */     if (r_mark_DA())
/*      */     {
/* 1664 */       this.bra = this.cursor;
/*      */ 
/* 1666 */       slice_del();
/*      */ 
/* 1668 */       int v_2 = this.limit - this.cursor;
/*      */ 
/* 1672 */       this.ket = this.cursor;
/*      */ 
/* 1675 */       int v_3 = this.limit - this.cursor;
/*      */ 
/* 1679 */       if (r_mark_lAr())
/*      */       {
/* 1684 */         this.bra = this.cursor;
/*      */ 
/* 1686 */         slice_del();
/*      */ 
/* 1688 */         int v_4 = this.limit - this.cursor;
/*      */ 
/* 1692 */         if (!r_stem_suffix_chain_before_ki())
/*      */         {
/* 1694 */           this.cursor = (this.limit - v_4);
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1700 */         this.cursor = (this.limit - v_3);
/*      */ 
/* 1703 */         if (!r_mark_possessives())
/*      */         {
/* 1705 */           this.cursor = (this.limit - v_2);
/*      */         }
/*      */         else
/*      */         {
/* 1709 */           this.bra = this.cursor;
/*      */ 
/* 1711 */           slice_del();
/*      */ 
/* 1713 */           int v_5 = this.limit - this.cursor;
/*      */ 
/* 1717 */           this.ket = this.cursor;
/*      */ 
/* 1719 */           if (!r_mark_lAr())
/*      */           {
/* 1721 */             this.cursor = (this.limit - v_5);
/*      */           }
/*      */           else
/*      */           {
/* 1725 */             this.bra = this.cursor;
/*      */ 
/* 1727 */             slice_del();
/*      */ 
/* 1729 */             if (!r_stem_suffix_chain_before_ki())
/*      */             {
/* 1731 */               this.cursor = (this.limit - v_5);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1739 */       this.cursor = (this.limit - v_1);
/*      */ 
/* 1743 */       if (r_mark_nUn())
/*      */       {
/* 1748 */         this.bra = this.cursor;
/*      */ 
/* 1750 */         slice_del();
/*      */ 
/* 1752 */         int v_6 = this.limit - this.cursor;
/*      */ 
/* 1756 */         this.ket = this.cursor;
/*      */ 
/* 1759 */         int v_7 = this.limit - this.cursor;
/*      */ 
/* 1763 */         if (r_mark_lArI())
/*      */         {
/* 1768 */           this.bra = this.cursor;
/*      */ 
/* 1770 */           slice_del();
/*      */         }
/*      */         else {
/* 1773 */           this.cursor = (this.limit - v_7);
/*      */ 
/* 1777 */           this.ket = this.cursor;
/*      */ 
/* 1780 */           int v_8 = this.limit - this.cursor;
/*      */ 
/* 1783 */           if (!r_mark_possessives())
/*      */           {
/* 1789 */             this.cursor = (this.limit - v_8);
/*      */ 
/* 1791 */             if (!r_mark_sU());
/*      */           }
/*      */           else
/*      */           {
/* 1797 */             this.bra = this.cursor;
/*      */ 
/* 1799 */             slice_del();
/*      */ 
/* 1801 */             int v_9 = this.limit - this.cursor;
/*      */ 
/* 1805 */             this.ket = this.cursor;
/*      */ 
/* 1807 */             if (!r_mark_lAr())
/*      */             {
/* 1809 */               this.cursor = (this.limit - v_9);
/* 1810 */               break label689;
/*      */             }
/*      */ 
/* 1813 */             this.bra = this.cursor;
/*      */ 
/* 1815 */             slice_del();
/*      */ 
/* 1817 */             if (r_stem_suffix_chain_before_ki())
/*      */               break label689;
/* 1819 */             this.cursor = (this.limit - v_9);
/* 1820 */             break label689;
/*      */           }
/*      */ 
/* 1825 */           this.cursor = (this.limit - v_7);
/*      */ 
/* 1828 */           if (!r_stem_suffix_chain_before_ki())
/*      */           {
/* 1830 */             this.cursor = (this.limit - v_6);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1837 */         this.cursor = (this.limit - v_1);
/*      */ 
/* 1840 */         if (!r_mark_ndA())
/*      */         {
/* 1842 */           return false;
/*      */         }
/*      */ 
/* 1847 */         int v_10 = this.limit - this.cursor;
/*      */ 
/* 1851 */         if (r_mark_lArI())
/*      */         {
/* 1856 */           this.bra = this.cursor;
/*      */ 
/* 1858 */           slice_del();
/*      */         }
/*      */         else {
/* 1861 */           this.cursor = (this.limit - v_10);
/*      */ 
/* 1866 */           if (r_mark_sU())
/*      */           {
/* 1871 */             this.bra = this.cursor;
/*      */ 
/* 1873 */             slice_del();
/*      */ 
/* 1875 */             int v_11 = this.limit - this.cursor;
/*      */ 
/* 1879 */             this.ket = this.cursor;
/*      */ 
/* 1881 */             if (!r_mark_lAr())
/*      */             {
/* 1883 */               this.cursor = (this.limit - v_11);
/*      */             }
/*      */             else
/*      */             {
/* 1887 */               this.bra = this.cursor;
/*      */ 
/* 1889 */               slice_del();
/*      */ 
/* 1891 */               if (!r_stem_suffix_chain_before_ki())
/*      */               {
/* 1893 */                 this.cursor = (this.limit - v_11);
/*      */               }
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 1899 */             this.cursor = (this.limit - v_10);
/*      */ 
/* 1902 */             if (!r_stem_suffix_chain_before_ki())
/*      */             {
/* 1904 */               return false;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1908 */     label689: return true;
/*      */   }
/*      */ 
/*      */   private boolean r_stem_noun_suffixes()
/*      */   {
/* 1942 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1946 */     this.ket = this.cursor;
/*      */ 
/* 1948 */     if (r_mark_lAr())
/*      */     {
/* 1953 */       this.bra = this.cursor;
/*      */ 
/* 1955 */       slice_del();
/*      */ 
/* 1957 */       int v_2 = this.limit - this.cursor;
/*      */ 
/* 1961 */       if (!r_stem_suffix_chain_before_ki())
/*      */       {
/* 1963 */         this.cursor = (this.limit - v_2);
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1969 */       this.cursor = (this.limit - v_1);
/*      */ 
/* 1973 */       this.ket = this.cursor;
/*      */ 
/* 1975 */       if (r_mark_ncA())
/*      */       {
/* 1980 */         this.bra = this.cursor;
/*      */ 
/* 1982 */         slice_del();
/*      */ 
/* 1984 */         int v_3 = this.limit - this.cursor;
/*      */ 
/* 1989 */         int v_4 = this.limit - this.cursor;
/*      */ 
/* 1993 */         this.ket = this.cursor;
/*      */ 
/* 1995 */         if (r_mark_lArI())
/*      */         {
/* 2000 */           this.bra = this.cursor;
/*      */ 
/* 2002 */           slice_del();
/*      */         }
/*      */         else {
/* 2005 */           this.cursor = (this.limit - v_4);
/*      */ 
/* 2009 */           this.ket = this.cursor;
/*      */ 
/* 2012 */           int v_5 = this.limit - this.cursor;
/*      */ 
/* 2015 */           if (!r_mark_possessives())
/*      */           {
/* 2021 */             this.cursor = (this.limit - v_5);
/*      */ 
/* 2023 */             if (!r_mark_sU());
/*      */           }
/*      */           else
/*      */           {
/* 2029 */             this.bra = this.cursor;
/*      */ 
/* 2031 */             slice_del();
/*      */ 
/* 2033 */             int v_6 = this.limit - this.cursor;
/*      */ 
/* 2037 */             this.ket = this.cursor;
/*      */ 
/* 2039 */             if (!r_mark_lAr())
/*      */             {
/* 2041 */               this.cursor = (this.limit - v_6);
/* 2042 */               break label1791;
/*      */             }
/*      */ 
/* 2045 */             this.bra = this.cursor;
/*      */ 
/* 2047 */             slice_del();
/*      */ 
/* 2049 */             if (r_stem_suffix_chain_before_ki())
/*      */               break label1791;
/* 2051 */             this.cursor = (this.limit - v_6);
/* 2052 */             break label1791;
/*      */           }
/*      */ 
/* 2057 */           this.cursor = (this.limit - v_4);
/*      */ 
/* 2060 */           this.ket = this.cursor;
/*      */ 
/* 2062 */           if (!r_mark_lAr())
/*      */           {
/* 2064 */             this.cursor = (this.limit - v_3);
/*      */           }
/*      */           else
/*      */           {
/* 2068 */             this.bra = this.cursor;
/*      */ 
/* 2070 */             slice_del();
/*      */ 
/* 2072 */             if (!r_stem_suffix_chain_before_ki())
/*      */             {
/* 2074 */               this.cursor = (this.limit - v_3);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 2081 */         this.cursor = (this.limit - v_1);
/*      */ 
/* 2085 */         this.ket = this.cursor;
/*      */ 
/* 2089 */         int v_7 = this.limit - this.cursor;
/*      */ 
/* 2092 */         if (!r_mark_ndA())
/*      */         {
/* 2098 */           this.cursor = (this.limit - v_7);
/*      */ 
/* 2100 */           if (!r_mark_nA());
/*      */         }
/*      */         else
/*      */         {
/* 2108 */           int v_8 = this.limit - this.cursor;
/*      */ 
/* 2112 */           if (r_mark_lArI())
/*      */           {
/* 2117 */             this.bra = this.cursor;
/*      */ 
/* 2119 */             slice_del();
/* 2120 */             break label1791;
/*      */           }
/* 2122 */           this.cursor = (this.limit - v_8);
/*      */ 
/* 2126 */           if (r_mark_sU())
/*      */           {
/* 2131 */             this.bra = this.cursor;
/*      */ 
/* 2133 */             slice_del();
/*      */ 
/* 2135 */             int v_9 = this.limit - this.cursor;
/*      */ 
/* 2139 */             this.ket = this.cursor;
/*      */ 
/* 2141 */             if (!r_mark_lAr())
/*      */             {
/* 2143 */               this.cursor = (this.limit - v_9);
/* 2144 */               break label1791;
/*      */             }
/*      */ 
/* 2147 */             this.bra = this.cursor;
/*      */ 
/* 2149 */             slice_del();
/*      */ 
/* 2151 */             if (r_stem_suffix_chain_before_ki())
/*      */               break label1791;
/* 2153 */             this.cursor = (this.limit - v_9);
/* 2154 */             break label1791;
/*      */           }
/*      */ 
/* 2159 */           this.cursor = (this.limit - v_8);
/*      */ 
/* 2162 */           if (r_stem_suffix_chain_before_ki())
/*      */           {
/*      */             break label1791;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2169 */         this.cursor = (this.limit - v_1);
/*      */ 
/* 2173 */         this.ket = this.cursor;
/*      */ 
/* 2177 */         int v_10 = this.limit - this.cursor;
/*      */ 
/* 2180 */         if (!r_mark_ndAn())
/*      */         {
/* 2186 */           this.cursor = (this.limit - v_10);
/*      */ 
/* 2188 */           if (!r_mark_nU());
/*      */         }
/*      */         else
/*      */         {
/* 2196 */           int v_11 = this.limit - this.cursor;
/*      */ 
/* 2200 */           if (r_mark_sU())
/*      */           {
/* 2205 */             this.bra = this.cursor;
/*      */ 
/* 2207 */             slice_del();
/*      */ 
/* 2209 */             int v_12 = this.limit - this.cursor;
/*      */ 
/* 2213 */             this.ket = this.cursor;
/*      */ 
/* 2215 */             if (!r_mark_lAr())
/*      */             {
/* 2217 */               this.cursor = (this.limit - v_12);
/* 2218 */               break label1791;
/*      */             }
/*      */ 
/* 2221 */             this.bra = this.cursor;
/*      */ 
/* 2223 */             slice_del();
/*      */ 
/* 2225 */             if (r_stem_suffix_chain_before_ki())
/*      */               break label1791;
/* 2227 */             this.cursor = (this.limit - v_12);
/* 2228 */             break label1791;
/*      */           }
/*      */ 
/* 2233 */           this.cursor = (this.limit - v_11);
/*      */ 
/* 2236 */           if (r_mark_lArI())
/*      */           {
/*      */             break label1791;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2243 */         this.cursor = (this.limit - v_1);
/*      */ 
/* 2247 */         this.ket = this.cursor;
/*      */ 
/* 2249 */         if (r_mark_DAn())
/*      */         {
/* 2254 */           this.bra = this.cursor;
/*      */ 
/* 2256 */           slice_del();
/*      */ 
/* 2258 */           int v_13 = this.limit - this.cursor;
/*      */ 
/* 2262 */           this.ket = this.cursor;
/*      */ 
/* 2266 */           int v_14 = this.limit - this.cursor;
/*      */ 
/* 2270 */           if (r_mark_possessives())
/*      */           {
/* 2275 */             this.bra = this.cursor;
/*      */ 
/* 2277 */             slice_del();
/*      */ 
/* 2279 */             int v_15 = this.limit - this.cursor;
/*      */ 
/* 2283 */             this.ket = this.cursor;
/*      */ 
/* 2285 */             if (!r_mark_lAr())
/*      */             {
/* 2287 */               this.cursor = (this.limit - v_15);
/*      */             }
/*      */             else
/*      */             {
/* 2291 */               this.bra = this.cursor;
/*      */ 
/* 2293 */               slice_del();
/*      */ 
/* 2295 */               if (!r_stem_suffix_chain_before_ki())
/*      */               {
/* 2297 */                 this.cursor = (this.limit - v_15);
/*      */               }
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 2303 */             this.cursor = (this.limit - v_14);
/*      */ 
/* 2307 */             if (r_mark_lAr())
/*      */             {
/* 2312 */               this.bra = this.cursor;
/*      */ 
/* 2314 */               slice_del();
/*      */ 
/* 2316 */               int v_16 = this.limit - this.cursor;
/*      */ 
/* 2320 */               if (!r_stem_suffix_chain_before_ki())
/*      */               {
/* 2322 */                 this.cursor = (this.limit - v_16);
/*      */               }
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 2328 */               this.cursor = (this.limit - v_14);
/*      */ 
/* 2331 */               if (!r_stem_suffix_chain_before_ki())
/*      */               {
/* 2333 */                 this.cursor = (this.limit - v_13);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 2340 */           this.cursor = (this.limit - v_1);
/*      */ 
/* 2344 */           this.ket = this.cursor;
/*      */ 
/* 2347 */           int v_17 = this.limit - this.cursor;
/*      */ 
/* 2350 */           if (!r_mark_nUn())
/*      */           {
/* 2356 */             this.cursor = (this.limit - v_17);
/*      */ 
/* 2358 */             if (!r_mark_ylA());
/*      */           }
/*      */           else
/*      */           {
/* 2364 */             this.bra = this.cursor;
/*      */ 
/* 2366 */             slice_del();
/*      */ 
/* 2368 */             int v_18 = this.limit - this.cursor;
/*      */ 
/* 2373 */             int v_19 = this.limit - this.cursor;
/*      */ 
/* 2377 */             this.ket = this.cursor;
/*      */ 
/* 2379 */             if (r_mark_lAr())
/*      */             {
/* 2384 */               this.bra = this.cursor;
/*      */ 
/* 2386 */               slice_del();
/*      */ 
/* 2388 */               if (r_stem_suffix_chain_before_ki())
/*      */               {
/*      */                 break label1791;
/*      */               }
/*      */             }
/*      */ 
/* 2394 */             this.cursor = (this.limit - v_19);
/*      */ 
/* 2398 */             this.ket = this.cursor;
/*      */ 
/* 2401 */             int v_20 = this.limit - this.cursor;
/*      */ 
/* 2404 */             if (!r_mark_possessives())
/*      */             {
/* 2410 */               this.cursor = (this.limit - v_20);
/*      */ 
/* 2412 */               if (!r_mark_sU());
/*      */             }
/*      */             else
/*      */             {
/* 2418 */               this.bra = this.cursor;
/*      */ 
/* 2420 */               slice_del();
/*      */ 
/* 2422 */               int v_21 = this.limit - this.cursor;
/*      */ 
/* 2426 */               this.ket = this.cursor;
/*      */ 
/* 2428 */               if (!r_mark_lAr())
/*      */               {
/* 2430 */                 this.cursor = (this.limit - v_21);
/* 2431 */                 break label1791;
/*      */               }
/*      */ 
/* 2434 */               this.bra = this.cursor;
/*      */ 
/* 2436 */               slice_del();
/*      */ 
/* 2438 */               if (r_stem_suffix_chain_before_ki())
/*      */                 break label1791;
/* 2440 */               this.cursor = (this.limit - v_21);
/* 2441 */               break label1791;
/*      */             }
/*      */ 
/* 2446 */             this.cursor = (this.limit - v_19);
/*      */ 
/* 2448 */             if (r_stem_suffix_chain_before_ki())
/*      */               break label1791;
/* 2450 */             this.cursor = (this.limit - v_18);
/* 2451 */             break label1791;
/*      */           }
/*      */ 
/* 2457 */           this.cursor = (this.limit - v_1);
/*      */ 
/* 2461 */           this.ket = this.cursor;
/*      */ 
/* 2463 */           if (r_mark_lArI())
/*      */           {
/* 2468 */             this.bra = this.cursor;
/*      */ 
/* 2470 */             slice_del();
/*      */           }
/*      */           else {
/* 2473 */             this.cursor = (this.limit - v_1);
/*      */ 
/* 2477 */             if (!r_stem_suffix_chain_before_ki())
/*      */             {
/* 2483 */               this.cursor = (this.limit - v_1);
/*      */ 
/* 2487 */               this.ket = this.cursor;
/*      */ 
/* 2490 */               int v_22 = this.limit - this.cursor;
/*      */ 
/* 2493 */               if (!r_mark_DA())
/*      */               {
/* 2499 */                 this.cursor = (this.limit - v_22);
/*      */ 
/* 2502 */                 if (!r_mark_yU())
/*      */                 {
/* 2508 */                   this.cursor = (this.limit - v_22);
/*      */ 
/* 2510 */                   if (!r_mark_yA())
/*      */                   {
/*      */                     break label1653;
/*      */                   }
/*      */                 }
/*      */               }
/* 2516 */               this.bra = this.cursor;
/*      */ 
/* 2518 */               slice_del();
/*      */ 
/* 2520 */               int v_23 = this.limit - this.cursor;
/*      */ 
/* 2524 */               this.ket = this.cursor;
/*      */ 
/* 2528 */               int v_24 = this.limit - this.cursor;
/*      */ 
/* 2532 */               if (r_mark_possessives())
/*      */               {
/* 2537 */                 this.bra = this.cursor;
/*      */ 
/* 2539 */                 slice_del();
/*      */ 
/* 2541 */                 int v_25 = this.limit - this.cursor;
/*      */ 
/* 2545 */                 this.ket = this.cursor;
/*      */ 
/* 2547 */                 if (!r_mark_lAr())
/*      */                 {
/* 2549 */                   this.cursor = (this.limit - v_25);
/*      */                 }
/*      */ 
/*      */               }
/*      */               else
/*      */               {
/* 2555 */                 this.cursor = (this.limit - v_24);
/*      */ 
/* 2557 */                 if (!r_mark_lAr())
/*      */                 {
/* 2559 */                   this.cursor = (this.limit - v_23);
/* 2560 */                   break label1791;
/*      */                 }
/*      */               }
/*      */ 
/* 2564 */               this.bra = this.cursor;
/*      */ 
/* 2566 */               slice_del();
/*      */ 
/* 2568 */               this.ket = this.cursor;
/*      */ 
/* 2570 */               if (!r_stem_suffix_chain_before_ki())
/*      */               {
/* 2572 */                 this.cursor = (this.limit - v_23);
/* 2573 */                 break label1791;
/*      */ 
/* 2578 */                 label1653: this.cursor = (this.limit - v_1);
/*      */ 
/* 2581 */                 this.ket = this.cursor;
/*      */ 
/* 2584 */                 int v_26 = this.limit - this.cursor;
/*      */ 
/* 2587 */                 if (!r_mark_possessives())
/*      */                 {
/* 2593 */                   this.cursor = (this.limit - v_26);
/*      */ 
/* 2595 */                   if (!r_mark_sU())
/*      */                   {
/* 2597 */                     return false;
/*      */                   }
/*      */                 }
/*      */ 
/* 2601 */                 this.bra = this.cursor;
/*      */ 
/* 2603 */                 slice_del();
/*      */ 
/* 2605 */                 int v_27 = this.limit - this.cursor;
/*      */ 
/* 2609 */                 this.ket = this.cursor;
/*      */ 
/* 2611 */                 if (!r_mark_lAr())
/*      */                 {
/* 2613 */                   this.cursor = (this.limit - v_27);
/*      */                 }
/*      */                 else
/*      */                 {
/* 2617 */                   this.bra = this.cursor;
/*      */ 
/* 2619 */                   slice_del();
/*      */ 
/* 2621 */                   if (!r_stem_suffix_chain_before_ki())
/*      */                   {
/* 2623 */                     this.cursor = (this.limit - v_27);
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2628 */     label1791: return true;
/*      */   }
/*      */ 
/*      */   private boolean r_post_process_last_consonants()
/*      */   {
/* 2635 */     this.ket = this.cursor;
/*      */ 
/* 2637 */     int among_var = find_among_b(a_23, 4);
/* 2638 */     if (among_var == 0)
/*      */     {
/* 2640 */       return false;
/*      */     }
/*      */ 
/* 2643 */     this.bra = this.cursor;
/* 2644 */     switch (among_var) {
/*      */     case 0:
/* 2646 */       return false;
/*      */     case 1:
/* 2650 */       slice_from("p");
/* 2651 */       break;
/*      */     case 2:
/* 2655 */       slice_from("ç");
/* 2656 */       break;
/*      */     case 3:
/* 2660 */       slice_from("t");
/* 2661 */       break;
/*      */     case 4:
/* 2665 */       slice_from("k");
/*      */     }
/*      */ 
/* 2668 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_append_U_to_stems_ending_with_d_or_g()
/*      */   {
/* 2689 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 2693 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 2696 */     if (!eq_s_b(1, "d"))
/*      */     {
/* 2702 */       this.cursor = (this.limit - v_2);
/*      */ 
/* 2704 */       if (!eq_s_b(1, "g"))
/*      */       {
/* 2706 */         return false;
/*      */       }
/*      */     }
/* 2709 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 2712 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 2716 */     int v_4 = this.limit - this.cursor;
/*      */     while (true)
/*      */     {
/* 2722 */       int v_5 = this.limit - this.cursor;
/*      */ 
/* 2724 */       if (in_grouping_b(g_vowel, 97, 305))
/*      */       {
/* 2728 */         this.cursor = (this.limit - v_5);
/* 2729 */         break;
/*      */       }
/* 2731 */       this.cursor = (this.limit - v_5);
/* 2732 */       if (this.cursor <= this.limit_backward)
/*      */       {
/*      */         break label249;
/*      */       }
/* 2736 */       this.cursor -= 1;
/*      */     }
/*      */ 
/* 2740 */     int v_6 = this.limit - this.cursor;
/*      */ 
/* 2743 */     if (!eq_s_b(1, "a"))
/*      */     {
/* 2749 */       this.cursor = (this.limit - v_6);
/*      */ 
/* 2751 */       if (!eq_s_b(1, "ı"));
/*      */     }
/*      */     else
/*      */     {
/* 2756 */       this.cursor = (this.limit - v_4);
/*      */ 
/* 2759 */       int c = this.cursor;
/* 2760 */       insert(this.cursor, this.cursor, "ı");
/* 2761 */       this.cursor = c;
/*      */ 
/* 2763 */       break label805;
/*      */     }
/* 2765 */     label249: this.cursor = (this.limit - v_3);
/*      */ 
/* 2769 */     int v_7 = this.limit - this.cursor;
/*      */     while (true)
/*      */     {
/* 2775 */       int v_8 = this.limit - this.cursor;
/*      */ 
/* 2777 */       if (in_grouping_b(g_vowel, 97, 305))
/*      */       {
/* 2781 */         this.cursor = (this.limit - v_8);
/* 2782 */         break;
/*      */       }
/* 2784 */       this.cursor = (this.limit - v_8);
/* 2785 */       if (this.cursor <= this.limit_backward)
/*      */       {
/*      */         break label436;
/*      */       }
/* 2789 */       this.cursor -= 1;
/*      */     }
/*      */ 
/* 2793 */     int v_9 = this.limit - this.cursor;
/*      */ 
/* 2796 */     if (!eq_s_b(1, "e"))
/*      */     {
/* 2802 */       this.cursor = (this.limit - v_9);
/*      */ 
/* 2804 */       if (!eq_s_b(1, "i"));
/*      */     }
/*      */     else
/*      */     {
/* 2809 */       this.cursor = (this.limit - v_7);
/*      */ 
/* 2812 */       int c = this.cursor;
/* 2813 */       insert(this.cursor, this.cursor, "i");
/* 2814 */       this.cursor = c;
/*      */ 
/* 2816 */       break label805;
/*      */     }
/* 2818 */     label436: this.cursor = (this.limit - v_3);
/*      */ 
/* 2822 */     int v_10 = this.limit - this.cursor;
/*      */     while (true)
/*      */     {
/* 2828 */       int v_11 = this.limit - this.cursor;
/*      */ 
/* 2830 */       if (in_grouping_b(g_vowel, 97, 305))
/*      */       {
/* 2834 */         this.cursor = (this.limit - v_11);
/* 2835 */         break;
/*      */       }
/* 2837 */       this.cursor = (this.limit - v_11);
/* 2838 */       if (this.cursor <= this.limit_backward)
/*      */       {
/*      */         break label623;
/*      */       }
/* 2842 */       this.cursor -= 1;
/*      */     }
/*      */ 
/* 2846 */     int v_12 = this.limit - this.cursor;
/*      */ 
/* 2849 */     if (!eq_s_b(1, "o"))
/*      */     {
/* 2855 */       this.cursor = (this.limit - v_12);
/*      */ 
/* 2857 */       if (!eq_s_b(1, "u"));
/*      */     }
/*      */     else
/*      */     {
/* 2862 */       this.cursor = (this.limit - v_10);
/*      */ 
/* 2865 */       int c = this.cursor;
/* 2866 */       insert(this.cursor, this.cursor, "u");
/* 2867 */       this.cursor = c;
/*      */ 
/* 2869 */       break label805;
/*      */     }
/* 2871 */     label623: this.cursor = (this.limit - v_3);
/*      */ 
/* 2874 */     int v_13 = this.limit - this.cursor;
/*      */     while (true)
/*      */     {
/* 2880 */       int v_14 = this.limit - this.cursor;
/*      */ 
/* 2882 */       if (in_grouping_b(g_vowel, 97, 305))
/*      */       {
/* 2886 */         this.cursor = (this.limit - v_14);
/* 2887 */         break;
/*      */       }
/* 2889 */       this.cursor = (this.limit - v_14);
/* 2890 */       if (this.cursor <= this.limit_backward)
/*      */       {
/* 2892 */         return false;
/*      */       }
/* 2894 */       this.cursor -= 1;
/*      */     }
/*      */ 
/* 2898 */     int v_15 = this.limit - this.cursor;
/*      */ 
/* 2901 */     if (!eq_s_b(1, "ö"))
/*      */     {
/* 2907 */       this.cursor = (this.limit - v_15);
/*      */ 
/* 2909 */       if (!eq_s_b(1, "ü"))
/*      */       {
/* 2911 */         return false;
/*      */       }
/*      */     }
/* 2914 */     this.cursor = (this.limit - v_13);
/*      */ 
/* 2917 */     int c = this.cursor;
/* 2918 */     insert(this.cursor, this.cursor, "ü");
/* 2919 */     this.cursor = c;
/*      */ 
/* 2922 */     label805: return true;
/*      */   }
/*      */ 
/*      */   private boolean r_more_than_one_syllable_word()
/*      */   {
/* 2930 */     int v_1 = this.cursor;
/*      */ 
/* 2934 */     int v_2 = 2;
/*      */     int v_3;
/*      */     while (true)
/*      */     {
/* 2938 */       v_3 = this.cursor;
/*      */ 
/* 2945 */       while (!in_grouping(g_vowel, 97, 305))
/*      */       {
/* 2951 */         if (this.cursor >= this.limit)
/*      */         {
/*      */           break label60;
/*      */         }
/* 2955 */         this.cursor += 1;
/*      */       }
/* 2957 */       v_2--;
/*      */     }
/*      */ 
/* 2960 */     label60: this.cursor = v_3;
/*      */ 
/* 2963 */     if (v_2 > 0)
/*      */     {
/* 2965 */       return false;
/*      */     }
/*      */ 
/* 2968 */     this.cursor = v_1;
/* 2969 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_is_reserved_word()
/*      */   {
/* 2979 */     int v_1 = this.cursor;
/*      */ 
/* 2982 */     int v_2 = this.cursor;
/*      */ 
/* 2989 */     while (!eq_s(2, "ad"))
/*      */     {
/* 2995 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label74;
/*      */       }
/* 2999 */       this.cursor += 1;
/*      */     }
/*      */ 
/* 3002 */     this.I_strlen = 2;
/*      */ 
/* 3004 */     if (this.I_strlen == this.limit)
/*      */     {
/* 3008 */       this.cursor = v_2;
/*      */     }
/*      */     else {
/* 3011 */       label74: this.cursor = v_1;
/*      */ 
/* 3013 */       int v_4 = this.cursor;
/*      */ 
/* 3020 */       while (!eq_s(5, "soyad"))
/*      */       {
/* 3026 */         if (this.cursor >= this.limit)
/*      */         {
/* 3028 */           return false;
/*      */         }
/* 3030 */         this.cursor += 1;
/*      */       }
/*      */ 
/* 3033 */       this.I_strlen = 5;
/*      */ 
/* 3035 */       if (this.I_strlen != this.limit)
/*      */       {
/* 3037 */         return false;
/*      */       }
/* 3039 */       this.cursor = v_4;
/*      */     }
/* 3041 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_postlude()
/*      */   {
/* 3051 */     int v_1 = this.cursor;
/*      */ 
/* 3055 */     if (r_is_reserved_word())
/*      */     {
/* 3059 */       return false;
/*      */     }
/* 3061 */     this.cursor = v_1;
/*      */ 
/* 3064 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 3067 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 3070 */     if (!r_append_U_to_stems_ending_with_d_or_g());
/* 3075 */     this.cursor = (this.limit - v_2);
/*      */ 
/* 3077 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 3080 */     if (!r_post_process_last_consonants());
/* 3085 */     this.cursor = (this.limit - v_3);
/* 3086 */     this.cursor = this.limit_backward; return true;
/*      */   }
/*      */ 
/*      */   public boolean stem()
/*      */   {
/* 3096 */     if (!r_more_than_one_syllable_word())
/*      */     {
/* 3098 */       return false;
/*      */     }
/*      */ 
/* 3102 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 3105 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 3108 */     if (!r_stem_nominal_verb_suffixes());
/* 3113 */     this.cursor = (this.limit - v_1);
/*      */ 
/* 3115 */     if (!this.B_continue_stemming_noun_suffixes)
/*      */     {
/* 3117 */       return false;
/*      */     }
/*      */ 
/* 3120 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 3123 */     if (!r_stem_noun_suffixes());
/* 3128 */     this.cursor = (this.limit - v_2);
/* 3129 */     this.cursor = this.limit_backward;
/* 3130 */     if (!r_postlude())
/*      */     {
/* 3132 */       return false;
/*      */     }
/* 3134 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 3139 */     return o instanceof TurkishStemmer;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 3144 */     return TurkishStemmer.class.getName().hashCode();
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.ext.TurkishStemmer
 * JD-Core Version:    0.6.2
 */