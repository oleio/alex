/*     */ package org.tartarus.snowball.ext;
/*     */ 
/*     */ import org.tartarus.snowball.Among;
/*     */ import org.tartarus.snowball.SnowballProgram;
/*     */ 
/*     */ public class IrishStemmer extends SnowballProgram
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  17 */   private static final IrishStemmer methodObject = new IrishStemmer();
/*     */ 
/*  19 */   private static final Among[] a_0 = { new Among("b'", -1, 4, "", methodObject), new Among("bh", -1, 14, "", methodObject), new Among("bhf", 1, 9, "", methodObject), new Among("bp", -1, 11, "", methodObject), new Among("ch", -1, 15, "", methodObject), new Among("d'", -1, 2, "", methodObject), new Among("d'fh", 5, 3, "", methodObject), new Among("dh", -1, 16, "", methodObject), new Among("dt", -1, 13, "", methodObject), new Among("fh", -1, 17, "", methodObject), new Among("gc", -1, 7, "", methodObject), new Among("gh", -1, 18, "", methodObject), new Among("h-", -1, 1, "", methodObject), new Among("m'", -1, 4, "", methodObject), new Among("mb", -1, 6, "", methodObject), new Among("mh", -1, 19, "", methodObject), new Among("n-", -1, 1, "", methodObject), new Among("nd", -1, 8, "", methodObject), new Among("ng", -1, 10, "", methodObject), new Among("ph", -1, 20, "", methodObject), new Among("sh", -1, 5, "", methodObject), new Among("t-", -1, 1, "", methodObject), new Among("th", -1, 21, "", methodObject), new Among("ts", -1, 12, "", methodObject) };
/*     */ 
/*  46 */   private static final Among[] a_1 = { new Among("íochta", -1, 1, "", methodObject), new Among("aíochta", 0, 1, "", methodObject), new Among("ire", -1, 2, "", methodObject), new Among("aire", 2, 2, "", methodObject), new Among("abh", -1, 1, "", methodObject), new Among("eabh", 4, 1, "", methodObject), new Among("ibh", -1, 1, "", methodObject), new Among("aibh", 6, 1, "", methodObject), new Among("amh", -1, 1, "", methodObject), new Among("eamh", 8, 1, "", methodObject), new Among("imh", -1, 1, "", methodObject), new Among("aimh", 10, 1, "", methodObject), new Among("íocht", -1, 1, "", methodObject), new Among("aíocht", 12, 1, "", methodObject), new Among("irí", -1, 2, "", methodObject), new Among("airí", 14, 2, "", methodObject) };
/*     */ 
/*  65 */   private static final Among[] a_2 = { new Among("óideacha", -1, 6, "", methodObject), new Among("patacha", -1, 5, "", methodObject), new Among("achta", -1, 1, "", methodObject), new Among("arcachta", 2, 2, "", methodObject), new Among("eachta", 2, 1, "", methodObject), new Among("grafaíochta", -1, 4, "", methodObject), new Among("paite", -1, 5, "", methodObject), new Among("ach", -1, 1, "", methodObject), new Among("each", 7, 1, "", methodObject), new Among("óideach", 8, 6, "", methodObject), new Among("gineach", 8, 3, "", methodObject), new Among("patach", 7, 5, "", methodObject), new Among("grafaíoch", -1, 4, "", methodObject), new Among("pataigh", -1, 5, "", methodObject), new Among("óidigh", -1, 6, "", methodObject), new Among("achtúil", -1, 1, "", methodObject), new Among("eachtúil", 15, 1, "", methodObject), new Among("gineas", -1, 3, "", methodObject), new Among("ginis", -1, 3, "", methodObject), new Among("acht", -1, 1, "", methodObject), new Among("arcacht", 19, 2, "", methodObject), new Among("eacht", 19, 1, "", methodObject), new Among("grafaíocht", -1, 4, "", methodObject), new Among("arcachtaí", -1, 2, "", methodObject), new Among("grafaíochtaí", -1, 4, "", methodObject) };
/*     */ 
/*  93 */   private static final Among[] a_3 = { new Among("imid", -1, 1, "", methodObject), new Among("aimid", 0, 1, "", methodObject), new Among("ímid", -1, 1, "", methodObject), new Among("aímid", 2, 1, "", methodObject), new Among("adh", -1, 2, "", methodObject), new Among("eadh", 4, 2, "", methodObject), new Among("faidh", -1, 1, "", methodObject), new Among("fidh", -1, 1, "", methodObject), new Among("áil", -1, 2, "", methodObject), new Among("ain", -1, 2, "", methodObject), new Among("tear", -1, 2, "", methodObject), new Among("tar", -1, 2, "", methodObject) };
/*     */ 
/* 108 */   private static final char[] g_v = { '\021', 'A', '\020', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\001', '\021', '\004', '\002' };
/*     */   private int I_p2;
/*     */   private int I_p1;
/*     */   private int I_pV;
/*     */ 
/*     */   private void copy_from(IrishStemmer other)
/*     */   {
/* 115 */     this.I_p2 = other.I_p2;
/* 116 */     this.I_p1 = other.I_p1;
/* 117 */     this.I_pV = other.I_pV;
/* 118 */     super.copy_from(other);
/*     */   }
/*     */ 
/*     */   private boolean r_mark_regions()
/*     */   {
/* 125 */     this.I_pV = this.limit;
/* 126 */     this.I_p1 = this.limit;
/* 127 */     this.I_p2 = this.limit;
/*     */ 
/* 129 */     int v_1 = this.cursor;
/*     */ 
/* 136 */     while (!in_grouping(g_v, 97, 250))
/*     */     {
/* 142 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label79;
/*     */       }
/* 146 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 149 */     this.I_pV = this.cursor;
/*     */ 
/* 151 */     label79: this.cursor = v_1;
/*     */ 
/* 153 */     int v_3 = this.cursor;
/*     */ 
/* 160 */     while (!in_grouping(g_v, 97, 250))
/*     */     {
/* 166 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label273;
/*     */       }
/* 170 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 176 */     while (!out_grouping(g_v, 97, 250))
/*     */     {
/* 182 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label273;
/*     */       }
/* 186 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 189 */     this.I_p1 = this.cursor;
/*     */ 
/* 194 */     while (!in_grouping(g_v, 97, 250))
/*     */     {
/* 200 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label273;
/*     */       }
/* 204 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 210 */     while (!out_grouping(g_v, 97, 250))
/*     */     {
/* 216 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label273;
/*     */       }
/* 220 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 223 */     this.I_p2 = this.cursor;
/*     */ 
/* 225 */     label273: this.cursor = v_3;
/* 226 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_initial_morph()
/*     */   {
/* 233 */     this.bra = this.cursor;
/*     */ 
/* 235 */     int among_var = find_among(a_0, 24);
/* 236 */     if (among_var == 0)
/*     */     {
/* 238 */       return false;
/*     */     }
/*     */ 
/* 241 */     this.ket = this.cursor;
/* 242 */     switch (among_var) {
/*     */     case 0:
/* 244 */       return false;
/*     */     case 1:
/* 248 */       slice_del();
/* 249 */       break;
/*     */     case 2:
/* 253 */       slice_del();
/* 254 */       break;
/*     */     case 3:
/* 258 */       slice_from("f");
/* 259 */       break;
/*     */     case 4:
/* 263 */       slice_del();
/* 264 */       break;
/*     */     case 5:
/* 268 */       slice_from("s");
/* 269 */       break;
/*     */     case 6:
/* 273 */       slice_from("b");
/* 274 */       break;
/*     */     case 7:
/* 278 */       slice_from("c");
/* 279 */       break;
/*     */     case 8:
/* 283 */       slice_from("d");
/* 284 */       break;
/*     */     case 9:
/* 288 */       slice_from("f");
/* 289 */       break;
/*     */     case 10:
/* 293 */       slice_from("g");
/* 294 */       break;
/*     */     case 11:
/* 298 */       slice_from("p");
/* 299 */       break;
/*     */     case 12:
/* 303 */       slice_from("s");
/* 304 */       break;
/*     */     case 13:
/* 308 */       slice_from("t");
/* 309 */       break;
/*     */     case 14:
/* 313 */       slice_from("b");
/* 314 */       break;
/*     */     case 15:
/* 318 */       slice_from("c");
/* 319 */       break;
/*     */     case 16:
/* 323 */       slice_from("d");
/* 324 */       break;
/*     */     case 17:
/* 328 */       slice_from("f");
/* 329 */       break;
/*     */     case 18:
/* 333 */       slice_from("g");
/* 334 */       break;
/*     */     case 19:
/* 338 */       slice_from("m");
/* 339 */       break;
/*     */     case 20:
/* 343 */       slice_from("p");
/* 344 */       break;
/*     */     case 21:
/* 348 */       slice_from("t");
/*     */     }
/*     */ 
/* 351 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_RV() {
/* 355 */     if (this.I_pV > this.cursor)
/*     */     {
/* 357 */       return false;
/*     */     }
/* 359 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R1() {
/* 363 */     if (this.I_p1 > this.cursor)
/*     */     {
/* 365 */       return false;
/*     */     }
/* 367 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R2() {
/* 371 */     if (this.I_p2 > this.cursor)
/*     */     {
/* 373 */       return false;
/*     */     }
/* 375 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_noun_sfx()
/*     */   {
/* 382 */     this.ket = this.cursor;
/*     */ 
/* 384 */     int among_var = find_among_b(a_1, 16);
/* 385 */     if (among_var == 0)
/*     */     {
/* 387 */       return false;
/*     */     }
/*     */ 
/* 390 */     this.bra = this.cursor;
/* 391 */     switch (among_var) {
/*     */     case 0:
/* 393 */       return false;
/*     */     case 1:
/* 397 */       if (!r_R1())
/*     */       {
/* 399 */         return false;
/*     */       }
/*     */ 
/* 402 */       slice_del();
/* 403 */       break;
/*     */     case 2:
/* 407 */       if (!r_R2())
/*     */       {
/* 409 */         return false;
/*     */       }
/*     */ 
/* 412 */       slice_del();
/*     */     }
/*     */ 
/* 415 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_deriv()
/*     */   {
/* 422 */     this.ket = this.cursor;
/*     */ 
/* 424 */     int among_var = find_among_b(a_2, 25);
/* 425 */     if (among_var == 0)
/*     */     {
/* 427 */       return false;
/*     */     }
/*     */ 
/* 430 */     this.bra = this.cursor;
/* 431 */     switch (among_var) {
/*     */     case 0:
/* 433 */       return false;
/*     */     case 1:
/* 437 */       if (!r_R2())
/*     */       {
/* 439 */         return false;
/*     */       }
/*     */ 
/* 442 */       slice_del();
/* 443 */       break;
/*     */     case 2:
/* 447 */       slice_from("arc");
/* 448 */       break;
/*     */     case 3:
/* 452 */       slice_from("gin");
/* 453 */       break;
/*     */     case 4:
/* 457 */       slice_from("graf");
/* 458 */       break;
/*     */     case 5:
/* 462 */       slice_from("paite");
/* 463 */       break;
/*     */     case 6:
/* 467 */       slice_from("óid");
/*     */     }
/*     */ 
/* 470 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_verb_sfx()
/*     */   {
/* 477 */     this.ket = this.cursor;
/*     */ 
/* 479 */     int among_var = find_among_b(a_3, 12);
/* 480 */     if (among_var == 0)
/*     */     {
/* 482 */       return false;
/*     */     }
/*     */ 
/* 485 */     this.bra = this.cursor;
/* 486 */     switch (among_var) {
/*     */     case 0:
/* 488 */       return false;
/*     */     case 1:
/* 492 */       if (!r_RV())
/*     */       {
/* 494 */         return false;
/*     */       }
/*     */ 
/* 497 */       slice_del();
/* 498 */       break;
/*     */     case 2:
/* 502 */       if (!r_R1())
/*     */       {
/* 504 */         return false;
/*     */       }
/*     */ 
/* 507 */       slice_del();
/*     */     }
/*     */ 
/* 510 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean stem()
/*     */   {
/* 522 */     int v_1 = this.cursor;
/*     */ 
/* 525 */     if (!r_initial_morph());
/* 530 */     this.cursor = v_1;
/*     */ 
/* 532 */     int v_2 = this.cursor;
/*     */ 
/* 535 */     if (!r_mark_regions());
/* 540 */     this.cursor = v_2;
/*     */ 
/* 542 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*     */ 
/* 545 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 548 */     if (!r_noun_sfx());
/* 553 */     this.cursor = (this.limit - v_3);
/*     */ 
/* 555 */     int v_4 = this.limit - this.cursor;
/*     */ 
/* 558 */     if (!r_deriv());
/* 563 */     this.cursor = (this.limit - v_4);
/*     */ 
/* 565 */     int v_5 = this.limit - this.cursor;
/*     */ 
/* 568 */     if (!r_verb_sfx());
/* 573 */     this.cursor = (this.limit - v_5);
/* 574 */     this.cursor = this.limit_backward; return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 579 */     return o instanceof IrishStemmer;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 584 */     return IrishStemmer.class.getName().hashCode();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.ext.IrishStemmer
 * JD-Core Version:    0.6.2
 */