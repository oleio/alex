/*     */ package org.tartarus.snowball.ext;
/*     */ 
/*     */ import org.tartarus.snowball.Among;
/*     */ import org.tartarus.snowball.SnowballProgram;
/*     */ 
/*     */ public class NorwegianStemmer extends SnowballProgram
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  17 */   private static final NorwegianStemmer methodObject = new NorwegianStemmer();
/*     */ 
/*  19 */   private static final Among[] a_0 = { new Among("a", -1, 1, "", methodObject), new Among("e", -1, 1, "", methodObject), new Among("ede", 1, 1, "", methodObject), new Among("ande", 1, 1, "", methodObject), new Among("ende", 1, 1, "", methodObject), new Among("ane", 1, 1, "", methodObject), new Among("ene", 1, 1, "", methodObject), new Among("hetene", 6, 1, "", methodObject), new Among("erte", 1, 3, "", methodObject), new Among("en", -1, 1, "", methodObject), new Among("heten", 9, 1, "", methodObject), new Among("ar", -1, 1, "", methodObject), new Among("er", -1, 1, "", methodObject), new Among("heter", 12, 1, "", methodObject), new Among("s", -1, 2, "", methodObject), new Among("as", 14, 1, "", methodObject), new Among("es", 14, 1, "", methodObject), new Among("edes", 16, 1, "", methodObject), new Among("endes", 16, 1, "", methodObject), new Among("enes", 16, 1, "", methodObject), new Among("hetenes", 19, 1, "", methodObject), new Among("ens", 14, 1, "", methodObject), new Among("hetens", 21, 1, "", methodObject), new Among("ers", 14, 1, "", methodObject), new Among("ets", 14, 1, "", methodObject), new Among("et", -1, 1, "", methodObject), new Among("het", 25, 1, "", methodObject), new Among("ert", -1, 3, "", methodObject), new Among("ast", -1, 1, "", methodObject) };
/*     */ 
/*  51 */   private static final Among[] a_1 = { new Among("dt", -1, -1, "", methodObject), new Among("vt", -1, -1, "", methodObject) };
/*     */ 
/*  56 */   private static final Among[] a_2 = { new Among("leg", -1, 1, "", methodObject), new Among("eleg", 0, 1, "", methodObject), new Among("ig", -1, 1, "", methodObject), new Among("eig", 2, 1, "", methodObject), new Among("lig", 2, 1, "", methodObject), new Among("elig", 4, 1, "", methodObject), new Among("els", -1, 1, "", methodObject), new Among("lov", -1, 1, "", methodObject), new Among("elov", 7, 1, "", methodObject), new Among("slov", 7, 1, "", methodObject), new Among("hetslov", 9, 1, "", methodObject) };
/*     */ 
/*  70 */   private static final char[] g_v = { '\021', 'A', '\020', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '0', '\000', '' };
/*     */ 
/*  72 */   private static final char[] g_s_ending = { 'w', '}', '', '\001' };
/*     */   private int I_x;
/*     */   private int I_p1;
/*     */ 
/*     */   private void copy_from(NorwegianStemmer other)
/*     */   {
/*  78 */     this.I_x = other.I_x;
/*  79 */     this.I_p1 = other.I_p1;
/*  80 */     super.copy_from(other);
/*     */   }
/*     */ 
/*     */   private boolean r_mark_regions()
/*     */   {
/*  87 */     this.I_p1 = this.limit;
/*     */ 
/*  89 */     int v_1 = this.cursor;
/*     */ 
/*  93 */     int c = this.cursor + 3;
/*  94 */     if ((0 > c) || (c > this.limit))
/*     */     {
/*  96 */       return false;
/*     */     }
/*  98 */     this.cursor = c;
/*     */ 
/* 101 */     this.I_x = this.cursor;
/* 102 */     this.cursor = v_1;
/*     */     while (true)
/*     */     {
/* 106 */       int v_2 = this.cursor;
/*     */ 
/* 108 */       if (in_grouping(g_v, 97, 248))
/*     */       {
/* 112 */         this.cursor = v_2;
/* 113 */         break;
/*     */       }
/* 115 */       this.cursor = v_2;
/* 116 */       if (this.cursor >= this.limit)
/*     */       {
/* 118 */         return false;
/*     */       }
/* 120 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 126 */     while (!out_grouping(g_v, 97, 248))
/*     */     {
/* 132 */       if (this.cursor >= this.limit)
/*     */       {
/* 134 */         return false;
/*     */       }
/* 136 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 139 */     this.I_p1 = this.cursor;
/*     */ 
/* 143 */     if (this.I_p1 < this.I_x)
/*     */     {
/* 147 */       this.I_p1 = this.I_x;
/*     */     }
/* 149 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_main_suffix()
/*     */   {
/* 159 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 161 */     if (this.cursor < this.I_p1)
/*     */     {
/* 163 */       return false;
/*     */     }
/* 165 */     this.cursor = this.I_p1;
/* 166 */     int v_2 = this.limit_backward;
/* 167 */     this.limit_backward = this.cursor;
/* 168 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 171 */     this.ket = this.cursor;
/*     */ 
/* 173 */     int among_var = find_among_b(a_0, 29);
/* 174 */     if (among_var == 0)
/*     */     {
/* 176 */       this.limit_backward = v_2;
/* 177 */       return false;
/*     */     }
/*     */ 
/* 180 */     this.bra = this.cursor;
/* 181 */     this.limit_backward = v_2;
/* 182 */     switch (among_var) {
/*     */     case 0:
/* 184 */       return false;
/*     */     case 1:
/* 188 */       slice_del();
/* 189 */       break;
/*     */     case 2:
/* 194 */       int v_3 = this.limit - this.cursor;
/*     */ 
/* 196 */       if (!in_grouping_b(g_s_ending, 98, 122))
/*     */       {
/* 202 */         this.cursor = (this.limit - v_3);
/*     */ 
/* 205 */         if (!eq_s_b(1, "k"))
/*     */         {
/* 207 */           return false;
/*     */         }
/* 209 */         if (!out_grouping_b(g_v, 97, 248))
/*     */         {
/* 211 */           return false;
/*     */         }
/*     */       }
/*     */ 
/* 215 */       slice_del();
/* 216 */       break;
/*     */     case 3:
/* 220 */       slice_from("er");
/*     */     }
/*     */ 
/* 223 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_consonant_pair()
/*     */   {
/* 232 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 235 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 237 */     if (this.cursor < this.I_p1)
/*     */     {
/* 239 */       return false;
/*     */     }
/* 241 */     this.cursor = this.I_p1;
/* 242 */     int v_3 = this.limit_backward;
/* 243 */     this.limit_backward = this.cursor;
/* 244 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 247 */     this.ket = this.cursor;
/*     */ 
/* 249 */     if (find_among_b(a_1, 2) == 0)
/*     */     {
/* 251 */       this.limit_backward = v_3;
/* 252 */       return false;
/*     */     }
/*     */ 
/* 255 */     this.bra = this.cursor;
/* 256 */     this.limit_backward = v_3;
/* 257 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 259 */     if (this.cursor <= this.limit_backward)
/*     */     {
/* 261 */       return false;
/*     */     }
/* 263 */     this.cursor -= 1;
/*     */ 
/* 265 */     this.bra = this.cursor;
/*     */ 
/* 267 */     slice_del();
/* 268 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_other_suffix()
/*     */   {
/* 277 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 279 */     if (this.cursor < this.I_p1)
/*     */     {
/* 281 */       return false;
/*     */     }
/* 283 */     this.cursor = this.I_p1;
/* 284 */     int v_2 = this.limit_backward;
/* 285 */     this.limit_backward = this.cursor;
/* 286 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 289 */     this.ket = this.cursor;
/*     */ 
/* 291 */     int among_var = find_among_b(a_2, 11);
/* 292 */     if (among_var == 0)
/*     */     {
/* 294 */       this.limit_backward = v_2;
/* 295 */       return false;
/*     */     }
/*     */ 
/* 298 */     this.bra = this.cursor;
/* 299 */     this.limit_backward = v_2;
/* 300 */     switch (among_var) {
/*     */     case 0:
/* 302 */       return false;
/*     */     case 1:
/* 306 */       slice_del();
/*     */     }
/*     */ 
/* 309 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean stem()
/*     */   {
/* 320 */     int v_1 = this.cursor;
/*     */ 
/* 323 */     if (!r_mark_regions());
/* 328 */     this.cursor = v_1;
/*     */ 
/* 330 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*     */ 
/* 333 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 336 */     if (!r_main_suffix());
/* 341 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 343 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 346 */     if (!r_consonant_pair());
/* 351 */     this.cursor = (this.limit - v_3);
/*     */ 
/* 353 */     int v_4 = this.limit - this.cursor;
/*     */ 
/* 356 */     if (!r_other_suffix());
/* 361 */     this.cursor = (this.limit - v_4);
/* 362 */     this.cursor = this.limit_backward; return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 367 */     return o instanceof NorwegianStemmer;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 372 */     return NorwegianStemmer.class.getName().hashCode();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.ext.NorwegianStemmer
 * JD-Core Version:    0.6.2
 */