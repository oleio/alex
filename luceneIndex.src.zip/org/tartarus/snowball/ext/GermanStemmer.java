/*     */ package org.tartarus.snowball.ext;
/*     */ 
/*     */ import org.tartarus.snowball.Among;
/*     */ import org.tartarus.snowball.SnowballProgram;
/*     */ 
/*     */ public class GermanStemmer extends SnowballProgram
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  17 */   private static final GermanStemmer methodObject = new GermanStemmer();
/*     */ 
/*  19 */   private static final Among[] a_0 = { new Among("", -1, 6, "", methodObject), new Among("U", 0, 2, "", methodObject), new Among("Y", 0, 1, "", methodObject), new Among("ä", 0, 3, "", methodObject), new Among("ö", 0, 4, "", methodObject), new Among("ü", 0, 5, "", methodObject) };
/*     */ 
/*  28 */   private static final Among[] a_1 = { new Among("e", -1, 1, "", methodObject), new Among("em", -1, 1, "", methodObject), new Among("en", -1, 1, "", methodObject), new Among("ern", -1, 1, "", methodObject), new Among("er", -1, 1, "", methodObject), new Among("s", -1, 2, "", methodObject), new Among("es", 5, 1, "", methodObject) };
/*     */ 
/*  38 */   private static final Among[] a_2 = { new Among("en", -1, 1, "", methodObject), new Among("er", -1, 1, "", methodObject), new Among("st", -1, 2, "", methodObject), new Among("est", 2, 1, "", methodObject) };
/*     */ 
/*  45 */   private static final Among[] a_3 = { new Among("ig", -1, 1, "", methodObject), new Among("lich", -1, 1, "", methodObject) };
/*     */ 
/*  50 */   private static final Among[] a_4 = { new Among("end", -1, 1, "", methodObject), new Among("ig", -1, 2, "", methodObject), new Among("ung", -1, 1, "", methodObject), new Among("lich", -1, 3, "", methodObject), new Among("isch", -1, 2, "", methodObject), new Among("ik", -1, 2, "", methodObject), new Among("heit", -1, 3, "", methodObject), new Among("keit", -1, 4, "", methodObject) };
/*     */ 
/*  61 */   private static final char[] g_v = { '\021', 'A', '\020', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\b', '\000', ' ', '\b' };
/*     */ 
/*  63 */   private static final char[] g_s_ending = { 'u', '\036', '\005' };
/*     */ 
/*  65 */   private static final char[] g_st_ending = { 'u', '\036', '\004' };
/*     */   private int I_x;
/*     */   private int I_p2;
/*     */   private int I_p1;
/*     */ 
/*     */   private void copy_from(GermanStemmer other)
/*     */   {
/*  72 */     this.I_x = other.I_x;
/*  73 */     this.I_p2 = other.I_p2;
/*  74 */     this.I_p1 = other.I_p1;
/*  75 */     super.copy_from(other);
/*     */   }
/*     */ 
/*     */   private boolean r_prelude()
/*     */   {
/*  87 */     int v_1 = this.cursor;
/*     */     int v_2;
/*     */     while (true)
/*     */     {
/*  91 */       v_2 = this.cursor;
/*     */ 
/*  96 */       int v_3 = this.cursor;
/*     */ 
/* 100 */       this.bra = this.cursor;
/*     */ 
/* 102 */       if (eq_s(1, "ß"))
/*     */       {
/* 107 */         this.ket = this.cursor;
/*     */ 
/* 109 */         slice_from("ss");
/*     */       }
/*     */       else {
/* 112 */         this.cursor = v_3;
/*     */ 
/* 114 */         if (this.cursor >= this.limit)
/*     */         {
/*     */           break;
/*     */         }
/* 118 */         this.cursor += 1;
/*     */       }
/*     */     }
/*     */ 
/* 122 */     this.cursor = v_2;
/*     */ 
/* 125 */     this.cursor = v_1;
/*     */ 
/* 129 */     int v_4 = this.cursor;
/*     */     while (true)
/*     */     {
/* 134 */       int v_5 = this.cursor;
/*     */ 
/* 137 */       if (in_grouping(g_v, 97, 252))
/*     */       {
/* 142 */         this.bra = this.cursor;
/*     */ 
/* 145 */         int v_6 = this.cursor;
/*     */ 
/* 149 */         if (eq_s(1, "u"))
/*     */         {
/* 154 */           this.ket = this.cursor;
/* 155 */           if (in_grouping(g_v, 97, 252))
/*     */           {
/* 160 */             slice_from("U");
/* 161 */             break label241;
/*     */           }
/*     */         }
/* 163 */         this.cursor = v_6;
/*     */ 
/* 166 */         if (eq_s(1, "y"))
/*     */         {
/* 171 */           this.ket = this.cursor;
/* 172 */           if (in_grouping(g_v, 97, 252))
/*     */           {
/* 177 */             slice_from("Y");
/*     */ 
/* 179 */             label241: this.cursor = v_5;
/* 180 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 182 */       this.cursor = v_5;
/* 183 */       if (this.cursor >= this.limit)
/*     */       {
/*     */         break label283;
/*     */       }
/* 187 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 191 */     label283: this.cursor = v_4;
/*     */ 
/* 194 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_mark_regions()
/*     */   {
/* 200 */     this.I_p1 = this.limit;
/* 201 */     this.I_p2 = this.limit;
/*     */ 
/* 203 */     int v_1 = this.cursor;
/*     */ 
/* 207 */     int c = this.cursor + 3;
/* 208 */     if ((0 > c) || (c > this.limit))
/*     */     {
/* 210 */       return false;
/*     */     }
/* 212 */     this.cursor = c;
/*     */ 
/* 215 */     this.I_x = this.cursor;
/* 216 */     this.cursor = v_1;
/*     */ 
/* 221 */     while (!in_grouping(g_v, 97, 252))
/*     */     {
/* 227 */       if (this.cursor >= this.limit)
/*     */       {
/* 229 */         return false;
/*     */       }
/* 231 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 237 */     while (!out_grouping(g_v, 97, 252))
/*     */     {
/* 243 */       if (this.cursor >= this.limit)
/*     */       {
/* 245 */         return false;
/*     */       }
/* 247 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 250 */     this.I_p1 = this.cursor;
/*     */ 
/* 254 */     if (this.I_p1 < this.I_x)
/*     */     {
/* 258 */       this.I_p1 = this.I_x;
/*     */     }
/*     */ 
/* 264 */     while (!in_grouping(g_v, 97, 252))
/*     */     {
/* 270 */       if (this.cursor >= this.limit)
/*     */       {
/* 272 */         return false;
/*     */       }
/* 274 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 280 */     while (!out_grouping(g_v, 97, 252))
/*     */     {
/* 286 */       if (this.cursor >= this.limit)
/*     */       {
/* 288 */         return false;
/*     */       }
/* 290 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 293 */     this.I_p2 = this.cursor;
/* 294 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_postlude()
/*     */   {
/*     */     int v_1;
/*     */     while (true)
/*     */     {
/* 303 */       v_1 = this.cursor;
/*     */ 
/* 307 */       this.bra = this.cursor;
/*     */ 
/* 309 */       int among_var = find_among(a_0, 6);
/* 310 */       if (among_var == 0)
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 315 */       this.ket = this.cursor;
/* 316 */       switch (among_var) {
/*     */       case 0:
/* 318 */         break;
/*     */       case 1:
/* 322 */         slice_from("y");
/* 323 */         break;
/*     */       case 2:
/* 327 */         slice_from("u");
/* 328 */         break;
/*     */       case 3:
/* 332 */         slice_from("a");
/* 333 */         break;
/*     */       case 4:
/* 337 */         slice_from("o");
/* 338 */         break;
/*     */       case 5:
/* 342 */         slice_from("u");
/* 343 */         break;
/*     */       case 6:
/* 347 */         if (this.cursor >= this.limit)
/*     */         {
/*     */           break label155;
/*     */         }
/* 351 */         this.cursor += 1;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 356 */     label155: this.cursor = v_1;
/*     */ 
/* 359 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R1() {
/* 363 */     if (this.I_p1 > this.cursor)
/*     */     {
/* 365 */       return false;
/*     */     }
/* 367 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_R2() {
/* 371 */     if (this.I_p2 > this.cursor)
/*     */     {
/* 373 */       return false;
/*     */     }
/* 375 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_standard_suffix()
/*     */   {
/* 391 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 395 */     this.ket = this.cursor;
/*     */ 
/* 397 */     int among_var = find_among_b(a_1, 7);
/* 398 */     if (among_var != 0)
/*     */     {
/* 403 */       this.bra = this.cursor;
/*     */ 
/* 405 */       if (r_R1())
/*     */       {
/* 409 */         switch (among_var) {
/*     */         case 0:
/* 411 */           break;
/*     */         case 1:
/* 415 */           slice_del();
/* 416 */           break;
/*     */         case 2:
/* 419 */           if (in_grouping_b(g_s_ending, 98, 116))
/*     */           {
/* 424 */             slice_del(); } break;
/*     */         }
/*     */       }
/*     */     }
/* 428 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 430 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 434 */     this.ket = this.cursor;
/*     */ 
/* 436 */     among_var = find_among_b(a_2, 4);
/* 437 */     if (among_var != 0)
/*     */     {
/* 442 */       this.bra = this.cursor;
/*     */ 
/* 444 */       if (r_R1())
/*     */       {
/* 448 */         switch (among_var) {
/*     */         case 0:
/* 450 */           break;
/*     */         case 1:
/* 454 */           slice_del();
/* 455 */           break;
/*     */         case 2:
/* 458 */           if (in_grouping_b(g_st_ending, 98, 116))
/*     */           {
/* 464 */             int c = this.cursor - 3;
/* 465 */             if ((this.limit_backward <= c) && (c <= this.limit))
/*     */             {
/* 469 */               this.cursor = c;
/*     */ 
/* 472 */               slice_del(); }  } break;
/*     */         }
/*     */       }
/*     */     }
/* 476 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 478 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 482 */     this.ket = this.cursor;
/*     */ 
/* 484 */     among_var = find_among_b(a_4, 8);
/* 485 */     if (among_var != 0)
/*     */     {
/* 490 */       this.bra = this.cursor;
/*     */ 
/* 492 */       if (r_R2())
/*     */       {
/* 496 */         switch (among_var) {
/*     */         case 0:
/* 498 */           break;
/*     */         case 1:
/* 502 */           slice_del();
/*     */ 
/* 504 */           int v_4 = this.limit - this.cursor;
/*     */ 
/* 508 */           this.ket = this.cursor;
/*     */ 
/* 510 */           if (!eq_s_b(2, "ig"))
/*     */           {
/* 512 */             this.cursor = (this.limit - v_4);
/*     */           }
/*     */           else
/*     */           {
/* 516 */             this.bra = this.cursor;
/*     */ 
/* 519 */             int v_5 = this.limit - this.cursor;
/*     */ 
/* 522 */             if (eq_s_b(1, "e"))
/*     */             {
/* 526 */               this.cursor = (this.limit - v_4);
/*     */             }
/*     */             else {
/* 529 */               this.cursor = (this.limit - v_5);
/*     */ 
/* 532 */               if (!r_R2())
/*     */               {
/* 534 */                 this.cursor = (this.limit - v_4);
/*     */               }
/*     */               else
/*     */               {
/* 538 */                 slice_del();
/*     */               }
/*     */             }
/*     */           }
/* 540 */           break;
/*     */         case 2:
/* 545 */           int v_6 = this.limit - this.cursor;
/*     */ 
/* 548 */           if (!eq_s_b(1, "e"))
/*     */           {
/* 554 */             this.cursor = (this.limit - v_6);
/*     */ 
/* 557 */             slice_del();
/* 558 */           }break;
/*     */         case 3:
/* 562 */           slice_del();
/*     */ 
/* 564 */           int v_7 = this.limit - this.cursor;
/*     */ 
/* 568 */           this.ket = this.cursor;
/*     */ 
/* 571 */           int v_8 = this.limit - this.cursor;
/*     */ 
/* 574 */           if (!eq_s_b(2, "er"))
/*     */           {
/* 580 */             this.cursor = (this.limit - v_8);
/*     */ 
/* 582 */             if (!eq_s_b(2, "en"))
/*     */             {
/* 584 */               this.cursor = (this.limit - v_7);
/* 585 */               break;
/*     */             }
/*     */           }
/*     */ 
/* 589 */           this.bra = this.cursor;
/*     */ 
/* 591 */           if (!r_R1())
/*     */           {
/* 593 */             this.cursor = (this.limit - v_7);
/*     */           }
/*     */           else
/*     */           {
/* 597 */             slice_del();
/*     */           }
/* 599 */           break;
/*     */         case 4:
/* 603 */           slice_del();
/*     */ 
/* 605 */           int v_9 = this.limit - this.cursor;
/*     */ 
/* 609 */           this.ket = this.cursor;
/*     */ 
/* 611 */           among_var = find_among_b(a_3, 2);
/* 612 */           if (among_var == 0)
/*     */           {
/* 614 */             this.cursor = (this.limit - v_9);
/*     */           }
/*     */           else
/*     */           {
/* 618 */             this.bra = this.cursor;
/*     */ 
/* 620 */             if (!r_R2())
/*     */             {
/* 622 */               this.cursor = (this.limit - v_9);
/*     */             }
/*     */             else
/* 625 */               switch (among_var) {
/*     */               case 0:
/* 627 */                 this.cursor = (this.limit - v_9);
/* 628 */                 break;
/*     */               case 1:
/* 632 */                 slice_del();
/*     */               }
/*     */           }
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 639 */     this.cursor = (this.limit - v_3);
/* 640 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean stem()
/*     */   {
/* 651 */     int v_1 = this.cursor;
/*     */ 
/* 654 */     if (!r_prelude());
/* 659 */     this.cursor = v_1;
/*     */ 
/* 661 */     int v_2 = this.cursor;
/*     */ 
/* 664 */     if (!r_mark_regions());
/* 669 */     this.cursor = v_2;
/*     */ 
/* 671 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*     */ 
/* 673 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 676 */     if (!r_standard_suffix());
/* 681 */     this.cursor = (this.limit - v_3);
/* 682 */     this.cursor = this.limit_backward;
/* 683 */     int v_4 = this.cursor;
/*     */ 
/* 686 */     if (!r_postlude());
/* 691 */     this.cursor = v_4;
/* 692 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 697 */     return o instanceof GermanStemmer;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 702 */     return GermanStemmer.class.getName().hashCode();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.ext.GermanStemmer
 * JD-Core Version:    0.6.2
 */