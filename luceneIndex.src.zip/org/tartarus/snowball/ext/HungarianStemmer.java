/*      */ package org.tartarus.snowball.ext;
/*      */ 
/*      */ import org.tartarus.snowball.Among;
/*      */ import org.tartarus.snowball.SnowballProgram;
/*      */ 
/*      */ public class HungarianStemmer extends SnowballProgram
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   17 */   private static final HungarianStemmer methodObject = new HungarianStemmer();
/*      */ 
/*   19 */   private static final Among[] a_0 = { new Among("cs", -1, -1, "", methodObject), new Among("dzs", -1, -1, "", methodObject), new Among("gy", -1, -1, "", methodObject), new Among("ly", -1, -1, "", methodObject), new Among("ny", -1, -1, "", methodObject), new Among("sz", -1, -1, "", methodObject), new Among("ty", -1, -1, "", methodObject), new Among("zs", -1, -1, "", methodObject) };
/*      */ 
/*   30 */   private static final Among[] a_1 = { new Among("á", -1, 1, "", methodObject), new Among("é", -1, 2, "", methodObject) };
/*      */ 
/*   35 */   private static final Among[] a_2 = { new Among("bb", -1, -1, "", methodObject), new Among("cc", -1, -1, "", methodObject), new Among("dd", -1, -1, "", methodObject), new Among("ff", -1, -1, "", methodObject), new Among("gg", -1, -1, "", methodObject), new Among("jj", -1, -1, "", methodObject), new Among("kk", -1, -1, "", methodObject), new Among("ll", -1, -1, "", methodObject), new Among("mm", -1, -1, "", methodObject), new Among("nn", -1, -1, "", methodObject), new Among("pp", -1, -1, "", methodObject), new Among("rr", -1, -1, "", methodObject), new Among("ccs", -1, -1, "", methodObject), new Among("ss", -1, -1, "", methodObject), new Among("zzs", -1, -1, "", methodObject), new Among("tt", -1, -1, "", methodObject), new Among("vv", -1, -1, "", methodObject), new Among("ggy", -1, -1, "", methodObject), new Among("lly", -1, -1, "", methodObject), new Among("nny", -1, -1, "", methodObject), new Among("tty", -1, -1, "", methodObject), new Among("ssz", -1, -1, "", methodObject), new Among("zz", -1, -1, "", methodObject) };
/*      */ 
/*   61 */   private static final Among[] a_3 = { new Among("al", -1, 1, "", methodObject), new Among("el", -1, 2, "", methodObject) };
/*      */ 
/*   66 */   private static final Among[] a_4 = { new Among("ba", -1, -1, "", methodObject), new Among("ra", -1, -1, "", methodObject), new Among("be", -1, -1, "", methodObject), new Among("re", -1, -1, "", methodObject), new Among("ig", -1, -1, "", methodObject), new Among("nak", -1, -1, "", methodObject), new Among("nek", -1, -1, "", methodObject), new Among("val", -1, -1, "", methodObject), new Among("vel", -1, -1, "", methodObject), new Among("ul", -1, -1, "", methodObject), new Among("nál", -1, -1, "", methodObject), new Among("nél", -1, -1, "", methodObject), new Among("ból", -1, -1, "", methodObject), new Among("ról", -1, -1, "", methodObject), new Among("tól", -1, -1, "", methodObject), new Among("bõl", -1, -1, "", methodObject), new Among("rõl", -1, -1, "", methodObject), new Among("tõl", -1, -1, "", methodObject), new Among("ül", -1, -1, "", methodObject), new Among("n", -1, -1, "", methodObject), new Among("an", 19, -1, "", methodObject), new Among("ban", 20, -1, "", methodObject), new Among("en", 19, -1, "", methodObject), new Among("ben", 22, -1, "", methodObject), new Among("képpen", 22, -1, "", methodObject), new Among("on", 19, -1, "", methodObject), new Among("ön", 19, -1, "", methodObject), new Among("képp", -1, -1, "", methodObject), new Among("kor", -1, -1, "", methodObject), new Among("t", -1, -1, "", methodObject), new Among("at", 29, -1, "", methodObject), new Among("et", 29, -1, "", methodObject), new Among("ként", 29, -1, "", methodObject), new Among("anként", 32, -1, "", methodObject), new Among("enként", 32, -1, "", methodObject), new Among("onként", 32, -1, "", methodObject), new Among("ot", 29, -1, "", methodObject), new Among("ért", 29, -1, "", methodObject), new Among("öt", 29, -1, "", methodObject), new Among("hez", -1, -1, "", methodObject), new Among("hoz", -1, -1, "", methodObject), new Among("höz", -1, -1, "", methodObject), new Among("vá", -1, -1, "", methodObject), new Among("vé", -1, -1, "", methodObject) };
/*      */ 
/*  113 */   private static final Among[] a_5 = { new Among("án", -1, 2, "", methodObject), new Among("én", -1, 1, "", methodObject), new Among("ánként", -1, 3, "", methodObject) };
/*      */ 
/*  119 */   private static final Among[] a_6 = { new Among("stul", -1, 2, "", methodObject), new Among("astul", 0, 1, "", methodObject), new Among("ástul", 0, 3, "", methodObject), new Among("stül", -1, 2, "", methodObject), new Among("estül", 3, 1, "", methodObject), new Among("éstül", 3, 4, "", methodObject) };
/*      */ 
/*  128 */   private static final Among[] a_7 = { new Among("á", -1, 1, "", methodObject), new Among("é", -1, 2, "", methodObject) };
/*      */ 
/*  133 */   private static final Among[] a_8 = { new Among("k", -1, 7, "", methodObject), new Among("ak", 0, 4, "", methodObject), new Among("ek", 0, 6, "", methodObject), new Among("ok", 0, 5, "", methodObject), new Among("ák", 0, 1, "", methodObject), new Among("ék", 0, 2, "", methodObject), new Among("ök", 0, 3, "", methodObject) };
/*      */ 
/*  143 */   private static final Among[] a_9 = { new Among("éi", -1, 7, "", methodObject), new Among("áéi", 0, 6, "", methodObject), new Among("ééi", 0, 5, "", methodObject), new Among("é", -1, 9, "", methodObject), new Among("ké", 3, 4, "", methodObject), new Among("aké", 4, 1, "", methodObject), new Among("eké", 4, 1, "", methodObject), new Among("oké", 4, 1, "", methodObject), new Among("áké", 4, 3, "", methodObject), new Among("éké", 4, 2, "", methodObject), new Among("öké", 4, 1, "", methodObject), new Among("éé", 3, 8, "", methodObject) };
/*      */ 
/*  158 */   private static final Among[] a_10 = { new Among("a", -1, 18, "", methodObject), new Among("ja", 0, 17, "", methodObject), new Among("d", -1, 16, "", methodObject), new Among("ad", 2, 13, "", methodObject), new Among("ed", 2, 13, "", methodObject), new Among("od", 2, 13, "", methodObject), new Among("ád", 2, 14, "", methodObject), new Among("éd", 2, 15, "", methodObject), new Among("öd", 2, 13, "", methodObject), new Among("e", -1, 18, "", methodObject), new Among("je", 9, 17, "", methodObject), new Among("nk", -1, 4, "", methodObject), new Among("unk", 11, 1, "", methodObject), new Among("ánk", 11, 2, "", methodObject), new Among("énk", 11, 3, "", methodObject), new Among("ünk", 11, 1, "", methodObject), new Among("uk", -1, 8, "", methodObject), new Among("juk", 16, 7, "", methodObject), new Among("ájuk", 17, 5, "", methodObject), new Among("ük", -1, 8, "", methodObject), new Among("jük", 19, 7, "", methodObject), new Among("éjük", 20, 6, "", methodObject), new Among("m", -1, 12, "", methodObject), new Among("am", 22, 9, "", methodObject), new Among("em", 22, 9, "", methodObject), new Among("om", 22, 9, "", methodObject), new Among("ám", 22, 10, "", methodObject), new Among("ém", 22, 11, "", methodObject), new Among("o", -1, 18, "", methodObject), new Among("á", -1, 19, "", methodObject), new Among("é", -1, 20, "", methodObject) };
/*      */ 
/*  192 */   private static final Among[] a_11 = { new Among("id", -1, 10, "", methodObject), new Among("aid", 0, 9, "", methodObject), new Among("jaid", 1, 6, "", methodObject), new Among("eid", 0, 9, "", methodObject), new Among("jeid", 3, 6, "", methodObject), new Among("áid", 0, 7, "", methodObject), new Among("éid", 0, 8, "", methodObject), new Among("i", -1, 15, "", methodObject), new Among("ai", 7, 14, "", methodObject), new Among("jai", 8, 11, "", methodObject), new Among("ei", 7, 14, "", methodObject), new Among("jei", 10, 11, "", methodObject), new Among("ái", 7, 12, "", methodObject), new Among("éi", 7, 13, "", methodObject), new Among("itek", -1, 24, "", methodObject), new Among("eitek", 14, 21, "", methodObject), new Among("jeitek", 15, 20, "", methodObject), new Among("éitek", 14, 23, "", methodObject), new Among("ik", -1, 29, "", methodObject), new Among("aik", 18, 26, "", methodObject), new Among("jaik", 19, 25, "", methodObject), new Among("eik", 18, 26, "", methodObject), new Among("jeik", 21, 25, "", methodObject), new Among("áik", 18, 27, "", methodObject), new Among("éik", 18, 28, "", methodObject), new Among("ink", -1, 20, "", methodObject), new Among("aink", 25, 17, "", methodObject), new Among("jaink", 26, 16, "", methodObject), new Among("eink", 25, 17, "", methodObject), new Among("jeink", 28, 16, "", methodObject), new Among("áink", 25, 18, "", methodObject), new Among("éink", 25, 19, "", methodObject), new Among("aitok", -1, 21, "", methodObject), new Among("jaitok", 32, 20, "", methodObject), new Among("áitok", -1, 22, "", methodObject), new Among("im", -1, 5, "", methodObject), new Among("aim", 35, 4, "", methodObject), new Among("jaim", 36, 1, "", methodObject), new Among("eim", 35, 4, "", methodObject), new Among("jeim", 38, 1, "", methodObject), new Among("áim", 35, 2, "", methodObject), new Among("éim", 35, 3, "", methodObject) };
/*      */ 
/*  237 */   private static final char[] g_v = { '\021', 'A', '\020', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\001', '\021', '4', '\016' };
/*      */   private int I_p1;
/*      */ 
/*      */   private void copy_from(HungarianStemmer other)
/*      */   {
/*  242 */     this.I_p1 = other.I_p1;
/*  243 */     super.copy_from(other);
/*      */   }
/*      */ 
/*      */   private boolean r_mark_regions()
/*      */   {
/*  251 */     this.I_p1 = this.limit;
/*      */ 
/*  254 */     int v_1 = this.cursor;
/*      */ 
/*  257 */     if (in_grouping(g_v, 97, 252))
/*      */     {
/*      */       while (true)
/*      */       {
/*  264 */         int v_2 = this.cursor;
/*      */ 
/*  266 */         if (out_grouping(g_v, 97, 252))
/*      */         {
/*  270 */           this.cursor = v_2;
/*  271 */           break;
/*      */         }
/*  273 */         this.cursor = v_2;
/*  274 */         if (this.cursor >= this.limit)
/*      */         {
/*      */           break label151;
/*      */         }
/*  278 */         this.cursor += 1;
/*      */       }
/*      */ 
/*  282 */       int v_3 = this.cursor;
/*      */ 
/*  285 */       if (find_among(a_0, 8) == 0)
/*      */       {
/*  291 */         this.cursor = v_3;
/*      */ 
/*  293 */         if (this.cursor < this.limit)
/*      */         {
/*  297 */           this.cursor += 1;
/*      */         }
/*      */       } else {
/*  300 */         this.I_p1 = this.cursor;
/*  301 */         break label222;
/*      */       }
/*      */     }
/*  303 */     label151: this.cursor = v_1;
/*      */ 
/*  305 */     if (!out_grouping(g_v, 97, 252))
/*      */     {
/*  307 */       return false;
/*      */     }
/*      */ 
/*  313 */     while (!in_grouping(g_v, 97, 252))
/*      */     {
/*  319 */       if (this.cursor >= this.limit)
/*      */       {
/*  321 */         return false;
/*      */       }
/*  323 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  326 */     this.I_p1 = this.cursor;
/*      */ 
/*  328 */     label222: return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R1() {
/*  332 */     if (this.I_p1 > this.cursor)
/*      */     {
/*  334 */       return false;
/*      */     }
/*  336 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_v_ending()
/*      */   {
/*  343 */     this.ket = this.cursor;
/*      */ 
/*  345 */     int among_var = find_among_b(a_1, 2);
/*  346 */     if (among_var == 0)
/*      */     {
/*  348 */       return false;
/*      */     }
/*      */ 
/*  351 */     this.bra = this.cursor;
/*      */ 
/*  353 */     if (!r_R1())
/*      */     {
/*  355 */       return false;
/*      */     }
/*  357 */     switch (among_var) {
/*      */     case 0:
/*  359 */       return false;
/*      */     case 1:
/*  363 */       slice_from("a");
/*  364 */       break;
/*      */     case 2:
/*  368 */       slice_from("e");
/*      */     }
/*      */ 
/*  371 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_double()
/*      */   {
/*  378 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  380 */     if (find_among_b(a_2, 23) == 0)
/*      */     {
/*  382 */       return false;
/*      */     }
/*  384 */     this.cursor = (this.limit - v_1);
/*  385 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_undouble()
/*      */   {
/*  391 */     if (this.cursor <= this.limit_backward)
/*      */     {
/*  393 */       return false;
/*      */     }
/*  395 */     this.cursor -= 1;
/*      */ 
/*  397 */     this.ket = this.cursor;
/*      */ 
/*  400 */     int c = this.cursor - 1;
/*  401 */     if ((this.limit_backward > c) || (c > this.limit))
/*      */     {
/*  403 */       return false;
/*      */     }
/*  405 */     this.cursor = c;
/*      */ 
/*  408 */     this.bra = this.cursor;
/*      */ 
/*  410 */     slice_del();
/*  411 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_instrum()
/*      */   {
/*  418 */     this.ket = this.cursor;
/*      */ 
/*  420 */     int among_var = find_among_b(a_3, 2);
/*  421 */     if (among_var == 0)
/*      */     {
/*  423 */       return false;
/*      */     }
/*      */ 
/*  426 */     this.bra = this.cursor;
/*      */ 
/*  428 */     if (!r_R1())
/*      */     {
/*  430 */       return false;
/*      */     }
/*  432 */     switch (among_var) {
/*      */     case 0:
/*  434 */       return false;
/*      */     case 1:
/*  438 */       if (!r_double())
/*      */       {
/*  440 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 2:
/*  446 */       if (!r_double())
/*      */       {
/*  448 */         return false;
/*      */       }
/*      */       break;
/*      */     }
/*      */ 
/*  453 */     slice_del();
/*      */ 
/*  455 */     if (!r_undouble())
/*      */     {
/*  457 */       return false;
/*      */     }
/*  459 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_case()
/*      */   {
/*  465 */     this.ket = this.cursor;
/*      */ 
/*  467 */     if (find_among_b(a_4, 44) == 0)
/*      */     {
/*  469 */       return false;
/*      */     }
/*      */ 
/*  472 */     this.bra = this.cursor;
/*      */ 
/*  474 */     if (!r_R1())
/*      */     {
/*  476 */       return false;
/*      */     }
/*      */ 
/*  479 */     slice_del();
/*      */ 
/*  481 */     if (!r_v_ending())
/*      */     {
/*  483 */       return false;
/*      */     }
/*  485 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_case_special()
/*      */   {
/*  492 */     this.ket = this.cursor;
/*      */ 
/*  494 */     int among_var = find_among_b(a_5, 3);
/*  495 */     if (among_var == 0)
/*      */     {
/*  497 */       return false;
/*      */     }
/*      */ 
/*  500 */     this.bra = this.cursor;
/*      */ 
/*  502 */     if (!r_R1())
/*      */     {
/*  504 */       return false;
/*      */     }
/*  506 */     switch (among_var) {
/*      */     case 0:
/*  508 */       return false;
/*      */     case 1:
/*  512 */       slice_from("e");
/*  513 */       break;
/*      */     case 2:
/*  517 */       slice_from("a");
/*  518 */       break;
/*      */     case 3:
/*  522 */       slice_from("a");
/*      */     }
/*      */ 
/*  525 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_case_other()
/*      */   {
/*  532 */     this.ket = this.cursor;
/*      */ 
/*  534 */     int among_var = find_among_b(a_6, 6);
/*  535 */     if (among_var == 0)
/*      */     {
/*  537 */       return false;
/*      */     }
/*      */ 
/*  540 */     this.bra = this.cursor;
/*      */ 
/*  542 */     if (!r_R1())
/*      */     {
/*  544 */       return false;
/*      */     }
/*  546 */     switch (among_var) {
/*      */     case 0:
/*  548 */       return false;
/*      */     case 1:
/*  552 */       slice_del();
/*  553 */       break;
/*      */     case 2:
/*  557 */       slice_del();
/*  558 */       break;
/*      */     case 3:
/*  562 */       slice_from("a");
/*  563 */       break;
/*      */     case 4:
/*  567 */       slice_from("e");
/*      */     }
/*      */ 
/*  570 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_factive()
/*      */   {
/*  577 */     this.ket = this.cursor;
/*      */ 
/*  579 */     int among_var = find_among_b(a_7, 2);
/*  580 */     if (among_var == 0)
/*      */     {
/*  582 */       return false;
/*      */     }
/*      */ 
/*  585 */     this.bra = this.cursor;
/*      */ 
/*  587 */     if (!r_R1())
/*      */     {
/*  589 */       return false;
/*      */     }
/*  591 */     switch (among_var) {
/*      */     case 0:
/*  593 */       return false;
/*      */     case 1:
/*  597 */       if (!r_double())
/*      */       {
/*  599 */         return false;
/*      */       }
/*      */ 
/*      */       break;
/*      */     case 2:
/*  605 */       if (!r_double())
/*      */       {
/*  607 */         return false;
/*      */       }
/*      */       break;
/*      */     }
/*      */ 
/*  612 */     slice_del();
/*      */ 
/*  614 */     if (!r_undouble())
/*      */     {
/*  616 */       return false;
/*      */     }
/*  618 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_plural()
/*      */   {
/*  625 */     this.ket = this.cursor;
/*      */ 
/*  627 */     int among_var = find_among_b(a_8, 7);
/*  628 */     if (among_var == 0)
/*      */     {
/*  630 */       return false;
/*      */     }
/*      */ 
/*  633 */     this.bra = this.cursor;
/*      */ 
/*  635 */     if (!r_R1())
/*      */     {
/*  637 */       return false;
/*      */     }
/*  639 */     switch (among_var) {
/*      */     case 0:
/*  641 */       return false;
/*      */     case 1:
/*  645 */       slice_from("a");
/*  646 */       break;
/*      */     case 2:
/*  650 */       slice_from("e");
/*  651 */       break;
/*      */     case 3:
/*  655 */       slice_del();
/*  656 */       break;
/*      */     case 4:
/*  660 */       slice_del();
/*  661 */       break;
/*      */     case 5:
/*  665 */       slice_del();
/*  666 */       break;
/*      */     case 6:
/*  670 */       slice_del();
/*  671 */       break;
/*      */     case 7:
/*  675 */       slice_del();
/*      */     }
/*      */ 
/*  678 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_owned()
/*      */   {
/*  685 */     this.ket = this.cursor;
/*      */ 
/*  687 */     int among_var = find_among_b(a_9, 12);
/*  688 */     if (among_var == 0)
/*      */     {
/*  690 */       return false;
/*      */     }
/*      */ 
/*  693 */     this.bra = this.cursor;
/*      */ 
/*  695 */     if (!r_R1())
/*      */     {
/*  697 */       return false;
/*      */     }
/*  699 */     switch (among_var) {
/*      */     case 0:
/*  701 */       return false;
/*      */     case 1:
/*  705 */       slice_del();
/*  706 */       break;
/*      */     case 2:
/*  710 */       slice_from("e");
/*  711 */       break;
/*      */     case 3:
/*  715 */       slice_from("a");
/*  716 */       break;
/*      */     case 4:
/*  720 */       slice_del();
/*  721 */       break;
/*      */     case 5:
/*  725 */       slice_from("e");
/*  726 */       break;
/*      */     case 6:
/*  730 */       slice_from("a");
/*  731 */       break;
/*      */     case 7:
/*  735 */       slice_del();
/*  736 */       break;
/*      */     case 8:
/*  740 */       slice_from("e");
/*  741 */       break;
/*      */     case 9:
/*  745 */       slice_del();
/*      */     }
/*      */ 
/*  748 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_sing_owner()
/*      */   {
/*  755 */     this.ket = this.cursor;
/*      */ 
/*  757 */     int among_var = find_among_b(a_10, 31);
/*  758 */     if (among_var == 0)
/*      */     {
/*  760 */       return false;
/*      */     }
/*      */ 
/*  763 */     this.bra = this.cursor;
/*      */ 
/*  765 */     if (!r_R1())
/*      */     {
/*  767 */       return false;
/*      */     }
/*  769 */     switch (among_var) {
/*      */     case 0:
/*  771 */       return false;
/*      */     case 1:
/*  775 */       slice_del();
/*  776 */       break;
/*      */     case 2:
/*  780 */       slice_from("a");
/*  781 */       break;
/*      */     case 3:
/*  785 */       slice_from("e");
/*  786 */       break;
/*      */     case 4:
/*  790 */       slice_del();
/*  791 */       break;
/*      */     case 5:
/*  795 */       slice_from("a");
/*  796 */       break;
/*      */     case 6:
/*  800 */       slice_from("e");
/*  801 */       break;
/*      */     case 7:
/*  805 */       slice_del();
/*  806 */       break;
/*      */     case 8:
/*  810 */       slice_del();
/*  811 */       break;
/*      */     case 9:
/*  815 */       slice_del();
/*  816 */       break;
/*      */     case 10:
/*  820 */       slice_from("a");
/*  821 */       break;
/*      */     case 11:
/*  825 */       slice_from("e");
/*  826 */       break;
/*      */     case 12:
/*  830 */       slice_del();
/*  831 */       break;
/*      */     case 13:
/*  835 */       slice_del();
/*  836 */       break;
/*      */     case 14:
/*  840 */       slice_from("a");
/*  841 */       break;
/*      */     case 15:
/*  845 */       slice_from("e");
/*  846 */       break;
/*      */     case 16:
/*  850 */       slice_del();
/*  851 */       break;
/*      */     case 17:
/*  855 */       slice_del();
/*  856 */       break;
/*      */     case 18:
/*  860 */       slice_del();
/*  861 */       break;
/*      */     case 19:
/*  865 */       slice_from("a");
/*  866 */       break;
/*      */     case 20:
/*  870 */       slice_from("e");
/*      */     }
/*      */ 
/*  873 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_plur_owner()
/*      */   {
/*  880 */     this.ket = this.cursor;
/*      */ 
/*  882 */     int among_var = find_among_b(a_11, 42);
/*  883 */     if (among_var == 0)
/*      */     {
/*  885 */       return false;
/*      */     }
/*      */ 
/*  888 */     this.bra = this.cursor;
/*      */ 
/*  890 */     if (!r_R1())
/*      */     {
/*  892 */       return false;
/*      */     }
/*  894 */     switch (among_var) {
/*      */     case 0:
/*  896 */       return false;
/*      */     case 1:
/*  900 */       slice_del();
/*  901 */       break;
/*      */     case 2:
/*  905 */       slice_from("a");
/*  906 */       break;
/*      */     case 3:
/*  910 */       slice_from("e");
/*  911 */       break;
/*      */     case 4:
/*  915 */       slice_del();
/*  916 */       break;
/*      */     case 5:
/*  920 */       slice_del();
/*  921 */       break;
/*      */     case 6:
/*  925 */       slice_del();
/*  926 */       break;
/*      */     case 7:
/*  930 */       slice_from("a");
/*  931 */       break;
/*      */     case 8:
/*  935 */       slice_from("e");
/*  936 */       break;
/*      */     case 9:
/*  940 */       slice_del();
/*  941 */       break;
/*      */     case 10:
/*  945 */       slice_del();
/*  946 */       break;
/*      */     case 11:
/*  950 */       slice_del();
/*  951 */       break;
/*      */     case 12:
/*  955 */       slice_from("a");
/*  956 */       break;
/*      */     case 13:
/*  960 */       slice_from("e");
/*  961 */       break;
/*      */     case 14:
/*  965 */       slice_del();
/*  966 */       break;
/*      */     case 15:
/*  970 */       slice_del();
/*  971 */       break;
/*      */     case 16:
/*  975 */       slice_del();
/*  976 */       break;
/*      */     case 17:
/*  980 */       slice_del();
/*  981 */       break;
/*      */     case 18:
/*  985 */       slice_from("a");
/*  986 */       break;
/*      */     case 19:
/*  990 */       slice_from("e");
/*  991 */       break;
/*      */     case 20:
/*  995 */       slice_del();
/*  996 */       break;
/*      */     case 21:
/* 1000 */       slice_del();
/* 1001 */       break;
/*      */     case 22:
/* 1005 */       slice_from("a");
/* 1006 */       break;
/*      */     case 23:
/* 1010 */       slice_from("e");
/* 1011 */       break;
/*      */     case 24:
/* 1015 */       slice_del();
/* 1016 */       break;
/*      */     case 25:
/* 1020 */       slice_del();
/* 1021 */       break;
/*      */     case 26:
/* 1025 */       slice_del();
/* 1026 */       break;
/*      */     case 27:
/* 1030 */       slice_from("a");
/* 1031 */       break;
/*      */     case 28:
/* 1035 */       slice_from("e");
/* 1036 */       break;
/*      */     case 29:
/* 1040 */       slice_del();
/*      */     }
/*      */ 
/* 1043 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean stem()
/*      */   {
/* 1060 */     int v_1 = this.cursor;
/*      */ 
/* 1063 */     if (!r_mark_regions());
/* 1068 */     this.cursor = v_1;
/*      */ 
/* 1070 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 1073 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1076 */     if (!r_instrum());
/* 1081 */     this.cursor = (this.limit - v_2);
/*      */ 
/* 1083 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1086 */     if (!r_case());
/* 1091 */     this.cursor = (this.limit - v_3);
/*      */ 
/* 1093 */     int v_4 = this.limit - this.cursor;
/*      */ 
/* 1096 */     if (!r_case_special());
/* 1101 */     this.cursor = (this.limit - v_4);
/*      */ 
/* 1103 */     int v_5 = this.limit - this.cursor;
/*      */ 
/* 1106 */     if (!r_case_other());
/* 1111 */     this.cursor = (this.limit - v_5);
/*      */ 
/* 1113 */     int v_6 = this.limit - this.cursor;
/*      */ 
/* 1116 */     if (!r_factive());
/* 1121 */     this.cursor = (this.limit - v_6);
/*      */ 
/* 1123 */     int v_7 = this.limit - this.cursor;
/*      */ 
/* 1126 */     if (!r_owned());
/* 1131 */     this.cursor = (this.limit - v_7);
/*      */ 
/* 1133 */     int v_8 = this.limit - this.cursor;
/*      */ 
/* 1136 */     if (!r_sing_owner());
/* 1141 */     this.cursor = (this.limit - v_8);
/*      */ 
/* 1143 */     int v_9 = this.limit - this.cursor;
/*      */ 
/* 1146 */     if (!r_plur_owner());
/* 1151 */     this.cursor = (this.limit - v_9);
/*      */ 
/* 1153 */     int v_10 = this.limit - this.cursor;
/*      */ 
/* 1156 */     if (!r_plural());
/* 1161 */     this.cursor = (this.limit - v_10);
/* 1162 */     this.cursor = this.limit_backward; return true;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1167 */     return o instanceof HungarianStemmer;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1172 */     return HungarianStemmer.class.getName().hashCode();
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.ext.HungarianStemmer
 * JD-Core Version:    0.6.2
 */