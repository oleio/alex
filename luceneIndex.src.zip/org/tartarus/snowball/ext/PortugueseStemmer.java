/*      */ package org.tartarus.snowball.ext;
/*      */ 
/*      */ import org.tartarus.snowball.Among;
/*      */ import org.tartarus.snowball.SnowballProgram;
/*      */ 
/*      */ public class PortugueseStemmer extends SnowballProgram
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   17 */   private static final PortugueseStemmer methodObject = new PortugueseStemmer();
/*      */ 
/*   19 */   private static final Among[] a_0 = { new Among("", -1, 3, "", methodObject), new Among("ã", 0, 1, "", methodObject), new Among("õ", 0, 2, "", methodObject) };
/*      */ 
/*   25 */   private static final Among[] a_1 = { new Among("", -1, 3, "", methodObject), new Among("a~", 0, 1, "", methodObject), new Among("o~", 0, 2, "", methodObject) };
/*      */ 
/*   31 */   private static final Among[] a_2 = { new Among("ic", -1, -1, "", methodObject), new Among("ad", -1, -1, "", methodObject), new Among("os", -1, -1, "", methodObject), new Among("iv", -1, 1, "", methodObject) };
/*      */ 
/*   38 */   private static final Among[] a_3 = { new Among("ante", -1, 1, "", methodObject), new Among("avel", -1, 1, "", methodObject), new Among("ível", -1, 1, "", methodObject) };
/*      */ 
/*   44 */   private static final Among[] a_4 = { new Among("ic", -1, 1, "", methodObject), new Among("abil", -1, 1, "", methodObject), new Among("iv", -1, 1, "", methodObject) };
/*      */ 
/*   50 */   private static final Among[] a_5 = { new Among("ica", -1, 1, "", methodObject), new Among("ância", -1, 1, "", methodObject), new Among("ência", -1, 4, "", methodObject), new Among("ira", -1, 9, "", methodObject), new Among("adora", -1, 1, "", methodObject), new Among("osa", -1, 1, "", methodObject), new Among("ista", -1, 1, "", methodObject), new Among("iva", -1, 8, "", methodObject), new Among("eza", -1, 1, "", methodObject), new Among("logía", -1, 2, "", methodObject), new Among("idade", -1, 7, "", methodObject), new Among("ante", -1, 1, "", methodObject), new Among("mente", -1, 6, "", methodObject), new Among("amente", 12, 5, "", methodObject), new Among("ável", -1, 1, "", methodObject), new Among("ível", -1, 1, "", methodObject), new Among("ución", -1, 3, "", methodObject), new Among("ico", -1, 1, "", methodObject), new Among("ismo", -1, 1, "", methodObject), new Among("oso", -1, 1, "", methodObject), new Among("amento", -1, 1, "", methodObject), new Among("imento", -1, 1, "", methodObject), new Among("ivo", -1, 8, "", methodObject), new Among("aça~o", -1, 1, "", methodObject), new Among("ador", -1, 1, "", methodObject), new Among("icas", -1, 1, "", methodObject), new Among("ências", -1, 4, "", methodObject), new Among("iras", -1, 9, "", methodObject), new Among("adoras", -1, 1, "", methodObject), new Among("osas", -1, 1, "", methodObject), new Among("istas", -1, 1, "", methodObject), new Among("ivas", -1, 8, "", methodObject), new Among("ezas", -1, 1, "", methodObject), new Among("logías", -1, 2, "", methodObject), new Among("idades", -1, 7, "", methodObject), new Among("uciones", -1, 3, "", methodObject), new Among("adores", -1, 1, "", methodObject), new Among("antes", -1, 1, "", methodObject), new Among("aço~es", -1, 1, "", methodObject), new Among("icos", -1, 1, "", methodObject), new Among("ismos", -1, 1, "", methodObject), new Among("osos", -1, 1, "", methodObject), new Among("amentos", -1, 1, "", methodObject), new Among("imentos", -1, 1, "", methodObject), new Among("ivos", -1, 8, "", methodObject) };
/*      */ 
/*   98 */   private static final Among[] a_6 = { new Among("ada", -1, 1, "", methodObject), new Among("ida", -1, 1, "", methodObject), new Among("ia", -1, 1, "", methodObject), new Among("aria", 2, 1, "", methodObject), new Among("eria", 2, 1, "", methodObject), new Among("iria", 2, 1, "", methodObject), new Among("ara", -1, 1, "", methodObject), new Among("era", -1, 1, "", methodObject), new Among("ira", -1, 1, "", methodObject), new Among("ava", -1, 1, "", methodObject), new Among("asse", -1, 1, "", methodObject), new Among("esse", -1, 1, "", methodObject), new Among("isse", -1, 1, "", methodObject), new Among("aste", -1, 1, "", methodObject), new Among("este", -1, 1, "", methodObject), new Among("iste", -1, 1, "", methodObject), new Among("ei", -1, 1, "", methodObject), new Among("arei", 16, 1, "", methodObject), new Among("erei", 16, 1, "", methodObject), new Among("irei", 16, 1, "", methodObject), new Among("am", -1, 1, "", methodObject), new Among("iam", 20, 1, "", methodObject), new Among("ariam", 21, 1, "", methodObject), new Among("eriam", 21, 1, "", methodObject), new Among("iriam", 21, 1, "", methodObject), new Among("aram", 20, 1, "", methodObject), new Among("eram", 20, 1, "", methodObject), new Among("iram", 20, 1, "", methodObject), new Among("avam", 20, 1, "", methodObject), new Among("em", -1, 1, "", methodObject), new Among("arem", 29, 1, "", methodObject), new Among("erem", 29, 1, "", methodObject), new Among("irem", 29, 1, "", methodObject), new Among("assem", 29, 1, "", methodObject), new Among("essem", 29, 1, "", methodObject), new Among("issem", 29, 1, "", methodObject), new Among("ado", -1, 1, "", methodObject), new Among("ido", -1, 1, "", methodObject), new Among("ando", -1, 1, "", methodObject), new Among("endo", -1, 1, "", methodObject), new Among("indo", -1, 1, "", methodObject), new Among("ara~o", -1, 1, "", methodObject), new Among("era~o", -1, 1, "", methodObject), new Among("ira~o", -1, 1, "", methodObject), new Among("ar", -1, 1, "", methodObject), new Among("er", -1, 1, "", methodObject), new Among("ir", -1, 1, "", methodObject), new Among("as", -1, 1, "", methodObject), new Among("adas", 47, 1, "", methodObject), new Among("idas", 47, 1, "", methodObject), new Among("ias", 47, 1, "", methodObject), new Among("arias", 50, 1, "", methodObject), new Among("erias", 50, 1, "", methodObject), new Among("irias", 50, 1, "", methodObject), new Among("aras", 47, 1, "", methodObject), new Among("eras", 47, 1, "", methodObject), new Among("iras", 47, 1, "", methodObject), new Among("avas", 47, 1, "", methodObject), new Among("es", -1, 1, "", methodObject), new Among("ardes", 58, 1, "", methodObject), new Among("erdes", 58, 1, "", methodObject), new Among("irdes", 58, 1, "", methodObject), new Among("ares", 58, 1, "", methodObject), new Among("eres", 58, 1, "", methodObject), new Among("ires", 58, 1, "", methodObject), new Among("asses", 58, 1, "", methodObject), new Among("esses", 58, 1, "", methodObject), new Among("isses", 58, 1, "", methodObject), new Among("astes", 58, 1, "", methodObject), new Among("estes", 58, 1, "", methodObject), new Among("istes", 58, 1, "", methodObject), new Among("is", -1, 1, "", methodObject), new Among("ais", 71, 1, "", methodObject), new Among("eis", 71, 1, "", methodObject), new Among("areis", 73, 1, "", methodObject), new Among("ereis", 73, 1, "", methodObject), new Among("ireis", 73, 1, "", methodObject), new Among("áreis", 73, 1, "", methodObject), new Among("éreis", 73, 1, "", methodObject), new Among("íreis", 73, 1, "", methodObject), new Among("ásseis", 73, 1, "", methodObject), new Among("ésseis", 73, 1, "", methodObject), new Among("ísseis", 73, 1, "", methodObject), new Among("áveis", 73, 1, "", methodObject), new Among("íeis", 73, 1, "", methodObject), new Among("aríeis", 84, 1, "", methodObject), new Among("eríeis", 84, 1, "", methodObject), new Among("iríeis", 84, 1, "", methodObject), new Among("ados", -1, 1, "", methodObject), new Among("idos", -1, 1, "", methodObject), new Among("amos", -1, 1, "", methodObject), new Among("áramos", 90, 1, "", methodObject), new Among("éramos", 90, 1, "", methodObject), new Among("íramos", 90, 1, "", methodObject), new Among("ávamos", 90, 1, "", methodObject), new Among("íamos", 90, 1, "", methodObject), new Among("aríamos", 95, 1, "", methodObject), new Among("eríamos", 95, 1, "", methodObject), new Among("iríamos", 95, 1, "", methodObject), new Among("emos", -1, 1, "", methodObject), new Among("aremos", 99, 1, "", methodObject), new Among("eremos", 99, 1, "", methodObject), new Among("iremos", 99, 1, "", methodObject), new Among("ássemos", 99, 1, "", methodObject), new Among("êssemos", 99, 1, "", methodObject), new Among("íssemos", 99, 1, "", methodObject), new Among("imos", -1, 1, "", methodObject), new Among("armos", -1, 1, "", methodObject), new Among("ermos", -1, 1, "", methodObject), new Among("irmos", -1, 1, "", methodObject), new Among("ámos", -1, 1, "", methodObject), new Among("arás", -1, 1, "", methodObject), new Among("erás", -1, 1, "", methodObject), new Among("irás", -1, 1, "", methodObject), new Among("eu", -1, 1, "", methodObject), new Among("iu", -1, 1, "", methodObject), new Among("ou", -1, 1, "", methodObject), new Among("ará", -1, 1, "", methodObject), new Among("erá", -1, 1, "", methodObject), new Among("irá", -1, 1, "", methodObject) };
/*      */ 
/*  221 */   private static final Among[] a_7 = { new Among("a", -1, 1, "", methodObject), new Among("i", -1, 1, "", methodObject), new Among("o", -1, 1, "", methodObject), new Among("os", -1, 1, "", methodObject), new Among("á", -1, 1, "", methodObject), new Among("í", -1, 1, "", methodObject), new Among("ó", -1, 1, "", methodObject) };
/*      */ 
/*  231 */   private static final Among[] a_8 = { new Among("e", -1, 1, "", methodObject), new Among("ç", -1, 2, "", methodObject), new Among("é", -1, 1, "", methodObject), new Among("ê", -1, 1, "", methodObject) };
/*      */ 
/*  238 */   private static final char[] g_v = { '\021', 'A', '\020', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\003', '\023', '\f', '\002' };
/*      */   private int I_p2;
/*      */   private int I_p1;
/*      */   private int I_pV;
/*      */ 
/*      */   private void copy_from(PortugueseStemmer other)
/*      */   {
/*  245 */     this.I_p2 = other.I_p2;
/*  246 */     this.I_p1 = other.I_p1;
/*  247 */     this.I_pV = other.I_pV;
/*  248 */     super.copy_from(other);
/*      */   }
/*      */ 
/*      */   private boolean r_prelude()
/*      */   {
/*      */     int v_1;
/*      */     while (true)
/*      */     {
/*  257 */       v_1 = this.cursor;
/*      */ 
/*  261 */       this.bra = this.cursor;
/*      */ 
/*  263 */       int among_var = find_among(a_0, 3);
/*  264 */       if (among_var == 0)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  269 */       this.ket = this.cursor;
/*  270 */       switch (among_var) {
/*      */       case 0:
/*  272 */         break;
/*      */       case 1:
/*  276 */         slice_from("a~");
/*  277 */         break;
/*      */       case 2:
/*  281 */         slice_from("o~");
/*  282 */         break;
/*      */       case 3:
/*  286 */         if (this.cursor >= this.limit)
/*      */         {
/*      */           break label116;
/*      */         }
/*  290 */         this.cursor += 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  295 */     label116: this.cursor = v_1;
/*      */ 
/*  298 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_regions()
/*      */   {
/*  308 */     this.I_pV = this.limit;
/*  309 */     this.I_p1 = this.limit;
/*  310 */     this.I_p2 = this.limit;
/*      */ 
/*  312 */     int v_1 = this.cursor;
/*      */ 
/*  317 */     int v_2 = this.cursor;
/*      */ 
/*  320 */     if (in_grouping(g_v, 97, 250))
/*      */     {
/*  326 */       int v_3 = this.cursor;
/*      */ 
/*  329 */       if (out_grouping(g_v, 97, 250))
/*      */       {
/*      */         while (true)
/*      */         {
/*  337 */           if (in_grouping(g_v, 97, 250))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  343 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  347 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */ 
/*  351 */       this.cursor = v_3;
/*      */ 
/*  353 */       if (in_grouping(g_v, 97, 250))
/*      */       {
/*      */         while (true)
/*      */         {
/*  361 */           if (out_grouping(g_v, 97, 250))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  367 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  371 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  376 */     this.cursor = v_2;
/*      */ 
/*  378 */     if (out_grouping(g_v, 97, 250))
/*      */     {
/*  384 */       int v_6 = this.cursor;
/*      */ 
/*  387 */       if (out_grouping(g_v, 97, 250))
/*      */       {
/*      */         while (true)
/*      */         {
/*  395 */           if (in_grouping(g_v, 97, 250))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  401 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  405 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */ 
/*  409 */       this.cursor = v_6;
/*      */ 
/*  411 */       if (in_grouping(g_v, 97, 250))
/*      */       {
/*  416 */         if (this.cursor < this.limit)
/*      */         {
/*  420 */           this.cursor += 1;
/*      */ 
/*  424 */           label319: this.I_pV = this.cursor;
/*      */         }
/*      */       }
/*      */     }
/*  426 */     this.cursor = v_1;
/*      */ 
/*  428 */     int v_8 = this.cursor;
/*      */ 
/*  435 */     while (!in_grouping(g_v, 97, 250))
/*      */     {
/*  441 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  445 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  451 */     while (!out_grouping(g_v, 97, 250))
/*      */     {
/*  457 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  461 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  464 */     this.I_p1 = this.cursor;
/*      */ 
/*  469 */     while (!in_grouping(g_v, 97, 250))
/*      */     {
/*  475 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  479 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  485 */     while (!out_grouping(g_v, 97, 250))
/*      */     {
/*  491 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  495 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  498 */     this.I_p2 = this.cursor;
/*      */ 
/*  500 */     label522: this.cursor = v_8;
/*  501 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_postlude()
/*      */   {
/*      */     int v_1;
/*      */     while (true)
/*      */     {
/*  510 */       v_1 = this.cursor;
/*      */ 
/*  514 */       this.bra = this.cursor;
/*      */ 
/*  516 */       int among_var = find_among(a_1, 3);
/*  517 */       if (among_var == 0)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  522 */       this.ket = this.cursor;
/*  523 */       switch (among_var) {
/*      */       case 0:
/*  525 */         break;
/*      */       case 1:
/*  529 */         slice_from("ã");
/*  530 */         break;
/*      */       case 2:
/*  534 */         slice_from("õ");
/*  535 */         break;
/*      */       case 3:
/*  539 */         if (this.cursor >= this.limit)
/*      */         {
/*      */           break label116;
/*      */         }
/*  543 */         this.cursor += 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  548 */     label116: this.cursor = v_1;
/*      */ 
/*  551 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_RV() {
/*  555 */     if (this.I_pV > this.cursor)
/*      */     {
/*  557 */       return false;
/*      */     }
/*  559 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R1() {
/*  563 */     if (this.I_p1 > this.cursor)
/*      */     {
/*  565 */       return false;
/*      */     }
/*  567 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R2() {
/*  571 */     if (this.I_p2 > this.cursor)
/*      */     {
/*  573 */       return false;
/*      */     }
/*  575 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_standard_suffix()
/*      */   {
/*  586 */     this.ket = this.cursor;
/*      */ 
/*  588 */     int among_var = find_among_b(a_5, 45);
/*  589 */     if (among_var == 0)
/*      */     {
/*  591 */       return false;
/*      */     }
/*      */ 
/*  594 */     this.bra = this.cursor;
/*  595 */     switch (among_var) {
/*      */     case 0:
/*  597 */       return false;
/*      */     case 1:
/*  601 */       if (!r_R2())
/*      */       {
/*  603 */         return false;
/*      */       }
/*      */ 
/*  606 */       slice_del();
/*  607 */       break;
/*      */     case 2:
/*  611 */       if (!r_R2())
/*      */       {
/*  613 */         return false;
/*      */       }
/*      */ 
/*  616 */       slice_from("log");
/*  617 */       break;
/*      */     case 3:
/*  621 */       if (!r_R2())
/*      */       {
/*  623 */         return false;
/*      */       }
/*      */ 
/*  626 */       slice_from("u");
/*  627 */       break;
/*      */     case 4:
/*  631 */       if (!r_R2())
/*      */       {
/*  633 */         return false;
/*      */       }
/*      */ 
/*  636 */       slice_from("ente");
/*  637 */       break;
/*      */     case 5:
/*  641 */       if (!r_R1())
/*      */       {
/*  643 */         return false;
/*      */       }
/*      */ 
/*  646 */       slice_del();
/*      */ 
/*  648 */       int v_1 = this.limit - this.cursor;
/*      */ 
/*  652 */       this.ket = this.cursor;
/*      */ 
/*  654 */       among_var = find_among_b(a_2, 4);
/*  655 */       if (among_var == 0)
/*      */       {
/*  657 */         this.cursor = (this.limit - v_1);
/*      */       }
/*      */       else
/*      */       {
/*  661 */         this.bra = this.cursor;
/*      */ 
/*  663 */         if (!r_R2())
/*      */         {
/*  665 */           this.cursor = (this.limit - v_1);
/*      */         }
/*      */         else
/*      */         {
/*  669 */           slice_del();
/*  670 */           switch (among_var) {
/*      */           case 0:
/*  672 */             this.cursor = (this.limit - v_1);
/*  673 */             break;
/*      */           case 1:
/*  677 */             this.ket = this.cursor;
/*      */ 
/*  679 */             if (!eq_s_b(2, "at"))
/*      */             {
/*  681 */               this.cursor = (this.limit - v_1);
/*      */             }
/*      */             else
/*      */             {
/*  685 */               this.bra = this.cursor;
/*      */ 
/*  687 */               if (!r_R2())
/*      */               {
/*  689 */                 this.cursor = (this.limit - v_1);
/*      */               }
/*      */               else
/*      */               {
/*  693 */                 slice_del(); }  } break;
/*      */           }
/*      */         }
/*      */       }
/*  697 */       break;
/*      */     case 6:
/*  701 */       if (!r_R2())
/*      */       {
/*  703 */         return false;
/*      */       }
/*      */ 
/*  706 */       slice_del();
/*      */ 
/*  708 */       int v_2 = this.limit - this.cursor;
/*      */ 
/*  712 */       this.ket = this.cursor;
/*      */ 
/*  714 */       among_var = find_among_b(a_3, 3);
/*  715 */       if (among_var == 0)
/*      */       {
/*  717 */         this.cursor = (this.limit - v_2);
/*      */       }
/*      */       else
/*      */       {
/*  721 */         this.bra = this.cursor;
/*  722 */         switch (among_var) {
/*      */         case 0:
/*  724 */           this.cursor = (this.limit - v_2);
/*  725 */           break;
/*      */         case 1:
/*  729 */           if (!r_R2())
/*      */           {
/*  731 */             this.cursor = (this.limit - v_2);
/*      */           }
/*      */           else
/*      */           {
/*  735 */             slice_del();
/*      */           }break;
/*      */         }
/*      */       }
/*  739 */       break;
/*      */     case 7:
/*  743 */       if (!r_R2())
/*      */       {
/*  745 */         return false;
/*      */       }
/*      */ 
/*  748 */       slice_del();
/*      */ 
/*  750 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  754 */       this.ket = this.cursor;
/*      */ 
/*  756 */       among_var = find_among_b(a_4, 3);
/*  757 */       if (among_var == 0)
/*      */       {
/*  759 */         this.cursor = (this.limit - v_3);
/*      */       }
/*      */       else
/*      */       {
/*  763 */         this.bra = this.cursor;
/*  764 */         switch (among_var) {
/*      */         case 0:
/*  766 */           this.cursor = (this.limit - v_3);
/*  767 */           break;
/*      */         case 1:
/*  771 */           if (!r_R2())
/*      */           {
/*  773 */             this.cursor = (this.limit - v_3);
/*      */           }
/*      */           else
/*      */           {
/*  777 */             slice_del();
/*      */           }break;
/*      */         }
/*      */       }
/*  781 */       break;
/*      */     case 8:
/*  785 */       if (!r_R2())
/*      */       {
/*  787 */         return false;
/*      */       }
/*      */ 
/*  790 */       slice_del();
/*      */ 
/*  792 */       int v_4 = this.limit - this.cursor;
/*      */ 
/*  796 */       this.ket = this.cursor;
/*      */ 
/*  798 */       if (!eq_s_b(2, "at"))
/*      */       {
/*  800 */         this.cursor = (this.limit - v_4);
/*      */       }
/*      */       else
/*      */       {
/*  804 */         this.bra = this.cursor;
/*      */ 
/*  806 */         if (!r_R2())
/*      */         {
/*  808 */           this.cursor = (this.limit - v_4);
/*      */         }
/*      */         else
/*      */         {
/*  812 */           slice_del();
/*      */         }
/*      */       }
/*  814 */       break;
/*      */     case 9:
/*  818 */       if (!r_RV())
/*      */       {
/*  820 */         return false;
/*      */       }
/*      */ 
/*  823 */       if (!eq_s_b(1, "e"))
/*      */       {
/*  825 */         return false;
/*      */       }
/*      */ 
/*  828 */       slice_from("ir");
/*      */     }
/*      */ 
/*  831 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_verb_suffix()
/*      */   {
/*  839 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  841 */     if (this.cursor < this.I_pV)
/*      */     {
/*  843 */       return false;
/*      */     }
/*  845 */     this.cursor = this.I_pV;
/*  846 */     int v_2 = this.limit_backward;
/*  847 */     this.limit_backward = this.cursor;
/*  848 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  851 */     this.ket = this.cursor;
/*      */ 
/*  853 */     int among_var = find_among_b(a_6, 120);
/*  854 */     if (among_var == 0)
/*      */     {
/*  856 */       this.limit_backward = v_2;
/*  857 */       return false;
/*      */     }
/*      */ 
/*  860 */     this.bra = this.cursor;
/*  861 */     switch (among_var) {
/*      */     case 0:
/*  863 */       this.limit_backward = v_2;
/*  864 */       return false;
/*      */     case 1:
/*  868 */       slice_del();
/*      */     }
/*      */ 
/*  871 */     this.limit_backward = v_2;
/*  872 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_residual_suffix()
/*      */   {
/*  879 */     this.ket = this.cursor;
/*      */ 
/*  881 */     int among_var = find_among_b(a_7, 7);
/*  882 */     if (among_var == 0)
/*      */     {
/*  884 */       return false;
/*      */     }
/*      */ 
/*  887 */     this.bra = this.cursor;
/*  888 */     switch (among_var) {
/*      */     case 0:
/*  890 */       return false;
/*      */     case 1:
/*  894 */       if (!r_RV())
/*      */       {
/*  896 */         return false;
/*      */       }
/*      */ 
/*  899 */       slice_del();
/*      */     }
/*      */ 
/*  902 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_residual_form()
/*      */   {
/*  912 */     this.ket = this.cursor;
/*      */ 
/*  914 */     int among_var = find_among_b(a_8, 4);
/*  915 */     if (among_var == 0)
/*      */     {
/*  917 */       return false;
/*      */     }
/*      */ 
/*  920 */     this.bra = this.cursor;
/*  921 */     switch (among_var) {
/*      */     case 0:
/*  923 */       return false;
/*      */     case 1:
/*  927 */       if (!r_RV())
/*      */       {
/*  929 */         return false;
/*      */       }
/*      */ 
/*  932 */       slice_del();
/*      */ 
/*  934 */       this.ket = this.cursor;
/*      */ 
/*  937 */       int v_1 = this.limit - this.cursor;
/*      */ 
/*  941 */       if (eq_s_b(1, "u"))
/*      */       {
/*  946 */         this.bra = this.cursor;
/*      */ 
/*  948 */         int v_2 = this.limit - this.cursor;
/*      */ 
/*  950 */         if (eq_s_b(1, "g"))
/*      */         {
/*  954 */           this.cursor = (this.limit - v_2);
/*  955 */           break label214;
/*      */         }
/*      */       }
/*  957 */       this.cursor = (this.limit - v_1);
/*      */ 
/*  960 */       if (!eq_s_b(1, "i"))
/*      */       {
/*  962 */         return false;
/*      */       }
/*      */ 
/*  965 */       this.bra = this.cursor;
/*      */ 
/*  967 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  969 */       if (!eq_s_b(1, "c"))
/*      */       {
/*  971 */         return false;
/*      */       }
/*  973 */       this.cursor = (this.limit - v_3);
/*      */ 
/*  976 */       if (!r_RV())
/*      */       {
/*  978 */         return false;
/*      */       }
/*      */ 
/*  981 */       slice_del();
/*  982 */       break;
/*      */     case 2:
/*  986 */       label214: slice_from("c");
/*      */     }
/*      */ 
/*  989 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean stem()
/*      */   {
/* 1006 */     int v_1 = this.cursor;
/*      */ 
/* 1009 */     if (!r_prelude());
/* 1014 */     this.cursor = v_1;
/*      */ 
/* 1016 */     int v_2 = this.cursor;
/*      */ 
/* 1019 */     if (!r_mark_regions());
/* 1024 */     this.cursor = v_2;
/*      */ 
/* 1026 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 1029 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1034 */     int v_4 = this.limit - this.cursor;
/*      */ 
/* 1038 */     int v_5 = this.limit - this.cursor;
/*      */ 
/* 1042 */     int v_6 = this.limit - this.cursor;
/*      */ 
/* 1045 */     if (!r_standard_suffix())
/*      */     {
/* 1051 */       this.cursor = (this.limit - v_6);
/*      */ 
/* 1053 */       if (!r_verb_suffix());
/*      */     }
/*      */     else
/*      */     {
/* 1058 */       this.cursor = (this.limit - v_5);
/*      */ 
/* 1060 */       int v_7 = this.limit - this.cursor;
/*      */ 
/* 1064 */       this.ket = this.cursor;
/*      */ 
/* 1066 */       if (eq_s_b(1, "i"))
/*      */       {
/* 1071 */         this.bra = this.cursor;
/*      */ 
/* 1073 */         int v_8 = this.limit - this.cursor;
/*      */ 
/* 1075 */         if (eq_s_b(1, "c"))
/*      */         {
/* 1079 */           this.cursor = (this.limit - v_8);
/*      */ 
/* 1081 */           if (r_RV())
/*      */           {
/* 1086 */             slice_del();
/*      */           }
/*      */         }
/*      */       }
/* 1088 */       this.cursor = (this.limit - v_7);
/* 1089 */       break label253;
/*      */     }
/* 1091 */     this.cursor = (this.limit - v_4);
/*      */ 
/* 1093 */     if (!r_residual_suffix());
/* 1099 */     label253: this.cursor = (this.limit - v_3);
/*      */ 
/* 1101 */     int v_9 = this.limit - this.cursor;
/*      */ 
/* 1104 */     if (!r_residual_form());
/* 1109 */     this.cursor = (this.limit - v_9);
/* 1110 */     this.cursor = this.limit_backward;
/* 1111 */     int v_10 = this.cursor;
/*      */ 
/* 1114 */     if (!r_postlude());
/* 1119 */     this.cursor = v_10;
/* 1120 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1125 */     return o instanceof PortugueseStemmer;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1130 */     return PortugueseStemmer.class.getName().hashCode();
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.ext.PortugueseStemmer
 * JD-Core Version:    0.6.2
 */