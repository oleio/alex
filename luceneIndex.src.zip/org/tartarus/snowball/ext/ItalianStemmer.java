/*      */ package org.tartarus.snowball.ext;
/*      */ 
/*      */ import org.tartarus.snowball.Among;
/*      */ import org.tartarus.snowball.SnowballProgram;
/*      */ 
/*      */ public class ItalianStemmer extends SnowballProgram
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   17 */   private static final ItalianStemmer methodObject = new ItalianStemmer();
/*      */ 
/*   19 */   private static final Among[] a_0 = { new Among("", -1, 7, "", methodObject), new Among("qu", 0, 6, "", methodObject), new Among("á", 0, 1, "", methodObject), new Among("é", 0, 2, "", methodObject), new Among("í", 0, 3, "", methodObject), new Among("ó", 0, 4, "", methodObject), new Among("ú", 0, 5, "", methodObject) };
/*      */ 
/*   29 */   private static final Among[] a_1 = { new Among("", -1, 3, "", methodObject), new Among("I", 0, 1, "", methodObject), new Among("U", 0, 2, "", methodObject) };
/*      */ 
/*   35 */   private static final Among[] a_2 = { new Among("la", -1, -1, "", methodObject), new Among("cela", 0, -1, "", methodObject), new Among("gliela", 0, -1, "", methodObject), new Among("mela", 0, -1, "", methodObject), new Among("tela", 0, -1, "", methodObject), new Among("vela", 0, -1, "", methodObject), new Among("le", -1, -1, "", methodObject), new Among("cele", 6, -1, "", methodObject), new Among("gliele", 6, -1, "", methodObject), new Among("mele", 6, -1, "", methodObject), new Among("tele", 6, -1, "", methodObject), new Among("vele", 6, -1, "", methodObject), new Among("ne", -1, -1, "", methodObject), new Among("cene", 12, -1, "", methodObject), new Among("gliene", 12, -1, "", methodObject), new Among("mene", 12, -1, "", methodObject), new Among("sene", 12, -1, "", methodObject), new Among("tene", 12, -1, "", methodObject), new Among("vene", 12, -1, "", methodObject), new Among("ci", -1, -1, "", methodObject), new Among("li", -1, -1, "", methodObject), new Among("celi", 20, -1, "", methodObject), new Among("glieli", 20, -1, "", methodObject), new Among("meli", 20, -1, "", methodObject), new Among("teli", 20, -1, "", methodObject), new Among("veli", 20, -1, "", methodObject), new Among("gli", 20, -1, "", methodObject), new Among("mi", -1, -1, "", methodObject), new Among("si", -1, -1, "", methodObject), new Among("ti", -1, -1, "", methodObject), new Among("vi", -1, -1, "", methodObject), new Among("lo", -1, -1, "", methodObject), new Among("celo", 31, -1, "", methodObject), new Among("glielo", 31, -1, "", methodObject), new Among("melo", 31, -1, "", methodObject), new Among("telo", 31, -1, "", methodObject), new Among("velo", 31, -1, "", methodObject) };
/*      */ 
/*   75 */   private static final Among[] a_3 = { new Among("ando", -1, 1, "", methodObject), new Among("endo", -1, 1, "", methodObject), new Among("ar", -1, 2, "", methodObject), new Among("er", -1, 2, "", methodObject), new Among("ir", -1, 2, "", methodObject) };
/*      */ 
/*   83 */   private static final Among[] a_4 = { new Among("ic", -1, -1, "", methodObject), new Among("abil", -1, -1, "", methodObject), new Among("os", -1, -1, "", methodObject), new Among("iv", -1, 1, "", methodObject) };
/*      */ 
/*   90 */   private static final Among[] a_5 = { new Among("ic", -1, 1, "", methodObject), new Among("abil", -1, 1, "", methodObject), new Among("iv", -1, 1, "", methodObject) };
/*      */ 
/*   96 */   private static final Among[] a_6 = { new Among("ica", -1, 1, "", methodObject), new Among("logia", -1, 3, "", methodObject), new Among("osa", -1, 1, "", methodObject), new Among("ista", -1, 1, "", methodObject), new Among("iva", -1, 9, "", methodObject), new Among("anza", -1, 1, "", methodObject), new Among("enza", -1, 5, "", methodObject), new Among("ice", -1, 1, "", methodObject), new Among("atrice", 7, 1, "", methodObject), new Among("iche", -1, 1, "", methodObject), new Among("logie", -1, 3, "", methodObject), new Among("abile", -1, 1, "", methodObject), new Among("ibile", -1, 1, "", methodObject), new Among("usione", -1, 4, "", methodObject), new Among("azione", -1, 2, "", methodObject), new Among("uzione", -1, 4, "", methodObject), new Among("atore", -1, 2, "", methodObject), new Among("ose", -1, 1, "", methodObject), new Among("ante", -1, 1, "", methodObject), new Among("mente", -1, 1, "", methodObject), new Among("amente", 19, 7, "", methodObject), new Among("iste", -1, 1, "", methodObject), new Among("ive", -1, 9, "", methodObject), new Among("anze", -1, 1, "", methodObject), new Among("enze", -1, 5, "", methodObject), new Among("ici", -1, 1, "", methodObject), new Among("atrici", 25, 1, "", methodObject), new Among("ichi", -1, 1, "", methodObject), new Among("abili", -1, 1, "", methodObject), new Among("ibili", -1, 1, "", methodObject), new Among("ismi", -1, 1, "", methodObject), new Among("usioni", -1, 4, "", methodObject), new Among("azioni", -1, 2, "", methodObject), new Among("uzioni", -1, 4, "", methodObject), new Among("atori", -1, 2, "", methodObject), new Among("osi", -1, 1, "", methodObject), new Among("anti", -1, 1, "", methodObject), new Among("amenti", -1, 6, "", methodObject), new Among("imenti", -1, 6, "", methodObject), new Among("isti", -1, 1, "", methodObject), new Among("ivi", -1, 9, "", methodObject), new Among("ico", -1, 1, "", methodObject), new Among("ismo", -1, 1, "", methodObject), new Among("oso", -1, 1, "", methodObject), new Among("amento", -1, 6, "", methodObject), new Among("imento", -1, 6, "", methodObject), new Among("ivo", -1, 9, "", methodObject), new Among("ità", -1, 8, "", methodObject), new Among("istà", -1, 1, "", methodObject), new Among("istè", -1, 1, "", methodObject), new Among("istì", -1, 1, "", methodObject) };
/*      */ 
/*  150 */   private static final Among[] a_7 = { new Among("isca", -1, 1, "", methodObject), new Among("enda", -1, 1, "", methodObject), new Among("ata", -1, 1, "", methodObject), new Among("ita", -1, 1, "", methodObject), new Among("uta", -1, 1, "", methodObject), new Among("ava", -1, 1, "", methodObject), new Among("eva", -1, 1, "", methodObject), new Among("iva", -1, 1, "", methodObject), new Among("erebbe", -1, 1, "", methodObject), new Among("irebbe", -1, 1, "", methodObject), new Among("isce", -1, 1, "", methodObject), new Among("ende", -1, 1, "", methodObject), new Among("are", -1, 1, "", methodObject), new Among("ere", -1, 1, "", methodObject), new Among("ire", -1, 1, "", methodObject), new Among("asse", -1, 1, "", methodObject), new Among("ate", -1, 1, "", methodObject), new Among("avate", 16, 1, "", methodObject), new Among("evate", 16, 1, "", methodObject), new Among("ivate", 16, 1, "", methodObject), new Among("ete", -1, 1, "", methodObject), new Among("erete", 20, 1, "", methodObject), new Among("irete", 20, 1, "", methodObject), new Among("ite", -1, 1, "", methodObject), new Among("ereste", -1, 1, "", methodObject), new Among("ireste", -1, 1, "", methodObject), new Among("ute", -1, 1, "", methodObject), new Among("erai", -1, 1, "", methodObject), new Among("irai", -1, 1, "", methodObject), new Among("isci", -1, 1, "", methodObject), new Among("endi", -1, 1, "", methodObject), new Among("erei", -1, 1, "", methodObject), new Among("irei", -1, 1, "", methodObject), new Among("assi", -1, 1, "", methodObject), new Among("ati", -1, 1, "", methodObject), new Among("iti", -1, 1, "", methodObject), new Among("eresti", -1, 1, "", methodObject), new Among("iresti", -1, 1, "", methodObject), new Among("uti", -1, 1, "", methodObject), new Among("avi", -1, 1, "", methodObject), new Among("evi", -1, 1, "", methodObject), new Among("ivi", -1, 1, "", methodObject), new Among("isco", -1, 1, "", methodObject), new Among("ando", -1, 1, "", methodObject), new Among("endo", -1, 1, "", methodObject), new Among("Yamo", -1, 1, "", methodObject), new Among("iamo", -1, 1, "", methodObject), new Among("avamo", -1, 1, "", methodObject), new Among("evamo", -1, 1, "", methodObject), new Among("ivamo", -1, 1, "", methodObject), new Among("eremo", -1, 1, "", methodObject), new Among("iremo", -1, 1, "", methodObject), new Among("assimo", -1, 1, "", methodObject), new Among("ammo", -1, 1, "", methodObject), new Among("emmo", -1, 1, "", methodObject), new Among("eremmo", 54, 1, "", methodObject), new Among("iremmo", 54, 1, "", methodObject), new Among("immo", -1, 1, "", methodObject), new Among("ano", -1, 1, "", methodObject), new Among("iscano", 58, 1, "", methodObject), new Among("avano", 58, 1, "", methodObject), new Among("evano", 58, 1, "", methodObject), new Among("ivano", 58, 1, "", methodObject), new Among("eranno", -1, 1, "", methodObject), new Among("iranno", -1, 1, "", methodObject), new Among("ono", -1, 1, "", methodObject), new Among("iscono", 65, 1, "", methodObject), new Among("arono", 65, 1, "", methodObject), new Among("erono", 65, 1, "", methodObject), new Among("irono", 65, 1, "", methodObject), new Among("erebbero", -1, 1, "", methodObject), new Among("irebbero", -1, 1, "", methodObject), new Among("assero", -1, 1, "", methodObject), new Among("essero", -1, 1, "", methodObject), new Among("issero", -1, 1, "", methodObject), new Among("ato", -1, 1, "", methodObject), new Among("ito", -1, 1, "", methodObject), new Among("uto", -1, 1, "", methodObject), new Among("avo", -1, 1, "", methodObject), new Among("evo", -1, 1, "", methodObject), new Among("ivo", -1, 1, "", methodObject), new Among("ar", -1, 1, "", methodObject), new Among("ir", -1, 1, "", methodObject), new Among("erà", -1, 1, "", methodObject), new Among("irà", -1, 1, "", methodObject), new Among("erò", -1, 1, "", methodObject), new Among("irò", -1, 1, "", methodObject) };
/*      */ 
/*  240 */   private static final char[] g_v = { '\021', 'A', '\020', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '', '', '\b', '\002', '\001' };
/*      */ 
/*  242 */   private static final char[] g_AEIO = { '\021', 'A', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '', '', '\b', '\002' };
/*      */ 
/*  244 */   private static final char[] g_CG = { '\021' };
/*      */   private int I_p2;
/*      */   private int I_p1;
/*      */   private int I_pV;
/*      */ 
/*      */   private void copy_from(ItalianStemmer other)
/*      */   {
/*  251 */     this.I_p2 = other.I_p2;
/*  252 */     this.I_p1 = other.I_p1;
/*  253 */     this.I_pV = other.I_pV;
/*  254 */     super.copy_from(other);
/*      */   }
/*      */ 
/*      */   private boolean r_prelude()
/*      */   {
/*  266 */     int v_1 = this.cursor;
/*      */     int v_2;
/*      */     while (true)
/*      */     {
/*  270 */       v_2 = this.cursor;
/*      */ 
/*  274 */       this.bra = this.cursor;
/*      */ 
/*  276 */       int among_var = find_among(a_0, 7);
/*  277 */       if (among_var == 0)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  282 */       this.ket = this.cursor;
/*  283 */       switch (among_var) {
/*      */       case 0:
/*  285 */         break;
/*      */       case 1:
/*  289 */         slice_from("à");
/*  290 */         break;
/*      */       case 2:
/*  294 */         slice_from("è");
/*  295 */         break;
/*      */       case 3:
/*  299 */         slice_from("ì");
/*  300 */         break;
/*      */       case 4:
/*  304 */         slice_from("ò");
/*  305 */         break;
/*      */       case 5:
/*  309 */         slice_from("ù");
/*  310 */         break;
/*      */       case 6:
/*  314 */         slice_from("qU");
/*  315 */         break;
/*      */       case 7:
/*  319 */         if (this.cursor >= this.limit)
/*      */         {
/*      */           break label176;
/*      */         }
/*  323 */         this.cursor += 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  328 */     label176: this.cursor = v_2;
/*      */ 
/*  331 */     this.cursor = v_1;
/*      */ 
/*  335 */     int v_3 = this.cursor;
/*      */     while (true)
/*      */     {
/*  340 */       int v_4 = this.cursor;
/*      */ 
/*  343 */       if (in_grouping(g_v, 97, 249))
/*      */       {
/*  348 */         this.bra = this.cursor;
/*      */ 
/*  351 */         int v_5 = this.cursor;
/*      */ 
/*  355 */         if (eq_s(1, "u"))
/*      */         {
/*  360 */           this.ket = this.cursor;
/*  361 */           if (in_grouping(g_v, 97, 249))
/*      */           {
/*  366 */             slice_from("U");
/*  367 */             break label332;
/*      */           }
/*      */         }
/*  369 */         this.cursor = v_5;
/*      */ 
/*  372 */         if (eq_s(1, "i"))
/*      */         {
/*  377 */           this.ket = this.cursor;
/*  378 */           if (in_grouping(g_v, 97, 249))
/*      */           {
/*  383 */             slice_from("I");
/*      */ 
/*  385 */             label332: this.cursor = v_4;
/*  386 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  388 */       this.cursor = v_4;
/*  389 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label374;
/*      */       }
/*  393 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  397 */     label374: this.cursor = v_3;
/*      */ 
/*  400 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_mark_regions()
/*      */   {
/*  410 */     this.I_pV = this.limit;
/*  411 */     this.I_p1 = this.limit;
/*  412 */     this.I_p2 = this.limit;
/*      */ 
/*  414 */     int v_1 = this.cursor;
/*      */ 
/*  419 */     int v_2 = this.cursor;
/*      */ 
/*  422 */     if (in_grouping(g_v, 97, 249))
/*      */     {
/*  428 */       int v_3 = this.cursor;
/*      */ 
/*  431 */       if (out_grouping(g_v, 97, 249))
/*      */       {
/*      */         while (true)
/*      */         {
/*  439 */           if (in_grouping(g_v, 97, 249))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  445 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  449 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */ 
/*  453 */       this.cursor = v_3;
/*      */ 
/*  455 */       if (in_grouping(g_v, 97, 249))
/*      */       {
/*      */         while (true)
/*      */         {
/*  463 */           if (out_grouping(g_v, 97, 249))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  469 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  473 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  478 */     this.cursor = v_2;
/*      */ 
/*  480 */     if (out_grouping(g_v, 97, 249))
/*      */     {
/*  486 */       int v_6 = this.cursor;
/*      */ 
/*  489 */       if (out_grouping(g_v, 97, 249))
/*      */       {
/*      */         while (true)
/*      */         {
/*  497 */           if (in_grouping(g_v, 97, 249))
/*      */           {
/*      */             break label319;
/*      */           }
/*      */ 
/*  503 */           if (this.cursor >= this.limit)
/*      */           {
/*      */             break;
/*      */           }
/*  507 */           this.cursor += 1;
/*      */         }
/*      */       }
/*      */ 
/*  511 */       this.cursor = v_6;
/*      */ 
/*  513 */       if (in_grouping(g_v, 97, 249))
/*      */       {
/*  518 */         if (this.cursor < this.limit)
/*      */         {
/*  522 */           this.cursor += 1;
/*      */ 
/*  526 */           label319: this.I_pV = this.cursor;
/*      */         }
/*      */       }
/*      */     }
/*  528 */     this.cursor = v_1;
/*      */ 
/*  530 */     int v_8 = this.cursor;
/*      */ 
/*  537 */     while (!in_grouping(g_v, 97, 249))
/*      */     {
/*  543 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  547 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  553 */     while (!out_grouping(g_v, 97, 249))
/*      */     {
/*  559 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  563 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  566 */     this.I_p1 = this.cursor;
/*      */ 
/*  571 */     while (!in_grouping(g_v, 97, 249))
/*      */     {
/*  577 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  581 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  587 */     while (!out_grouping(g_v, 97, 249))
/*      */     {
/*  593 */       if (this.cursor >= this.limit)
/*      */       {
/*      */         break label522;
/*      */       }
/*  597 */       this.cursor += 1;
/*      */     }
/*      */ 
/*  600 */     this.I_p2 = this.cursor;
/*      */ 
/*  602 */     label522: this.cursor = v_8;
/*  603 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_postlude()
/*      */   {
/*      */     int v_1;
/*      */     while (true)
/*      */     {
/*  612 */       v_1 = this.cursor;
/*      */ 
/*  616 */       this.bra = this.cursor;
/*      */ 
/*  618 */       int among_var = find_among(a_1, 3);
/*  619 */       if (among_var == 0)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  624 */       this.ket = this.cursor;
/*  625 */       switch (among_var) {
/*      */       case 0:
/*  627 */         break;
/*      */       case 1:
/*  631 */         slice_from("i");
/*  632 */         break;
/*      */       case 2:
/*  636 */         slice_from("u");
/*  637 */         break;
/*      */       case 3:
/*  641 */         if (this.cursor >= this.limit)
/*      */         {
/*      */           break label116;
/*      */         }
/*  645 */         this.cursor += 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  650 */     label116: this.cursor = v_1;
/*      */ 
/*  653 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_RV() {
/*  657 */     if (this.I_pV > this.cursor)
/*      */     {
/*  659 */       return false;
/*      */     }
/*  661 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R1() {
/*  665 */     if (this.I_p1 > this.cursor)
/*      */     {
/*  667 */       return false;
/*      */     }
/*  669 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_R2() {
/*  673 */     if (this.I_p2 > this.cursor)
/*      */     {
/*  675 */       return false;
/*      */     }
/*  677 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_attached_pronoun()
/*      */   {
/*  684 */     this.ket = this.cursor;
/*      */ 
/*  686 */     if (find_among_b(a_2, 37) == 0)
/*      */     {
/*  688 */       return false;
/*      */     }
/*      */ 
/*  691 */     this.bra = this.cursor;
/*      */ 
/*  693 */     int among_var = find_among_b(a_3, 5);
/*  694 */     if (among_var == 0)
/*      */     {
/*  696 */       return false;
/*      */     }
/*      */ 
/*  700 */     if (!r_RV())
/*      */     {
/*  702 */       return false;
/*      */     }
/*  704 */     switch (among_var) {
/*      */     case 0:
/*  706 */       return false;
/*      */     case 1:
/*  710 */       slice_del();
/*  711 */       break;
/*      */     case 2:
/*  715 */       slice_from("e");
/*      */     }
/*      */ 
/*  718 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_standard_suffix()
/*      */   {
/*  729 */     this.ket = this.cursor;
/*      */ 
/*  731 */     int among_var = find_among_b(a_6, 51);
/*  732 */     if (among_var == 0)
/*      */     {
/*  734 */       return false;
/*      */     }
/*      */ 
/*  737 */     this.bra = this.cursor;
/*  738 */     switch (among_var) {
/*      */     case 0:
/*  740 */       return false;
/*      */     case 1:
/*  744 */       if (!r_R2())
/*      */       {
/*  746 */         return false;
/*      */       }
/*      */ 
/*  749 */       slice_del();
/*  750 */       break;
/*      */     case 2:
/*  754 */       if (!r_R2())
/*      */       {
/*  756 */         return false;
/*      */       }
/*      */ 
/*  759 */       slice_del();
/*      */ 
/*  761 */       int v_1 = this.limit - this.cursor;
/*      */ 
/*  765 */       this.ket = this.cursor;
/*      */ 
/*  767 */       if (!eq_s_b(2, "ic"))
/*      */       {
/*  769 */         this.cursor = (this.limit - v_1);
/*      */       }
/*      */       else
/*      */       {
/*  773 */         this.bra = this.cursor;
/*      */ 
/*  775 */         if (!r_R2())
/*      */         {
/*  777 */           this.cursor = (this.limit - v_1);
/*      */         }
/*      */         else
/*      */         {
/*  781 */           slice_del();
/*      */         }
/*      */       }
/*  783 */       break;
/*      */     case 3:
/*  787 */       if (!r_R2())
/*      */       {
/*  789 */         return false;
/*      */       }
/*      */ 
/*  792 */       slice_from("log");
/*  793 */       break;
/*      */     case 4:
/*  797 */       if (!r_R2())
/*      */       {
/*  799 */         return false;
/*      */       }
/*      */ 
/*  802 */       slice_from("u");
/*  803 */       break;
/*      */     case 5:
/*  807 */       if (!r_R2())
/*      */       {
/*  809 */         return false;
/*      */       }
/*      */ 
/*  812 */       slice_from("ente");
/*  813 */       break;
/*      */     case 6:
/*  817 */       if (!r_RV())
/*      */       {
/*  819 */         return false;
/*      */       }
/*      */ 
/*  822 */       slice_del();
/*  823 */       break;
/*      */     case 7:
/*  827 */       if (!r_R1())
/*      */       {
/*  829 */         return false;
/*      */       }
/*      */ 
/*  832 */       slice_del();
/*      */ 
/*  834 */       int v_2 = this.limit - this.cursor;
/*      */ 
/*  838 */       this.ket = this.cursor;
/*      */ 
/*  840 */       among_var = find_among_b(a_4, 4);
/*  841 */       if (among_var == 0)
/*      */       {
/*  843 */         this.cursor = (this.limit - v_2);
/*      */       }
/*      */       else
/*      */       {
/*  847 */         this.bra = this.cursor;
/*      */ 
/*  849 */         if (!r_R2())
/*      */         {
/*  851 */           this.cursor = (this.limit - v_2);
/*      */         }
/*      */         else
/*      */         {
/*  855 */           slice_del();
/*  856 */           switch (among_var) {
/*      */           case 0:
/*  858 */             this.cursor = (this.limit - v_2);
/*  859 */             break;
/*      */           case 1:
/*  863 */             this.ket = this.cursor;
/*      */ 
/*  865 */             if (!eq_s_b(2, "at"))
/*      */             {
/*  867 */               this.cursor = (this.limit - v_2);
/*      */             }
/*      */             else
/*      */             {
/*  871 */               this.bra = this.cursor;
/*      */ 
/*  873 */               if (!r_R2())
/*      */               {
/*  875 */                 this.cursor = (this.limit - v_2);
/*      */               }
/*      */               else
/*      */               {
/*  879 */                 slice_del(); }  } break;
/*      */           }
/*      */         }
/*      */       }
/*  883 */       break;
/*      */     case 8:
/*  887 */       if (!r_R2())
/*      */       {
/*  889 */         return false;
/*      */       }
/*      */ 
/*  892 */       slice_del();
/*      */ 
/*  894 */       int v_3 = this.limit - this.cursor;
/*      */ 
/*  898 */       this.ket = this.cursor;
/*      */ 
/*  900 */       among_var = find_among_b(a_5, 3);
/*  901 */       if (among_var == 0)
/*      */       {
/*  903 */         this.cursor = (this.limit - v_3);
/*      */       }
/*      */       else
/*      */       {
/*  907 */         this.bra = this.cursor;
/*  908 */         switch (among_var) {
/*      */         case 0:
/*  910 */           this.cursor = (this.limit - v_3);
/*  911 */           break;
/*      */         case 1:
/*  915 */           if (!r_R2())
/*      */           {
/*  917 */             this.cursor = (this.limit - v_3);
/*      */           }
/*      */           else
/*      */           {
/*  921 */             slice_del();
/*      */           }break;
/*      */         }
/*      */       }
/*  925 */       break;
/*      */     case 9:
/*  929 */       if (!r_R2())
/*      */       {
/*  931 */         return false;
/*      */       }
/*      */ 
/*  934 */       slice_del();
/*      */ 
/*  936 */       int v_4 = this.limit - this.cursor;
/*      */ 
/*  940 */       this.ket = this.cursor;
/*      */ 
/*  942 */       if (!eq_s_b(2, "at"))
/*      */       {
/*  944 */         this.cursor = (this.limit - v_4);
/*      */       }
/*      */       else
/*      */       {
/*  948 */         this.bra = this.cursor;
/*      */ 
/*  950 */         if (!r_R2())
/*      */         {
/*  952 */           this.cursor = (this.limit - v_4);
/*      */         }
/*      */         else
/*      */         {
/*  956 */           slice_del();
/*      */ 
/*  958 */           this.ket = this.cursor;
/*      */ 
/*  960 */           if (!eq_s_b(2, "ic"))
/*      */           {
/*  962 */             this.cursor = (this.limit - v_4);
/*      */           }
/*      */           else
/*      */           {
/*  966 */             this.bra = this.cursor;
/*      */ 
/*  968 */             if (!r_R2())
/*      */             {
/*  970 */               this.cursor = (this.limit - v_4);
/*      */             }
/*      */             else
/*      */             {
/*  974 */               slice_del();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       break;
/*      */     }
/*  978 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_verb_suffix()
/*      */   {
/*  986 */     int v_1 = this.limit - this.cursor;
/*      */ 
/*  988 */     if (this.cursor < this.I_pV)
/*      */     {
/*  990 */       return false;
/*      */     }
/*  992 */     this.cursor = this.I_pV;
/*  993 */     int v_2 = this.limit_backward;
/*  994 */     this.limit_backward = this.cursor;
/*  995 */     this.cursor = (this.limit - v_1);
/*      */ 
/*  998 */     this.ket = this.cursor;
/*      */ 
/* 1000 */     int among_var = find_among_b(a_7, 87);
/* 1001 */     if (among_var == 0)
/*      */     {
/* 1003 */       this.limit_backward = v_2;
/* 1004 */       return false;
/*      */     }
/*      */ 
/* 1007 */     this.bra = this.cursor;
/* 1008 */     switch (among_var) {
/*      */     case 0:
/* 1010 */       this.limit_backward = v_2;
/* 1011 */       return false;
/*      */     case 1:
/* 1015 */       slice_del();
/*      */     }
/*      */ 
/* 1018 */     this.limit_backward = v_2;
/* 1019 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean r_vowel_suffix()
/*      */   {
/* 1027 */     int v_1 = this.limit - this.cursor;
/*      */ 
/* 1031 */     this.ket = this.cursor;
/* 1032 */     if (!in_grouping_b(g_AEIO, 97, 242))
/*      */     {
/* 1034 */       this.cursor = (this.limit - v_1);
/*      */     }
/*      */     else
/*      */     {
/* 1038 */       this.bra = this.cursor;
/*      */ 
/* 1040 */       if (!r_RV())
/*      */       {
/* 1042 */         this.cursor = (this.limit - v_1);
/*      */       }
/*      */       else
/*      */       {
/* 1046 */         slice_del();
/*      */ 
/* 1048 */         this.ket = this.cursor;
/*      */ 
/* 1050 */         if (!eq_s_b(1, "i"))
/*      */         {
/* 1052 */           this.cursor = (this.limit - v_1);
/*      */         }
/*      */         else
/*      */         {
/* 1056 */           this.bra = this.cursor;
/*      */ 
/* 1058 */           if (!r_RV())
/*      */           {
/* 1060 */             this.cursor = (this.limit - v_1);
/*      */           }
/*      */           else
/*      */           {
/* 1064 */             slice_del();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1067 */     int v_2 = this.limit - this.cursor;
/*      */ 
/* 1071 */     this.ket = this.cursor;
/*      */ 
/* 1073 */     if (!eq_s_b(1, "h"))
/*      */     {
/* 1075 */       this.cursor = (this.limit - v_2);
/*      */     }
/*      */     else
/*      */     {
/* 1079 */       this.bra = this.cursor;
/* 1080 */       if (!in_grouping_b(g_CG, 99, 103))
/*      */       {
/* 1082 */         this.cursor = (this.limit - v_2);
/*      */       }
/* 1086 */       else if (!r_RV())
/*      */       {
/* 1088 */         this.cursor = (this.limit - v_2);
/*      */       }
/*      */       else
/*      */       {
/* 1092 */         slice_del();
/*      */       }
/*      */     }
/* 1094 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean stem()
/*      */   {
/* 1108 */     int v_1 = this.cursor;
/*      */ 
/* 1111 */     if (!r_prelude());
/* 1116 */     this.cursor = v_1;
/*      */ 
/* 1118 */     int v_2 = this.cursor;
/*      */ 
/* 1121 */     if (!r_mark_regions());
/* 1126 */     this.cursor = v_2;
/*      */ 
/* 1128 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*      */ 
/* 1131 */     int v_3 = this.limit - this.cursor;
/*      */ 
/* 1134 */     if (!r_attached_pronoun());
/* 1139 */     this.cursor = (this.limit - v_3);
/*      */ 
/* 1141 */     int v_4 = this.limit - this.cursor;
/*      */ 
/* 1146 */     int v_5 = this.limit - this.cursor;
/*      */ 
/* 1149 */     if (!r_standard_suffix())
/*      */     {
/* 1155 */       this.cursor = (this.limit - v_5);
/*      */ 
/* 1157 */       if (r_verb_suffix());
/*      */     }
/*      */ 
/* 1163 */     this.cursor = (this.limit - v_4);
/*      */ 
/* 1165 */     int v_6 = this.limit - this.cursor;
/*      */ 
/* 1168 */     if (!r_vowel_suffix());
/* 1173 */     this.cursor = (this.limit - v_6);
/* 1174 */     this.cursor = this.limit_backward;
/* 1175 */     int v_7 = this.cursor;
/*      */ 
/* 1178 */     if (!r_postlude());
/* 1183 */     this.cursor = v_7;
/* 1184 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1189 */     return o instanceof ItalianStemmer;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1194 */     return ItalianStemmer.class.getName().hashCode();
/*      */   }
/*      */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.ext.ItalianStemmer
 * JD-Core Version:    0.6.2
 */