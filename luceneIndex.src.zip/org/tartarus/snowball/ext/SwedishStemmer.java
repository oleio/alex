/*     */ package org.tartarus.snowball.ext;
/*     */ 
/*     */ import org.tartarus.snowball.Among;
/*     */ import org.tartarus.snowball.SnowballProgram;
/*     */ 
/*     */ public class SwedishStemmer extends SnowballProgram
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  17 */   private static final SwedishStemmer methodObject = new SwedishStemmer();
/*     */ 
/*  19 */   private static final Among[] a_0 = { new Among("a", -1, 1, "", methodObject), new Among("arna", 0, 1, "", methodObject), new Among("erna", 0, 1, "", methodObject), new Among("heterna", 2, 1, "", methodObject), new Among("orna", 0, 1, "", methodObject), new Among("ad", -1, 1, "", methodObject), new Among("e", -1, 1, "", methodObject), new Among("ade", 6, 1, "", methodObject), new Among("ande", 6, 1, "", methodObject), new Among("arne", 6, 1, "", methodObject), new Among("are", 6, 1, "", methodObject), new Among("aste", 6, 1, "", methodObject), new Among("en", -1, 1, "", methodObject), new Among("anden", 12, 1, "", methodObject), new Among("aren", 12, 1, "", methodObject), new Among("heten", 12, 1, "", methodObject), new Among("ern", -1, 1, "", methodObject), new Among("ar", -1, 1, "", methodObject), new Among("er", -1, 1, "", methodObject), new Among("heter", 18, 1, "", methodObject), new Among("or", -1, 1, "", methodObject), new Among("s", -1, 2, "", methodObject), new Among("as", 21, 1, "", methodObject), new Among("arnas", 22, 1, "", methodObject), new Among("ernas", 22, 1, "", methodObject), new Among("ornas", 22, 1, "", methodObject), new Among("es", 21, 1, "", methodObject), new Among("ades", 26, 1, "", methodObject), new Among("andes", 26, 1, "", methodObject), new Among("ens", 21, 1, "", methodObject), new Among("arens", 29, 1, "", methodObject), new Among("hetens", 29, 1, "", methodObject), new Among("erns", 21, 1, "", methodObject), new Among("at", -1, 1, "", methodObject), new Among("andet", -1, 1, "", methodObject), new Among("het", -1, 1, "", methodObject), new Among("ast", -1, 1, "", methodObject) };
/*     */ 
/*  59 */   private static final Among[] a_1 = { new Among("dd", -1, -1, "", methodObject), new Among("gd", -1, -1, "", methodObject), new Among("nn", -1, -1, "", methodObject), new Among("dt", -1, -1, "", methodObject), new Among("gt", -1, -1, "", methodObject), new Among("kt", -1, -1, "", methodObject), new Among("tt", -1, -1, "", methodObject) };
/*     */ 
/*  69 */   private static final Among[] a_2 = { new Among("ig", -1, 1, "", methodObject), new Among("lig", 0, 1, "", methodObject), new Among("els", -1, 1, "", methodObject), new Among("fullt", -1, 3, "", methodObject), new Among("löst", -1, 2, "", methodObject) };
/*     */ 
/*  77 */   private static final char[] g_v = { '\021', 'A', '\020', '\001', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\030', '\000', ' ' };
/*     */ 
/*  79 */   private static final char[] g_s_ending = { 'w', '', '' };
/*     */   private int I_x;
/*     */   private int I_p1;
/*     */ 
/*     */   private void copy_from(SwedishStemmer other)
/*     */   {
/*  85 */     this.I_x = other.I_x;
/*  86 */     this.I_p1 = other.I_p1;
/*  87 */     super.copy_from(other);
/*     */   }
/*     */ 
/*     */   private boolean r_mark_regions()
/*     */   {
/*  94 */     this.I_p1 = this.limit;
/*     */ 
/*  96 */     int v_1 = this.cursor;
/*     */ 
/* 100 */     int c = this.cursor + 3;
/* 101 */     if ((0 > c) || (c > this.limit))
/*     */     {
/* 103 */       return false;
/*     */     }
/* 105 */     this.cursor = c;
/*     */ 
/* 108 */     this.I_x = this.cursor;
/* 109 */     this.cursor = v_1;
/*     */     while (true)
/*     */     {
/* 113 */       int v_2 = this.cursor;
/*     */ 
/* 115 */       if (in_grouping(g_v, 97, 246))
/*     */       {
/* 119 */         this.cursor = v_2;
/* 120 */         break;
/*     */       }
/* 122 */       this.cursor = v_2;
/* 123 */       if (this.cursor >= this.limit)
/*     */       {
/* 125 */         return false;
/*     */       }
/* 127 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 133 */     while (!out_grouping(g_v, 97, 246))
/*     */     {
/* 139 */       if (this.cursor >= this.limit)
/*     */       {
/* 141 */         return false;
/*     */       }
/* 143 */       this.cursor += 1;
/*     */     }
/*     */ 
/* 146 */     this.I_p1 = this.cursor;
/*     */ 
/* 150 */     if (this.I_p1 < this.I_x)
/*     */     {
/* 154 */       this.I_p1 = this.I_x;
/*     */     }
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_main_suffix()
/*     */   {
/* 165 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 167 */     if (this.cursor < this.I_p1)
/*     */     {
/* 169 */       return false;
/*     */     }
/* 171 */     this.cursor = this.I_p1;
/* 172 */     int v_2 = this.limit_backward;
/* 173 */     this.limit_backward = this.cursor;
/* 174 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 177 */     this.ket = this.cursor;
/*     */ 
/* 179 */     int among_var = find_among_b(a_0, 37);
/* 180 */     if (among_var == 0)
/*     */     {
/* 182 */       this.limit_backward = v_2;
/* 183 */       return false;
/*     */     }
/*     */ 
/* 186 */     this.bra = this.cursor;
/* 187 */     this.limit_backward = v_2;
/* 188 */     switch (among_var) {
/*     */     case 0:
/* 190 */       return false;
/*     */     case 1:
/* 194 */       slice_del();
/* 195 */       break;
/*     */     case 2:
/* 198 */       if (!in_grouping_b(g_s_ending, 98, 121))
/*     */       {
/* 200 */         return false;
/*     */       }
/*     */ 
/* 203 */       slice_del();
/*     */     }
/*     */ 
/* 206 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_consonant_pair()
/*     */   {
/* 214 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 216 */     if (this.cursor < this.I_p1)
/*     */     {
/* 218 */       return false;
/*     */     }
/* 220 */     this.cursor = this.I_p1;
/* 221 */     int v_2 = this.limit_backward;
/* 222 */     this.limit_backward = this.cursor;
/* 223 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 226 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 228 */     if (find_among_b(a_1, 7) == 0)
/*     */     {
/* 230 */       this.limit_backward = v_2;
/* 231 */       return false;
/*     */     }
/* 233 */     this.cursor = (this.limit - v_3);
/*     */ 
/* 236 */     this.ket = this.cursor;
/*     */ 
/* 238 */     if (this.cursor <= this.limit_backward)
/*     */     {
/* 240 */       this.limit_backward = v_2;
/* 241 */       return false;
/*     */     }
/* 243 */     this.cursor -= 1;
/*     */ 
/* 245 */     this.bra = this.cursor;
/*     */ 
/* 247 */     slice_del();
/* 248 */     this.limit_backward = v_2;
/* 249 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean r_other_suffix()
/*     */   {
/* 257 */     int v_1 = this.limit - this.cursor;
/*     */ 
/* 259 */     if (this.cursor < this.I_p1)
/*     */     {
/* 261 */       return false;
/*     */     }
/* 263 */     this.cursor = this.I_p1;
/* 264 */     int v_2 = this.limit_backward;
/* 265 */     this.limit_backward = this.cursor;
/* 266 */     this.cursor = (this.limit - v_1);
/*     */ 
/* 269 */     this.ket = this.cursor;
/*     */ 
/* 271 */     int among_var = find_among_b(a_2, 5);
/* 272 */     if (among_var == 0)
/*     */     {
/* 274 */       this.limit_backward = v_2;
/* 275 */       return false;
/*     */     }
/*     */ 
/* 278 */     this.bra = this.cursor;
/* 279 */     switch (among_var) {
/*     */     case 0:
/* 281 */       this.limit_backward = v_2;
/* 282 */       return false;
/*     */     case 1:
/* 286 */       slice_del();
/* 287 */       break;
/*     */     case 2:
/* 291 */       slice_from("lös");
/* 292 */       break;
/*     */     case 3:
/* 296 */       slice_from("full");
/*     */     }
/*     */ 
/* 299 */     this.limit_backward = v_2;
/* 300 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean stem()
/*     */   {
/* 311 */     int v_1 = this.cursor;
/*     */ 
/* 314 */     if (!r_mark_regions());
/* 319 */     this.cursor = v_1;
/*     */ 
/* 321 */     this.limit_backward = this.cursor; this.cursor = this.limit;
/*     */ 
/* 324 */     int v_2 = this.limit - this.cursor;
/*     */ 
/* 327 */     if (!r_main_suffix());
/* 332 */     this.cursor = (this.limit - v_2);
/*     */ 
/* 334 */     int v_3 = this.limit - this.cursor;
/*     */ 
/* 337 */     if (!r_consonant_pair());
/* 342 */     this.cursor = (this.limit - v_3);
/*     */ 
/* 344 */     int v_4 = this.limit - this.cursor;
/*     */ 
/* 347 */     if (!r_other_suffix());
/* 352 */     this.cursor = (this.limit - v_4);
/* 353 */     this.cursor = this.limit_backward; return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 358 */     return o instanceof SwedishStemmer;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 363 */     return SwedishStemmer.class.getName().hashCode();
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.ext.SwedishStemmer
 * JD-Core Version:    0.6.2
 */