/*    */ package org.tartarus.snowball;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class Among
/*    */ {
/* 46 */   private static final Class<?>[] EMPTY_PARAMS = new Class[0];
/*    */   public final int s_size;
/*    */   public final char[] s;
/*    */   public final int substring_i;
/*    */   public final int result;
/*    */   public final Method method;
/*    */   public final SnowballProgram methodobject;
/*    */ 
/*    */   public Among(String s, int substring_i, int result, String methodname, SnowballProgram methodobject)
/*    */   {
/* 50 */     this.s_size = s.length();
/* 51 */     this.s = s.toCharArray();
/* 52 */     this.substring_i = substring_i;
/* 53 */     this.result = result;
/* 54 */     this.methodobject = methodobject;
/* 55 */     if (methodname.length() == 0)
/* 56 */       this.method = null;
/*    */     else
/*    */       try {
/* 59 */         this.method = methodobject.getClass().getDeclaredMethod(methodname, EMPTY_PARAMS);
/*    */       }
/*    */       catch (NoSuchMethodException e) {
/* 62 */         throw new RuntimeException(e);
/*    */       }
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     org.tartarus.snowball.Among
 * JD-Core Version:    0.6.2
 */