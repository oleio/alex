/*    */ package com.yunsichuangzhi.lucene;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Map;
/*    */ import org.apache.lucene.analysis.Analyzer;
/*    */ import org.apache.lucene.document.Document;
/*    */ import org.apache.lucene.document.Field.Store;
/*    */ import org.apache.lucene.document.FieldType;
/*    */ import org.apache.lucene.document.StringField;
/*    */ import org.apache.lucene.document.TextField;
/*    */ import org.apache.lucene.index.IndexWriter;
/*    */ import org.apache.lucene.index.IndexWriterConfig;
/*    */ import org.apache.lucene.store.Directory;
/*    */ import org.apache.lucene.store.SimpleFSDirectory;
/*    */ 
/*    */ public class LuceneIndexer
/*    */ {
/* 21 */   private IndexWriter indexWriter = null;
/* 22 */   private String indexFolder = "resources/index/";
/*    */ 
/*    */   public IndexWriter getIndexWriter() throws IOException {
/* 25 */     if (this.indexWriter == null) {
/* 26 */       Analyzer analyzer = Util.getChineseAnalyzer();
/* 27 */       IndexWriterConfig c = new IndexWriterConfig(Util.LUCENE_VERSION, analyzer);
/*    */ 
/* 34 */       Directory indexDir = new SimpleFSDirectory(new File(this.indexFolder));
/* 35 */       this.indexWriter = new IndexWriter(indexDir, c);
/*    */     }
/* 37 */     return this.indexWriter;
/*    */   }
/*    */ 
/*    */   public void closeIndexWriter() throws IOException {
/* 41 */     if (this.indexWriter != null)
/* 42 */       this.indexWriter.close();
/*    */   }
/*    */ 
/*    */   public void indexBreakDownDoc(BreakDownDoc doc) throws IOException
/*    */   {
/* 47 */     IndexWriter writer = getIndexWriter();
/* 48 */     Document lucene_doc = new Document();
/* 49 */     FieldType t = new FieldType();
/* 50 */     t.setIndexed(true);
/* 51 */     t.setStored(true);
/*    */ 
/* 54 */     for (String field : doc.values.keySet())
/* 55 */       if (BreakDownDoc.types.get(field) == BreakDownDoc.FIELD_TYPE.TEXT) {
/* 56 */         String tokened = Util.replaceDigit((String)doc.values.get(field));
/*    */ 
/* 59 */         lucene_doc.add(new TextField(field, doc.values.get(field) == null ? "" : tokened, Field.Store.YES));
/*    */       } else {
/* 61 */         lucene_doc.add(new StringField(field, (String)doc.values.get(field), Field.Store.YES));
/*    */       }
/* 63 */     writer.addDocument(lucene_doc);
/*    */   }
/*    */ 
/*    */   public void indexBreakDownFolder(String folder) throws IOException {
/* 67 */     File dir = new File(folder);
/* 68 */     File[] files = dir.listFiles();
/* 69 */     int count = 0;
/* 70 */     for (File f : files) {
/* 71 */       if (f.isDirectory())
/* 72 */         indexBreakDownFolder(f.getAbsolutePath());
/* 73 */       if (f.getName().endsWith(".json"))
/*    */       {
/* 75 */         System.out.println("Processing " + f.getAbsolutePath());
/* 76 */         indexBreakDownDoc(new BreakDownDoc(f.getAbsolutePath()));
/* 77 */         count++;
/*    */       }
/*    */     }
/* 79 */     System.out.println(count + " files are indexed");
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws IOException {
/* 83 */     LuceneIndexer indexer = new LuceneIndexer();
/*    */ 
/* 87 */     indexer.indexBreakDownFolder(args[0]);
/* 88 */     indexer.closeIndexWriter();
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     com.yunsichuangzhi.lucene.LuceneIndexer
 * JD-Core Version:    0.6.2
 */