/*     */ package com.yunsichuangzhi.lucene;
/*     */ 
/*     */ import java.io.FileReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONObject;
/*     */ import org.json.simple.parser.JSONParser;
/*     */ 
/*     */ public class BreakDownDoc
/*     */ {
/*     */   public static List<String> fields;
/*     */   public static List<FIELD_TYPE> fieldTypes;
/*  26 */   public Map<String, String> values = new HashMap();
/*     */   public static Map<String, FIELD_TYPE> types;
/*     */ 
/*     */   static
/*     */   {
/*  17 */     fields = new ArrayList(Arrays.asList(new String[] { 
/*  18 */       "fileName", "savedJsonName", "title", "codeNo", "downtimeDate", "equipName", 
/*  19 */       "breakdownTime", "areaLocation", "maintainTeam", "lostTime", "lostProductNum", "plantName", "originator", "rootCause", 
/*  20 */       "person_TL", "person_ENG", "person_GL", "person_Manager", "faultDesc" }));
/*  21 */     fieldTypes = new ArrayList(Arrays.asList(
/*  22 */       new FIELD_TYPE[] { FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.TEXT, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, 
/*  23 */       FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.TEXT, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.TEXT, 
/*  24 */       FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.VALUE, FIELD_TYPE.TEXT }));
/*     */ 
/*  27 */     types = new HashMap();
/*     */ 
/*  29 */     assert (fields.size() == fieldTypes.size());
/*  30 */     for (int i = 1; i <= 7; i++) {
/*  31 */       fields.add("troubleShooting_" + i + "_" + "descr");
/*  32 */       fieldTypes.add(FIELD_TYPE.TEXT);
/*  33 */       fields.add("troubleShooting_" + i + "_" + "lostMin");
/*  34 */       fieldTypes.add(FIELD_TYPE.VALUE);
/*  35 */       fields.add("troubleShooting_" + i + "_" + "success");
/*  36 */       fieldTypes.add(FIELD_TYPE.VALUE);
/*     */     }
/*  38 */     for (int i = 1; i <= 2; i++) {
/*  39 */       String prefix = i == 1 ? "shortTerm_" : "longTerm_";
/*  40 */       for (int j = 1; j <= 4; j++) {
/*  41 */         fields.add(prefix + j + "_" + "counterMeasure");
/*  42 */         fieldTypes.add(FIELD_TYPE.TEXT);
/*  43 */         fields.add(prefix + j + "_" + "resp");
/*  44 */         fieldTypes.add(FIELD_TYPE.TEXT);
/*  45 */         fields.add(prefix + j + "_" + "supp");
/*  46 */         fieldTypes.add(FIELD_TYPE.TEXT);
/*  47 */         fields.add(prefix + j + "_" + "compDate");
/*  48 */         fieldTypes.add(FIELD_TYPE.TEXT);
/*  49 */         fields.add(prefix + j + "_" + "status");
/*  50 */         fieldTypes.add(FIELD_TYPE.TEXT);
/*     */       }
/*     */     }
/*  53 */     for (int i = 1; i <= 5; i++) {
/*  54 */       fields.add("why_" + i);
/*  55 */       fieldTypes.add(FIELD_TYPE.TEXT);
/*     */     }
/*  57 */     for (int i = 0; i < fields.size(); i++)
/*  58 */       types.put((String)fields.get(i), (FIELD_TYPE)fieldTypes.get(i));
/*     */   }
/*     */ 
/*     */   public BreakDownDoc()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BreakDownDoc(String file) {
/*  66 */     loadFromJson(file);
/*     */   }
/*     */ 
/*     */   public void loadFromJson(String file) {
/*  70 */     JSONParser parser = new JSONParser();
/*     */     try {
/*  72 */       Object obj = parser.parse(new FileReader(file));
/*  73 */       JSONObject root = (JSONObject)obj;
/*     */ 
/*  75 */       this.values.put("fileName", (String)root.get("fileName"));
/*  76 */       this.values.put("savedJsonName", (String)root.get("savedJsonName"));
/*  77 */       this.values.put("title", (String)root.get("title"));
/*  78 */       this.values.put("codeNo", (String)root.get("codeNo"));
/*  79 */       this.values.put("downtimeDate", (String)root.get("downtimeDate"));
/*  80 */       this.values.put("equipName", ((String)root.get("equipName")).replace("设备名称:", "").trim());
/*  81 */       this.values.put("breakdownTime", Long.valueOf(getNumber(((String)root.get("breakdownTime")).replace("设备名称:", "").trim())).toString());
/*  82 */       this.values.put("areaLocation", ((String)root.get("areaLocation")).replace("停机区域/点:", "").trim());
/*  83 */       this.values.put("maintainTeam", ((String)root.get("maintainTeam")).replace("维修班组", "").trim());
/*  84 */       this.values.put("lostTime", Long.valueOf(getNumber(((String)root.get("lostTime")).replace("NONE", "0").trim())).toString());
/*  85 */       this.values.put("lostProductNum", Long.valueOf(getNumber(((String)root.get("lostProductNum")).replace("NONE", "0").trim())).toString());
/*  86 */       this.values.put("plantName", ((String)root.get("plantName")).replace("厂区：", "").replace("Plant", "").trim());
/*  87 */       this.values.put("originator", ((String)root.get("originator")).replace("填表人/日期:", "").replace("Oringinator", "").trim());
/*  88 */       this.values.put("rootCause", (String)root.get("rootCause"));
/*  89 */       this.values.put("person_TL", ((String)root.get("person_TL")).replace("班组长/TL", "").replace(":", "").replace("签名及日期 /Signature & Date:", "").trim());
/*  90 */       this.values.put("person_ENG", ((String)root.get("person_ENG")).replace("工程师/ENG.:", "").trim());
/*  91 */       this.values.put("person_GL", ((String)root.get("person_GL")).replace("班组长/TL：", "").replace("工段长/ GL:", "").trim());
/*  92 */       this.values.put("person_Manager", ((String)root.get("person_Manager")).replace("工程师/ENG.:", "").replace("技术经理/Tech.Manager.:", "").trim());
/*     */ 
/*  95 */       JSONArray troubleShooting = (JSONArray)root.get("troubleShooting");
/*  96 */       Iterator troubleShootingIter = troubleShooting.iterator();
/*  97 */       while (troubleShootingIter.hasNext()) {
/*  98 */         JSONArray troubleArray = (JSONArray)troubleShootingIter.next();
/*  99 */         JSONObject trouble = (JSONObject)troubleArray.iterator().next();
/* 100 */         long step = getNumber(trouble.get("step"));
/* 101 */         String prefix = "troubleShooting_" + step + "_";
/* 102 */         String descr = (String)trouble.get("descr");
/* 103 */         this.values.put(prefix + "descr", descr);
/* 104 */         long lostMin = getNumber(trouble.get("lostMin"));
/* 105 */         this.values.put(prefix + "lostMin", Long.valueOf(lostMin).toString());
/* 106 */         boolean success = getBoolean(trouble.get("success"));
/* 107 */         this.values.put(prefix + "success", success ? "true" : "false");
/*     */       }
/*     */ 
/* 110 */       JSONArray faultDescription = (JSONArray)root.get("faultDescription");
/* 111 */       Iterator faultDescriptionIter = faultDescription.iterator();
/* 112 */       String faultDesc = "";
/* 113 */       while (faultDescriptionIter.hasNext()) {
/* 114 */         JSONArray falutArray = (JSONArray)faultDescriptionIter.next();
/* 115 */         faultDesc = faultDesc + (String)falutArray.iterator().next();
/*     */       }
/*     */ 
/* 118 */       this.values.put("faultDesc", faultDesc);
/*     */ 
/* 120 */       JSONArray fiveWhy = (JSONArray)root.get("fiveWhy");
/* 121 */       Iterator fiveWhyIter = fiveWhy.iterator();
/* 122 */       int countWhy = 0;
/* 123 */       while (fiveWhyIter.hasNext()) {
/* 124 */         JSONArray whyArray = (JSONArray)fiveWhyIter.next();
/* 125 */         String why = (String)whyArray.iterator().next();
/* 126 */         countWhy++;
/* 127 */         this.values.put("why_" + countWhy, why);
/*     */       }
/*     */ 
/* 130 */       loadShortOrLongTerm((JSONArray)root.get("shortTerm"), true);
/* 131 */       loadShortOrLongTerm((JSONArray)root.get("longTerm"), false);
/*     */ 
/* 133 */       JSONArray correctPath = (JSONArray)root.get("correctPath");
/* 134 */       Iterator correctPathIter = correctPath.iterator();
/* 135 */       while (correctPathIter.hasNext()) {
/* 136 */         JSONArray correctArray = (JSONArray)correctPathIter.next();
/* 137 */         JSONObject correct = (JSONObject)correctArray.iterator().next();
/* 138 */         long step = getNumber(correct.get("step"));
/* 139 */         String descr = (String)correct.get("descr");
/* 140 */         String prefix = "correctPath_" + step + "_";
/* 141 */         this.values.put(prefix + "descr", descr);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 145 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean getBoolean(Object v) {
/* 150 */     if ((v instanceof Long)) {
/* 151 */       return ((Long)v).longValue() == 0L;
/*     */     }
/* 153 */     String strV = ((String)v).trim();
/* 154 */     if ((strV.isEmpty()) || (strV.equals("O")))
/* 155 */       return true;
/* 156 */     if (strV.equals("X"))
/* 157 */       return false;
/* 158 */     return true;
/*     */   }
/*     */ 
/*     */   protected String getString(Object v) {
/* 162 */     if ((v instanceof Long)) {
/* 163 */       return ((Long)v).toString();
/*     */     }
/* 165 */     return (String)v;
/*     */   }
/*     */ 
/*     */   protected long getNumber(Object v) {
/* 169 */     if ((v instanceof Long)) {
/* 170 */       long step = ((Long)v).longValue();
/* 171 */       return step;
/*     */     }
/* 173 */     String strV = ((String)v).trim();
/* 174 */     if ((!strV.isEmpty()) && (strV.charAt(0) == '"') && (strV.charAt(strV.length() - 1) == '"'))
/* 175 */       strV = strV.substring(1, strV.length() - 1).trim();
/* 176 */     if ((strV.length() > 3) && (strV.endsWith("min")))
/* 177 */       strV = strV.substring(0, strV.length() - 3).trim();
/* 178 */     if ((strV.length() > 2) && (strV.startsWith("累计")))
/* 179 */       strV = strV.substring(2);
/* 180 */     if ((strV.isEmpty()) || (strV.equals("O")))
/* 181 */       return 0L;
/*     */     try
/*     */     {
/* 184 */       return Integer.parseInt(strV); } catch (NumberFormatException e) {
/*     */     }
/* 186 */     return 0L;
/*     */   }
/*     */ 
/*     */   protected void loadShortOrLongTerm(JSONArray term, boolean shortTerm)
/*     */   {
/* 192 */     Iterator termIter = term.iterator();
/* 193 */     int count = 0;
/* 194 */     String prefix = shortTerm ? "shortTerm_" : "longTerm_";
/* 195 */     while (termIter.hasNext()) {
/* 196 */       JSONArray termArray = (JSONArray)termIter.next();
/* 197 */       JSONObject shortT = (JSONObject)termArray.iterator().next();
/* 198 */       count++;
/* 199 */       this.values.put(prefix + count + "_" + "counterMeasure", (String)shortT.get("counterMeasure"));
/* 200 */       this.values.put(prefix + count + "_" + "resp", (String)shortT.get("resp"));
/* 201 */       this.values.put(prefix + count + "_" + "supp", (String)shortT.get("supp"));
/* 202 */       this.values.put(prefix + count + "_" + "compDate", Long.valueOf(getNumber(shortT.get("compDate"))).toString());
/* 203 */       this.values.put(prefix + count + "_" + "status", (String)shortT.get("status"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 208 */     BreakDownDoc test = new BreakDownDoc("/Users/yangyu/Documents/my/doc/self/com/sparesData/jsonv2/2011ESI20.json");
/*     */   }
/*     */ 
/*     */   public static enum FIELD_TYPE
/*     */   {
/*  16 */     TEXT, VALUE;
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     com.yunsichuangzhi.lucene.BreakDownDoc
 * JD-Core Version:    0.6.2
 */