/*     */ package com.yunsichuangzhi.lucene;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.cli.CommandLine;
/*     */ import org.apache.commons.cli.CommandLineParser;
/*     */ import org.apache.commons.cli.DefaultParser;
/*     */ import org.apache.commons.cli.Options;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*     */ import org.apache.lucene.document.Document;
/*     */ import org.apache.lucene.index.DirectoryReader;
/*     */ import org.apache.lucene.index.IndexReader;
/*     */ import org.apache.lucene.index.IndexableField;
/*     */ import org.apache.lucene.index.MultiReader;
/*     */ import org.apache.lucene.index.Term;
/*     */ import org.apache.lucene.search.BooleanClause.Occur;
/*     */ import org.apache.lucene.search.BooleanQuery;
/*     */ import org.apache.lucene.search.IndexSearcher;
/*     */ import org.apache.lucene.search.ScoreDoc;
/*     */ import org.apache.lucene.search.TermQuery;
/*     */ import org.apache.lucene.search.TopDocs;
/*     */ import org.apache.lucene.store.Directory;
/*     */ import org.apache.lucene.store.FSDirectory;
/*     */ 
/*     */ public class LuceneQuery
/*     */ {
/*  41 */   static IndexReader indexReader = null;
/*  42 */   static IndexSearcher storeSearcher = null;
/*     */   static String FIELD_DOC;
/*     */   static int skipSize;
/*  45 */   final Analyzer searcherAnalyzer = Util.getChineseAnalyzer();
/*  46 */   final int MAX_NUM_RESULTS = 100;
/*     */ 
/*  84 */   private static final FileFilter dirFilter = new FileFilter() {
/*  85 */     public boolean accept(File path) { return path.isDirectory(); }
/*     */ 
/*  84 */   };
/*     */ 
/*     */   public LuceneQuery(String storePath, String fieldDoc, int skip)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  53 */       indexReader = getReader(getIndexSetForDirs(storePath));
/*  54 */       storeSearcher = new IndexSearcher(indexReader);
/*  55 */       FIELD_DOC = fieldDoc;
/*  56 */       skipSize = skip;
/*     */     } catch (IOException e) {
/*  58 */       System.err.println(e.getMessage());
/*  59 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Set<File> getIndexSetForDirs(String dir)
/*     */     throws IOException
/*     */   {
/*  69 */     Set set = new HashSet();
/*  70 */     File root = new File(dir);
/*  71 */     Directory ld = FSDirectory.open(root);
/*     */     try {
/*  73 */       if (DirectoryReader.indexExists(ld)) { set.add(root);
/*     */       } else {
/*  75 */         File[] subdirs = root.listFiles(dirFilter);
/*  76 */         if (subdirs != null) for (File f2 : subdirs) set.add(f2);  
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*  79 */       ld.close();
/*     */     }
/*  81 */     return set;
/*     */   }
/*     */ 
/*     */   public static IndexReader getReader(File index)
/*     */     throws IOException
/*     */   {
/*  89 */     FSDirectory dir = FSDirectory.open(index);
/*  90 */     return DirectoryReader.open(dir);
/*     */   }
/*     */ 
/*     */   public static IndexReader getReader(Set<File> indices)
/*     */     throws IOException
/*     */   {
/*  97 */     if (indices.size() == 1) return getReader((File)indices.iterator().next());
/*  98 */     IndexReader[] indexReaders = new IndexReader[indices.size()];
/*  99 */     int i = 0;
/*     */     File index;
/* 100 */     for (Iterator localIterator = indices.iterator(); localIterator.hasNext(); indexReaders[(i++)] = getReader(index)) index = (File)localIterator.next();
/* 101 */     return new MultiReader(indexReaders, false);
/*     */   }
/*     */ 
/*     */   protected List<String> searchTokens(Set<String> tokens, String field, List<List<String>> keyWordGroups, int num) throws IOException {
/* 105 */     if (((keyWordGroups == null) || (keyWordGroups.isEmpty())) && (tokens.isEmpty()))
/* 106 */       return null;
/* 107 */     BooleanQuery booleanQuery = buildMultTermQuery(tokens, field, keyWordGroups, num);
/* 108 */     TopDocs hits = storeSearcher.search(booleanQuery, num);
/* 109 */     List rs = new ArrayList();
/* 110 */     for (ScoreDoc d : hits.scoreDocs) {
/* 111 */       rs.add(getBreakDown(d.doc));
/*     */     }
/* 113 */     return rs;
/*     */   }
/*     */ 
/*     */   protected BooleanQuery buildMultTermQuery(Set<String> tokens, String field, List<List<String>> keyWordGroups, int num) throws IOException {
/* 117 */     BooleanQuery booleanQuery = new BooleanQuery();
/*     */     TermQuery tq;
/* 118 */     if ((keyWordGroups != null) && (!keyWordGroups.isEmpty()))
/*     */     {
/* 133 */       for (int i = 0; i < keyWordGroups.size(); i++) {
/* 134 */         tq = buildTermQuery((String)((List)keyWordGroups.get(i)).get(0), field);
/* 135 */         booleanQuery.add(tq, BooleanClause.Occur.SHOULD);
/*     */       }
/*     */     }
/* 138 */     if (!tokens.isEmpty()) {
/* 139 */       for (String token : tokens) {
/* 140 */         TermQuery tq = buildTermQuery(token, field);
/* 141 */         booleanQuery.add(tq, BooleanClause.Occur.SHOULD);
/*     */       }
/*     */     }
/* 144 */     return booleanQuery;
/*     */   }
/*     */ 
/*     */   protected TermQuery buildTermQuery(String token, String field) throws IOException {
/* 148 */     TokenStream ts = this.searcherAnalyzer.tokenStream(field, new StringReader(token));
/* 149 */     ts.reset();
/* 150 */     CharTermAttribute cta = (CharTermAttribute)ts.addAttribute(CharTermAttribute.class);
/* 151 */     ts.incrementToken();
/* 152 */     Term term = new Term(field, cta.toString());
/* 153 */     ts.end();
/* 154 */     ts.close();
/* 155 */     TermQuery tq = new TermQuery(term, 2);
/* 156 */     return tq;
/*     */   }
/*     */ 
/*     */   protected BooleanQuery buildMultFieldsQuery(List<String> values, List<String> fields) throws IOException {
/* 160 */     BooleanQuery booleanQuery = new BooleanQuery();
/* 161 */     for (int j = 0; j < values.size(); j++) {
/* 162 */       BooleanQuery orQuery = new BooleanQuery();
/* 163 */       for (int i = 0; i < fields.size(); i++) {
/* 164 */         if (BreakDownDoc.types.get(fields.get(i)) == BreakDownDoc.FIELD_TYPE.TEXT) {
/* 165 */           Set words = new HashSet(Util.getUnigramsFromString(Util.tokenEnglish((String)values.get(i))));
/* 166 */           BooleanQuery q = buildMultTermQuery(words, (String)fields.get(i), null, 100);
/* 167 */           orQuery.add(q, BooleanClause.Occur.SHOULD);
/*     */         } else {
/* 169 */           TermQuery q = buildValueQuery((String)values.get(i), (String)fields.get(i));
/* 170 */           orQuery.add(q, BooleanClause.Occur.SHOULD);
/*     */         }
/*     */       }
/* 173 */       booleanQuery.add(orQuery, BooleanClause.Occur.MUST);
/*     */     }
/* 175 */     return booleanQuery;
/*     */   }
/*     */ 
/*     */   protected String getBreakDown(int docId) {
/* 179 */     Document d = null;
/*     */     try {
/* 181 */       d = indexReader.document(docId);
/*     */     } catch (IOException e) {
/* 183 */       e.printStackTrace();
/*     */     }
/* 185 */     if (d != null) {
/* 186 */       String v = d.getField(FIELD_DOC).stringValue();
/* 187 */       if (BreakDownDoc.types.get(FIELD_DOC) == BreakDownDoc.FIELD_TYPE.TEXT) {
/* 188 */         return Util.recoverDigit(v);
/*     */       }
/* 190 */       return v;
/*     */     }
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */   public TermQuery buildValueQuery(String v, String field) {
/* 196 */     Term term = new Term(field, v);
/* 197 */     TermQuery vq = new TermQuery(term, 2);
/* 198 */     return vq;
/*     */   }
/*     */ 
/*     */   public List<String> searchOnText(String q, String field)
/*     */   {
/* 203 */     List rs = null;
/*     */     try {
/* 205 */       Set words = new HashSet(Util.getUnigramsFromString(q));
/*     */ 
/* 207 */       List keyWordGroups = new ArrayList();
/* 208 */       for (List keywords : keyWordGroups) {
/* 209 */         words.remove(keywords.get(0));
/*     */       }
/* 211 */       rs = searchTokens(words, field, keyWordGroups, 100);
/*     */     }
/*     */     catch (IOException e) {
/* 214 */       e.printStackTrace();
/*     */     }
/* 216 */     if ((rs != null) && (rs.size() > 0)) {
/* 217 */       return rs;
/*     */     }
/* 219 */     return null;
/*     */   }
/*     */ 
/*     */   public List<String> search(List<String> values, List<String> fields, int num) throws IOException {
/* 223 */     BooleanQuery booleanQuery = buildMultFieldsQuery(values, fields);
/* 224 */     TopDocs hits = storeSearcher.search(booleanQuery, num);
/* 225 */     List rs = new ArrayList();
/* 226 */     for (ScoreDoc d : hits.scoreDocs) {
/* 227 */       rs.add(getBreakDown(d.doc));
/*     */     }
/* 229 */     return rs;
/*     */   }
/*     */ 
/*     */   public static boolean checkFields(List<String> fields) {
/* 233 */     for (String f : fields) {
/* 234 */       if (!BreakDownDoc.fields.contains(f)) {
/* 235 */         System.err.println("Unrecognized field " + f);
/* 236 */         System.err.println("All known fields are " + BreakDownDoc.fields.toString());
/* 237 */         return false;
/*     */       }
/*     */     }
/* 240 */     return true;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws IOException, org.apache.lucene.queryparser.classic.ParseException, org.apache.commons.cli.ParseException {
/* 244 */     Options options = new Options();
/* 245 */     options.addOption("fields", true, "specifiy the list of fields to search");
/* 246 */     options.addOption("values", true, "specifiy the list of values to search");
/* 247 */     options.addOption("return", true, "specifiy the field to return, default is fileName");
/* 248 */     options.addOption("max", true, "specifiy the max number of records to return, default is 10");
/* 249 */     CommandLineParser parser = new DefaultParser();
/* 250 */     CommandLine cmd = parser.parse(options, args);
/* 251 */     String fieldsStr = cmd.getOptionValue("fields");
/* 252 */     String valuesStr = cmd.getOptionValue("values");
/* 253 */     List fields = Arrays.asList(fieldsStr.split(","));
/* 254 */     List values = Arrays.asList(valuesStr.split(","));
/* 255 */     fieldsStr = cmd.getOptionValue("fields");
/* 256 */     if (!checkFields(fields))
/* 257 */       return;
/* 258 */     String returnField = "fileName";
/* 259 */     if (cmd.hasOption("return")) {
/* 260 */       returnField = cmd.getOptionValue("return");
/*     */     }
/* 262 */     int maxReturn = 10;
/* 263 */     if (cmd.hasOption("max")) {
/* 264 */       maxReturn = Integer.parseInt(cmd.getOptionValue("max"));
/*     */     }
/* 266 */     LuceneQuery exe = new LuceneQuery("resources/index/", returnField, maxReturn);
/* 267 */     List rs = exe.search(values, fields, maxReturn);
/* 268 */     for (String r : rs)
/* 269 */       System.out.println(r);
/*     */   }
/*     */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     com.yunsichuangzhi.lucene.LuceneQuery
 * JD-Core Version:    0.6.2
 */