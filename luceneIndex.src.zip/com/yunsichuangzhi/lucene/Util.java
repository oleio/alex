/*    */ package com.yunsichuangzhi.lucene;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.StringReader;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.lucene.analysis.Analyzer;
/*    */ import org.apache.lucene.analysis.TokenStream;
/*    */ import org.apache.lucene.analysis.cn.smart.SmartChineseAnalyzer;
/*    */ import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
/*    */ import org.apache.lucene.util.Version;
/*    */ 
/*    */ public class Util
/*    */ {
/* 17 */   public static final Version LUCENE_VERSION = Version.LUCENE_48;
/*    */ 
/*    */   protected static Analyzer getChineseAnalyzer() {
/* 20 */     Analyzer analyzer = new SmartChineseAnalyzer(LUCENE_VERSION);
/* 21 */     return analyzer;
/*    */   }
/*    */ 
/*    */   public static List<String> getUnigramsFromString(String question) throws IOException
/*    */   {
/* 26 */     List response = new ArrayList();
/*    */ 
/* 29 */     Analyzer analyzer = getChineseAnalyzer();
/*    */ 
/* 31 */     TokenStream stream = analyzer.tokenStream(null, new StringReader(question));
/* 32 */     CharTermAttribute cta = (CharTermAttribute)stream.addAttribute(CharTermAttribute.class);
/* 33 */     stream.reset();
/* 34 */     while (stream.incrementToken()) {
/* 35 */       String analyzedText = cta.toString();
/* 36 */       response.add(analyzedText);
/*    */     }
/* 38 */     stream.close();
/* 39 */     analyzer.close();
/*    */ 
/* 41 */     return response;
/*    */   }
/*    */ 
/*    */   public static String tokenEnglish(String text) {
/* 45 */     Pattern p = Pattern.compile("[a-zA-Z]*([0-9]*)[a-zA-Z]*");
/* 46 */     Matcher m = p.matcher(text);
/* 47 */     String newText = "";
/* 48 */     int lastEnd = 0;
/* 49 */     if (m.find()) {
/* 50 */       while (m.find()) {
/* 51 */         String n = m.group(1);
/* 52 */         if (!n.isEmpty())
/*    */         {
/* 54 */           newText = newText + text.substring(lastEnd, m.start(1));
/* 55 */           newText = newText + replaceDigit(n);
/* 56 */           lastEnd = m.end(1);
/*    */         }
/*    */       }
/* 58 */       newText = newText + text.substring(lastEnd);
/* 59 */       return newText;
/*    */     }
/* 61 */     return text;
/*    */   }
/*    */ 
/*    */   public static String replaceDigit(String digits) {
/* 65 */     digits = digits.replaceAll("0", "zero");
/* 66 */     digits = digits.replaceAll("1", "one");
/* 67 */     digits = digits.replaceAll("2", "two");
/* 68 */     digits = digits.replaceAll("3", "three");
/* 69 */     digits = digits.replaceAll("4", "four");
/* 70 */     digits = digits.replaceAll("5", "five");
/* 71 */     digits = digits.replaceAll("6", "six");
/* 72 */     digits = digits.replaceAll("7", "seven");
/* 73 */     digits = digits.replaceAll("8", "eight");
/* 74 */     digits = digits.replaceAll("9", "nine");
/* 75 */     return digits;
/*    */   }
/*    */ 
/*    */   public static String recoverDigit(String digits) {
/* 79 */     digits = digits.replaceAll("zero", "0");
/* 80 */     digits = digits.replaceAll("one", "1");
/* 81 */     digits = digits.replaceAll("two", "2");
/* 82 */     digits = digits.replaceAll("three", "3");
/* 83 */     digits = digits.replaceAll("four", "4");
/* 84 */     digits = digits.replaceAll("five", "5");
/* 85 */     digits = digits.replaceAll("six", "6");
/* 86 */     digits = digits.replaceAll("seven", "7");
/* 87 */     digits = digits.replaceAll("eight", "8");
/* 88 */     digits = digits.replaceAll("nine", "9");
/* 89 */     return digits;
/*    */   }
/*    */ }

/* Location:           /media/f/e/studyworkspace/nodejsstudy/alex/luceneIndex.jar
 * Qualified Name:     com.yunsichuangzhi.lucene.Util
 * JD-Core Version:    0.6.2
 */